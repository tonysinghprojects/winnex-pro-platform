import { Link, useLocation } from "wouter";

export default function TestRouting() {
  const [location, setLocation] = useLocation();
  
  console.log('Current location:', location);
  
  return (
    <div className="p-8 bg-white text-black">
      <h1>Routing Test</h1>
      <p>Current location: {location}</p>
      
      <div className="space-y-4 mt-4">
        <div>
          <Link href="/sports" className="bg-blue-500 text-white px-4 py-2 rounded mr-4">
            Go to Sports
          </Link>
          <Link href="/casino" className="bg-green-500 text-white px-4 py-2 rounded mr-4">
            Go to Casino
          </Link>
          <Link href="/" className="bg-red-500 text-white px-4 py-2 rounded">
            Go to Home
          </Link>
        </div>
        
        <div>
          <button 
            onClick={() => setLocation('/sports')} 
            className="bg-purple-500 text-white px-4 py-2 rounded mr-4"
          >
            Navigate to Sports (programmatic)
          </button>
          <button 
            onClick={() => setLocation('/casino')} 
            className="bg-orange-500 text-white px-4 py-2 rounded"
          >
            Navigate to Casino (programmatic)
          </button>
        </div>
      </div>
    </div>
  );
}