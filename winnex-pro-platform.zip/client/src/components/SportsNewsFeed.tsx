import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clock, ExternalLink, TrendingUp, Users, Zap, BookOpen } from "lucide-react";

interface NewsArticle {
  id: string;
  title: string;
  summary: string;
  content: string;
  author: string;
  publishedAt: string;
  category: 'breaking' | 'analysis' | 'injury' | 'transfer' | 'match_preview';
  sport: string;
  tags: string[];
  imageUrl?: string;
  readTime: number;
  trending: boolean;
  reactions: {
    likes: number;
    shares: number;
    comments: number;
  };
  source: {
    name: string;
    logo: string;
    verified: boolean;
  };
}

interface MarketMovement {
  matchId: number;
  team: string;
  movement: 'up' | 'down';
  percentage: number;
  reason: string;
  timestamp: string;
}

export default function SportsNewsFeed() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [liveUpdates, setLiveUpdates] = useState(true);

  const { data: newsData, refetch } = useQuery({
    queryKey: ['/api/sports/news', selectedCategory],
    refetchInterval: liveUpdates ? 60000 : false, // Update every minute if live updates enabled
  });

  const { data: marketMovements } = useQuery({
    queryKey: ['/api/sports/market-movements'],
    refetchInterval: 30000, // Update every 30 seconds
  });

  // Mock data for demonstration
  const mockNews: NewsArticle[] = [
    {
      id: "1",
      title: "Chiefs Secure Playoff Spot with Dominant Win",
      summary: "Kansas City Chiefs clinch AFC West division with a commanding 31-14 victory over Denver Broncos",
      content: "The Kansas City Chiefs secured their playoff berth with a stellar performance...",
      author: "Mike Johnson",
      publishedAt: "2024-01-15T18:30:00Z",
      category: "breaking",
      sport: "Football",
      tags: ["NFL", "Playoffs", "Chiefs", "AFC West"],
      readTime: 3,
      trending: true,
      reactions: { likes: 1247, shares: 456, comments: 89 },
      source: { name: "ESPN", logo: "📺", verified: true }
    },
    {
      id: "2", 
      title: "Lakers Star Questionable for Tonight's Game",
      summary: "LeBron James listed as questionable with ankle injury ahead of crucial matchup",
      content: "Los Angeles Lakers superstar LeBron James is dealing with a minor ankle...",
      author: "Sarah Wilson",
      publishedAt: "2024-01-15T16:45:00Z",
      category: "injury",
      sport: "Basketball",
      tags: ["NBA", "Lakers", "LeBron James", "Injury Report"],
      readTime: 2,
      trending: false,
      reactions: { likes: 892, shares: 234, comments: 67 },
      source: { name: "The Athletic", logo: "🏀", verified: true }
    },
    {
      id: "3",
      title: "Manchester City Eyes Summer Transfer Target",
      summary: "Premier League champions reportedly preparing €80M bid for Brazilian midfielder",
      content: "Manchester City are set to make a significant move in the transfer market...",
      author: "David Rodriguez",
      publishedAt: "2024-01-15T14:20:00Z",
      category: "transfer",
      sport: "Soccer",
      tags: ["Premier League", "Man City", "Transfer", "Brazil"],
      readTime: 4,
      trending: true,
      reactions: { likes: 2156, shares: 892, comments: 234 },
      source: { name: "Sky Sports", logo: "⚽", verified: true }
    }
  ];

  const mockMovements: MarketMovement[] = [
    {
      matchId: 1,
      team: "Chiefs",
      movement: "up",
      percentage: 15,
      reason: "Key player return from injury",
      timestamp: "2024-01-15T18:00:00Z"
    },
    {
      matchId: 2,
      team: "Lakers",
      movement: "down",
      percentage: 8,
      reason: "Star player injury concern",
      timestamp: "2024-01-15T17:30:00Z"
    }
  ];

  const news = newsData || mockNews;
  const movements = marketMovements || mockMovements;

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'breaking': return '🚨';
      case 'analysis': return '📊';
      case 'injury': return '🏥';
      case 'transfer': return '↔️';
      case 'match_preview': return '👁️';
      default: return '📰';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'breaking': return 'bg-red-600';
      case 'analysis': return 'bg-blue-600';
      case 'injury': return 'bg-orange-600';
      case 'transfer': return 'bg-green-600';
      case 'match_preview': return 'bg-purple-600';
      default: return 'bg-gray-600';
    }
  };

  const timeAgo = (dateString: string) => {
    const now = new Date();
    const published = new Date(dateString);
    const diffMs = now.getTime() - published.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return published.toLocaleDateString();
  };

  return (
    <div className="space-y-6">
      <Card className="bg-winnex-dark border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-500" />
              Sports News Feed
            </CardTitle>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${liveUpdates ? 'bg-green-500 animate-pulse' : 'bg-gray-500'}`}></div>
              <span className="text-sm text-gray-400">
                {liveUpdates ? 'Live' : 'Paused'}
              </span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setLiveUpdates(!liveUpdates)}
                className="text-xs"
              >
                {liveUpdates ? 'Pause' : 'Resume'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="news" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800">
              <TabsTrigger value="news" className="text-white">Latest News</TabsTrigger>
              <TabsTrigger value="trending" className="text-white">Trending</TabsTrigger>
              <TabsTrigger value="movements" className="text-white">Market Moves</TabsTrigger>
            </TabsList>

            <TabsContent value="news" className="space-y-4">
              {/* Category Filter */}
              <div className="flex flex-wrap gap-2 mb-4">
                {['all', 'breaking', 'analysis', 'injury', 'transfer', 'match_preview'].map((category) => (
                  <Button
                    key={category}
                    size="sm"
                    variant={selectedCategory === category ? "default" : "outline"}
                    onClick={() => setSelectedCategory(category)}
                    className="capitalize"
                  >
                    {getCategoryIcon(category)} {category === 'all' ? 'All' : category.replace('_', ' ')}
                  </Button>
                ))}
              </div>

              {/* News Articles */}
              <div className="space-y-4">
                {news
                  .filter(article => selectedCategory === 'all' || article.category === selectedCategory)
                  .map((article) => (
                    <Card key={article.id} className="bg-gray-800 border-gray-600 hover:bg-gray-750 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          {/* Article Icon */}
                          <div className="text-2xl">
                            {getCategoryIcon(article.category)}
                          </div>
                          
                          {/* Article Content */}
                          <div className="flex-1 space-y-2">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-2 flex-wrap">
                                <Badge className={`${getCategoryColor(article.category)} text-white`}>
                                  {article.category.replace('_', ' ')}
                                </Badge>
                                <Badge variant="outline" className="text-gray-400">
                                  {article.sport}
                                </Badge>
                                {article.trending && (
                                  <Badge className="bg-orange-600 text-white animate-pulse">
                                    <TrendingUp className="w-3 h-3 mr-1" />
                                    Trending
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-2 text-xs text-gray-400">
                                <span>{article.source.logo}</span>
                                <span>{article.source.name}</span>
                                {article.source.verified && <span className="text-blue-400">✓</span>}
                              </div>
                            </div>

                            <h3 className="text-white font-semibold text-lg hover:text-winnex-green cursor-pointer">
                              {article.title}
                            </h3>
                            
                            <p className="text-gray-400 text-sm leading-relaxed">
                              {article.summary}
                            </p>

                            {/* Article Meta */}
                            <div className="flex items-center justify-between text-xs text-gray-500">
                              <div className="flex items-center gap-4">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {timeAgo(article.publishedAt)}
                                </span>
                                <span>{article.readTime} min read</span>
                                <span>By {article.author}</span>
                              </div>
                              
                              <div className="flex items-center gap-3">
                                <span className="flex items-center gap-1">
                                  👍 {article.reactions.likes}
                                </span>
                                <span className="flex items-center gap-1">
                                  📤 {article.reactions.shares}
                                </span>
                                <span className="flex items-center gap-1">
                                  💬 {article.reactions.comments}
                                </span>
                                <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                                  <ExternalLink className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>

                            {/* Tags */}
                            <div className="flex flex-wrap gap-1">
                              {article.tags.slice(0, 4).map((tag, index) => (
                                <span key={index} className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded">
                                  #{tag}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="trending" className="space-y-4">
              <div className="space-y-4">
                {news
                  .filter(article => article.trending)
                  .sort((a, b) => b.reactions.likes - a.reactions.likes)
                  .map((article, index) => (
                    <Card key={article.id} className="bg-gray-800 border-gray-600">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          <div className="text-2xl font-bold text-orange-500">
                            #{index + 1}
                          </div>
                          <div className="flex-1">
                            <h3 className="text-white font-semibold">{article.title}</h3>
                            <div className="flex items-center gap-4 text-sm text-gray-400 mt-1">
                              <span>{article.sport}</span>
                              <span>👍 {article.reactions.likes.toLocaleString()}</span>
                              <span>📤 {article.reactions.shares}</span>
                              <span>{timeAgo(article.publishedAt)}</span>
                            </div>
                          </div>
                          <TrendingUp className="w-5 h-5 text-orange-500 animate-bounce" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="movements" className="space-y-4">
              <div className="space-y-4">
                {movements.map((movement, index) => (
                  <Card key={index} className="bg-gray-800 border-gray-600">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${movement.movement === 'up' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                          {movement.movement === 'up' ? '📈' : '📉'}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="text-white font-semibold">{movement.team}</h3>
                            <Badge className={movement.movement === 'up' ? 'bg-green-600' : 'bg-red-600'}>
                              {movement.movement === 'up' ? '+' : '-'}{movement.percentage}%
                            </Badge>
                          </div>
                          <p className="text-gray-400 text-sm">{movement.reason}</p>
                          <span className="text-xs text-gray-500">{timeAgo(movement.timestamp)}</span>
                        </div>
                        <Zap className="w-5 h-5 text-yellow-500" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}