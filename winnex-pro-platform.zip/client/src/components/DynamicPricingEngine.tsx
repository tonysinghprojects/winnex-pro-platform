import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TrendingUp, TrendingDown, Target, Zap, Eye, BarChart3, Settings, DollarSign } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface CompetitorOdds {
  bookmaker: string;
  odds: number;
  margin: number;
  volume: number;
  lastUpdate: string;
  marketShare: number;
  ranking: number;
}

interface MarketCondition {
  sport: string;
  event: string;
  marketType: string;
  liquidity: number;
  volatility: number;
  timeToEvent: string;
  publicMoney: number;
  sharpMoney: number;
  steamMoves: number;
  conditions: 'normal' | 'high_volume' | 'low_liquidity' | 'steam_move' | 'closing_line';
}

interface PricingRule {
  id: string;
  name: string;
  sport: string;
  marketType: string;
  condition: string;
  baseMargin: number;
  dynamicAdjustment: number;
  maxMargin: number;
  minMargin: number;
  priority: number;
  active: boolean;
  triggers: Array<{
    metric: string;
    operator: string;
    value: number;
    adjustment: number;
  }>;
}

interface YieldOptimization {
  event: string;
  currentYield: number;
  optimizedYield: number;
  potentialIncrease: number;
  recommendedActions: Array<{
    action: string;
    impact: number;
    risk: string;
  }>;
  marketSegments: Array<{
    segment: string;
    elasticity: number;
    optimalPrice: number;
    expectedVolume: number;
  }>;
}

interface MLPrediction {
  model: string;
  accuracy: number;
  prediction: {
    optimalOdds: number;
    confidence: number;
    expectedVolume: number;
    profitability: number;
  };
  factors: Array<{
    name: string;
    importance: number;
    impact: 'positive' | 'negative';
  }>;
  backtestResults: {
    period: string;
    totalPredictions: number;
    accuracy: number;
    profitIncrease: number;
  };
}

export default function DynamicPricingEngine() {
  const [selectedSport, setSelectedSport] = useState<string>('football');
  const [selectedEvent, setSelectedEvent] = useState<string>('');
  const [autoOptimization, setAutoOptimization] = useState<boolean>(true);
  const queryClient = useQueryClient();

  const { data: competitorOdds } = useQuery({
    queryKey: ['/api/pricing/competitor-odds', selectedSport],
    queryFn: () => apiRequest(`/api/pricing/competitor-odds?sport=${selectedSport}`),
    refetchInterval: 5000, // Update every 5 seconds
  });

  const { data: marketConditions } = useQuery({
    queryKey: ['/api/pricing/market-conditions'],
    queryFn: () => apiRequest('/api/pricing/market-conditions'),
    refetchInterval: 10000,
  });

  const { data: pricingRules } = useQuery({
    queryKey: ['/api/pricing/rules'],
    queryFn: () => apiRequest('/api/pricing/rules'),
  });

  const { data: yieldOptimization } = useQuery({
    queryKey: ['/api/pricing/yield-optimization', selectedEvent],
    queryFn: () => apiRequest(`/api/pricing/yield-optimization?event=${selectedEvent}`),
    enabled: !!selectedEvent,
  });

  const { data: mlPredictions } = useQuery({
    queryKey: ['/api/pricing/ml-predictions', selectedSport],
    queryFn: () => apiRequest(`/api/pricing/ml-predictions?sport=${selectedSport}`),
    refetchInterval: 30000,
  });

  const updatePricingRuleMutation = useMutation({
    mutationFn: (data: Partial<PricingRule>) =>
      apiRequest('/api/pricing/update-rule', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pricing/rules'] });
    },
  });

  const applyOptimizationMutation = useMutation({
    mutationFn: (data: { event: string; optimizations: any[] }) =>
      apiRequest('/api/pricing/apply-optimization', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pricing/yield-optimization'] });
    },
  });

  const enableAutoOptimizationMutation = useMutation({
    mutationFn: (enabled: boolean) =>
      apiRequest('/api/pricing/auto-optimization', 'POST', { enabled }),
  });

  const getMarginColor = (margin: number) => {
    if (margin < 3) return 'text-red-400 bg-red-500/20';
    if (margin < 5) return 'text-yellow-400 bg-yellow-500/20';
    if (margin < 7) return 'text-green-400 bg-green-500/20';
    return 'text-blue-400 bg-blue-500/20';
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'steam_move': return 'bg-red-500/20 text-red-400';
      case 'high_volume': return 'bg-green-500/20 text-green-400';
      case 'low_liquidity': return 'bg-yellow-500/20 text-yellow-400';
      default: return 'bg-blue-500/20 text-blue-400';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Dynamic Pricing Engine</h1>
              <p className="text-slate-300">Real-time odds optimization with AI-powered competitor intelligence</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button
                variant={autoOptimization ? 'default' : 'outline'}
                onClick={() => {
                  setAutoOptimization(!autoOptimization);
                  enableAutoOptimizationMutation.mutate(!autoOptimization);
                }}
                className="flex items-center space-x-2"
              >
                <Zap className={`h-4 w-4 ${autoOptimization ? 'animate-pulse' : ''}`} />
                <span>{autoOptimization ? 'Auto-Optimization ON' : 'Manual Mode'}</span>
              </Button>
            </div>
          </div>
        </div>

        {/* Pricing Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/20 border-green-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Yield Increase</p>
                  <p className="text-3xl font-bold text-white">+18.4%</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-blue-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 text-sm font-medium">Avg Margin</p>
                  <p className="text-3xl font-bold text-white">5.8%</p>
                </div>
                <BarChart3 className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-purple-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-400 text-sm font-medium">ML Accuracy</p>
                  <p className="text-3xl font-bold text-white">92.1%</p>
                </div>
                <Target className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-yellow-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-400 text-sm font-medium">Price Updates</p>
                  <p className="text-3xl font-bold text-white">2,847</p>
                </div>
                <Settings className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="competitor" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="competitor" className="data-[state=active]:bg-green-500/20">
              Competitor Intelligence
            </TabsTrigger>
            <TabsTrigger value="conditions" className="data-[state=active]:bg-green-500/20">
              Market Conditions
            </TabsTrigger>
            <TabsTrigger value="rules" className="data-[state=active]:bg-green-500/20">
              Pricing Rules
            </TabsTrigger>
            <TabsTrigger value="optimization" className="data-[state=active]:bg-green-500/20">
              Yield Optimization
            </TabsTrigger>
            <TabsTrigger value="ml" className="data-[state=active]:bg-green-500/20">
              ML Predictions
            </TabsTrigger>
          </TabsList>

          <TabsContent value="competitor" className="space-y-6">
            <div className="flex justify-between items-center">
              <Select value={selectedSport} onValueChange={setSelectedSport}>
                <SelectTrigger className="w-48 bg-slate-800/50 border-slate-600">
                  <SelectValue placeholder="Select sport" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="football">Football</SelectItem>
                  <SelectItem value="basketball">Basketball</SelectItem>
                  <SelectItem value="soccer">Soccer</SelectItem>
                  <SelectItem value="tennis">Tennis</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex items-center space-x-2 text-slate-400 text-sm">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span>Live competitor monitoring</span>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {competitorOdds?.map((competitor: CompetitorOdds, index: number) => (
                <Card key={index} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-sm">
                            #{competitor.ranking}
                          </span>
                        </div>
                        <div>
                          <h3 className="text-white font-bold">{competitor.bookmaker}</h3>
                          <p className="text-slate-400 text-sm">Market Share: {competitor.marketShare}%</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-white">{competitor.odds.toFixed(2)}</p>
                        <Badge className={getMarginColor(competitor.margin)}>
                          {competitor.margin.toFixed(1)}% margin
                        </Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Volume</p>
                        <p className="text-white font-bold">${competitor.volume.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Last Update</p>
                        <p className="text-white">{new Date(competitor.lastUpdate).toLocaleTimeString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Position</p>
                        <div className="flex items-center space-x-1">
                          {competitor.ranking <= 3 ? (
                            <TrendingUp className="h-4 w-4 text-green-400" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-red-400" />
                          )}
                          <span className="text-white">#{competitor.ranking}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="conditions" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {marketConditions?.map((condition: MarketCondition, index: number) => (
                <Card key={index} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle className="text-white">{condition.event}</CardTitle>
                        <p className="text-slate-400">{condition.sport} • {condition.marketType}</p>
                      </div>
                      <Badge className={getConditionColor(condition.conditions)}>
                        {condition.conditions.replace('_', ' ')}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Liquidity</p>
                        <div className="flex items-center space-x-2">
                          <p className="text-white font-bold">${condition.liquidity.toLocaleString()}</p>
                          <Progress value={(condition.liquidity / 1000000) * 100} className="h-2 flex-1" />
                        </div>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Volatility</p>
                        <div className="flex items-center space-x-2">
                          <p className="text-white font-bold">{condition.volatility.toFixed(1)}%</p>
                          <Progress value={condition.volatility} className="h-2 flex-1" />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-600">
                      <div className="text-center">
                        <p className="text-slate-400 text-sm">Public Money</p>
                        <p className="text-blue-400 font-bold">{condition.publicMoney}%</p>
                      </div>
                      <div className="text-center">
                        <p className="text-slate-400 text-sm">Sharp Money</p>
                        <p className="text-green-400 font-bold">{condition.sharpMoney}%</p>
                      </div>
                      <div className="text-center">
                        <p className="text-slate-400 text-sm">Steam Moves</p>
                        <p className="text-red-400 font-bold">{condition.steamMoves}</p>
                      </div>
                    </div>

                    <div className="text-center">
                      <p className="text-slate-400 text-sm">Time to Event</p>
                      <p className="text-white font-bold">{condition.timeToEvent}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="rules" className="space-y-6">
            <div className="space-y-4">
              {pricingRules?.map((rule: PricingRule) => (
                <Card key={rule.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-white font-bold text-lg">{rule.name}</h3>
                        <p className="text-slate-400">{rule.sport} • {rule.marketType}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={`${
                          rule.priority === 1 ? 'bg-red-500/20 text-red-400' :
                          rule.priority <= 3 ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-green-500/20 text-green-400'
                        }`}>
                          Priority {rule.priority}
                        </Badge>
                        <Button
                          size="sm"
                          variant={rule.active ? 'default' : 'outline'}
                          onClick={() => updatePricingRuleMutation.mutate({
                            ...rule,
                            active: !rule.active
                          })}
                          className={rule.active ? 'bg-green-500/20 text-green-400' : 'border-gray-500/20 text-gray-400'}
                        >
                          {rule.active ? 'Active' : 'Inactive'}
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-slate-400 text-sm">Base Margin</p>
                        <p className="text-white font-bold">{rule.baseMargin}%</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Dynamic Adj.</p>
                        <p className="text-blue-400 font-bold">±{rule.dynamicAdjustment}%</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Min Margin</p>
                        <p className="text-green-400 font-bold">{rule.minMargin}%</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Max Margin</p>
                        <p className="text-red-400 font-bold">{rule.maxMargin}%</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">Triggers</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {rule.triggers.map((trigger, index) => (
                          <div key={index} className="p-2 bg-slate-800/30 rounded text-sm">
                            <span className="text-white">{trigger.metric} {trigger.operator} {trigger.value}</span>
                            <span className="text-green-400 ml-2">→ {trigger.adjustment > 0 ? '+' : ''}{trigger.adjustment}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="optimization" className="space-y-6">
            <div className="flex justify-between items-center">
              <Select value={selectedEvent} onValueChange={setSelectedEvent}>
                <SelectTrigger className="w-64 bg-slate-800/50 border-slate-600">
                  <SelectValue placeholder="Select event for optimization" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="chiefs-bills">Chiefs vs Bills</SelectItem>
                  <SelectItem value="cowboys-eagles">Cowboys vs Eagles</SelectItem>
                  <SelectItem value="lakers-celtics">Lakers vs Celtics</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {yieldOptimization && (
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Yield Optimization for {yieldOptimization.event}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-3 gap-6">
                    <div className="text-center p-4 bg-slate-800/30 rounded-lg">
                      <p className="text-slate-400 text-sm">Current Yield</p>
                      <p className="text-2xl font-bold text-white">{yieldOptimization.currentYield.toFixed(2)}%</p>
                    </div>
                    <div className="text-center p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                      <p className="text-green-400 text-sm">Optimized Yield</p>
                      <p className="text-2xl font-bold text-green-400">{yieldOptimization.optimizedYield.toFixed(2)}%</p>
                    </div>
                    <div className="text-center p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                      <p className="text-blue-400 text-sm">Potential Increase</p>
                      <p className="text-2xl font-bold text-blue-400">+{yieldOptimization.potentialIncrease.toFixed(2)}%</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-white font-medium mb-3">Recommended Actions</h4>
                    <div className="space-y-2">
                      {yieldOptimization.recommendedActions.map((action, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                          <div>
                            <p className="text-white font-medium">{action.action}</p>
                            <p className="text-slate-400 text-sm">Impact: +{action.impact.toFixed(2)}%</p>
                          </div>
                          <Badge className={`${
                            action.risk === 'low' ? 'bg-green-500/20 text-green-400' :
                            action.risk === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {action.risk} risk
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-white font-medium mb-3">Market Segments</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {yieldOptimization.marketSegments.map((segment, index) => (
                        <div key={index} className="p-4 bg-slate-800/30 rounded-lg">
                          <h5 className="text-white font-medium mb-2">{segment.segment}</h5>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-slate-400">Elasticity</span>
                              <span className="text-white">{segment.elasticity.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Optimal Price</span>
                              <span className="text-green-400">{segment.optimalPrice.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Expected Volume</span>
                              <span className="text-blue-400">{segment.expectedVolume.toLocaleString()}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button
                    className="w-full bg-green-500 hover:bg-green-600"
                    onClick={() => applyOptimizationMutation.mutate({
                      event: selectedEvent,
                      optimizations: yieldOptimization.recommendedActions
                    })}
                  >
                    <DollarSign className="h-4 w-4 mr-2" />
                    Apply Optimization
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="ml" className="space-y-6">
            {mlPredictions?.map((prediction: MLPrediction, index: number) => (
              <Card key={index} className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-white">{prediction.model} Model</CardTitle>
                    <Badge className="bg-blue-500/20 text-blue-400">
                      {prediction.accuracy}% accuracy
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-3 bg-slate-800/30 rounded-lg">
                      <p className="text-slate-400 text-sm">Optimal Odds</p>
                      <p className="text-2xl font-bold text-white">{prediction.prediction.optimalOdds.toFixed(2)}</p>
                    </div>
                    <div className="text-center p-3 bg-slate-800/30 rounded-lg">
                      <p className="text-slate-400 text-sm">Confidence</p>
                      <p className="text-2xl font-bold text-green-400">{prediction.prediction.confidence}%</p>
                    </div>
                    <div className="text-center p-3 bg-slate-800/30 rounded-lg">
                      <p className="text-slate-400 text-sm">Expected Volume</p>
                      <p className="text-2xl font-bold text-blue-400">{prediction.prediction.expectedVolume.toLocaleString()}</p>
                    </div>
                    <div className="text-center p-3 bg-slate-800/30 rounded-lg">
                      <p className="text-slate-400 text-sm">Profitability</p>
                      <p className="text-2xl font-bold text-purple-400">{prediction.prediction.profitability.toFixed(1)}%</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-white font-medium mb-3">Key Factors</h4>
                    <div className="space-y-2">
                      {prediction.factors.map((factor, factorIndex) => (
                        <div key={factorIndex} className="flex items-center justify-between p-2 bg-slate-800/30 rounded">
                          <span className="text-white">{factor.name}</span>
                          <div className="flex items-center space-x-2">
                            <div className="w-20 bg-slate-700 rounded-full h-2">
                              <div 
                                className="h-2 rounded-full bg-blue-400" 
                                style={{ width: `${factor.importance}%` }}
                              />
                            </div>
                            <span className={`text-sm ${factor.impact === 'positive' ? 'text-green-400' : 'text-red-400'}`}>
                              {factor.importance}%
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <h4 className="text-green-400 font-medium mb-2">Backtest Results</h4>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-slate-400">Period</p>
                        <p className="text-white font-bold">{prediction.backtestResults.period}</p>
                      </div>
                      <div>
                        <p className="text-slate-400">Predictions</p>
                        <p className="text-white font-bold">{prediction.backtestResults.totalPredictions.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400">Profit Increase</p>
                        <p className="text-green-400 font-bold">+{prediction.backtestResults.profitIncrease.toFixed(1)}%</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}