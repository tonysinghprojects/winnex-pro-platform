import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, TrendingUp, Target, DollarSign, AlertTriangle, Star, Zap, Trophy } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface PredictiveAnalysis {
  matchId: number;
  sport: string;
  teams: string;
  prediction: {
    outcome: string;
    confidence: number;
    expectedValue: number;
    riskLevel: 'low' | 'medium' | 'high';
    reasoning: string[];
  };
  modelAccuracy: number;
  historicalPerformance: {
    winRate: number;
    avgReturn: number;
    totalPredictions: number;
  };
}

interface PersonalizedRecommendation {
  id: string;
  type: 'value_bet' | 'safe_bet' | 'system_bet' | 'cash_out';
  title: string;
  description: string;
  matchInfo: string;
  recommendation: string;
  suggestedStake: number;
  potentialReturn: number;
  confidence: number;
  riskScore: number;
  reasoning: string[];
  timeframe: string;
  priority: 'high' | 'medium' | 'low';
}

interface BankrollStrategy {
  currentBalance: number;
  optimalBetSize: number;
  riskLevel: 'conservative' | 'moderate' | 'aggressive';
  kellyPercentage: number;
  dailyTarget: number;
  weeklyGoal: number;
  riskOfRuin: number;
  streakAnalysis: {
    currentStreak: number;
    longestWin: number;
    longestLoss: number;
    recommendation: string;
  };
}

interface MarketInefficiency {
  id: string;
  market: string;
  inefficiencyType: 'overvalued' | 'undervalued' | 'arbitrage';
  expectedValue: number;
  confidence: number;
  timeRemaining: string;
  bookmakerOdds: number;
  fairOdds: number;
  edge: number;
  maxStake: number;
}

export default function AIBettingAssistant() {
  const [activeTab, setActiveTab] = useState('predictions');
  const [userProfile, setUserProfile] = useState({
    riskTolerance: 'moderate',
    preferredSports: ['football', 'basketball'],
    avgStake: 25,
    winRate: 0.58,
    totalBets: 247
  });

  // Mock AI predictions with 94.2% accuracy
  const predictions: PredictiveAnalysis[] = [
    {
      matchId: 1,
      sport: 'Football',
      teams: 'Chiefs vs Bills',
      prediction: {
        outcome: 'Chiefs -3.5',
        confidence: 87,
        expectedValue: 12.4,
        riskLevel: 'low',
        reasoning: [
          'Chiefs 8-2 home record this season',
          'Bills struggling vs playoff teams (2-5)',
          'Weather favors Chiefs rushing attack',
          'Key Bills injuries on defense'
        ]
      },
      modelAccuracy: 94.2,
      historicalPerformance: {
        winRate: 0.72,
        avgReturn: 1.18,
        totalPredictions: 156
      }
    },
    {
      matchId: 2,
      sport: 'Basketball',
      teams: 'Lakers vs Celtics',
      prediction: {
        outcome: 'Over 218.5',
        confidence: 91,
        expectedValue: 15.8,
        riskLevel: 'low',
        reasoning: [
          'Both teams averaging 115+ points',
          'Fast pace expected (102+ possessions)',
          'Defensive injuries for both sides',
          'Historical O/U trend: 78% over in H2H'
        ]
      },
      modelAccuracy: 89.6,
      historicalPerformance: {
        winRate: 0.69,
        avgReturn: 1.24,
        totalPredictions: 203
      }
    }
  ];

  const recommendations: PersonalizedRecommendation[] = [
    {
      id: '1',
      type: 'value_bet',
      title: 'High Value Opportunity',
      description: 'Liverpool to score 2+ goals vs Arsenal',
      matchInfo: 'Premier League • Today 3:00 PM',
      recommendation: 'Back Liverpool Over 1.5 Goals',
      suggestedStake: 35,
      potentialReturn: 63,
      confidence: 89,
      riskScore: 3,
      reasoning: [
        'Liverpool scored 2+ in 8/10 recent away games',
        'Arsenal conceded 2+ in 6/8 home games',
        'Key Arsenal defenders injured'
      ],
      timeframe: '2 hours remaining',
      priority: 'high'
    },
    {
      id: '2',
      type: 'safe_bet',
      title: 'Conservative Play',
      description: 'Double Chance on Manchester Derby',
      matchInfo: 'Premier League • Tomorrow 12:30 PM',
      recommendation: 'Man City or Draw',
      suggestedStake: 50,
      potentialReturn: 70,
      confidence: 78,
      riskScore: 2,
      reasoning: [
        'City unbeaten at home this season',
        'United poor away record vs top 6',
        'Safe value at current odds'
      ],
      timeframe: '1 day remaining',
      priority: 'medium'
    }
  ];

  const bankrollStrategy: BankrollStrategy = {
    currentBalance: 1250,
    optimalBetSize: 28,
    riskLevel: 'moderate',
    kellyPercentage: 2.2,
    dailyTarget: 45,
    weeklyGoal: 280,
    riskOfRuin: 0.08,
    streakAnalysis: {
      currentStreak: 4,
      longestWin: 12,
      longestLoss: 6,
      recommendation: 'Continue current strategy - positive momentum'
    }
  };

  const marketInefficiencies: MarketInefficiency[] = [
    {
      id: '1',
      market: 'NBA Total Points',
      inefficiencyType: 'undervalued',
      expectedValue: 18.5,
      confidence: 92,
      timeRemaining: '45 minutes',
      bookmakerOdds: 1.90,
      fairOdds: 1.65,
      edge: 13.2,
      maxStake: 150
    },
    {
      id: '2',
      market: 'Soccer Asian Handicap',
      inefficiencyType: 'overvalued',
      expectedValue: 11.7,
      confidence: 85,
      timeRemaining: '2 hours',
      bookmakerOdds: 2.10,
      fairOdds: 2.35,
      edge: 10.6,
      maxStake: 75
    }
  ];

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Assistant Header */}
      <Card className="bg-gradient-to-r from-winnex-blue/20 to-winnex-green/20 border-winnex-blue/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-winnex-blue/20 rounded-lg">
                <Brain className="w-6 h-6 text-winnex-blue" />
              </div>
              <div>
                <CardTitle className="text-xl">AI Betting Assistant</CardTitle>
                <p className="text-sm text-gray-400">94.2% prediction accuracy • Real-time analysis</p>
              </div>
            </div>
            <Badge className="bg-winnex-green text-black font-medium">
              <Zap className="w-3 h-3 mr-1" />
              ACTIVE
            </Badge>
          </div>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 bg-winnex-dark">
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
          <TabsTrigger value="recommendations">Smart Picks</TabsTrigger>
          <TabsTrigger value="bankroll">Bankroll</TabsTrigger>
          <TabsTrigger value="insights">Market Edge</TabsTrigger>
        </TabsList>

        <TabsContent value="predictions" className="space-y-4">
          <div className="grid gap-4">
            {predictions?.map((prediction: PredictiveAnalysis, index: number) => (
              <Card key={index} className="bg-winnex-gray border-gray-600">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{prediction.teams}</h3>
                      <p className="text-sm text-gray-400">{prediction.sport}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-2">
                        <Badge className="bg-winnex-green text-black">
                          {prediction.prediction.confidence}% Confidence
                        </Badge>
                        <Badge variant="outline" className={getRiskColor(prediction.prediction.riskLevel)}>
                          {prediction.prediction.riskLevel.toUpperCase()} RISK
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="bg-winnex-dark rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">AI Prediction:</span>
                      <span className="text-winnex-green font-bold">{prediction.prediction.outcome}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Expected Value:</span>
                      <span className="text-winnex-green font-medium">+{prediction.prediction.expectedValue}%</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">AI Reasoning:</h4>
                    <ul className="space-y-1">
                      {prediction.prediction.reasoning.map((reason, idx) => (
                        <li key={idx} className="text-sm text-gray-300 flex items-start">
                          <span className="text-winnex-green mr-2">•</span>
                          {reason}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-400 border-t border-gray-600 pt-3">
                    <span>Model Accuracy: {prediction.modelAccuracy}%</span>
                    <span>Win Rate: {(prediction.historicalPerformance.winRate * 100).toFixed(1)}%</span>
                    <span>Avg Return: +{((prediction.historicalPerformance.avgReturn - 1) * 100).toFixed(1)}%</span>
                  </div>

                  <Button className="w-full bg-winnex-green text-black hover:bg-green-400 font-medium">
                    Add to Bet Slip
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          <div className="grid gap-4">
            {recommendations?.map((rec: PersonalizedRecommendation) => (
              <Card key={rec.id} className="bg-winnex-gray border-gray-600">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Badge className={getPriorityColor(rec.priority)}>
                        {rec.priority.toUpperCase()}
                      </Badge>
                      <h3 className="font-semibold">{rec.title}</h3>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-400" />
                      <span className="text-sm font-medium">{rec.confidence}%</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-400">{rec.matchInfo}</p>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="bg-winnex-dark rounded-lg p-4 space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Recommendation:</span>
                      <span className="text-winnex-green">{rec.recommendation}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Suggested Stake:</span>
                      <span className="text-sm font-medium">${rec.suggestedStake}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Potential Return:</span>
                      <span className="text-sm font-medium text-winnex-green">${rec.potentialReturn}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Analysis:</h4>
                    <ul className="space-y-1">
                      {rec.reasoning.map((reason, idx) => (
                        <li key={idx} className="text-sm text-gray-300 flex items-start">
                          <span className="text-winnex-blue mr-2">•</span>
                          {reason}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>Risk Score: {rec.riskScore}/10</span>
                    <span>{rec.timeframe}</span>
                  </div>

                  <Button className="w-full bg-winnex-blue text-white hover:bg-blue-400 font-medium">
                    Follow Recommendation
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="bankroll" className="space-y-4">
          <Card className="bg-winnex-gray border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="w-5 h-5 mr-2 text-winnex-green" />
                Smart Bankroll Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-winnex-dark rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-winnex-green">${bankrollStrategy.currentBalance}</div>
                  <div className="text-sm text-gray-400">Current Balance</div>
                </div>
                <div className="bg-winnex-dark rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-winnex-blue">${bankrollStrategy.optimalBetSize}</div>
                  <div className="text-sm text-gray-400">Optimal Bet Size</div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Daily Progress</span>
                    <span>${bankrollStrategy.dailyTarget}</span>
                  </div>
                  <Progress value={65} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Weekly Goal</span>
                    <span>${bankrollStrategy.weeklyGoal}</span>
                  </div>
                  <Progress value={43} className="h-2" />
                </div>
              </div>

              <div className="bg-winnex-dark rounded-lg p-4 space-y-2">
                <h4 className="font-medium">Kelly Criterion Analysis</h4>
                <div className="flex justify-between text-sm">
                  <span>Recommended Stake %:</span>
                  <span className="text-winnex-green">{bankrollStrategy.kellyPercentage}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Risk of Ruin:</span>
                  <span className="text-green-400">{(bankrollStrategy.riskOfRuin * 100).toFixed(1)}%</span>
                </div>
              </div>

              <div className="bg-gradient-to-r from-winnex-green/10 to-winnex-blue/10 rounded-lg p-4">
                <h4 className="font-medium mb-2 flex items-center">
                  <Trophy className="w-4 h-4 mr-2 text-winnex-green" />
                  Streak Analysis
                </h4>
                <div className="grid grid-cols-3 gap-3 text-center text-sm">
                  <div>
                    <div className="font-bold text-winnex-green">{bankrollStrategy.streakAnalysis.currentStreak}</div>
                    <div className="text-gray-400">Current Win</div>
                  </div>
                  <div>
                    <div className="font-bold text-blue-400">{bankrollStrategy.streakAnalysis.longestWin}</div>
                    <div className="text-gray-400">Best Streak</div>
                  </div>
                  <div>
                    <div className="font-bold text-red-400">{bankrollStrategy.streakAnalysis.longestLoss}</div>
                    <div className="text-gray-400">Worst Streak</div>
                  </div>
                </div>
                <p className="text-sm text-gray-300 mt-3 text-center">
                  {bankrollStrategy.streakAnalysis.recommendation}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid gap-4">
            {marketInefficiencies?.map((inefficiency: MarketInefficiency) => (
              <Card key={inefficiency.id} className="bg-gradient-to-r from-orange-500/10 to-red-500/10 border-orange-500/30">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className="w-5 h-5 text-orange-400" />
                      <h3 className="font-semibold">Market Inefficiency Detected</h3>
                    </div>
                    <Badge className="bg-orange-500 text-white">
                      {inefficiency.confidence}% Confidence
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="bg-winnex-dark rounded-lg p-4 space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Market:</span>
                      <span className="text-winnex-green">{inefficiency.market}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Type:</span>
                      <span className={`font-medium ${
                        inefficiency.inefficiencyType === 'undervalued' ? 'text-green-400' : 
                        inefficiency.inefficiencyType === 'overvalued' ? 'text-red-400' : 'text-blue-400'
                      }`}>
                        {inefficiency.inefficiencyType.toUpperCase()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Edge:</span>
                      <span className="text-winnex-green font-bold">+{inefficiency.edge.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Max Stake:</span>
                      <span className="font-medium">${inefficiency.maxStake}</span>
                    </div>
                  </div>

                  <div className="bg-winnex-dark rounded-lg p-4 space-y-2">
                    <h4 className="font-medium text-sm">Odds Comparison</h4>
                    <div className="flex justify-between">
                      <span className="text-sm">Bookmaker Odds:</span>
                      <span className="text-sm">{inefficiency.bookmakerOdds}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Fair Value:</span>
                      <span className="text-sm text-winnex-green">{inefficiency.fairOdds}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Expected Value:</span>
                      <span className="text-sm text-winnex-green">+{inefficiency.expectedValue.toFixed(1)}%</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>Time remaining: {inefficiency.timeRemaining}</span>
                    <span className="text-orange-400">⚡ Limited time</span>
                  </div>

                  <Button className="w-full bg-orange-500 text-white hover:bg-orange-400 font-medium">
                    Exploit Market Edge
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}