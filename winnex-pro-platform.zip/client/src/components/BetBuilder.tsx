import { useState } from "react";
import { Plus, X, Calculator } from "lucide-react";

interface BetSelection {
  matchId: number;
  match: string;
  market: string;
  selection: string;
  odds: number;
}

export default function BetBuilder() {
  const [selections, setSelections] = useState<BetSelection[]>([]);
  const [stake, setStake] = useState("");

  const addSelection = (selection: BetSelection) => {
    setSelections([...selections, selection]);
  };

  const removeSelection = (index: number) => {
    setSelections(selections.filter((_, i) => i !== index));
  };

  const combinedOdds = selections.reduce((acc, sel) => acc * sel.odds, 1);
  const potentialWin = parseFloat(stake) * combinedOdds;

  return (
    <div className="card-modern p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-winnex-green">Bet Builder</h3>
        <Calculator className="text-winnex-blue" size={20} />
      </div>

      {selections.length === 0 ? (
        <div className="text-center py-8 text-white/60">
          <Plus className="mx-auto mb-3" size={24} />
          <p>Add selections to build your bet</p>
        </div>
      ) : (
        <div className="space-y-3 mb-6">
          {selections.map((selection, index) => (
            <div key={index} className="glass rounded-lg p-4 flex items-center justify-between">
              <div>
                <div className="font-medium">{selection.match}</div>
                <div className="text-sm text-white/60">{selection.market}: {selection.selection}</div>
              </div>
              <div className="flex items-center space-x-3">
                <span className="font-bold text-winnex-green">{selection.odds.toFixed(2)}</span>
                <button 
                  onClick={() => removeSelection(index)}
                  className="text-red-400 hover:text-red-300"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {selections.length > 0 && (
        <div className="border-t border-white/10 pt-4">
          <div className="flex justify-between items-center mb-4">
            <span>Combined Odds:</span>
            <span className="text-xl font-bold text-winnex-green">{combinedOdds.toFixed(2)}</span>
          </div>
          
          <div className="space-y-3">
            <input
              type="number"
              placeholder="Enter stake amount"
              value={stake}
              onChange={(e) => setStake(e.target.value)}
              className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
            />
            
            {stake && (
              <div className="flex justify-between items-center text-lg">
                <span>Potential Win:</span>
                <span className="font-bold text-winnex-orange">${potentialWin.toFixed(2)}</span>
              </div>
            )}
            
            <button className="btn-primary w-full">
              Place Bet Builder
            </button>
          </div>
        </div>
      )}
    </div>
  );
}