import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Trophy, 
  Users, 
  Star, 
  Target, 
  Calendar, 
  DollarSign,
  Clock,
  Award,
  TrendingUp,
  Zap
} from "lucide-react";

interface FantasyLeague {
  id: string;
  name: string;
  sport: string;
  format: 'daily' | 'weekly' | 'season';
  entryFee: number;
  prizePool: number;
  participants: number;
  maxParticipants: number;
  startTime: string;
  status: 'upcoming' | 'live' | 'completed';
  difficulty: 'beginner' | 'intermediate' | 'expert';
}

interface FantasyTeam {
  id: string;
  name: string;
  leagueId: string;
  players: FantasyPlayer[];
  totalSalary: number;
  salaryCap: number;
  currentPoints: number;
  projectedPoints: number;
  rank: number;
  isOptimal: boolean;
}

interface FantasyPlayer {
  id: string;
  name: string;
  team: string;
  position: string;
  salary: number;
  projectedPoints: number;
  actualPoints?: number;
  ownership: number; // percentage of teams that have this player
  isInjured: boolean;
  gameInfo: {
    opponent: string;
    homeAway: 'home' | 'away';
    gameTime: string;
  };
}

interface Contest {
  id: string;
  name: string;
  sport: string;
  entryFee: number;
  totalPrizes: number;
  entries: number;
  maxEntries: number;
  startTime: string;
  prizes: PrizeStructure[];
  guaranteed: boolean;
}

interface PrizeStructure {
  rank: string;
  prize: number;
  winners: number;
}

interface UserStats {
  totalEarnings: number;
  totalEntries: number;
  winRate: number;
  averageFinish: number;
  bestFinish: number;
  favoritePlayer: string;
  currentStreak: number;
  monthlyStats: {
    entries: number;
    winnings: number;
    topFinishes: number;
  };
}

export default function FantasySports() {
  const [leagues, setLeagues] = useState<FantasyLeague[]>([]);
  const [contests, setContests] = useState<Contest[]>([]);
  const [myTeams, setMyTeams] = useState<FantasyTeam[]>([]);
  const [playerPool, setPlayerPool] = useState<FantasyPlayer[]>([]);
  const [userStats, setUserStats] = useState<UserStats | null>(null);
  const [selectedSport, setSelectedSport] = useState('nfl');

  useEffect(() => {
    const mockLeagues: FantasyLeague[] = [
      {
        id: 'league_1',
        name: 'Sunday Million',
        sport: 'NFL',
        format: 'weekly',
        entryFee: 25,
        prizePool: 1000000,
        participants: 38420,
        maxParticipants: 50000,
        startTime: '2024-01-21 13:00',
        status: 'upcoming',
        difficulty: 'expert'
      },
      {
        id: 'league_2',
        name: 'NBA Showdown',
        sport: 'NBA',
        format: 'daily',
        entryFee: 5,
        prizePool: 100000,
        participants: 15280,
        maxParticipants: 20000,
        startTime: '2024-01-16 19:00',
        status: 'live',
        difficulty: 'intermediate'
      },
      {
        id: 'league_3',
        name: 'Soccer Champions',
        sport: 'Soccer',
        format: 'weekly',
        entryFee: 10,
        prizePool: 50000,
        participants: 4850,
        maxParticipants: 10000,
        startTime: '2024-01-20 12:00',
        status: 'upcoming',
        difficulty: 'beginner'
      }
    ];

    const mockContests: Contest[] = [
      {
        id: 'contest_1',
        name: 'GPP Millionaire Maker',
        sport: 'NFL',
        entryFee: 20,
        totalPrizes: 1000000,
        entries: 42350,
        maxEntries: 50000,
        startTime: '2024-01-21 13:00',
        guaranteed: true,
        prizes: [
          { rank: '1st', prize: 200000, winners: 1 },
          { rank: '2nd', prize: 100000, winners: 1 },
          { rank: '3rd', prize: 50000, winners: 1 },
          { rank: '4th-10th', prize: 10000, winners: 7 },
          { rank: '11th-100th', prize: 1000, winners: 90 }
        ]
      }
    ];

    const mockPlayerPool: FantasyPlayer[] = [
      {
        id: 'player_1',
        name: 'Josh Allen',
        team: 'BUF',
        position: 'QB',
        salary: 8500,
        projectedPoints: 22.5,
        actualPoints: 24.2,
        ownership: 18.5,
        isInjured: false,
        gameInfo: {
          opponent: 'KC',
          homeAway: 'home',
          gameTime: '2024-01-21 15:30'
        }
      },
      {
        id: 'player_2',
        name: 'Christian McCaffrey',
        team: 'SF',
        position: 'RB',
        salary: 9200,
        projectedPoints: 20.8,
        ownership: 25.3,
        isInjured: false,
        gameInfo: {
          opponent: 'DAL',
          homeAway: 'away',
          gameTime: '2024-01-21 16:25'
        }
      },
      {
        id: 'player_3',
        name: 'Cooper Kupp',
        team: 'LAR',
        position: 'WR',
        salary: 7800,
        projectedPoints: 18.2,
        ownership: 15.7,
        isInjured: true,
        gameInfo: {
          opponent: 'TB',
          homeAway: 'home',
          gameTime: '2024-01-21 13:00'
        }
      }
    ];

    const mockUserStats: UserStats = {
      totalEarnings: 3250,
      totalEntries: 156,
      winRate: 22.4,
      averageFinish: 4250,
      bestFinish: 1,
      favoritePlayer: 'Josh Allen',
      currentStreak: 3,
      monthlyStats: {
        entries: 24,
        winnings: 485,
        topFinishes: 5
      }
    };

    const mockMyTeams: FantasyTeam[] = [
      {
        id: 'team_1',
        name: 'Championship Squad',
        leagueId: 'league_1',
        players: mockPlayerPool,
        totalSalary: 49500,
        salaryCap: 50000,
        currentPoints: 145.8,
        projectedPoints: 142.5,
        rank: 1250,
        isOptimal: false
      }
    ];

    setLeagues(mockLeagues);
    setContests(mockContests);
    setPlayerPool(mockPlayerPool);
    setUserStats(mockUserStats);
    setMyTeams(mockMyTeams);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-red-500';
      case 'upcoming': return 'bg-blue-500';
      case 'completed': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'text-green-400';
      case 'intermediate': return 'text-yellow-400';
      case 'expert': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getPositionColor = (position: string) => {
    switch (position) {
      case 'QB': return 'text-red-400';
      case 'RB': return 'text-green-400';
      case 'WR': return 'text-blue-400';
      case 'TE': return 'text-purple-400';
      case 'K': return 'text-yellow-400';
      case 'DEF': return 'text-orange-400';
      default: return 'text-gray-400';
    }
  };

  if (!userStats) return null;

  return (
    <div className="p-6 space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <Trophy className="w-12 h-12 text-emerald-400 mr-3" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            Fantasy Sports
          </h1>
        </div>
        <p className="text-gray-400 text-lg">Build your dream team and compete for massive prizes</p>
      </div>

      {/* User Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-3xl font-bold text-emerald-400">${userStats.totalEarnings.toLocaleString()}</div>
            <div className="text-sm text-gray-400">Total Winnings</div>
          </CardContent>
        </Card>
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-3xl font-bold text-blue-400">{userStats.winRate}%</div>
            <div className="text-sm text-gray-400">Win Rate</div>
          </CardContent>
        </Card>
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-3xl font-bold text-purple-400">{userStats.bestFinish}</div>
            <div className="text-sm text-gray-400">Best Finish</div>
          </CardContent>
        </Card>
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-3xl font-bold text-orange-400">{userStats.currentStreak}</div>
            <div className="text-sm text-gray-400">Win Streak</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="contests" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="contests" className="flex items-center">
            <Trophy className="w-4 h-4 mr-2" />
            Contests
          </TabsTrigger>
          <TabsTrigger value="my-teams" className="flex items-center">
            <Users className="w-4 h-4 mr-2" />
            My Teams
          </TabsTrigger>
          <TabsTrigger value="player-pool" className="flex items-center">
            <Star className="w-4 h-4 mr-2" />
            Players
          </TabsTrigger>
          <TabsTrigger value="research" className="flex items-center">
            <Target className="w-4 h-4 mr-2" />
            Research
          </TabsTrigger>
        </TabsList>

        <TabsContent value="contests" className="space-y-6">
          <div className="grid gap-6">
            {leagues.map((league) => (
              <Card key={league.id} className="casino-card">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-white text-xl">{league.name}</CardTitle>
                      <div className="flex items-center space-x-3 mt-2">
                        <Badge variant="outline">{league.sport}</Badge>
                        <Badge variant="outline" className="capitalize">{league.format}</Badge>
                        <Badge className={getStatusColor(league.status)}>
                          {league.status.toUpperCase()}
                        </Badge>
                        <Badge variant="outline" className={getDifficultyColor(league.difficulty)}>
                          {league.difficulty}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-emerald-400">
                        ${league.prizePool.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-400">Prize Pool</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Entry Fee: </span>
                      <span className="text-white font-semibold">${league.entryFee}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Participants: </span>
                      <span className="text-white">{league.participants.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Max: </span>
                      <span className="text-white">{league.maxParticipants.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Starts: </span>
                      <span className="text-white">{league.startTime}</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-400">Contest Fill</span>
                      <span className="text-white">
                        {Math.round((league.participants / league.maxParticipants) * 100)}%
                      </span>
                    </div>
                    <Progress 
                      value={(league.participants / league.maxParticipants) * 100} 
                      className="h-2"
                    />
                  </div>

                  <div className="flex space-x-3">
                    <Button className="flex-1 bg-emerald-500 hover:bg-emerald-600">
                      Enter Contest
                    </Button>
                    <Button variant="outline" className="flex-1">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="my-teams" className="space-y-6">
          {myTeams.length > 0 ? (
            <div className="grid gap-6">
              {myTeams.map((team) => (
                <Card key={team.id} className="casino-card">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-white">{team.name}</CardTitle>
                        <p className="text-gray-400">
                          Rank: #{team.rank.toLocaleString()} • {team.currentPoints} points
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-emerald-400">
                          ${(team.salaryCap - team.totalSalary).toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-400">Remaining</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-lg font-bold text-white">{team.currentPoints}</div>
                        <div className="text-sm text-gray-400">Current Points</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-blue-400">{team.projectedPoints}</div>
                        <div className="text-sm text-gray-400">Projected</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-purple-400">#{team.rank}</div>
                        <div className="text-sm text-gray-400">Current Rank</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold text-white">Lineup</h4>
                      {team.players.map((player) => (
                        <div key={player.id} className="flex items-center justify-between p-2 bg-gray-800 rounded">
                          <div className="flex items-center space-x-3">
                            <Badge className={getPositionColor(player.position)}>
                              {player.position}
                            </Badge>
                            <div>
                              <span className="text-white font-medium">{player.name}</span>
                              <span className="text-gray-400 ml-2">({player.team})</span>
                              {player.isInjured && (
                                <Badge variant="destructive" className="ml-2 text-xs">
                                  INJ
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-white font-semibold">
                              {player.actualPoints || player.projectedPoints} pts
                            </div>
                            <div className="text-sm text-gray-400">${player.salary}</div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex space-x-3">
                      <Button className="flex-1 bg-blue-500 hover:bg-blue-600">
                        Edit Lineup
                      </Button>
                      <Button variant="outline" className="flex-1">
                        View Contest
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="casino-card text-center">
              <CardContent className="p-12">
                <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Teams Yet</h3>
                <p className="text-gray-400 mb-6">
                  Create your first fantasy team to start competing
                </p>
                <Button className="bg-emerald-500 hover:bg-emerald-600">
                  Create Team
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="player-pool" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-white">Player Pool</CardTitle>
                <div className="flex space-x-2">
                  <select className="bg-gray-800 border border-gray-700 rounded px-3 py-1 text-white text-sm">
                    <option value="all">All Positions</option>
                    <option value="QB">Quarterbacks</option>
                    <option value="RB">Running Backs</option>
                    <option value="WR">Wide Receivers</option>
                    <option value="TE">Tight Ends</option>
                  </select>
                  <select className="bg-gray-800 border border-gray-700 rounded px-3 py-1 text-white text-sm">
                    <option value="salary">Sort by Salary</option>
                    <option value="projected">Sort by Projection</option>
                    <option value="ownership">Sort by Ownership</option>
                  </select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {playerPool.map((player) => (
                  <Card key={player.id} className="border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <Badge className={getPositionColor(player.position)}>
                            {player.position}
                          </Badge>
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-semibold text-white">{player.name}</span>
                              <span className="text-gray-400">({player.team})</span>
                              {player.isInjured && (
                                <Badge variant="destructive" className="text-xs">
                                  INJURED
                                </Badge>
                              )}
                            </div>
                            <div className="text-sm text-gray-400">
                              vs {player.gameInfo.opponent} • {player.gameInfo.gameTime}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-6">
                          <div className="text-center">
                            <div className="text-lg font-bold text-emerald-400">
                              {player.projectedPoints}
                            </div>
                            <div className="text-xs text-gray-400">Projected</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold text-white">
                              ${player.salary.toLocaleString()}
                            </div>
                            <div className="text-xs text-gray-400">Salary</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold text-blue-400">
                              {player.ownership}%
                            </div>
                            <div className="text-xs text-gray-400">Ownership</div>
                          </div>
                          <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600">
                            Add
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="research" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-white">Research Tools</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full bg-blue-500 hover:bg-blue-600">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Lineup Optimizer
                </Button>
                <Button className="w-full bg-purple-500 hover:bg-purple-600">
                  <Target className="w-4 h-4 mr-2" />
                  Matchup Analysis
                </Button>
                <Button className="w-full bg-orange-500 hover:bg-orange-600">
                  <Clock className="w-4 h-4 mr-2" />
                  Weather Reports
                </Button>
                <Button className="w-full bg-green-500 hover:bg-green-600">
                  <Zap className="w-4 h-4 mr-2" />
                  Injury Reports
                </Button>
              </CardContent>
            </Card>

            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-white">Expert Picks</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-gray-800 rounded">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">Josh Allen (QB)</span>
                    <Badge className="bg-green-500">BUY</Badge>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">
                    Great matchup vs weak secondary, projected 25+ points
                  </p>
                </div>
                <div className="p-3 bg-gray-800 rounded">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">Cooper Kupp (WR)</span>
                    <Badge className="bg-red-500">AVOID</Badge>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">
                    Injury concerns and tough matchup, consider alternatives
                  </p>
                </div>
                <div className="p-3 bg-gray-800 rounded">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">Christian McCaffrey (RB)</span>
                    <Badge className="bg-yellow-500">HOLD</Badge>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">
                    High ownership but proven floor, tournament play dependent
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}