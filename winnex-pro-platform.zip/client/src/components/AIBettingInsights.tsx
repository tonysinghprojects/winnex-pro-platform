import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Brain, TrendingUp, Target, Zap, Star, AlertTriangle, CheckCircle } from "lucide-react";

interface AIInsight {
  id: string;
  type: 'prediction' | 'value_bet' | 'risk_alert' | 'trend_analysis';
  confidence: number;
  title: string;
  description: string;
  recommendation: string;
  odds: number;
  expectedValue: number;
  matchId: number;
  market: string;
  reasons: string[];
  riskLevel: 'low' | 'medium' | 'high';
}

interface PersonalizedRecommendation {
  matchId: number;
  match: string;
  recommendation: string;
  confidence: number;
  reasoning: string;
  suggestedStake: number;
  expectedROI: number;
  riskScore: number;
}

export default function AIBettingInsights() {
  const [activeTab, setActiveTab] = useState<'insights' | 'predictions' | 'recommendations'>('insights');

  const { data: aiInsights = [] } = useQuery<AIInsight[]>({
    queryKey: ["/api/ai/insights"],
  });

  const { data: predictions = [] } = useQuery({
    queryKey: ["/api/ai/predictions"],
  });

  const { data: personalRecommendations = [] } = useQuery<PersonalizedRecommendation[]>({
    queryKey: ["/api/ai/recommendations"],
  });

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'text-winnex-green';
    if (confidence >= 60) return 'text-winnex-orange';
    return 'text-red-400';
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'prediction': return <Brain className="text-winnex-blue" size={20} />;
      case 'value_bet': return <Star className="text-winnex-green" size={20} />;
      case 'risk_alert': return <AlertTriangle className="text-red-400" size={20} />;
      case 'trend_analysis': return <TrendingUp className="text-winnex-purple" size={20} />;
      default: return <Target className="text-white" size={20} />;
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-winnex-green';
      case 'medium': return 'text-winnex-orange';
      case 'high': return 'text-red-400';
      default: return 'text-white';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card-modern p-6 gradient-accent">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Brain className="text-white" size={32} />
            <div>
              <h2 className="text-2xl font-bold text-white">AI Betting Intelligence</h2>
              <p className="text-white/80">Machine learning-powered insights and predictions</p>
            </div>
          </div>
          <div className="glass rounded-2xl p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">94.2%</div>
              <div className="text-white/70 text-sm">AI Accuracy</div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="glass rounded-xl p-1 flex">
        {(['insights', 'predictions', 'recommendations'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all capitalize ${
              activeTab === tab ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* AI Insights Tab */}
      {activeTab === 'insights' && (
        <div className="space-y-4">
          {aiInsights.length === 0 ? (
            <div className="card-modern p-12 text-center">
              <Brain className="mx-auto mb-4 text-white/40" size={48} />
              <h3 className="text-xl font-bold mb-2">AI Analysis in Progress</h3>
              <p className="text-white/60">Our machine learning models are analyzing current matches and market data</p>
            </div>
          ) : (
            aiInsights.map((insight) => (
              <div key={insight.id} className="card-modern p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    {getInsightIcon(insight.type)}
                    <div>
                      <h3 className="font-bold text-lg">{insight.title}</h3>
                      <div className="flex items-center space-x-3 mt-1">
                        <span className={`text-sm font-medium ${getConfidenceColor(insight.confidence)}`}>
                          {insight.confidence}% Confidence
                        </span>
                        <span className={`text-sm ${getRiskColor(insight.riskLevel)}`}>
                          {insight.riskLevel.toUpperCase()} Risk
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-winnex-green">{insight.odds.toFixed(2)}</div>
                    <div className="text-sm text-white/60">Odds</div>
                  </div>
                </div>

                <p className="text-white/80 mb-4">{insight.description}</p>

                <div className="glass rounded-lg p-4 mb-4">
                  <h4 className="font-semibold mb-2 flex items-center">
                    <Target className="mr-2" size={16} />
                    AI Recommendation
                  </h4>
                  <p className="text-winnex-green">{insight.recommendation}</p>
                </div>

                {insight.reasons.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Key Factors:</h4>
                    <div className="space-y-1">
                      {insight.reasons.map((reason, index) => (
                        <div key={index} className="flex items-center space-x-2 text-sm">
                          <CheckCircle size={12} className="text-winnex-green flex-shrink-0" />
                          <span className="text-white/80">{reason}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex justify-between items-center mt-4 pt-4 border-t border-white/10">
                  <div className="text-sm">
                    <span className="text-white/60">Expected Value: </span>
                    <span className={`font-bold ${insight.expectedValue > 0 ? 'text-winnex-green' : 'text-red-400'}`}>
                      {insight.expectedValue > 0 ? '+' : ''}{insight.expectedValue.toFixed(2)}%
                    </span>
                  </div>
                  <button className="btn-primary text-sm px-4 py-2">
                    Place Bet
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Predictions Tab */}
      {activeTab === 'predictions' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card-modern p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <Zap className="mr-2 text-winnex-blue" />
              Match Outcome Predictions
            </h3>
            <div className="space-y-4">
              {[
                { match: "Arsenal vs Chelsea", prediction: "Arsenal Win", probability: 68, odds: 2.15 },
                { match: "Real Madrid vs Barcelona", prediction: "Over 2.5 Goals", probability: 74, odds: 1.85 },
                { match: "Liverpool vs Man City", prediction: "Both Teams to Score", probability: 82, odds: 1.62 },
              ].map((pred, index) => (
                <div key={index} className="glass rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium">{pred.match}</h4>
                    <span className="text-winnex-green font-bold">{pred.odds}</span>
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-white/80">{pred.prediction}</span>
                    <span className={`text-sm font-bold ${getConfidenceColor(pred.probability)}`}>
                      {pred.probability}%
                    </span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-2">
                    <div 
                      className="bg-winnex-green h-2 rounded-full transition-all duration-500"
                      style={{ width: `${pred.probability}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card-modern p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <TrendingUp className="mr-2 text-winnex-purple" />
              Market Trends
            </h3>
            <div className="space-y-4">
              <div className="glass rounded-lg p-4">
                <h4 className="font-medium mb-2">Over/Under Goals Trend</h4>
                <p className="text-sm text-white/80 mb-3">
                  Premier League matches show 67% rate for Over 2.5 goals in last 10 games
                </p>
                <div className="flex justify-between text-sm">
                  <span>Confidence:</span>
                  <span className="text-winnex-green font-bold">High</span>
                </div>
              </div>

              <div className="glass rounded-lg p-4">
                <h4 className="font-medium mb-2">Home Team Advantage</h4>
                <p className="text-sm text-white/80 mb-3">
                  Home teams winning 58% more frequently this season
                </p>
                <div className="flex justify-between text-sm">
                  <span>Impact:</span>
                  <span className="text-winnex-orange font-bold">Medium</span>
                </div>
              </div>

              <div className="glass rounded-lg p-4">
                <h4 className="font-medium mb-2">Value Betting Opportunities</h4>
                <p className="text-sm text-white/80 mb-3">
                  14 value bets identified with positive expected value
                </p>
                <div className="flex justify-between text-sm">
                  <span>Avg. EV:</span>
                  <span className="text-winnex-green font-bold">+12.3%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Personal Recommendations Tab */}
      {activeTab === 'recommendations' && (
        <div className="space-y-4">
          <div className="card-modern p-6 mb-6">
            <h3 className="text-xl font-bold mb-4">Personalized for Your Betting Style</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-winnex-green">72%</div>
                <div className="text-sm text-white/60">Your Win Rate</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-winnex-blue">+18.5%</div>
                <div className="text-sm text-white/60">Average ROI</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-winnex-orange">Football</div>
                <div className="text-sm text-white/60">Best Sport</div>
              </div>
            </div>
          </div>

          {personalRecommendations.map((rec, index) => (
            <div key={index} className="card-modern p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-bold text-lg">{rec.match}</h3>
                  <p className="text-winnex-green font-medium">{rec.recommendation}</p>
                </div>
                <div className="text-right">
                  <div className={`text-lg font-bold ${getConfidenceColor(rec.confidence)}`}>
                    {rec.confidence}%
                  </div>
                  <div className="text-sm text-white/60">Match</div>
                </div>
              </div>

              <p className="text-white/80 mb-4">{rec.reasoning}</p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-white">${rec.suggestedStake}</div>
                  <div className="text-xs text-white/60">Suggested Stake</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-winnex-green">+{rec.expectedROI}%</div>
                  <div className="text-xs text-white/60">Expected ROI</div>
                </div>
                <div className="text-center">
                  <div className={`text-lg font-bold ${getRiskColor(rec.riskScore < 30 ? 'low' : rec.riskScore < 70 ? 'medium' : 'high')}`}>
                    {rec.riskScore}/100
                  </div>
                  <div className="text-xs text-white/60">Risk Score</div>
                </div>
                <div className="text-center">
                  <button className="btn-primary w-full text-sm">
                    Accept
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}