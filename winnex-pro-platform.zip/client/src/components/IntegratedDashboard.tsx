import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { 
  TrendingUp, 
  Users, 
  Trophy, 
  Brain, 
  Gamepad2, 
  Shield, 
  Heart,
  CreditCard,
  Play,
  Star,
  Zap,
  Target,
  Crown,
  MessageCircle
} from "lucide-react";

interface DashboardMetrics {
  totalBets: number;
  activeBets: number;
  totalWinnings: number;
  currentBalance: number;
  winRate: number;
  socialFollowers: number;
  vipTier: string;
  responsibleGamingStatus: string;
  aiRecommendations: number;
}

interface LiveUpdate {
  id: string;
  type: 'bet_result' | 'social_activity' | 'ai_insight' | 'vip_reward' | 'compliance_alert';
  title: string;
  description: string;
  timestamp: string;
  priority: 'low' | 'medium' | 'high';
}

export default function IntegratedDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [liveUpdates, setLiveUpdates] = useState<LiveUpdate[]>([]);
  const { isAuthenticated } = useAuth();

  const { data: metrics, isLoading: metricsLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics"],
    refetchInterval: 30000, // Refresh every 30 seconds
    enabled: isAuthenticated,
  });

  const { data: aiInsights, isLoading: aiLoading } = useQuery({
    queryKey: ["/api/ai/dashboard-insights"],
    enabled: isAuthenticated,
  });

  const { data: socialActivity, isLoading: socialLoading } = useQuery({
    queryKey: ["/api/social/dashboard-activity"],
    enabled: isAuthenticated,
  });

  const { data: vipStatus, isLoading: vipLoading } = useQuery({
    queryKey: ["/api/vip/status"],
    enabled: isAuthenticated,
  });

  const { data: complianceStatus, isLoading: complianceLoading } = useQuery({
    queryKey: ["/api/compliance/status"],
    enabled: isAuthenticated,
  });

  const mockMetrics: DashboardMetrics = {
    totalBets: 247,
    activeBets: 8,
    totalWinnings: 3420.50,
    currentBalance: 1250.75,
    winRate: 67.2,
    socialFollowers: 156,
    vipTier: "Gold",
    responsibleGamingStatus: "Healthy",
    aiRecommendations: 5
  };

  const mockLiveUpdates: LiveUpdate[] = [
    {
      id: "1",
      type: "bet_result",
      title: "Bet Won!",
      description: "Chelsea vs Arsenal - Chelsea Win (+$125)",
      timestamp: "2 minutes ago",
      priority: "high"
    },
    {
      id: "2", 
      type: "ai_insight",
      title: "AI Recommendation",
      description: "High value bet opportunity detected",
      timestamp: "5 minutes ago",
      priority: "medium"
    },
    {
      id: "3",
      type: "social_activity",
      title: "New Follower",
      description: "SportsBetPro is now following you",
      timestamp: "8 minutes ago",
      priority: "low"
    },
    {
      id: "4",
      type: "vip_reward",
      title: "VIP Bonus",
      description: "Weekly cashback: $45.20 credited",
      timestamp: "1 hour ago",
      priority: "medium"
    }
  ];

  useEffect(() => {
    setLiveUpdates(mockLiveUpdates);
  }, []);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'bet_result': return <Trophy className="w-4 h-4" />;
      case 'ai_insight': return <Brain className="w-4 h-4" />;
      case 'social_activity': return <Users className="w-4 h-4" />;
      case 'vip_reward': return <Crown className="w-4 h-4" />;
      case 'compliance_alert': return <Shield className="w-4 h-4" />;
      default: return <Zap className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-winnex-dark text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            Unified Gaming Dashboard
          </h1>
          <p className="text-gray-400 mt-2">
            Complete overview of your betting, gaming, and social activities
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-winnex-gray">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4" />
              <span>Overview</span>
            </TabsTrigger>
            <TabsTrigger value="betting" className="flex items-center space-x-2">
              <Trophy className="w-4 h-4" />
              <span>Betting</span>
            </TabsTrigger>
            <TabsTrigger value="social" className="flex items-center space-x-2">
              <Users className="w-4 h-4" />
              <span>Social</span>
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex items-center space-x-2">
              <Brain className="w-4 h-4" />
              <span>AI Insights</span>
            </TabsTrigger>
            <TabsTrigger value="account" className="flex items-center space-x-2">
              <Shield className="w-4 h-4" />
              <span>Account</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Current Balance</CardTitle>
                  <CreditCard className="h-4 w-4 text-emerald-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-emerald-400">
                    {metricsLoading ? "Loading..." : `$${(metrics?.currentBalance || mockMetrics.currentBalance).toFixed(2)}`}
                  </div>
                  <p className="text-xs text-gray-400">
                    +12.5% from last week
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Win Rate</CardTitle>
                  <Target className="h-4 w-4 text-cyan-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-cyan-400">
                    {metricsLoading ? "Loading..." : `${(metrics?.winRate || mockMetrics.winRate).toFixed(1)}%`}
                  </div>
                  <p className="text-xs text-gray-400">
                    Above average
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Active Bets</CardTitle>
                  <Play className="h-4 w-4 text-yellow-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-yellow-400">
                    {metricsLoading ? "Loading..." : (metrics?.activeBets || mockMetrics.activeBets)}
                  </div>
                  <p className="text-xs text-gray-400">
                    Total potential: $450
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">VIP Status</CardTitle>
                  <Crown className="h-4 w-4 text-purple-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-400">
                    {vipLoading ? "Loading..." : ((vipStatus as any)?.currentTier || mockMetrics.vipTier)}
                  </div>
                  <p className="text-xs text-gray-400">
                    {vipLoading ? "..." : `${(vipStatus as any)?.pointsToNext || 2150} points to ${(vipStatus as any)?.nextTier || "Platinum"}`}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Live Activity Feed */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Zap className="w-5 h-5 text-emerald-400" />
                    <span>Live Updates</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 max-h-96 overflow-y-auto">
                  {liveUpdates.map((update) => (
                    <div key={update.id} className="flex items-start space-x-3 p-3 rounded-lg bg-winnex-dark hover:bg-gray-700 transition-colors">
                      <div className={`${getPriorityColor(update.priority)}`}>
                        {getTypeIcon(update.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white">{update.title}</p>
                        <p className="text-sm text-gray-400">{update.description}</p>
                        <p className="text-xs text-gray-500">{update.timestamp}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Star className="w-5 h-5 text-cyan-400" />
                    <span>Quick Actions</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Button className="h-16 flex flex-col items-center justify-center space-y-2 bg-emerald-600 hover:bg-emerald-700">
                      <Trophy className="w-6 h-6" />
                      <span className="text-sm">Place Bet</span>
                    </Button>
                    <Button className="h-16 flex flex-col items-center justify-center space-y-2 bg-cyan-600 hover:bg-cyan-700">
                      <Brain className="w-6 h-6" />
                      <span className="text-sm">AI Insights</span>
                    </Button>
                    <Button className="h-16 flex flex-col items-center justify-center space-y-2 bg-purple-600 hover:bg-purple-700">
                      <Users className="w-6 h-6" />
                      <span className="text-sm">Social Hub</span>
                    </Button>
                    <Button className="h-16 flex flex-col items-center justify-center space-y-2 bg-yellow-600 hover:bg-yellow-700">
                      <Gamepad2 className="w-6 h-6" />
                      <span className="text-sm">Casino</span>
                    </Button>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-600">
                    <h4 className="text-sm font-medium text-gray-400 mb-3">Responsible Gaming</h4>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-300">Daily Limit Used</span>
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        Safe: 15%
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="betting">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle>Betting Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Total Bets</span>
                      <span className="font-bold">{mockMetrics.totalBets}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Win Rate</span>
                      <span className="font-bold text-emerald-400">{mockMetrics.winRate}%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Total Winnings</span>
                      <span className="font-bold text-emerald-400">${mockMetrics.totalWinnings}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Active Bets</span>
                      <Badge className="bg-yellow-600">{mockMetrics.activeBets}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-winnex-dark">
                      <div>
                        <p className="font-medium">Lakers vs Celtics</p>
                        <p className="text-sm text-gray-400">Over 215.5 Points</p>
                      </div>
                      <Badge className="bg-green-600">Won +$50</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-winnex-dark">
                      <div>
                        <p className="font-medium">Arsenal vs Chelsea</p>
                        <p className="text-sm text-gray-400">Arsenal Win</p>
                      </div>
                      <Badge className="bg-yellow-600">Live</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-winnex-dark">
                      <div>
                        <p className="font-medium">Chiefs vs Bills</p>
                        <p className="text-sm text-gray-400">Chiefs -3.5</p>
                      </div>
                      <Badge className="bg-red-600">Lost -$25</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="social">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="w-5 h-5" />
                    <span>Social Stats</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Followers</span>
                      <span className="font-bold">{mockMetrics.socialFollowers}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Following</span>
                      <span className="font-bold">89</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Tips Shared</span>
                      <span className="font-bold">23</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Community Rank</span>
                      <Badge className="bg-purple-600">#47</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle>Community Feed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3 p-3 rounded-lg bg-winnex-dark">
                      <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold">JP</span>
                      </div>
                      <div>
                        <p className="text-sm"><span className="font-medium">@johnpro</span> shared a tip</p>
                        <p className="text-xs text-gray-400">Lakers +2.5 looks good tonight</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3 p-3 rounded-lg bg-winnex-dark">
                      <div className="w-8 h-8 bg-cyan-600 rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold">SA</span>
                      </div>
                      <div>
                        <p className="text-sm"><span className="font-medium">@sportsace</span> started following you</p>
                        <p className="text-xs text-gray-400">5 minutes ago</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="ai">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="w-5 h-5" />
                    <span>AI Recommendations</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg bg-emerald-600/20 border border-emerald-600/30">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-emerald-400">High Value Bet</span>
                        <Badge className="bg-emerald-600">95% Confidence</Badge>
                      </div>
                      <p className="text-sm text-gray-300">Lakers vs Celtics - Over 215.5</p>
                      <p className="text-xs text-gray-400">Expected value: +18.5%</p>
                    </div>
                    
                    <div className="p-4 rounded-lg bg-yellow-600/20 border border-yellow-600/30">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-yellow-400">Market Inefficiency</span>
                        <Badge className="bg-yellow-600">82% Confidence</Badge>
                      </div>
                      <p className="text-sm text-gray-300">Arsenal Draw vs Chelsea</p>
                      <p className="text-xs text-gray-400">Overvalued by 12%</p>
                    </div>

                    <div className="p-4 rounded-lg bg-cyan-600/20 border border-cyan-600/30">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-cyan-400">Bankroll Alert</span>
                        <Badge className="bg-cyan-600">Advisory</Badge>
                      </div>
                      <p className="text-sm text-gray-300">Consider reducing bet sizes</p>
                      <p className="text-xs text-gray-400">Current streak: 3 losses</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle>Predictive Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-400">Win Probability This Week</span>
                        <span className="text-sm font-medium">73%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-emerald-600 h-2 rounded-full" style={{width: '73%'}}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-400">Optimal Bet Size</span>
                        <span className="text-sm font-medium">$45-65</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-cyan-600 h-2 rounded-full" style={{width: '55%'}}></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-400">Risk Score</span>
                        <span className="text-sm font-medium">Low</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-green-600 h-2 rounded-full" style={{width: '25%'}}></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="account">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="w-5 h-5" />
                    <span>Compliance Status</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">KYC Verification</span>
                      <Badge className="bg-green-600">Verified</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Document Status</span>
                      <Badge className="bg-green-600">Complete</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">AML Check</span>
                      <Badge className="bg-green-600">Passed</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Account Level</span>
                      <Badge className="bg-purple-600">Premium</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-winnex-gray border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Heart className="w-5 h-5" />
                    <span>Responsible Gaming</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-400">Daily Limit</span>
                        <span className="text-sm font-medium">$75 / $500</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-green-600 h-2 rounded-full" style={{width: '15%'}}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-400">Session Time</span>
                        <span className="text-sm font-medium">45 min / 4 hrs</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-yellow-600 h-2 rounded-full" style={{width: '18%'}}></div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-gray-600">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">Wellness Status</span>
                        <Badge className="bg-green-600">Healthy</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}