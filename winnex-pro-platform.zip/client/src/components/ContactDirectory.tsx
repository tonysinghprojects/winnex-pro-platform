import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Mail, Phone, MessageCircle, Users, CreditCard, 
  TrendingUp, Settings, HelpCircle, Building 
} from 'lucide-react';

interface ContactInfo {
  department: string;
  email: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  purposes: string[];
}

export default function ContactDirectory() {
  const contacts: ContactInfo[] = [
    {
      department: 'Account Management',
      email: 'accounts@winnexpro.io',
      description: 'All account-related queries, transactions, deposits, and withdrawals',
      icon: <CreditCard className="h-5 w-5" />,
      color: 'bg-green-100 text-green-800 border-green-300',
      purposes: ['Deposits & Withdrawals', 'Balance Inquiries', 'Transaction History', 'Account Verification']
    },
    {
      department: 'Technical Support',
      email: 'support@winnexpro.io',
      description: '24/7 technical assistance, platform issues, and general support',
      icon: <Settings className="h-5 w-5" />,
      color: 'bg-blue-100 text-blue-800 border-blue-300',
      purposes: ['Platform Issues', 'Login Problems', 'Security Concerns', '2FA Assistance']
    },
    {
      department: 'Trading & Betting',
      email: 'traders@winnexpro.io',
      description: 'Betting assistance, odds queries, market information, and trading support',
      icon: <TrendingUp className="h-5 w-5" />,
      color: 'bg-purple-100 text-purple-800 border-purple-300',
      purposes: ['Betting Questions', 'Odds Inquiries', 'Market Information', 'Cash Out Issues']
    },
    {
      department: 'Sales & Partnerships',
      email: 'sales@winnexpro.io',
      description: 'VIP programs, partnerships, affiliate programs, and premium services',
      icon: <Users className="h-5 w-5" />,
      color: 'bg-gold-100 text-gold-800 border-gold-300',
      purposes: ['VIP Services', 'Partnership Inquiries', 'Affiliate Program', 'Premium Features']
    },
    {
      department: 'General Information',
      email: 'info@winnexpro.io',
      description: 'General platform information, features, and basic inquiries',
      icon: <HelpCircle className="h-5 w-5" />,
      color: 'bg-gray-100 text-gray-800 border-gray-300',
      purposes: ['Platform Info', 'Feature Questions', 'General Inquiries', 'Getting Started']
    },
    {
      department: 'Business Inquiries',
      email: 'enquiries@winnexpro.io',
      description: 'Corporate partnerships, business development, and enterprise solutions',
      icon: <Building className="h-5 w-5" />,
      color: 'bg-indigo-100 text-indigo-800 border-indigo-300',
      purposes: ['Corporate Accounts', 'Business Development', 'Enterprise Solutions', 'White Label']
    },
    {
      department: 'Development Team',
      email: 'developers@winnexpro.io',
      description: 'API documentation, technical integration, and developer resources',
      icon: <MessageCircle className="h-5 w-5" />,
      color: 'bg-red-100 text-red-800 border-red-300',
      purposes: ['API Support', 'Technical Integration', 'Developer Resources', 'Custom Solutions']
    }
  ];

  const handleEmailClick = (email: string, subject?: string) => {
    const mailtoLink = `mailto:${email}${subject ? `?subject=${encodeURIComponent(subject)}` : ''}`;
    window.open(mailtoLink, '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Contact Winnex Pro</h1>
          <p className="text-gray-600">Get in touch with our specialized teams for expert assistance</p>
        </div>

        {/* Quick Contact Bar */}
        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                variant="outline" 
                className="bg-white/20 border-white/30 text-white hover:bg-white/30"
                onClick={() => handleEmailClick('support@winnexpro.io', 'Urgent Support Request')}
              >
                <Phone className="h-4 w-4 mr-2" />
                24/7 Support
              </Button>
              <Button 
                variant="outline" 
                className="bg-white/20 border-white/30 text-white hover:bg-white/30"
                onClick={() => handleEmailClick('accounts@winnexpro.io', 'Account Inquiry')}
              >
                <CreditCard className="h-4 w-4 mr-2" />
                Account Help
              </Button>
              <Button 
                variant="outline" 
                className="bg-white/20 border-white/30 text-white hover:bg-white/30"
                onClick={() => handleEmailClick('traders@winnexpro.io', 'Betting Question')}
              >
                <TrendingUp className="h-4 w-4 mr-2" />
                Betting Support
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Contact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {contacts.map((contact) => (
            <Card key={contact.email} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${contact.color}`}>
                    {contact.icon}
                  </div>
                  <div>
                    <CardTitle className="text-lg">{contact.department}</CardTitle>
                    <CardDescription className="text-sm">{contact.description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <a 
                    href={`mailto:${contact.email}`}
                    className="text-blue-600 hover:text-blue-800 font-medium"
                  >
                    {contact.email}
                  </a>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-700">What we help with:</h4>
                  <div className="flex flex-wrap gap-1">
                    {contact.purposes.map((purpose, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {purpose}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Button 
                  className="w-full" 
                  onClick={() => handleEmailClick(contact.email, `${contact.department} Inquiry`)}
                >
                  <Mail className="h-4 w-4 mr-2" />
                  Send Email
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Emergency Contact */}
        <Card className="bg-red-50 border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <Phone className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <h3 className="font-bold text-red-800">Emergency Security Issues</h3>
                <p className="text-red-600">For immediate security concerns or account compromise:</p>
                <a 
                  href="mailto:support@winnexpro.io?subject=URGENT%20SECURITY%20ALERT"
                  className="text-red-700 font-bold hover:underline"
                >
                  support@winnexpro.io - Mark as URGENT
                </a>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Business Hours */}
        <Card>
          <CardContent className="p-6">
            <h3 className="font-bold text-gray-900 mb-4">Response Times</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-medium text-gray-700">Priority Support</h4>
                <p className="text-gray-600">support@winnexpro.io - Within 1 hour</p>
                <p className="text-gray-600">accounts@winnexpro.io - Within 2 hours</p>
              </div>
              <div>
                <h4 className="font-medium text-gray-700">Standard Response</h4>
                <p className="text-gray-600">All other departments - Within 24 hours</p>
                <p className="text-gray-600">Business hours: 24/7 for critical issues</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}