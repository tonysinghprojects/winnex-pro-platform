import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, TrendingDown, DollarSign, Target, Trophy, 
  Eye, Clock, Zap, Crown, Star, BarChart3, PieChart, Activity
} from "lucide-react";

interface DashboardStats {
  balance: number;
  totalProfit: number;
  totalBets: number;
  winRate: number;
  roi: number;
  avgOdds: number;
  currentStreak: number;
  streakType: 'win' | 'loss';
  weeklyProfit: number;
  monthlyProfit: number;
  todaysBets: number;
  pendingBets: number;
}

interface RecentBet {
  id: string;
  match: string;
  selection: string;
  odds: number;
  stake: number;
  status: 'won' | 'lost' | 'pending' | 'void';
  profit: number;
  timestamp: string;
  sport: string;
}

interface ProfitChart {
  date: string;
  profit: number;
  cumulative: number;
}

interface Goal {
  id: string;
  title: string;
  target: number;
  current: number;
  deadline: string;
  type: 'profit' | 'winrate' | 'volume';
  reward: string;
}

export default function EnhancedDashboard() {
  const [timeRange, setTimeRange] = useState<'today' | 'week' | 'month' | 'year'>('week');
  const [activeTab, setActiveTab] = useState('overview');

  // Mock dashboard data
  const stats: DashboardStats = {
    balance: 2847.50,
    totalProfit: 1542.75,
    totalBets: 247,
    winRate: 68.4,
    roi: 23.8,
    avgOdds: 2.14,
    currentStreak: 8,
    streakType: 'win',
    weeklyProfit: 342.50,
    monthlyProfit: 1249.25,
    todaysBets: 5,
    pendingBets: 3
  };

  const recentBets: RecentBet[] = [
    {
      id: '1',
      match: 'Liverpool vs Arsenal',
      selection: 'Over 2.5 Goals',
      odds: 1.85,
      stake: 50,
      status: 'won',
      profit: 42.50,
      timestamp: '2024-06-14T16:30:00Z',
      sport: 'Football'
    },
    {
      id: '2',
      match: 'Lakers vs Celtics',
      selection: 'Lakers -2.5',
      odds: 1.92,
      stake: 75,
      status: 'pending',
      profit: 0,
      timestamp: '2024-06-14T18:00:00Z',
      sport: 'Basketball'
    },
    {
      id: '3',
      match: 'Chiefs vs Bills',
      selection: 'Chiefs Win',
      odds: 1.75,
      stake: 100,
      status: 'won',
      profit: 75,
      timestamp: '2024-06-14T14:15:00Z',
      sport: 'Football'
    },
    {
      id: '4',
      match: 'Barcelona vs PSG',
      selection: 'Both Teams Score',
      odds: 1.65,
      stake: 25,
      status: 'lost',
      profit: -25,
      timestamp: '2024-06-14T12:45:00Z',
      sport: 'Football'
    }
  ];

  const profitChart: ProfitChart[] = [
    { date: 'Mon', profit: 125, cumulative: 125 },
    { date: 'Tue', profit: 87, cumulative: 212 },
    { date: 'Wed', profit: -45, cumulative: 167 },
    { date: 'Thu', profit: 203, cumulative: 370 },
    { date: 'Fri', profit: 95, cumulative: 465 },
    { date: 'Sat', profit: 156, cumulative: 621 },
    { date: 'Sun', profit: 78, cumulative: 699 }
  ];

  const goals: Goal[] = [
    {
      id: '1',
      title: 'Weekly Profit Target',
      target: 500,
      current: 342.50,
      deadline: '2 days',
      type: 'profit',
      reward: '$50 bonus'
    },
    {
      id: '2',
      title: 'Win Rate Challenge',
      target: 70,
      current: 68.4,
      deadline: '1 week',
      type: 'winrate',
      reward: 'VIP status'
    },
    {
      id: '3',
      title: 'Monthly Volume',
      target: 50,
      current: 37,
      deadline: '2 weeks',
      type: 'volume',
      reward: '5% cashback'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'won': return 'text-green-400';
      case 'lost': return 'text-red-400';
      case 'pending': return 'text-yellow-400';
      case 'void': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'won': return '✅';
      case 'lost': return '❌';
      case 'pending': return '⏳';
      case 'void': return '⭕';
      default: return '';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      {/* Quick Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card className="bg-gradient-to-r from-winnex-green/20 to-green-500/20 border-winnex-green/30">
          <CardContent className="p-4 text-center">
            <DollarSign className="w-6 h-6 mx-auto mb-2 text-winnex-green" />
            <div className="text-2xl font-bold text-winnex-green">{formatCurrency(stats.balance)}</div>
            <div className="text-xs text-gray-400">Balance</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500/20 to-winnex-blue/20 border-blue-500/30">
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-6 h-6 mx-auto mb-2 text-blue-400" />
            <div className="text-2xl font-bold text-blue-400">{formatCurrency(stats.totalProfit)}</div>
            <div className="text-xs text-gray-400">Total Profit</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-500/30">
          <CardContent className="p-4 text-center">
            <Target className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
            <div className="text-2xl font-bold text-yellow-400">{stats.winRate}%</div>
            <div className="text-xs text-gray-400">Win Rate</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-purple-500/30">
          <CardContent className="p-4 text-center">
            <BarChart3 className="w-6 h-6 mx-auto mb-2 text-purple-400" />
            <div className="text-2xl font-bold text-purple-400">{stats.roi}%</div>
            <div className="text-xs text-gray-400">ROI</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-500/20 to-red-500/20 border-orange-500/30">
          <CardContent className="p-4 text-center">
            <Zap className="w-6 h-6 mx-auto mb-2 text-orange-400" />
            <div className="text-2xl font-bold text-orange-400">{stats.currentStreak}</div>
            <div className="text-xs text-gray-400">{stats.streakType} streak</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-cyan-500/30">
          <CardContent className="p-4 text-center">
            <Activity className="w-6 h-6 mx-auto mb-2 text-cyan-400" />
            <div className="text-2xl font-bold text-cyan-400">{stats.totalBets}</div>
            <div className="text-xs text-gray-400">Total Bets</div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 bg-winnex-dark">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Activity */}
            <div className="lg:col-span-2">
              <Card className="bg-winnex-gray border-gray-600">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Recent Bets
                    <Button size="sm" variant="outline" className="border-gray-600">
                      View All
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {recentBets.map((bet) => (
                    <div key={bet.id} className="flex items-center justify-between p-3 bg-winnex-dark rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="font-medium text-sm">{bet.match}</span>
                          <Badge variant="outline" className="text-xs">
                            {bet.sport}
                          </Badge>
                        </div>
                        <div className="text-xs text-gray-400">
                          {bet.selection} @ {bet.odds} • {formatCurrency(bet.stake)}
                        </div>
                        <div className="text-xs text-gray-500">
                          {new Date(bet.timestamp).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="text-sm">{getStatusIcon(bet.status)}</span>
                          <span className={`text-sm font-medium ${getStatusColor(bet.status)}`}>
                            {bet.status.toUpperCase()}
                          </span>
                        </div>
                        <div className={`text-sm font-bold ${
                          bet.profit > 0 ? 'text-green-400' : 
                          bet.profit < 0 ? 'text-red-400' : 'text-gray-400'
                        }`}>
                          {bet.profit > 0 ? '+' : ''}{formatCurrency(bet.profit)}
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="space-y-4">
              <Card className="bg-winnex-gray border-gray-600">
                <CardHeader>
                  <CardTitle className="text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full bg-winnex-green text-black hover:bg-green-400">
                    Place Quick Bet
                  </Button>
                  <Button className="w-full bg-winnex-blue text-white hover:bg-blue-400">
                    View Live Matches
                  </Button>
                  <Button className="w-full bg-orange-500 text-white hover:bg-orange-400">
                    Crypto Deposit
                  </Button>
                  <Button variant="outline" className="w-full border-gray-600">
                    Cash Out Bets
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-500/30">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Crown className="w-5 h-5 mr-2 text-yellow-400" />
                    VIP Progress
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Next Tier: Platinum</span>
                      <span>78%</span>
                    </div>
                    <Progress value={78} className="h-2" />
                    <div className="text-xs text-gray-400">
                      $1,200 more volume needed
                    </div>
                  </div>
                  <div className="space-y-1 text-sm">
                    <div className="text-yellow-400 font-medium">Current Benefits:</div>
                    <ul className="text-xs text-gray-300 space-y-1">
                      <li>• 2% daily cashback</li>
                      <li>• Priority support</li>
                      <li>• Exclusive promotions</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Profit Chart */}
            <Card className="bg-winnex-gray border-gray-600">
              <CardHeader>
                <CardTitle>Weekly Profit Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {profitChart.map((day, index) => (
                    <div key={day.date} className="flex items-center justify-between">
                      <span className="text-sm font-medium">{day.date}</span>
                      <div className="flex items-center space-x-4">
                        <div className={`text-sm font-medium ${
                          day.profit > 0 ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {day.profit > 0 ? '+' : ''}{formatCurrency(day.profit)}
                        </div>
                        <div className="w-24 bg-winnex-dark rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              day.profit > 0 ? 'bg-green-400' : 'bg-red-400'
                            }`}
                            style={{ width: `${Math.abs(day.profit) / 250 * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            <Card className="bg-winnex-gray border-gray-600">
              <CardHeader>
                <CardTitle>Performance Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-winnex-dark rounded-lg">
                    <div className="text-lg font-bold text-winnex-green">{formatCurrency(stats.weeklyProfit)}</div>
                    <div className="text-xs text-gray-400">This Week</div>
                  </div>
                  <div className="text-center p-3 bg-winnex-dark rounded-lg">
                    <div className="text-lg font-bold text-winnex-blue">{formatCurrency(stats.monthlyProfit)}</div>
                    <div className="text-xs text-gray-400">This Month</div>
                  </div>
                  <div className="text-center p-3 bg-winnex-dark rounded-lg">
                    <div className="text-lg font-bold text-yellow-400">{stats.avgOdds}</div>
                    <div className="text-xs text-gray-400">Avg Odds</div>
                  </div>
                  <div className="text-center p-3 bg-winnex-dark rounded-lg">
                    <div className="text-lg font-bold text-orange-400">{stats.todaysBets}</div>
                    <div className="text-xs text-gray-400">Today's Bets</div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Win Rate Progress</span>
                      <span>{stats.winRate}%</span>
                    </div>
                    <Progress value={stats.winRate} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>ROI Performance</span>
                      <span>{stats.roi}%</span>
                    </div>
                    <Progress value={stats.roi > 25 ? 100 : (stats.roi / 25) * 100} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="goals" className="space-y-4">
          <div className="grid gap-4">
            {goals.map((goal) => (
              <Card key={goal.id} className="bg-winnex-gray border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-medium">{goal.title}</h3>
                      <p className="text-sm text-gray-400">Deadline: {goal.deadline}</p>
                    </div>
                    <Badge className="bg-winnex-green text-black">
                      {goal.reward}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>
                        {goal.current}{goal.type === 'winrate' ? '%' : goal.type === 'profit' ? '' : ' bets'} / 
                        {goal.target}{goal.type === 'winrate' ? '%' : goal.type === 'profit' ? '' : ' bets'}
                      </span>
                    </div>
                    <Progress 
                      value={(goal.current / goal.target) * 100} 
                      className="h-3"
                    />
                    <div className="text-xs text-gray-400">
                      {((goal.current / goal.target) * 100).toFixed(1)}% complete
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid gap-4">
            <Card className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border-blue-500/30">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="w-5 h-5 mr-2 text-blue-400" />
                  AI Performance Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Optimal Betting Times</div>
                    <div className="text-xs text-gray-400">
                      • Weekends: 2-6 PM (78% win rate)<br/>
                      • Live betting: During 2nd half (65% win rate)<br/>
                      • Value bets: Tuesday-Thursday (best odds)
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Strength Analysis</div>
                    <div className="text-xs text-gray-400">
                      • Football totals: 73% accuracy<br/>
                      • Basketball spreads: 69% accuracy<br/>
                      • Live betting: 62% accuracy
                    </div>
                  </div>
                </div>
                
                <div className="bg-winnex-dark rounded-lg p-3">
                  <div className="font-medium text-sm text-winnex-green mb-2">AI Recommendation</div>
                  <div className="text-sm text-gray-300">
                    Focus on football over/under bets during weekend prime time. 
                    Your historical data shows 78% success rate in this category. 
                    Consider reducing live betting volume to improve overall ROI.
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-winnex-gray border-gray-600">
              <CardHeader>
                <CardTitle>Risk Management Alert</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
                    <div>
                      <div className="font-medium text-green-400">Bankroll Health: Excellent</div>
                      <div className="text-sm text-gray-400">Current risk level: Low</div>
                    </div>
                    <div className="text-green-400">✅</div>
                  </div>
                  
                  <div className="text-sm text-gray-300">
                    <strong>Recommended Actions:</strong><br/>
                    • Maintain current stake sizing (2-3% of bankroll)<br/>
                    • Continue diversifying across sports<br/>
                    • Consider increasing stakes on high-confidence AI picks
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}