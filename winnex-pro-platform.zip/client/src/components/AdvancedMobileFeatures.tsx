import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Smartphone, Fingerprint, Eye, Wifi, WifiOff, Clock, Bell, Gamepad2, Camera } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface BiometricAuth {
  available: boolean;
  enabled: boolean;
  types: Array<'fingerprint' | 'faceId' | 'voiceId' | 'iris'>;
  lastUsed: string;
  securityLevel: 'basic' | 'enhanced' | 'military';
  failedAttempts: number;
  lockoutUntil?: string;
}

interface OfflineBet {
  id: string;
  matchId: number;
  selection: string;
  odds: number;
  stake: number;
  timestamp: string;
  status: 'pending_sync' | 'synced' | 'failed';
  estimatedReturn: number;
  deviceId: string;
}

interface PushNotification {
  id: string;
  type: 'odds_change' | 'bet_result' | 'promotion' | 'live_score' | 'cash_out';
  title: string;
  message: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  scheduledFor?: string;
  delivered: boolean;
  opened: boolean;
  actionData?: any;
  personalizedContent: {
    userSegment: string;
    interests: string[];
    optimalTime: string;
    engagement_score: number;
  };
}

interface ARVRExperience {
  id: string;
  title: string;
  description: string;
  type: 'ar_stats_overlay' | 'vr_stadium' | 'ar_live_odds' | 'vr_social_lounge';
  device_compatibility: string[];
  availability: 'live' | 'coming_soon' | 'beta';
  participants: number;
  rating: number;
  features: string[];
  requirements: {
    bandwidth: string;
    device_specs: string;
    sensor_access: string[];
  };
}

interface SmartTiming {
  optimalBettingWindows: Array<{
    sport: string;
    timeframe: string;
    probability: number;
    reasoning: string;
  }>;
  userBehaviorPattern: {
    mostActiveHours: string[];
    preferredDays: string[];
    sessionDuration: number;
    engagementScore: number;
  };
  nextRecommendedSession: {
    datetime: string;
    duration: string;
    reasoning: string;
    expectedMatches: number;
  };
}

export default function AdvancedMobileFeatures() {
  const [isOffline, setIsOffline] = useState(false);
  const [biometricSupported, setBiometricSupported] = useState(false);
  const [arSupported, setArSupported] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    // Check for offline status
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Check for biometric support (Web Authentication API)
    if (navigator.credentials && 'create' in navigator.credentials) {
      setBiometricSupported(true);
    }
    
    // Check for AR/VR support
    if ('xr' in navigator) {
      setBiometricSupported(true);
    }
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const { data: biometricAuth } = useQuery({
    queryKey: ['/api/mobile/biometric-auth'],
    queryFn: () => apiRequest('/api/mobile/biometric-auth'),
  });

  const { data: offlineBets } = useQuery({
    queryKey: ['/api/mobile/offline-bets'],
    queryFn: () => apiRequest('/api/mobile/offline-bets'),
  });

  const { data: pushNotifications } = useQuery({
    queryKey: ['/api/mobile/push-notifications'],
    queryFn: () => apiRequest('/api/mobile/push-notifications'),
  });

  const { data: arvrExperiences } = useQuery({
    queryKey: ['/api/mobile/arvr-experiences'],
    queryFn: () => apiRequest('/api/mobile/arvr-experiences'),
  });

  const { data: smartTiming } = useQuery({
    queryKey: ['/api/mobile/smart-timing'],
    queryFn: () => apiRequest('/api/mobile/smart-timing'),
  });

  const enableBiometricMutation = useMutation({
    mutationFn: (authType: string) =>
      apiRequest('/api/mobile/enable-biometric', 'POST', { authType }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mobile/biometric-auth'] });
    },
  });

  const syncOfflineBetsMutation = useMutation({
    mutationFn: () => apiRequest('/api/mobile/sync-offline-bets', 'POST'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mobile/offline-bets'] });
    },
  });

  const launchARExperienceMutation = useMutation({
    mutationFn: (experienceId: string) =>
      apiRequest('/api/mobile/launch-ar-experience', 'POST', { experienceId }),
  });

  const scheduleNotificationMutation = useMutation({
    mutationFn: (data: { type: string; scheduleTime: string; content: any }) =>
      apiRequest('/api/mobile/schedule-notification', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mobile/push-notifications'] });
    },
  });

  const handleBiometricAuth = async (type: string) => {
    if (!biometricSupported) {
      alert('Biometric authentication not supported on this device');
      return;
    }

    try {
      const credential = await navigator.credentials.create({
        publicKey: {
          challenge: new Uint8Array(32),
          rp: { name: "Winnex" },
          user: {
            id: new Uint8Array(16),
            name: "user@winnex.com",
            displayName: "Winnex User"
          },
          pubKeyCredParams: [{ alg: -7, type: "public-key" }],
          authenticatorSelection: {
            authenticatorAttachment: "platform",
            userVerification: "required"
          },
          timeout: 60000,
          attestation: "direct"
        }
      });

      if (credential) {
        enableBiometricMutation.mutate(type);
      }
    } catch (error) {
      console.error('Biometric authentication failed:', error);
    }
  };

  const launchARExperience = async (experienceId: string) => {
    if (!arSupported) {
      alert('AR/VR not supported on this device');
      return;
    }

    try {
      const session = await (navigator as any).xr?.requestSession('immersive-ar', {
        requiredFeatures: ['local', 'hit-test'],
        optionalFeatures: ['dom-overlay', 'light-estimation']
      });

      if (session) {
        launchARExperienceMutation.mutate(experienceId);
      }
    } catch (error) {
      console.error('AR experience launch failed:', error);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'odds_change': return <TrendingUp className="h-5 w-5 text-blue-400" />;
      case 'bet_result': return <CheckCircle className="h-5 w-5 text-green-400" />;
      case 'live_score': return <Activity className="h-5 w-5 text-yellow-400" />;
      case 'cash_out': return <DollarSign className="h-5 w-5 text-purple-400" />;
      default: return <Bell className="h-5 w-5 text-gray-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Advanced Mobile Features</h1>
          <p className="text-slate-300">Next-generation mobile betting with biometrics, offline mode, and AR/VR</p>
        </div>

        {/* Connection Status Alert */}
        {isOffline && (
          <Alert className="mb-6 bg-orange-900/20 border-orange-500/20">
            <WifiOff className="h-4 w-4" />
            <AlertDescription className="text-orange-300">
              You're currently offline. Bets will be queued and synced when connection is restored.
            </AlertDescription>
          </Alert>
        )}

        {/* Mobile Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/20 border-green-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Biometric Logins</p>
                  <p className="text-3xl font-bold text-white">847</p>
                </div>
                <Fingerprint className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-blue-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 text-sm font-medium">Offline Bets</p>
                  <p className="text-3xl font-bold text-white">{offlineBets?.filter((bet: OfflineBet) => bet.status === 'pending_sync').length || 0}</p>
                </div>
                <WifiOff className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-purple-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-400 text-sm font-medium">AR Sessions</p>
                  <p className="text-3xl font-bold text-white">23</p>
                </div>
                <Camera className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-yellow-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-400 text-sm font-medium">Push Notifications</p>
                  <p className="text-3xl font-bold text-white">{pushNotifications?.filter((n: PushNotification) => !n.opened).length || 0}</p>
                </div>
                <Bell className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="biometric" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="biometric" className="data-[state=active]:bg-green-500/20">
              Biometric Auth
            </TabsTrigger>
            <TabsTrigger value="offline" className="data-[state=active]:bg-green-500/20">
              Offline Mode
            </TabsTrigger>
            <TabsTrigger value="notifications" className="data-[state=active]:bg-green-500/20">
              Smart Notifications
            </TabsTrigger>
            <TabsTrigger value="arvr" className="data-[state=active]:bg-green-500/20">
              AR/VR Experiences
            </TabsTrigger>
            <TabsTrigger value="timing" className="data-[state=active]:bg-green-500/20">
              Smart Timing
            </TabsTrigger>
          </TabsList>

          <TabsContent value="biometric" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Biometric Authentication</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${biometricAuth?.available ? 'bg-green-500' : 'bg-red-500'}`} />
                      <span className="text-white">Device Support</span>
                    </div>
                    <Badge className={biometricAuth?.available ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}>
                      {biometricAuth?.available ? 'Available' : 'Not Available'}
                    </Badge>
                  </div>

                  {biometricAuth?.available && (
                    <>
                      <div className="space-y-3">
                        <h4 className="text-white font-medium">Available Authentication Methods</h4>
                        {biometricAuth.types.map((type: string) => (
                          <div key={type} className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                            <div className="flex items-center space-x-3">
                              {type === 'fingerprint' && <Fingerprint className="h-5 w-5 text-blue-400" />}
                              {type === 'faceId' && <Eye className="h-5 w-5 text-green-400" />}
                              {type === 'voiceId' && <Mic className="h-5 w-5 text-purple-400" />}
                              {type === 'iris' && <Eye className="h-5 w-5 text-yellow-400" />}
                              <span className="text-white capitalize">{type.replace('Id', ' ID')}</span>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => handleBiometricAuth(type)}
                              className="bg-green-500/20 border border-green-500/30 text-green-400 hover:bg-green-500/30"
                            >
                              {biometricAuth.enabled ? 'Enabled' : 'Enable'}
                            </Button>
                          </div>
                        ))}
                      </div>

                      <div className="p-4 bg-slate-800/30 rounded-lg">
                        <h4 className="text-white font-medium mb-3">Security Settings</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-slate-300">Security Level</span>
                            <Badge className={`${
                              biometricAuth.securityLevel === 'military' ? 'bg-red-500/20 text-red-400' :
                              biometricAuth.securityLevel === 'enhanced' ? 'bg-yellow-500/20 text-yellow-400' :
                              'bg-green-500/20 text-green-400'
                            }`}>
                              {biometricAuth.securityLevel}
                            </Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-300">Failed Attempts</span>
                            <span className="text-white">{biometricAuth.failedAttempts}/5</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-300">Last Used</span>
                            <span className="text-white">{new Date(biometricAuth.lastUsed).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Security Features</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <h4 className="text-green-400 font-medium mb-2">Advanced Security</h4>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Liveness detection to prevent spoofing</li>
                      <li>• Multi-factor biometric combination</li>
                      <li>• Behavioral biometrics analysis</li>
                      <li>• Hardware security module integration</li>
                    </ul>
                  </div>

                  <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                    <h4 className="text-blue-400 font-medium mb-2">Privacy Protection</h4>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Biometric data stored locally only</li>
                      <li>• End-to-end encryption</li>
                      <li>• No cloud storage of biometric templates</li>
                      <li>• GDPR compliant data handling</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="offline" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-white">Offline Betting Queue</CardTitle>
                      <Button
                        onClick={() => syncOfflineBetsMutation.mutate()}
                        className="bg-blue-500 hover:bg-blue-600"
                        disabled={isOffline}
                      >
                        <Wifi className="h-4 w-4 mr-2" />
                        Sync Now
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {offlineBets?.map((bet: OfflineBet) => (
                        <div key={bet.id} className="p-4 bg-slate-800/30 rounded-lg border border-slate-600/30">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <p className="text-white font-medium">Match {bet.matchId}</p>
                              <p className="text-slate-400 text-sm">{bet.selection} @ {bet.odds}</p>
                            </div>
                            <Badge className={`${
                              bet.status === 'synced' ? 'bg-green-500/20 text-green-400' :
                              bet.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                              'bg-yellow-500/20 text-yellow-400'
                            }`}>
                              {bet.status.replace('_', ' ')}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <p className="text-slate-400">Stake</p>
                              <p className="text-white font-bold">${bet.stake}</p>
                            </div>
                            <div>
                              <p className="text-slate-400">Potential Return</p>
                              <p className="text-green-400 font-bold">${bet.estimatedReturn}</p>
                            </div>
                            <div>
                              <p className="text-slate-400">Placed</p>
                              <p className="text-white">{new Date(bet.timestamp).toLocaleTimeString()}</p>
                            </div>
                          </div>
                        </div>
                      ))}

                      {(!offlineBets || offlineBets.length === 0) && (
                        <div className="text-center py-8">
                          <WifiOff className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                          <p className="text-slate-400">No offline bets in queue</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Offline Capabilities</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <h4 className="text-green-400 font-medium mb-2">Available Offline</h4>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• View betting history</li>
                      <li>• Browse cached odds</li>
                      <li>• Place bets (queued)</li>
                      <li>• Access account balance</li>
                      <li>• Read betting tips</li>
                    </ul>
                  </div>

                  <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                    <h4 className="text-yellow-400 font-medium mb-2">Auto-Sync Features</h4>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Queue bets when offline</li>
                      <li>• Sync when connection restored</li>
                      <li>• Verify odds before placement</li>
                      <li>• Update cached content</li>
                    </ul>
                  </div>

                  <div className="p-3 bg-slate-800/30 rounded-lg">
                    <h4 className="text-white font-medium mb-2">Storage Usage</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-300">Cached Data</span>
                        <span className="text-white">45.2 MB</span>
                      </div>
                      <Progress value={65} className="h-2" />
                      <p className="text-xs text-slate-400">65% of available cache</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6">
            <div className="space-y-4">
              {pushNotifications?.map((notification: PushNotification) => (
                <Card key={notification.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0">
                        {getNotificationIcon(notification.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-white font-medium">{notification.title}</h3>
                          <div className="flex items-center space-x-2">
                            <Badge className={`${
                              notification.priority === 'urgent' ? 'bg-red-500/20 text-red-400' :
                              notification.priority === 'high' ? 'bg-orange-500/20 text-orange-400' :
                              notification.priority === 'normal' ? 'bg-blue-500/20 text-blue-400' :
                              'bg-gray-500/20 text-gray-400'
                            }`}>
                              {notification.priority}
                            </Badge>
                            {!notification.opened && (
                              <div className="w-2 h-2 bg-green-500 rounded-full" />
                            )}
                          </div>
                        </div>
                        <p className="text-slate-300 mb-3">{notification.message}</p>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-slate-400">User Segment</p>
                            <p className="text-white">{notification.personalizedContent.userSegment}</p>
                          </div>
                          <div>
                            <p className="text-slate-400">Optimal Time</p>
                            <p className="text-white">{notification.personalizedContent.optimalTime}</p>
                          </div>
                          <div>
                            <p className="text-slate-400">Engagement Score</p>
                            <p className="text-blue-400">{notification.personalizedContent.engagement_score}%</p>
                          </div>
                          <div>
                            <p className="text-slate-400">Status</p>
                            <p className={notification.delivered ? 'text-green-400' : 'text-yellow-400'}>
                              {notification.delivered ? 'Delivered' : 'Pending'}
                            </p>
                          </div>
                        </div>

                        {notification.personalizedContent.interests.length > 0 && (
                          <div className="mt-3">
                            <p className="text-slate-400 text-sm mb-1">Targeted Interests:</p>
                            <div className="flex flex-wrap gap-1">
                              {notification.personalizedContent.interests.map((interest, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {interest}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="arvr" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {arvrExperiences?.map((experience: ARVRExperience) => (
                <Card key={experience.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-white">{experience.title}</CardTitle>
                        <p className="text-slate-400 text-sm">{experience.description}</p>
                      </div>
                      <Badge className={`${
                        experience.availability === 'live' ? 'bg-green-500/20 text-green-400' :
                        experience.availability === 'beta' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-blue-500/20 text-blue-400'
                      }`}>
                        {experience.availability}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Participants</p>
                        <p className="text-white font-bold">{experience.participants}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Rating</p>
                        <div className="flex items-center space-x-1">
                          <span className="text-yellow-400 font-bold">{experience.rating}</span>
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className={`h-3 w-3 ${i < experience.rating ? 'text-yellow-400 fill-current' : 'text-gray-400'}`} />
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">Features</p>
                      <div className="flex flex-wrap gap-1">
                        {experience.features.map((feature, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="p-3 bg-slate-800/30 rounded-lg">
                      <p className="text-slate-400 text-sm mb-2">Requirements</p>
                      <div className="space-y-1 text-xs text-slate-300">
                        <p>• Bandwidth: {experience.requirements.bandwidth}</p>
                        <p>• Device: {experience.requirements.device_specs}</p>
                        <p>• Sensors: {experience.requirements.sensor_access.join(', ')}</p>
                      </div>
                    </div>

                    <Button
                      className="w-full bg-purple-500 hover:bg-purple-600"
                      onClick={() => launchARExperience(experience.id)}
                      disabled={experience.availability !== 'live'}
                    >
                      <Gamepad2 className="h-4 w-4 mr-2" />
                      {experience.availability === 'live' ? 'Launch Experience' : 
                       experience.availability === 'beta' ? 'Join Beta' : 'Coming Soon'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="timing" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Optimal Betting Windows</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {smartTiming?.optimalBettingWindows?.map((window: any, index: number) => (
                      <div key={index} className="p-4 bg-slate-800/30 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="text-white font-medium">{window.sport}</h4>
                          <Badge className="bg-green-500/20 text-green-400">
                            {window.probability}% optimal
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-slate-400">Time Window</p>
                            <p className="text-white">{window.timeframe}</p>
                          </div>
                          <div>
                            <p className="text-slate-400">Reasoning</p>
                            <p className="text-slate-300">{window.reasoning}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Your Betting Pattern</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-slate-800/30 rounded-lg">
                    <h4 className="text-white font-medium mb-3">Behavior Analysis</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-slate-300">Most Active Hours</span>
                        <span className="text-white">{smartTiming?.userBehaviorPattern?.mostActiveHours?.join(', ')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-300">Preferred Days</span>
                        <span className="text-white">{smartTiming?.userBehaviorPattern?.preferredDays?.join(', ')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-300">Avg Session</span>
                        <span className="text-white">{smartTiming?.userBehaviorPattern?.sessionDuration} min</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-300">Engagement Score</span>
                        <span className="text-green-400">{smartTiming?.userBehaviorPattern?.engagementScore}/100</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                    <h4 className="text-blue-400 font-medium mb-2">Next Recommended Session</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-300">Date & Time</span>
                        <span className="text-white">{smartTiming?.nextRecommendedSession?.datetime}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-300">Duration</span>
                        <span className="text-white">{smartTiming?.nextRecommendedSession?.duration}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-300">Expected Matches</span>
                        <span className="text-white">{smartTiming?.nextRecommendedSession?.expectedMatches}</span>
                      </div>
                      <p className="text-slate-300 text-xs mt-2">{smartTiming?.nextRecommendedSession?.reasoning}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}