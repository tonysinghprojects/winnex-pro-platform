import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { 
  Trophy, 
  Activity, 
  Dice1, 
  Gamepad2, 
  Gift,
  Volleyball,
  Users,
  Home,
  User,
  Menu,
  X,
  Brain,
  Crown,
  Play,
  DollarSign,
  MessageCircle,
  Shield,
  Heart,
  ChevronDown
} from "lucide-react";
import { useState, useEffect, useRef } from "react";
import Sidebar from "./Sidebar";
import BetSlip from "./BetSlip";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const { user } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const { data: balance = { balance: "0.00" } } = useQuery({
    queryKey: ["/api/user/balance"],
    enabled: !!user,
  });

  const { data: sports = [] } = useQuery({
    queryKey: ["/api/sports"],
  });

  const navigate = (path: string) => {
    if ((window as any).navigateTo) {
      (window as any).navigateTo(path);
    } else {
      window.location.href = path;
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpenDropdown(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const navigationGroups = [
    { name: "Home", href: "/", icon: Home, current: location === "/" },
    { name: "Dashboard", href: "/integrated-dashboard", icon: Activity, current: location === "/integrated-dashboard" },
    {
      name: "Betting",
      icon: Trophy,
      dropdown: [
        { name: "Sports", href: "/sports", icon: Volleyball, current: location === "/sports" },
        { name: "Live Betting", href: "/live", icon: Activity, current: location === "/live" },
        { name: "Fantasy Sports", href: "/fantasy-sports", icon: Trophy, current: location === "/fantasy-sports" },
        { name: "Social Betting", href: "/social-betting", icon: MessageCircle, current: location === "/social-betting" },
      ]
    },
    {
      name: "Gaming",
      icon: Dice1,
      dropdown: [
        { name: "Casino", href: "/casino", icon: Dice1, current: location === "/casino" },
        { name: "Esports", href: "/esports", icon: Gamepad2, current: location === "/esports" },
        { name: "Live Streaming", href: "/streaming", icon: Play, current: location === "/streaming" },
      ]
    },
    {
      name: "Services",
      icon: Users,
      dropdown: [
        { name: "AI Assistant", href: "/ai-assistant", icon: Brain, current: location === "/ai-assistant" },
        { name: "VIP Program", href: "/vip", icon: Crown, current: location === "/vip" },
        { name: "Payments", href: "/payments", icon: DollarSign, current: location === "/payments" },
        { name: "Promotions", href: "/promotions", icon: Gift, current: location === "/promotions" },
      ]
    },
    {
      name: "Business",
      icon: Shield,
      dropdown: [
        { name: "Affiliate Program", href: "/affiliate-program", icon: Users, current: location === "/affiliate-program" },
        { name: "Responsible Gaming", href: "/responsible-gambling", icon: Heart, current: location === "/responsible-gambling" },
        { name: "Compliance", href: "/compliance", icon: Shield, current: location === "/compliance" },
      ]
    },
  ];

  return (
    <div className="min-h-screen bg-winnex-dark text-white">
      {/* Header */}
      <header className="bg-winnex-gray border-b border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <button className="flex items-center" onClick={() => navigate('/')}>
                <div className="w-10 h-10 mr-3 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-black text-lg">W</span>
                </div>
                <span className="text-2xl font-light text-white tracking-wide">
                  WIN<span className="font-black text-green-400">NEX</span>
                </span>
              </button>
              <nav className="hidden md:flex space-x-6">
                {navigationGroups.map((item) => (
                  item.dropdown ? (
                    <div key={item.name} className="relative" ref={dropdownRef}>
                      <button
                        className={`flex items-center space-x-1 transition-colors ${
                          item.dropdown.some(sub => sub.current)
                            ? "text-winnex-green font-medium" 
                            : "hover:text-winnex-green"
                        }`}
                        onClick={() => setOpenDropdown(openDropdown === item.name ? null : item.name)}
                      >
                        <item.icon className="w-4 h-4" />
                        <span>{item.name}</span>
                        <ChevronDown className="w-3 h-3" />
                      </button>
                      {openDropdown === item.name && (
                        <div className="absolute top-full left-0 mt-2 w-48 bg-winnex-gray border border-gray-600 rounded-lg shadow-lg z-50">
                          {item.dropdown.map((subItem) => (
                            <button 
                              key={subItem.name} 
                              className={`w-full text-left flex items-center space-x-2 px-4 py-3 transition-colors hover:bg-winnex-dark cursor-pointer ${
                                subItem.current 
                                  ? "text-winnex-green bg-winnex-dark" 
                                  : "text-gray-300"
                              }`}
                              onClick={() => {
                                navigate(subItem.href);
                                setOpenDropdown(null);
                              }}
                            >
                              <subItem.icon className="w-4 h-4" />
                              <span>{subItem.name}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <button 
                      key={item.name} 
                      className={`flex items-center space-x-1 transition-colors cursor-pointer ${
                        item.current 
                          ? "text-winnex-green font-medium" 
                          : "hover:text-winnex-green"
                      }`}
                      onClick={() => navigate(item.href)}
                    >
                      <item.icon className="w-4 h-4" />
                      <span>{item.name}</span>
                    </button>
                  )
                ))}
              </nav>
            </div>
            
            <div className="flex items-center space-x-4">
              {user && (
                <div className="hidden md:flex items-center space-x-2 bg-winnex-dark px-3 py-2 rounded-lg">
                  <i className="fas fa-wallet text-winnex-green"></i>
                  <span>${balance.balance}</span>
                </div>
              )}
              <button className="bg-winnex-green text-black hover:bg-green-400 px-4 py-2 rounded-md font-medium transition-colors" onClick={() => navigate('/deposit')}>
                Deposit
              </button>
              
              {user ? (
                <div className="flex items-center space-x-2">
                  <img
                    src={user.profileImageUrl || `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40`}
                    alt={user.firstName || "User"}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="hidden md:block">
                    <button className="text-sm hover:text-winnex-green cursor-pointer" onClick={() => navigate('/profile')}>
                      {user.firstName} {user.lastName}
                    </button>
                  </div>
                </div>
              ) : (
                <Button
                  onClick={() => window.location.href = "/api/login"}
                  variant="outline"
                  className="border-winnex-green text-winnex-green hover:bg-winnex-green hover:text-black"
                >
                  Sign In
                </Button>
              )}
              
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X /> : <Menu />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex min-h-screen">
        {/* Sidebar */}
        <Sidebar sports={sports} />

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>

        {/* Bet Slip */}
        <div className="hidden xl:block w-80">
          <BetSlip />
        </div>
      </div>

      {/* Mobile Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-winnex-gray border-t border-gray-700 px-4 py-2 z-40">
        <div className="flex justify-around">
          <button className={`flex flex-col items-center py-2 cursor-pointer ${
            location === "/" ? "text-winnex-green" : "text-gray-400"
          }`} onClick={() => navigate('/')}>
            <Home size={20} />
            <span className="text-xs mt-1">Home</span>
          </button>
          <button className={`flex flex-col items-center py-2 cursor-pointer ${
            location === "/integrated-dashboard" ? "text-winnex-green" : "text-gray-400"
          }`} onClick={() => navigate('/integrated-dashboard')}>
            <Activity size={20} />
            <span className="text-xs mt-1">Dashboard</span>
          </button>
          <button
            className={`flex flex-col items-center py-2 ${
              ["/sports", "/live", "/fantasy-sports", "/social-betting"].includes(location) ? "text-winnex-green" : "text-gray-400"
            }`}
            onClick={() => setOpenDropdown(openDropdown === "mobile-betting" ? null : "mobile-betting")}
          >
            <Trophy size={20} />
            <span className="text-xs mt-1">Betting</span>
          </button>
          <button
            className={`flex flex-col items-center py-2 ${
              ["/casino", "/esports", "/streaming"].includes(location) ? "text-winnex-green" : "text-gray-400"
            }`}
            onClick={() => setOpenDropdown(openDropdown === "mobile-gaming" ? null : "mobile-gaming")}
          >
            <Dice1 size={20} />
            <span className="text-xs mt-1">Gaming</span>
          </button>
          <button className={`flex flex-col items-center py-2 cursor-pointer ${
            location === "/profile" ? "text-winnex-green" : "text-gray-400"
          }`} onClick={() => navigate('/profile')}>
            <User size={20} />
            <span className="text-xs mt-1">Account</span>
          </button>
        </div>
        
        {/* Mobile Dropdown Overlays */}
        {openDropdown === "mobile-betting" && (
          <div className="fixed bottom-16 left-0 right-0 bg-winnex-gray border-t border-gray-600 p-4 z-50">
            <div className="grid grid-cols-2 gap-4">
              <button className="flex items-center space-x-2 p-3 rounded-lg bg-winnex-dark hover:bg-gray-600 cursor-pointer" onClick={() => navigate('/sports')}>
                <Volleyball className="w-5 h-5" />
                <span>Sports</span>
              </button>
              <button className="flex items-center space-x-2 p-3 rounded-lg bg-winnex-dark hover:bg-gray-600 cursor-pointer" onClick={() => navigate('/live')}>
                <Activity className="w-5 h-5" />
                <span>Live Betting</span>
              </button>
              <button className="flex items-center space-x-2 p-3 rounded-lg bg-winnex-dark hover:bg-gray-600 cursor-pointer" onClick={() => navigate('/fantasy-sports')}>
                <Trophy className="w-5 h-5" />
                <span>Fantasy Sports</span>
              </button>
              <button className="flex items-center space-x-2 p-3 rounded-lg bg-winnex-dark hover:bg-gray-600 cursor-pointer" onClick={() => navigate('/social-betting')}>
                <MessageCircle className="w-5 h-5" />
                <span>Social Betting</span>
              </button>
            </div>
          </div>
        )}
        
        {openDropdown === "mobile-gaming" && (
          <div className="fixed bottom-16 left-0 right-0 bg-winnex-gray border-t border-gray-600 p-4 z-50">
            <div className="grid grid-cols-2 gap-4">
              <button className="flex items-center space-x-2 p-3 rounded-lg bg-winnex-dark hover:bg-gray-600 cursor-pointer" onClick={() => navigate('/casino')}>
                <Dice1 className="w-5 h-5" />
                <span>Casino</span>
              </button>
              <button className="flex items-center space-x-2 p-3 rounded-lg bg-winnex-dark hover:bg-gray-600 cursor-pointer" onClick={() => navigate('/esports')}>
                <Gamepad2 className="w-5 h-5" />
                <span>Esports</span>
              </button>
              <button className="flex items-center space-x-2 p-3 rounded-lg bg-winnex-dark hover:bg-gray-600 cursor-pointer" onClick={() => navigate('/streaming')}>
                <Play className="w-5 h-5" />
                <span>Live Streaming</span>
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Floating Chat Widget */}
      <div className="fixed bottom-20 right-4 z-50">
        <Button
          size="lg"
          className="w-14 h-14 rounded-full bg-winnex-green text-black hover:bg-green-400 shadow-lg"
        >
          <i className="fas fa-comments text-xl"></i>
        </Button>
      </div>
    </div>
  );
}