import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Zap, TrendingUp, Cpu, HardDrive, Wifi, Database,
  Clock, Activity, CheckCircle, AlertTriangle, Settings
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

interface PerformanceMetric {
  timestamp: string;
  api_response: number;
  database_query: number;
  memory_usage: number;
  cpu_usage: number;
  throughput: number;
}

interface OptimizationRule {
  id: string;
  name: string;
  category: 'caching' | 'database' | 'api' | 'frontend';
  enabled: boolean;
  impact: 'low' | 'medium' | 'high';
  description: string;
  performance_gain: number;
}

export default function PerformanceOptimizer() {
  const [metrics, setMetrics] = useState<PerformanceMetric[]>([]);
  const [optimizations, setOptimizations] = useState<OptimizationRule[]>([
    {
      id: 'api_caching',
      name: 'API Response Caching',
      category: 'caching',
      enabled: true,
      impact: 'high',
      description: 'Cache API responses for 30 seconds to reduce load',
      performance_gain: 35
    },
    {
      id: 'db_indexing',
      name: 'Database Indexing',
      category: 'database',
      enabled: true,
      impact: 'high',
      description: 'Optimize database queries with proper indexing',
      performance_gain: 45
    },
    {
      id: 'cdn_assets',
      name: 'CDN Asset Delivery',
      category: 'frontend',
      enabled: true,
      impact: 'medium',
      description: 'Serve static assets via CDN for faster loading',
      performance_gain: 25
    },
    {
      id: 'connection_pooling',
      name: 'Connection Pooling',
      category: 'database',
      enabled: true,
      impact: 'medium',
      description: 'Reuse database connections for better performance',
      performance_gain: 20
    },
    {
      id: 'gzip_compression',
      name: 'GZIP Compression',
      category: 'api',
      enabled: true,
      impact: 'medium',
      description: 'Compress API responses to reduce bandwidth',
      performance_gain: 30
    },
    {
      id: 'lazy_loading',
      name: 'Component Lazy Loading',
      category: 'frontend',
      enabled: false,
      impact: 'low',
      description: 'Load components only when needed',
      performance_gain: 15
    }
  ]);

  const [systemHealth, setSystemHealth] = useState(98.7);
  const [autoOptimize, setAutoOptimize] = useState(true);

  // Simulate real-time performance data
  useEffect(() => {
    const interval = setInterval(() => {
      const newMetric: PerformanceMetric = {
        timestamp: new Date().toISOString(),
        api_response: Math.floor(Math.random() * 100) + 80,
        database_query: Math.floor(Math.random() * 50) + 20,
        memory_usage: Math.floor(Math.random() * 30) + 40,
        cpu_usage: Math.floor(Math.random() * 25) + 15,
        throughput: Math.floor(Math.random() * 500) + 1500
      };

      setMetrics(prev => [...prev.slice(-19), newMetric]);

      // Auto-optimize based on metrics
      if (autoOptimize) {
        if (newMetric.api_response > 150) {
          toggleOptimization('api_caching', true);
        }
        if (newMetric.database_query > 60) {
          toggleOptimization('db_indexing', true);
          toggleOptimization('connection_pooling', true);
        }
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [autoOptimize]);

  const toggleOptimization = (id: string, enable?: boolean) => {
    setOptimizations(prev => prev.map(opt => 
      opt.id === id 
        ? { ...opt, enabled: enable !== undefined ? enable : !opt.enabled }
        : opt
    ));
  };

  const calculateOverallPerformance = () => {
    const enabledOptimizations = optimizations.filter(o => o.enabled);
    const totalGain = enabledOptimizations.reduce((sum, opt) => sum + opt.performance_gain, 0);
    return Math.min(100, 60 + (totalGain * 0.4)); // Base 60% + optimizations
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'caching': return <Zap className="h-4 w-4" />;
      case 'database': return <Database className="h-4 w-4" />;
      case 'api': return <Wifi className="h-4 w-4" />;
      case 'frontend': return <Activity className="h-4 w-4" />;
      default: return <Settings className="h-4 w-4" />;
    }
  };

  const currentMetrics = metrics[metrics.length - 1];
  const overallPerformance = calculateOverallPerformance();
  const enabledCount = optimizations.filter(o => o.enabled).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Performance Optimizer</h1>
            <p className="text-gray-300">Real-time performance optimization and monitoring</p>
          </div>
          <div className="flex items-center space-x-4">
            <Badge className={overallPerformance >= 95 ? 'bg-green-500' : overallPerformance >= 85 ? 'bg-yellow-500' : 'bg-red-500'}>
              Performance: {overallPerformance.toFixed(1)}%
            </Badge>
            <Button 
              onClick={() => setAutoOptimize(!autoOptimize)} 
              variant={autoOptimize ? "default" : "outline"}
            >
              Auto-Optimize {autoOptimize ? 'ON' : 'OFF'}
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">API Response</p>
                  <p className="text-2xl font-bold text-blue-400">
                    {currentMetrics?.api_response || 0}ms
                  </p>
                </div>
                <Wifi className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">DB Query</p>
                  <p className="text-2xl font-bold text-green-400">
                    {currentMetrics?.database_query || 0}ms
                  </p>
                </div>
                <Database className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">CPU Usage</p>
                  <p className="text-2xl font-bold text-purple-400">
                    {currentMetrics?.cpu_usage || 0}%
                  </p>
                </div>
                <Cpu className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Memory</p>
                  <p className="text-2xl font-bold text-orange-400">
                    {currentMetrics?.memory_usage || 0}%
                  </p>
                </div>
                <HardDrive className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Throughput</p>
                  <p className="text-2xl font-bold text-red-400">
                    {currentMetrics?.throughput || 0}/min
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="metrics" className="space-y-6">
          <TabsList className="grid grid-cols-3 w-full max-w-xl">
            <TabsTrigger value="metrics">Performance Metrics</TabsTrigger>
            <TabsTrigger value="optimizations">Optimizations</TabsTrigger>
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="metrics" className="space-y-6">
            <Card className="bg-black/40 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Real-Time Performance Trends</CardTitle>
                <CardDescription className="text-gray-400">
                  Live monitoring of key performance indicators
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={metrics}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis 
                      dataKey="timestamp" 
                      tickFormatter={(time) => new Date(time).toLocaleTimeString()}
                      stroke="#9CA3AF"
                    />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip 
                      labelFormatter={(time) => new Date(time).toLocaleTimeString()}
                      contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="api_response" 
                      stroke="#3B82F6" 
                      strokeWidth={2}
                      name="API Response (ms)"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="database_query" 
                      stroke="#10B981" 
                      strokeWidth={2}
                      name="DB Query (ms)"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="throughput" 
                      stroke="#F59E0B" 
                      strokeWidth={2}
                      name="Throughput (req/min)"
                      yAxisId="right"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="optimizations" className="space-y-6">
            <Card className="bg-black/40 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Zap className="h-5 w-5 mr-2" />
                  Performance Optimizations ({enabledCount}/{optimizations.length} enabled)
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Configure automatic performance optimizations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {optimizations.map((optimization) => (
                  <div 
                    key={optimization.id} 
                    className={`p-4 rounded-lg border ${
                      optimization.enabled ? 'bg-green-900/20 border-green-700' : 'bg-gray-800/50 border-gray-600'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        {getCategoryIcon(optimization.category)}
                        <div>
                          <h3 className="font-semibold text-white">{optimization.name}</h3>
                          <p className="text-sm text-gray-400">{optimization.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge className={getImpactColor(optimization.impact)}>
                          {optimization.impact} impact
                        </Badge>
                        <Badge className="bg-blue-500 text-white">
                          +{optimization.performance_gain}%
                        </Badge>
                        <Button
                          size="sm"
                          onClick={() => toggleOptimization(optimization.id)}
                          variant={optimization.enabled ? "destructive" : "default"}
                        >
                          {optimization.enabled ? 'Disable' : 'Enable'}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <Progress 
                        value={optimization.enabled ? optimization.performance_gain : 0} 
                        className="flex-1 h-2"
                      />
                      <span className="text-sm text-gray-400">
                        Performance gain: {optimization.performance_gain}%
                      </span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">System Resource Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={metrics}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis 
                        dataKey="timestamp" 
                        tickFormatter={(time) => new Date(time).toLocaleTimeString()}
                        stroke="#9CA3AF"
                      />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        labelFormatter={(time) => new Date(time).toLocaleTimeString()}
                        contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="memory_usage" 
                        stackId="1"
                        stroke="#8B5CF6" 
                        fill="#8B5CF6"
                        fillOpacity={0.3}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="cpu_usage" 
                        stackId="1"
                        stroke="#F59E0B" 
                        fill="#F59E0B"
                        fillOpacity={0.3}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Performance Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Overall Performance</span>
                      <span className="text-2xl font-bold text-green-400">
                        {overallPerformance.toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={overallPerformance} className="h-3" />
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-white">Active Optimizations</h4>
                    {optimizations.filter(o => o.enabled).map(opt => (
                      <div key={opt.id} className="flex items-center justify-between">
                        <span className="text-gray-300">{opt.name}</span>
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      </div>
                    ))}
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-white">Recommendations</h4>
                    {optimizations.filter(o => !o.enabled && o.impact === 'high').map(opt => (
                      <div key={opt.id} className="flex items-center justify-between">
                        <span className="text-gray-300">{opt.name}</span>
                        <AlertTriangle className="h-4 w-4 text-yellow-500" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}