import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Crown, Gift, TrendingUp, Star, Award } from "lucide-react";

interface LoyaltyData {
  currentPoints: number;
  tier: string;
  nextTier: string;
  pointsToNextTier: number;
  totalEarned: number;
  recentActivity: Array<{
    id: number;
    points: number;
    source: string;
    description: string;
    createdAt: string;
  }>;
}

const TIER_COLORS = {
  Bronze: "text-orange-400",
  Silver: "text-gray-300", 
  Gold: "text-yellow-400",
  Platinum: "text-purple-400",
  Diamond: "text-blue-400"
};

const TIER_BENEFITS = {
  Bronze: ["1x Points", "Basic Support"],
  Silver: ["1.2x Points", "Priority Support", "Monthly Free Bet"],
  Gold: ["1.5x Points", "VIP Support", "Weekly Free Bets", "Cashback 5%"],
  Platinum: ["2x Points", "Dedicated Manager", "Daily Free Bets", "Cashback 10%"],
  Diamond: ["3x Points", "Personal Concierge", "Premium Bonuses", "Cashback 15%"]
};

export default function LoyaltyDashboard() {
  const [activeTab, setActiveTab] = useState<'overview' | 'rewards' | 'history'>('overview');

  const { data: loyaltyData } = useQuery<LoyaltyData>({
    queryKey: ["/api/loyalty"],
  });

  if (!loyaltyData) {
    return (
      <div className="card-modern p-8 text-center">
        <div className="animate-pulse">
          <div className="h-6 bg-white/10 rounded mb-4"></div>
          <div className="h-4 bg-white/10 rounded mb-2"></div>
          <div className="h-4 bg-white/10 rounded"></div>
        </div>
      </div>
    );
  }

  const progressPercentage = loyaltyData.nextTier 
    ? ((loyaltyData.currentPoints / (loyaltyData.currentPoints + loyaltyData.pointsToNextTier)) * 100)
    : 100;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card-modern p-6 gradient-accent">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <Crown className="text-yellow-400" size={32} />
            <div>
              <h2 className="text-2xl font-bold text-white">VIP Loyalty Program</h2>
              <p className="text-white/80">Unlock exclusive rewards and benefits</p>
            </div>
          </div>
          <div className="text-right">
            <div className={`text-2xl font-bold ${TIER_COLORS[loyaltyData.tier as keyof typeof TIER_COLORS]}`}>
              {loyaltyData.tier} Member
            </div>
            <div className="text-white/80 text-sm">Since 2024</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-winnex-green mb-1">
              {loyaltyData.currentPoints.toLocaleString()}
            </div>
            <div className="text-white/70 text-sm">Current Points</div>
          </div>
          <div className="glass rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-winnex-blue mb-1">
              {loyaltyData.totalEarned.toLocaleString()}
            </div>
            <div className="text-white/70 text-sm">Total Earned</div>
          </div>
          <div className="glass rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-winnex-orange mb-1">
              {loyaltyData.pointsToNextTier || 0}
            </div>
            <div className="text-white/70 text-sm">To Next Tier</div>
          </div>
        </div>
      </div>

      {/* Progress to Next Tier */}
      {loyaltyData.nextTier && (
        <div className="card-modern p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg">Progress to {loyaltyData.nextTier}</h3>
            <span className="text-sm text-white/60">{progressPercentage.toFixed(1)}%</span>
          </div>
          <div className="relative">
            <div className="w-full bg-white/10 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-winnex-green to-winnex-blue h-3 rounded-full transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
            <div className="absolute -top-8 right-0 text-sm font-medium text-winnex-green">
              {loyaltyData.pointsToNextTier} points to go
            </div>
          </div>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="glass rounded-xl p-1 flex">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeTab === 'overview' ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab('rewards')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeTab === 'rewards' ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
          }`}
        >
          Rewards
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
            activeTab === 'history' ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
          }`}
        >
          History
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="card-modern p-6">
            <h3 className="font-bold text-lg mb-4">Your {loyaltyData.tier} Benefits</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {TIER_BENEFITS[loyaltyData.tier as keyof typeof TIER_BENEFITS]?.map((benefit, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <Star className="text-winnex-green" size={16} />
                  <span>{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="card-modern p-6">
            <h3 className="font-bold text-lg mb-4">How to Earn Points</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span>Place a bet</span>
                <span className="text-winnex-green font-medium">1 point per $1</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Refer a friend</span>
                <span className="text-winnex-green font-medium">500 points</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Complete daily challenges</span>
                <span className="text-winnex-green font-medium">50-200 points</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Monthly loyalty bonus</span>
                <span className="text-winnex-green font-medium">100-1000 points</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'rewards' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { name: "Free Bet $10", cost: 1000, icon: Gift },
            { name: "Cashback 5%", cost: 2000, icon: TrendingUp },
            { name: "Odds Boost", cost: 500, icon: Award },
            { name: "VIP Support", cost: 3000, icon: Crown },
            { name: "Free Bet $25", cost: 2500, icon: Gift },
            { name: "Exclusive Bonus", cost: 5000, icon: Star },
          ].map((reward, index) => (
            <div key={index} className="card-modern p-6 text-center">
              <reward.icon className="mx-auto mb-3 text-winnex-green" size={32} />
              <h3 className="font-bold mb-2">{reward.name}</h3>
              <div className="text-2xl font-bold text-winnex-orange mb-4">
                {reward.cost.toLocaleString()} pts
              </div>
              <button 
                className={`w-full py-2 rounded-lg font-medium transition-all ${
                  loyaltyData.currentPoints >= reward.cost 
                    ? 'btn-primary' 
                    : 'bg-white/10 text-white/50 cursor-not-allowed'
                }`}
                disabled={loyaltyData.currentPoints < reward.cost}
              >
                {loyaltyData.currentPoints >= reward.cost ? 'Redeem' : 'Insufficient Points'}
              </button>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'history' && (
        <div className="card-modern p-6">
          <h3 className="font-bold text-lg mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {loyaltyData.recentActivity?.map((activity) => (
              <div key={activity.id} className="flex items-center justify-between py-3 border-b border-white/10 last:border-b-0">
                <div>
                  <div className="font-medium">{activity.description}</div>
                  <div className="text-sm text-white/60">{activity.source}</div>
                </div>
                <div className="text-right">
                  <div className="text-winnex-green font-bold">+{activity.points} pts</div>
                  <div className="text-xs text-white/60">
                    {new Date(activity.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
            )) || (
              <div className="text-center py-8 text-white/60">
                <Award className="mx-auto mb-3" size={24} />
                <p>No recent activity</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}