import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Users, TrendingUp, MessageCircle, Heart, Share2, Star, Trophy, Eye } from "lucide-react";

interface Tipster {
  id: string;
  username: string;
  avatar: string;
  followers: number;
  winRate: number;
  roi: number;
  totalTips: number;
  isVerified: boolean;
  isFollowing: boolean;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
}

interface SocialBet {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  match: string;
  prediction: string;
  odds: number;
  stake: number;
  confidence: number;
  reasoning: string;
  likes: number;
  comments: number;
  isLiked: boolean;
  timestamp: string;
  followers: number;
  isLive: boolean;
}

interface BettingTip {
  id: string;
  tipster: string;
  avatar: string;
  match: string;
  tip: string;
  odds: number;
  confidence: number;
  likes: number;
  comments: number;
  timestamp: string;
  category: string;
  isVIP: boolean;
}

export default function SocialBettingHub() {
  const [activeTab, setActiveTab] = useState<'feed' | 'tipsters' | 'leaderboard' | 'community'>('feed');
  const [filter, setFilter] = useState<'all' | 'following' | 'trending'>('all');

  const { data: socialBets = [] } = useQuery<SocialBet[]>({
    queryKey: ["/api/social/bets", filter],
  });

  const { data: topTipsters = [] } = useQuery<Tipster[]>({
    queryKey: ["/api/social/tipsters"],
  });

  const { data: bettingTips = [] } = useQuery<BettingTip[]>({
    queryKey: ["/api/social/tips"],
  });

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'bronze': return 'text-orange-400';
      case 'silver': return 'text-gray-300';
      case 'gold': return 'text-yellow-400';
      case 'platinum': return 'text-purple-400';
      default: return 'text-white';
    }
  };

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'platinum': return '💎';
      case 'gold': return '🥇';
      case 'silver': return '🥈';
      case 'bronze': return '🥉';
      default: return '⭐';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card-modern p-6 gradient-accent">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Users className="text-white" size={32} />
            <div>
              <h2 className="text-2xl font-bold text-white">Social Betting Hub</h2>
              <p className="text-white/80">Follow expert tipsters and share your winning strategies</p>
            </div>
          </div>
          <div className="glass rounded-2xl p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">2.4K</div>
              <div className="text-white/70 text-sm">Followers</div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="glass rounded-xl p-1 flex">
        {(['feed', 'tipsters', 'leaderboard', 'community'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all capitalize ${
              activeTab === tab ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Social Feed */}
      {activeTab === 'feed' && (
        <div className="space-y-6">
          {/* Filter Bar */}
          <div className="flex justify-between items-center">
            <div className="flex bg-secondary rounded-xl p-1">
              {(['all', 'following', 'trending'] as const).map((filterOption) => (
                <button
                  key={filterOption}
                  onClick={() => setFilter(filterOption)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all capitalize ${
                    filter === filterOption ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
                  }`}
                >
                  {filterOption}
                </button>
              ))}
            </div>
            <button className="btn-primary">Share Your Bet</button>
          </div>

          {/* Social Bets Feed */}
          <div className="space-y-4">
            {socialBets.map((bet) => (
              <div key={bet.id} className="card-modern p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-winnex-green to-winnex-blue flex items-center justify-center font-bold text-black">
                    {bet.username.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h3 className="font-bold">{bet.username}</h3>
                      <span className="text-sm text-white/60">{bet.timestamp}</span>
                      {bet.isLive && (
                        <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full animate-pulse">
                          LIVE
                        </span>
                      )}
                      <span className="text-sm text-winnex-blue">{bet.followers} followers</span>
                    </div>
                    
                    <div className="glass rounded-lg p-4 mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-medium">{bet.match}</h4>
                        <span className="text-winnex-green font-bold">{bet.odds}</span>
                      </div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-lg font-bold text-winnex-green">{bet.prediction}</span>
                        <div className="text-right">
                          <div className="text-sm text-white/60">Stake: ${bet.stake}</div>
                          <div className="text-sm text-winnex-orange">Confidence: {bet.confidence}%</div>
                        </div>
                      </div>
                      <p className="text-white/80 text-sm">{bet.reasoning}</p>
                    </div>

                    <div className="flex items-center space-x-6">
                      <button className={`flex items-center space-x-2 ${bet.isLiked ? 'text-red-400' : 'text-white/60'} hover:text-red-400 transition-colors`}>
                        <Heart size={16} className={bet.isLiked ? 'fill-current' : ''} />
                        <span>{bet.likes}</span>
                      </button>
                      <button className="flex items-center space-x-2 text-white/60 hover:text-winnex-blue transition-colors">
                        <MessageCircle size={16} />
                        <span>{bet.comments}</span>
                      </button>
                      <button className="flex items-center space-x-2 text-white/60 hover:text-winnex-green transition-colors">
                        <Share2 size={16} />
                        <span>Share</span>
                      </button>
                      <button className="btn-secondary ml-auto">Copy Bet</button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Top Tipsters */}
      {activeTab === 'tipsters' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topTipsters.map((tipster) => (
              <div key={tipster.id} className="card-modern p-6 text-center">
                <div className="relative mb-4">
                  <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-winnex-green to-winnex-blue flex items-center justify-center font-bold text-xl text-black">
                    {tipster.username.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="absolute -top-2 -right-2 text-2xl">
                    {getTierIcon(tipster.tier)}
                  </div>
                  {tipster.isVerified && (
                    <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-winnex-blue rounded-full flex items-center justify-center">
                      <Star size={12} className="text-white" />
                    </div>
                  )}
                </div>

                <h3 className="font-bold text-lg mb-2">{tipster.username}</h3>
                <div className={`text-sm mb-4 ${getTierColor(tipster.tier)}`}>
                  {tipster.tier.toUpperCase()} Tipster
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4 text-sm">
                  <div className="text-center">
                    <div className="font-bold text-winnex-green">{tipster.winRate}%</div>
                    <div className="text-white/60">Win Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-winnex-blue">+{tipster.roi}%</div>
                    <div className="text-white/60">ROI</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-winnex-orange">{tipster.totalTips}</div>
                    <div className="text-white/60">Tips</div>
                  </div>
                </div>

                <div className="flex items-center justify-center space-x-2 mb-4 text-sm text-white/60">
                  <Users size={14} />
                  <span>{tipster.followers.toLocaleString()} followers</span>
                </div>

                <button className={`w-full py-2 rounded-lg font-medium transition-all ${
                  tipster.isFollowing 
                    ? 'bg-white/10 text-white border border-white/20' 
                    : 'btn-primary'
                }`}>
                  {tipster.isFollowing ? 'Following' : 'Follow'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Leaderboard */}
      {activeTab === 'leaderboard' && (
        <div className="space-y-6">
          <div className="card-modern p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <Trophy className="mr-2 text-winnex-orange" />
              This Month's Top Performers
            </h3>
            <div className="space-y-3">
              {topTipsters.slice(0, 10).map((tipster, index) => (
                <div key={tipster.id} className="flex items-center justify-between p-4 glass-hover rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                      index === 0 ? 'bg-yellow-400 text-black' :
                      index === 1 ? 'bg-gray-300 text-black' :
                      index === 2 ? 'bg-orange-400 text-black' :
                      'bg-white/10 text-white'
                    }`}>
                      {index + 1}
                    </div>
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-winnex-green to-winnex-blue flex items-center justify-center font-bold text-black">
                      {tipster.username.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="font-medium">{tipster.username}</div>
                      <div className="text-sm text-white/60">{tipster.followers} followers</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-winnex-green">+{tipster.roi}% ROI</div>
                    <div className="text-sm text-white/60">{tipster.winRate}% win rate</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Community Tips */}
      {activeTab === 'community' && (
        <div className="space-y-4">
          {bettingTips.map((tip) => (
            <div key={tip.id} className="card-modern p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-winnex-green to-winnex-blue flex items-center justify-center font-bold text-black">
                    {tip.tipster.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="font-bold">{tip.tipster}</h3>
                      {tip.isVIP && (
                        <span className="bg-gradient-casino text-white text-xs px-2 py-1 rounded-full">
                          VIP
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-white/60">{tip.timestamp}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-winnex-blue">{tip.category}</div>
                  <div className="text-sm text-white/60">{tip.confidence}% confidence</div>
                </div>
              </div>

              <div className="glass rounded-lg p-4 mb-4">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium">{tip.match}</h4>
                  <span className="text-winnex-green font-bold">{tip.odds}</span>
                </div>
                <div className="text-lg font-bold text-winnex-green mb-2">{tip.tip}</div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <button className="flex items-center space-x-2 text-white/60 hover:text-red-400 transition-colors">
                    <Heart size={16} />
                    <span>{tip.likes}</span>
                  </button>
                  <button className="flex items-center space-x-2 text-white/60 hover:text-winnex-blue transition-colors">
                    <MessageCircle size={16} />
                    <span>{tip.comments}</span>
                  </button>
                  <button className="flex items-center space-x-2 text-white/60 hover:text-winnex-green transition-colors">
                    <Eye size={16} />
                    <span>View Analysis</span>
                  </button>
                </div>
                <button className="btn-primary">Follow Tip</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}