import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  CreditCard, 
  Smartphone, 
  Bitcoin, 
  DollarSign, 
  ArrowUpRight, 
  ArrowDownLeft,
  Clock,
  Shield,
  Zap,
  Globe,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  Wallet
} from "lucide-react";

interface PaymentMethod {
  id: string;
  type: 'card' | 'crypto' | 'bank' | 'ewallet' | 'mobile';
  name: string;
  icon: React.ReactNode;
  isDefault: boolean;
  isEnabled: boolean;
  fees: {
    deposit: number;
    withdrawal: number;
  };
  limits: {
    minDeposit: number;
    maxDeposit: number;
    minWithdrawal: number;
    maxWithdrawal: number;
  };
  processingTime: {
    deposit: string;
    withdrawal: string;
  };
  currencies: string[];
}

interface CryptoCurrency {
  symbol: string;
  name: string;
  icon: string;
  price: number;
  change24h: number;
  network: string;
  confirmations: number;
  address?: string;
  qrCode?: string;
}

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  method: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
  timestamp: string;
  txHash?: string;
  fee: number;
  exchange_rate?: number;
}

interface TaxReport {
  year: number;
  totalDeposits: number;
  totalWithdrawals: number;
  totalFees: number;
  netGains: number;
  taxableEvents: Array<{
    date: string;
    type: string;
    amount: number;
    currency: string;
    taxable: boolean;
  }>;
}

export default function AdvancedPaymentGateway() {
  const [selectedTab, setSelectedTab] = useState('methods');
  const [selectedMethod, setSelectedMethod] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [currency, setCurrency] = useState<string>('USD');
  const [withdrawalAddress, setWithdrawalAddress] = useState<string>('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: paymentMethods } = useQuery({
    queryKey: ['/api/payment/methods'],
  });

  const { data: cryptoPrices } = useQuery({
    queryKey: ['/api/crypto/prices'],
    refetchInterval: 30000,
  });

  const { data: transactions } = useQuery({
    queryKey: ['/api/user/transactions'],
  });

  const { data: taxReport } = useQuery({
    queryKey: ['/api/user/tax-report'],
  });

  const mockPaymentMethods: PaymentMethod[] = [
    {
      id: 'visa',
      type: 'card',
      name: 'Visa/Mastercard',
      icon: <CreditCard className="w-6 h-6" />,
      isDefault: true,
      isEnabled: true,
      fees: { deposit: 2.9, withdrawal: 0 },
      limits: { minDeposit: 10, maxDeposit: 5000, minWithdrawal: 20, maxWithdrawal: 2500 },
      processingTime: { deposit: 'Instant', withdrawal: '1-3 business days' },
      currencies: ['USD', 'EUR', 'GBP', 'CAD']
    },
    {
      id: 'paypal',
      type: 'ewallet',
      name: 'PayPal',
      icon: <Smartphone className="w-6 h-6" />,
      isDefault: false,
      isEnabled: true,
      fees: { deposit: 3.5, withdrawal: 1.0 },
      limits: { minDeposit: 5, maxDeposit: 2000, minWithdrawal: 10, maxWithdrawal: 1000 },
      processingTime: { deposit: 'Instant', withdrawal: '24 hours' },
      currencies: ['USD', 'EUR', 'GBP']
    },
    {
      id: 'bitcoin',
      type: 'crypto',
      name: 'Bitcoin',
      icon: <Bitcoin className="w-6 h-6" />,
      isDefault: false,
      isEnabled: true,
      fees: { deposit: 0, withdrawal: 0.0005 },
      limits: { minDeposit: 0.001, maxDeposit: 10, minWithdrawal: 0.002, maxWithdrawal: 5 },
      processingTime: { deposit: '10-60 minutes', withdrawal: '10-60 minutes' },
      currencies: ['BTC']
    },
    {
      id: 'ethereum',
      type: 'crypto',
      name: 'Ethereum',
      icon: <Globe className="w-6 h-6" />,
      isDefault: false,
      isEnabled: true,
      fees: { deposit: 0, withdrawal: 0.01 },
      limits: { minDeposit: 0.01, maxDeposit: 100, minWithdrawal: 0.02, maxWithdrawal: 50 },
      processingTime: { deposit: '5-15 minutes', withdrawal: '5-15 minutes' },
      currencies: ['ETH']
    },
    {
      id: 'apple_pay',
      type: 'mobile',
      name: 'Apple Pay',
      icon: <Smartphone className="w-6 h-6" />,
      isDefault: false,
      isEnabled: true,
      fees: { deposit: 2.5, withdrawal: 0 },
      limits: { minDeposit: 1, maxDeposit: 1000, minWithdrawal: 0, maxWithdrawal: 0 },
      processingTime: { deposit: 'Instant', withdrawal: 'Not supported' },
      currencies: ['USD', 'EUR', 'GBP']
    }
  ];

  const mockCryptoPrices: CryptoCurrency[] = [
    {
      symbol: 'BTC',
      name: 'Bitcoin',
      icon: '₿',
      price: 42850.32,
      change24h: 2.45,
      network: 'Bitcoin',
      confirmations: 3,
      address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
      qrCode: 'btc_qr_placeholder'
    },
    {
      symbol: 'ETH',
      name: 'Ethereum',
      icon: 'Ξ',
      price: 2650.87,
      change24h: -1.23,
      network: 'Ethereum',
      confirmations: 12,
      address: '0x742d35Cc6634C0532925a3b8D0D6E',
      qrCode: 'eth_qr_placeholder'
    },
    {
      symbol: 'LTC',
      name: 'Litecoin',
      icon: 'Ł',
      price: 72.45,
      change24h: 0.89,
      network: 'Litecoin',
      confirmations: 6,
      address: 'LQTpS7FRN8XWJwJZjyJvN9eqeH',
      qrCode: 'ltc_qr_placeholder'
    },
    {
      symbol: 'USDT',
      name: 'Tether',
      icon: '₮',
      price: 1.00,
      change24h: 0.01,
      network: 'Ethereum (ERC-20)',
      confirmations: 12,
      address: '0x742d35Cc6634C0532925a3b8D0D6E',
      qrCode: 'usdt_qr_placeholder'
    }
  ];

  const mockTransactions: Transaction[] = [
    {
      id: '1',
      type: 'deposit',
      method: 'Bitcoin',
      amount: 0.125,
      currency: 'BTC',
      status: 'completed',
      timestamp: '2024-01-15 14:30:22',
      txHash: '1a2b3c4d5e6f7890abcdef1234567890',
      fee: 0.0005,
      exchange_rate: 42850.32
    },
    {
      id: '2',
      type: 'withdrawal',
      method: 'PayPal',
      amount: 500,
      currency: 'USD',
      status: 'processing',
      timestamp: '2024-01-15 12:15:45',
      fee: 5.00
    },
    {
      id: '3',
      type: 'deposit',
      method: 'Visa',
      amount: 250,
      currency: 'USD',
      status: 'completed',
      timestamp: '2024-01-14 18:45:12',
      fee: 7.25
    }
  ];

  const mockTaxReport: TaxReport = {
    year: 2024,
    totalDeposits: 15750.00,
    totalWithdrawals: 8230.50,
    totalFees: 156.75,
    netGains: 2340.80,
    taxableEvents: [
      { date: '2024-01-15', type: 'Crypto Sale', amount: 5356.40, currency: 'USD', taxable: true },
      { date: '2024-01-10', type: 'Winning Withdrawal', amount: 1250.00, currency: 'USD', taxable: true },
      { date: '2024-01-05', type: 'Deposit', amount: 500.00, currency: 'USD', taxable: false }
    ]
  };

  const methods = paymentMethods || mockPaymentMethods;
  const prices = cryptoPrices || mockCryptoPrices;
  const txList = transactions || mockTransactions;
  const taxData = taxReport || mockTaxReport;

  const depositMutation = useMutation({
    mutationFn: async (data: { method: string; amount: number; currency: string }) => {
      return apiRequest('POST', '/api/payment/deposit', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user/balance'] });
      toast({
        title: "Deposit Initiated",
        description: "Your deposit is being processed",
      });
      setAmount('');
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (data: { method: string; amount: number; currency: string; address?: string }) => {
      return apiRequest('POST', '/api/payment/withdraw', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user/balance'] });
      toast({
        title: "Withdrawal Initiated",
        description: "Your withdrawal is being processed",
      });
      setAmount('');
      setWithdrawalAddress('');
    },
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'processing': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'pending': return <Clock className="w-4 h-4 text-blue-500" />;
      case 'failed': return <AlertCircle className="w-4 h-4 text-red-500" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getMethodIcon = (type: string) => {
    switch (type) {
      case 'card': return <CreditCard className="w-5 h-5" />;
      case 'crypto': return <Bitcoin className="w-5 h-5" />;
      case 'ewallet': return <Wallet className="w-5 h-5" />;
      case 'mobile': return <Smartphone className="w-5 h-5" />;
      default: return <DollarSign className="w-5 h-5" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Payment Center</h1>
        <p className="text-gray-400">Manage deposits, withdrawals, and payment methods</p>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-4 mb-8">
        <Card className="bg-winnex-dark border-gray-700">
          <CardContent className="p-4 text-center">
            <ArrowDownLeft className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <div className="text-sm font-semibold text-white">Total Deposits</div>
            <div className="text-2xl font-bold text-green-500">${taxData.totalDeposits.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card className="bg-winnex-dark border-gray-700">
          <CardContent className="p-4 text-center">
            <ArrowUpRight className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <div className="text-sm font-semibold text-white">Total Withdrawals</div>
            <div className="text-2xl font-bold text-blue-500">${taxData.totalWithdrawals.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card className="bg-winnex-dark border-gray-700">
          <CardContent className="p-4 text-center">
            <DollarSign className="w-8 h-8 text-purple-500 mx-auto mb-2" />
            <div className="text-sm font-semibold text-white">Total Fees</div>
            <div className="text-2xl font-bold text-purple-500">${taxData.totalFees.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="bg-winnex-dark border-gray-700">
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
            <div className="text-sm font-semibold text-white">Net P&L</div>
            <div className={`text-2xl font-bold ${taxData.netGains >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              ${taxData.netGains.toFixed(2)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-winnex-gray">
          <TabsTrigger value="methods" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Payment Methods
          </TabsTrigger>
          <TabsTrigger value="crypto" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Cryptocurrency
          </TabsTrigger>
          <TabsTrigger value="deposit" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Deposit
          </TabsTrigger>
          <TabsTrigger value="withdraw" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Withdraw
          </TabsTrigger>
          <TabsTrigger value="history" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Transaction History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="methods" className="mt-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {methods.map((method) => (
              <Card key={method.id} className={`border-2 transition-all duration-300 ${
                method.isDefault ? 'border-green-500 bg-green-900/20' : 'border-gray-600 bg-winnex-dark'
              }`}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                      {getMethodIcon(method.type)}
                      {method.name}
                    </CardTitle>
                    {method.isDefault && (
                      <Badge className="bg-green-600">Default</Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-lg font-bold text-white mb-1">
                      {method.processingTime.deposit}
                    </div>
                    <div className="text-sm text-gray-400">Processing Time</div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Deposit Fee:</span>
                      <span className="text-white">{method.fees.deposit}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Withdrawal Fee:</span>
                      <span className="text-white">{method.fees.withdrawal}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Min Deposit:</span>
                      <span className="text-white">${method.limits.minDeposit}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Max Deposit:</span>
                      <span className="text-white">${method.limits.maxDeposit.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      className="flex-1 bg-winnex-green text-black"
                      onClick={() => {
                        setSelectedMethod(method.id);
                        setSelectedTab('deposit');
                      }}
                    >
                      Deposit
                    </Button>
                    {method.limits.maxWithdrawal > 0 && (
                      <Button 
                        variant="outline" 
                        className="flex-1 border-blue-500 text-blue-500"
                        onClick={() => {
                          setSelectedMethod(method.id);
                          setSelectedTab('withdraw');
                        }}
                      >
                        Withdraw
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="crypto" className="mt-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {prices.map((crypto) => (
              <Card key={crypto.symbol} className="bg-winnex-dark border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center text-white font-bold">
                        {crypto.icon}
                      </div>
                      <div>
                        <div className="font-semibold text-white">{crypto.symbol}</div>
                        <div className="text-sm text-gray-400">{crypto.name}</div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-2xl font-bold text-white">
                        ${crypto.price.toLocaleString()}
                      </span>
                      <Badge className={`${crypto.change24h >= 0 ? 'bg-green-600' : 'bg-red-600'}`}>
                        {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h.toFixed(2)}%
                      </Badge>
                    </div>

                    <div className="text-sm text-gray-400 space-y-1">
                      <div>Network: {crypto.network}</div>
                      <div>Confirmations: {crypto.confirmations}</div>
                    </div>

                    {crypto.address && (
                      <div className="mt-4 p-3 bg-gray-800 rounded-lg">
                        <div className="text-xs text-gray-400 mb-1">Deposit Address:</div>
                        <div className="text-xs text-white font-mono break-all">
                          {crypto.address}
                        </div>
                        <div className="mt-2 w-20 h-20 bg-white rounded mx-auto flex items-center justify-center">
                          <span className="text-xs text-black">QR</span>
                        </div>
                      </div>
                    )}

                    <div className="flex gap-2 mt-4">
                      <Button 
                        size="sm" 
                        className="flex-1 bg-winnex-green text-black"
                        onClick={() => {
                          setSelectedMethod(crypto.symbol.toLowerCase());
                          setCurrency(crypto.symbol);
                          setSelectedTab('deposit');
                        }}
                      >
                        Deposit
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1 border-blue-500 text-blue-500"
                        onClick={() => {
                          setSelectedMethod(crypto.symbol.toLowerCase());
                          setCurrency(crypto.symbol);
                          setSelectedTab('withdraw');
                        }}
                      >
                        Withdraw
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="deposit" className="mt-6">
          <div className="max-w-md mx-auto">
            <Card className="bg-winnex-dark border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <ArrowDownLeft className="w-5 h-5" />
                  Make a Deposit
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-white text-sm font-semibold mb-2 block">Payment Method</label>
                  <select 
                    value={selectedMethod}
                    onChange={(e) => setSelectedMethod(e.target.value)}
                    className="w-full bg-winnex-gray border border-gray-600 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="">Select payment method</option>
                    {methods.filter(m => m.isEnabled).map(method => (
                      <option key={method.id} value={method.id}>{method.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-white text-sm font-semibold mb-2 block">Amount</label>
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="bg-winnex-gray border-gray-600"
                  />
                </div>

                <div>
                  <label className="text-white text-sm font-semibold mb-2 block">Currency</label>
                  <select 
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full bg-winnex-gray border border-gray-600 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                    <option value="GBP">GBP</option>
                    <option value="BTC">BTC</option>
                    <option value="ETH">ETH</option>
                  </select>
                </div>

                {selectedMethod && (
                  <div className="p-4 bg-gray-800 rounded-lg">
                    {(() => {
                      const method = methods.find(m => m.id === selectedMethod);
                      if (!method) return null;
                      
                      const fee = parseFloat(amount) * (method.fees.deposit / 100);
                      const total = parseFloat(amount) + fee;
                      
                      return (
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Amount:</span>
                            <span className="text-white">{amount} {currency}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Fee ({method.fees.deposit}%):</span>
                            <span className="text-white">{fee.toFixed(2)} {currency}</span>
                          </div>
                          <div className="flex justify-between border-t border-gray-600 pt-2">
                            <span className="text-white font-semibold">Total:</span>
                            <span className="text-white font-semibold">{total.toFixed(2)} {currency}</span>
                          </div>
                          <div className="text-xs text-gray-400 mt-2">
                            Processing time: {method.processingTime.deposit}
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}

                <Button 
                  className="w-full bg-winnex-green text-black"
                  disabled={!selectedMethod || !amount || parseFloat(amount) <= 0}
                  onClick={() => depositMutation.mutate({
                    method: selectedMethod,
                    amount: parseFloat(amount),
                    currency
                  })}
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Secure Deposit
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="withdraw" className="mt-6">
          <div className="max-w-md mx-auto">
            <Card className="bg-winnex-dark border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <ArrowUpRight className="w-5 h-5" />
                  Request Withdrawal
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-white text-sm font-semibold mb-2 block">Withdrawal Method</label>
                  <select 
                    value={selectedMethod}
                    onChange={(e) => setSelectedMethod(e.target.value)}
                    className="w-full bg-winnex-gray border border-gray-600 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="">Select withdrawal method</option>
                    {methods.filter(m => m.isEnabled && m.limits.maxWithdrawal > 0).map(method => (
                      <option key={method.id} value={method.id}>{method.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-white text-sm font-semibold mb-2 block">Amount</label>
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="bg-winnex-gray border-gray-600"
                  />
                </div>

                {selectedMethod && methods.find(m => m.id === selectedMethod)?.type === 'crypto' && (
                  <div>
                    <label className="text-white text-sm font-semibold mb-2 block">Withdrawal Address</label>
                    <Input
                      value={withdrawalAddress}
                      onChange={(e) => setWithdrawalAddress(e.target.value)}
                      placeholder="Enter crypto address"
                      className="bg-winnex-gray border-gray-600"
                    />
                  </div>
                )}

                {selectedMethod && (
                  <div className="p-4 bg-gray-800 rounded-lg">
                    {(() => {
                      const method = methods.find(m => m.id === selectedMethod);
                      if (!method) return null;
                      
                      const fee = parseFloat(amount) * (method.fees.withdrawal / 100);
                      const total = parseFloat(amount) - fee;
                      
                      return (
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Amount:</span>
                            <span className="text-white">{amount} {currency}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Fee ({method.fees.withdrawal}%):</span>
                            <span className="text-white">{fee.toFixed(4)} {currency}</span>
                          </div>
                          <div className="flex justify-between border-t border-gray-600 pt-2">
                            <span className="text-white font-semibold">You receive:</span>
                            <span className="text-white font-semibold">{total.toFixed(4)} {currency}</span>
                          </div>
                          <div className="text-xs text-gray-400 mt-2">
                            Processing time: {method.processingTime.withdrawal}
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}

                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled={
                    !selectedMethod || 
                    !amount || 
                    parseFloat(amount) <= 0 ||
                    (methods.find(m => m.id === selectedMethod)?.type === 'crypto' && !withdrawalAddress)
                  }
                  onClick={() => withdrawMutation.mutate({
                    method: selectedMethod,
                    amount: parseFloat(amount),
                    currency,
                    address: withdrawalAddress
                  })}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Instant Withdrawal
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="mt-6">
          <Card className="bg-winnex-dark border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Transaction History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {txList.map((transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="flex-shrink-0">
                        {getStatusIcon(transaction.status)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-white font-semibold capitalize">
                            {transaction.type}
                          </span>
                          <Badge className={`text-xs ${
                            transaction.type === 'deposit' ? 'bg-green-600' : 'bg-blue-600'
                          }`}>
                            {transaction.method}
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-400">
                          {transaction.timestamp}
                        </div>
                        {transaction.txHash && (
                          <div className="text-xs text-gray-500 font-mono">
                            Hash: {transaction.txHash.substring(0, 16)}...
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className={`font-semibold ${
                        transaction.type === 'deposit' ? 'text-green-500' : 'text-blue-500'
                      }`}>
                        {transaction.type === 'deposit' ? '+' : '-'}
                        {transaction.amount} {transaction.currency}
                      </div>
                      <div className="text-xs text-gray-400">
                        Fee: {transaction.fee} {transaction.currency}
                      </div>
                      <Badge className={`text-xs mt-1 ${
                        transaction.status === 'completed' ? 'bg-green-600' :
                        transaction.status === 'processing' ? 'bg-yellow-600' :
                        transaction.status === 'failed' ? 'bg-red-600' : 'bg-blue-600'
                      }`}>
                        {transaction.status.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 text-center">
                <Button variant="outline" className="border-green-500 text-green-500">
                  Export Transaction History
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}