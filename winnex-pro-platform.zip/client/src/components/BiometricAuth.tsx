import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { Fingerprint, Eye, Mic, Shield, Smartphone, Lock, CheckCircle, AlertTriangle } from "lucide-react";

interface BiometricMethod {
  id: string;
  name: string;
  type: 'fingerprint' | 'faceId' | 'voiceId' | 'iris';
  icon: React.ReactNode;
  enabled: boolean;
  enrolled: boolean;
  accuracy: number;
  lastUsed: string;
  deviceSupport: boolean;
  securityLevel: 'basic' | 'enhanced' | 'military';
}

interface AuthSession {
  id: string;
  method: string;
  timestamp: string;
  location: string;
  device: string;
  status: 'success' | 'failed' | 'blocked';
  riskScore: number;
}

interface SecuritySettings {
  requireBiometric: boolean;
  fallbackPassword: boolean;
  lockoutThreshold: number;
  sessionTimeout: number;
  multiFactorRequired: boolean;
  adaptiveAuth: boolean;
}

export default function BiometricAuth() {
  const [biometricMethods, setBiometricMethods] = useState<BiometricMethod[]>([]);
  const [authSessions, setAuthSessions] = useState<AuthSession[]>([]);
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>({
    requireBiometric: true,
    fallbackPassword: true,
    lockoutThreshold: 3,
    sessionTimeout: 30,
    multiFactorRequired: false,
    adaptiveAuth: true
  });
  const [enrollmentProgress, setEnrollmentProgress] = useState(0);
  const [isEnrolling, setIsEnrolling] = useState(false);

  useEffect(() => {
    const mockBiometricMethods: BiometricMethod[] = [
      {
        id: 'fingerprint',
        name: 'Fingerprint',
        type: 'fingerprint',
        icon: <Fingerprint className="w-6 h-6" />,
        enabled: true,
        enrolled: true,
        accuracy: 99.8,
        lastUsed: '2024-01-15 14:30',
        deviceSupport: true,
        securityLevel: 'enhanced'
      },
      {
        id: 'faceId',
        name: 'Face ID',
        type: 'faceId',
        icon: <Eye className="w-6 h-6" />,
        enabled: true,
        enrolled: true,
        accuracy: 99.2,
        lastUsed: '2024-01-15 12:15',
        deviceSupport: true,
        securityLevel: 'enhanced'
      },
      {
        id: 'voiceId',
        name: 'Voice Recognition',
        type: 'voiceId',
        icon: <Mic className="w-6 h-6" />,
        enabled: false,
        enrolled: false,
        accuracy: 96.5,
        lastUsed: 'Never',
        deviceSupport: true,
        securityLevel: 'basic'
      },
      {
        id: 'iris',
        name: 'Iris Scan',
        type: 'iris',
        icon: <Eye className="w-6 h-6" />,
        enabled: false,
        enrolled: false,
        accuracy: 99.9,
        lastUsed: 'Never',
        deviceSupport: false,
        securityLevel: 'military'
      }
    ];

    const mockAuthSessions: AuthSession[] = [
      {
        id: 'session_1',
        method: 'Fingerprint',
        timestamp: '2024-01-15 14:30:25',
        location: 'London, UK',
        device: 'iPhone 15 Pro',
        status: 'success',
        riskScore: 2
      },
      {
        id: 'session_2',
        method: 'Face ID',
        timestamp: '2024-01-15 12:15:43',
        location: 'London, UK',
        device: 'iPhone 15 Pro',
        status: 'success',
        riskScore: 1
      },
      {
        id: 'session_3',
        method: 'Password',
        timestamp: '2024-01-14 18:45:12',
        location: 'Manchester, UK',
        device: 'Chrome Browser',
        status: 'success',
        riskScore: 5
      },
      {
        id: 'session_4',
        method: 'Fingerprint',
        timestamp: '2024-01-14 09:20:30',
        location: 'Unknown Location',
        device: 'Unknown Device',
        status: 'failed',
        riskScore: 9
      }
    ];

    setBiometricMethods(mockBiometricMethods);
    setAuthSessions(mockAuthSessions);
  }, []);

  const getSecurityLevelColor = (level: string) => {
    switch (level) {
      case 'military': return 'text-red-400';
      case 'enhanced': return 'text-emerald-400';
      case 'basic': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'text-green-400';
      case 'failed': return 'text-red-400';
      case 'blocked': return 'text-orange-400';
      default: return 'text-gray-400';
    }
  };

  const getRiskScoreColor = (score: number) => {
    if (score <= 3) return 'text-green-400';
    if (score <= 6) return 'text-yellow-400';
    return 'text-red-400';
  };

  const enrollBiometric = async (methodId: string) => {
    setIsEnrolling(true);
    setEnrollmentProgress(0);

    // Simulate enrollment progress
    const interval = setInterval(() => {
      setEnrollmentProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsEnrolling(false);
          
          // Update the method as enrolled
          setBiometricMethods(methods => 
            methods.map(method => 
              method.id === methodId 
                ? { ...method, enrolled: true, enabled: true }
                : method
            )
          );
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  };

  const toggleMethod = (methodId: string) => {
    setBiometricMethods(methods => 
      methods.map(method => 
        method.id === methodId 
          ? { ...method, enabled: !method.enabled }
          : method
      )
    );
  };

  const updateSecuritySetting = (key: keyof SecuritySettings, value: boolean | number) => {
    setSecuritySettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="p-6 space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <Shield className="w-12 h-12 text-emerald-400 mr-3" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            Biometric Security
          </h1>
        </div>
        <p className="text-gray-400 text-lg">Advanced authentication methods for maximum security</p>
      </div>

      {/* Security Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-emerald-400">
              {biometricMethods.filter(m => m.enrolled).length}
            </div>
            <div className="text-sm text-gray-400">Methods Enrolled</div>
          </CardContent>
        </Card>
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-400">
              {biometricMethods.filter(m => m.enabled).length}
            </div>
            <div className="text-sm text-gray-400">Active Methods</div>
          </CardContent>
        </Card>
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-400">
              {authSessions.filter(s => s.status === 'success').length}
            </div>
            <div className="text-sm text-gray-400">Successful Logins</div>
          </CardContent>
        </Card>
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-red-400">
              {authSessions.filter(s => s.status === 'failed').length}
            </div>
            <div className="text-sm text-gray-400">Failed Attempts</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Biometric Methods */}
        <div className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Biometric Methods</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {biometricMethods.map((method) => (
                <Card key={method.id} className="border-gray-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="text-emerald-400">{method.icon}</div>
                        <div>
                          <h3 className="font-semibold text-white">{method.name}</h3>
                          <div className="flex items-center space-x-2">
                            <Badge 
                              variant={method.enrolled ? 'default' : 'secondary'}
                              className="text-xs"
                            >
                              {method.enrolled ? 'Enrolled' : 'Not Enrolled'}
                            </Badge>
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${getSecurityLevelColor(method.securityLevel)}`}
                            >
                              {method.securityLevel}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {method.enrolled && (
                          <Switch
                            checked={method.enabled}
                            onCheckedChange={() => toggleMethod(method.id)}
                            disabled={!method.deviceSupport}
                          />
                        )}
                      </div>
                    </div>

                    {method.enrolled ? (
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Accuracy:</span>
                          <span className="text-emerald-400">{method.accuracy}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Last Used:</span>
                          <span className="text-white">{method.lastUsed}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {!method.deviceSupport ? (
                          <div className="flex items-center space-x-2 text-orange-400">
                            <AlertTriangle className="w-4 h-4" />
                            <span className="text-sm">Device not supported</span>
                          </div>
                        ) : (
                          <Button 
                            onClick={() => enrollBiometric(method.id)}
                            disabled={isEnrolling}
                            className="w-full bg-emerald-500 hover:bg-emerald-600"
                          >
                            Enroll {method.name}
                          </Button>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}

              {isEnrolling && (
                <Card className="border-emerald-400/20 bg-emerald-500/10">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <Smartphone className="w-5 h-5 text-emerald-400" />
                      <span className="text-white font-semibold">Enrolling Biometric...</span>
                    </div>
                    <Progress value={enrollmentProgress} className="h-2" />
                    <p className="text-sm text-gray-400 mt-2">
                      Please follow the on-screen instructions on your device
                    </p>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>

          {/* Security Settings */}
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Security Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-white">Require Biometric Authentication</div>
                  <div className="text-sm text-gray-400">Always require biometric verification</div>
                </div>
                <Switch
                  checked={securitySettings.requireBiometric}
                  onCheckedChange={(checked) => updateSecuritySetting('requireBiometric', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-white">Password Fallback</div>
                  <div className="text-sm text-gray-400">Allow password if biometric fails</div>
                </div>
                <Switch
                  checked={securitySettings.fallbackPassword}
                  onCheckedChange={(checked) => updateSecuritySetting('fallbackPassword', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-white">Multi-Factor Authentication</div>
                  <div className="text-sm text-gray-400">Require multiple verification methods</div>
                </div>
                <Switch
                  checked={securitySettings.multiFactorRequired}
                  onCheckedChange={(checked) => updateSecuritySetting('multiFactorRequired', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-white">Adaptive Authentication</div>
                  <div className="text-sm text-gray-400">Adjust security based on risk</div>
                </div>
                <Switch
                  checked={securitySettings.adaptiveAuth}
                  onCheckedChange={(checked) => updateSecuritySetting('adaptiveAuth', checked)}
                />
              </div>

              <div className="space-y-2">
                <div className="font-medium text-white">Failed Attempt Lockout</div>
                <div className="text-sm text-gray-400">
                  Lock account after {securitySettings.lockoutThreshold} failed attempts
                </div>
              </div>

              <div className="space-y-2">
                <div className="font-medium text-white">Session Timeout</div>
                <div className="text-sm text-gray-400">
                  Auto-lock after {securitySettings.sessionTimeout} minutes of inactivity
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Authentication History */}
        <div className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Recent Authentication Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {authSessions.map((session) => (
                <Card key={session.id} className="border-gray-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${
                          session.status === 'success' ? 'bg-green-400' :
                          session.status === 'failed' ? 'bg-red-400' : 'bg-orange-400'
                        }`} />
                        <span className="font-medium text-white">{session.method}</span>
                        <Badge variant="outline" className={getStatusColor(session.status)}>
                          {session.status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className={`text-sm font-semibold ${getRiskScoreColor(session.riskScore)}`}>
                        Risk: {session.riskScore}/10
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-400">
                      <div>
                        <div>Time: {session.timestamp}</div>
                        <div>Location: {session.location}</div>
                      </div>
                      <div>
                        <div>Device: {session.device}</div>
                        <div className="flex items-center">
                          {session.status === 'success' ? (
                            <CheckCircle className="w-4 h-4 text-green-400 mr-1" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-red-400 mr-1" />
                          )}
                          {session.status === 'success' ? 'Verified' : 'Blocked'}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>

          {/* Security Recommendations */}
          <Card className="casino-card border-blue-400/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Shield className="w-5 h-5 mr-2 text-blue-400" />
                Security Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400 mt-0.5" />
                <div>
                  <div className="font-medium text-white">Enable Face ID</div>
                  <div className="text-sm text-gray-400">
                    Add Face ID as a backup authentication method
                  </div>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-5 h-5 text-orange-400 mt-0.5" />
                <div>
                  <div className="font-medium text-white">Review Failed Attempts</div>
                  <div className="text-sm text-gray-400">
                    Investigate recent failed authentication attempts
                  </div>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Lock className="w-5 h-5 text-blue-400 mt-0.5" />
                <div>
                  <div className="font-medium text-white">Enable Multi-Factor Auth</div>
                  <div className="text-sm text-gray-400">
                    Increase security with multiple verification methods
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}