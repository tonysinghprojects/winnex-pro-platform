import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Shield, Clock, DollarSign, AlertTriangle, Heart, Timer, Lock } from "lucide-react";

interface GamblingLimit {
  id: string;
  type: 'deposit' | 'loss' | 'wager' | 'session';
  period: 'daily' | 'weekly' | 'monthly';
  amount?: number;
  duration?: number; // for session limits in minutes
  currentUsage: number;
  isActive: boolean;
  setDate: string;
  nextResetDate: string;
}

interface SelfExclusion {
  isActive: boolean;
  type: 'temporary' | 'permanent';
  startDate: string;
  endDate?: string;
  reason: string;
  canReverse: boolean;
  cooldownPeriod: number; // days before can be reversed
}

interface GamblingSession {
  id: string;
  startTime: string;
  endTime?: string;
  duration: number; // minutes
  totalWagered: number;
  netResult: number;
  gamesPlayed: string[];
  status: 'active' | 'completed';
}

interface RiskAssessment {
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  score: number;
  factors: Array<{
    category: string;
    description: string;
    impact: 'positive' | 'negative';
    severity: number;
  }>;
  recommendations: string[];
  lastAssessment: string;
}

export default function ResponsibleGambling() {
  const [limits, setLimits] = useState<GamblingLimit[]>([]);
  const [selfExclusion, setSelfExclusion] = useState<SelfExclusion | null>(null);
  const [recentSessions, setRecentSessions] = useState<GamblingSession[]>([]);
  const [riskAssessment, setRiskAssessment] = useState<RiskAssessment | null>(null);
  const [activeTab, setActiveTab] = useState('limits');

  useEffect(() => {
    const mockLimits: GamblingLimit[] = [
      {
        id: 'deposit_daily',
        type: 'deposit',
        period: 'daily',
        amount: 500,
        currentUsage: 150,
        isActive: true,
        setDate: '2024-01-01',
        nextResetDate: '2024-01-16'
      },
      {
        id: 'loss_weekly',
        type: 'loss',
        period: 'weekly',
        amount: 1000,
        currentUsage: 350,
        isActive: true,
        setDate: '2024-01-01',
        nextResetDate: '2024-01-22'
      },
      {
        id: 'session_daily',
        type: 'session',
        period: 'daily',
        duration: 120, // 2 hours
        currentUsage: 45,
        isActive: true,
        setDate: '2024-01-01',
        nextResetDate: '2024-01-16'
      }
    ];

    const mockSelfExclusion: SelfExclusion = {
      isActive: false,
      type: 'temporary',
      startDate: '',
      endDate: '',
      reason: '',
      canReverse: false,
      cooldownPeriod: 7
    };

    const mockSessions: GamblingSession[] = [
      {
        id: 'session_1',
        startTime: '2024-01-15 14:30',
        endTime: '2024-01-15 16:15',
        duration: 105,
        totalWagered: 250,
        netResult: -75,
        gamesPlayed: ['Sports Betting', 'Blackjack'],
        status: 'completed'
      },
      {
        id: 'session_2',
        startTime: '2024-01-15 20:00',
        duration: 45,
        totalWagered: 120,
        netResult: 30,
        gamesPlayed: ['Sports Betting'],
        status: 'active'
      }
    ];

    const mockRiskAssessment: RiskAssessment = {
      riskLevel: 'medium',
      score: 65,
      factors: [
        {
          category: 'Time Spent',
          description: 'Playing 3+ hours per session',
          impact: 'negative',
          severity: 6
        },
        {
          category: 'Loss Pattern',
          description: 'Consistent losses over 7 days',
          impact: 'negative',
          severity: 7
        },
        {
          category: 'Limit Adherence',
          description: 'Staying within set limits',
          impact: 'positive',
          severity: 8
        }
      ],
      recommendations: [
        'Consider reducing session time limits',
        'Take regular breaks during gaming sessions',
        'Review your betting strategy and patterns'
      ],
      lastAssessment: '2024-01-15'
    };

    setLimits(mockLimits);
    setSelfExclusion(mockSelfExclusion);
    setRecentSessions(mockSessions);
    setRiskAssessment(mockRiskAssessment);
  }, []);

  const updateLimit = (limitId: string, newAmount: number) => {
    setLimits(prev => 
      prev.map(limit => 
        limit.id === limitId 
          ? { ...limit, amount: newAmount }
          : limit
      )
    );
  };

  const toggleLimit = (limitId: string) => {
    setLimits(prev => 
      prev.map(limit => 
        limit.id === limitId 
          ? { ...limit, isActive: !limit.isActive }
          : limit
      )
    );
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-orange-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getUsageColor = (usage: number, limit: number) => {
    const percentage = (usage / limit) * 100;
    if (percentage >= 90) return 'text-red-400';
    if (percentage >= 70) return 'text-yellow-400';
    return 'text-green-400';
  };

  return (
    <div className="p-6 space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <Shield className="w-12 h-12 text-emerald-400 mr-3" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            Responsible Gambling
          </h1>
        </div>
        <p className="text-gray-400 text-lg">Take control of your gaming experience with our safety tools</p>
      </div>

      {/* Risk Assessment Banner */}
      {riskAssessment && (
        <Card className={`casino-card border-${riskAssessment.riskLevel === 'critical' ? 'red' : riskAssessment.riskLevel === 'high' ? 'orange' : riskAssessment.riskLevel === 'medium' ? 'yellow' : 'green'}-400/20`}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Heart className={`w-6 h-6 ${getRiskLevelColor(riskAssessment.riskLevel)}`} />
                <div>
                  <h3 className="text-xl font-bold text-white">Risk Assessment</h3>
                  <p className="text-gray-400">Last updated: {riskAssessment.lastAssessment}</p>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-3xl font-bold ${getRiskLevelColor(riskAssessment.riskLevel)}`}>
                  {riskAssessment.riskLevel.toUpperCase()}
                </div>
                <div className="text-sm text-gray-400">Score: {riskAssessment.score}/100</div>
              </div>
            </div>
            <Progress value={riskAssessment.score} className="h-3 mb-4" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {riskAssessment.factors.map((factor, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${factor.impact === 'positive' ? 'bg-green-400' : 'bg-red-400'}`} />
                  <span className="text-sm text-gray-300">{factor.description}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="limits" className="flex items-center">
            <DollarSign className="w-4 h-4 mr-2" />
            Limits
          </TabsTrigger>
          <TabsTrigger value="exclusion" className="flex items-center">
            <Lock className="w-4 h-4 mr-2" />
            Self-Exclusion
          </TabsTrigger>
          <TabsTrigger value="sessions" className="flex items-center">
            <Timer className="w-4 h-4 mr-2" />
            Sessions
          </TabsTrigger>
          <TabsTrigger value="support" className="flex items-center">
            <Heart className="w-4 h-4 mr-2" />
            Support
          </TabsTrigger>
        </TabsList>

        <TabsContent value="limits" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Spending & Time Limits</CardTitle>
              <p className="text-gray-400">Set limits to control your gambling activity</p>
            </CardHeader>
            <CardContent className="space-y-6">
              {limits.map((limit) => (
                <Card key={limit.id} className="border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="text-emerald-400">
                          {limit.type === 'session' ? <Clock className="w-5 h-5" /> : <DollarSign className="w-5 h-5" />}
                        </div>
                        <div>
                          <h3 className="font-semibold text-white capitalize">
                            {limit.type} Limit ({limit.period})
                          </h3>
                          <p className="text-sm text-gray-400">
                            {limit.type === 'session' 
                              ? `Max ${limit.duration} minutes per ${limit.period}`
                              : `Max $${limit.amount} per ${limit.period}`
                            }
                          </p>
                        </div>
                      </div>
                      <Switch
                        checked={limit.isActive}
                        onCheckedChange={() => toggleLimit(limit.id)}
                      />
                    </div>

                    {limit.isActive && (
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span className="text-gray-400">
                              Usage: {limit.currentUsage}{limit.type === 'session' ? ' minutes' : ''} / 
                              {limit.type === 'session' ? limit.duration : limit.amount}
                              {limit.type !== 'session' ? '' : ' minutes'}
                            </span>
                            <span className={getUsageColor(limit.currentUsage, limit.type === 'session' ? limit.duration! : limit.amount!)}>
                              {Math.round((limit.currentUsage / (limit.type === 'session' ? limit.duration! : limit.amount!)) * 100)}%
                            </span>
                          </div>
                          <Progress 
                            value={(limit.currentUsage / (limit.type === 'session' ? limit.duration! : limit.amount!)) * 100} 
                            className="h-2"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm text-gray-400 mb-2 block">
                              {limit.type === 'session' ? 'Duration (minutes)' : 'Amount ($)'}
                            </label>
                            <Input
                              type="number"
                              value={limit.type === 'session' ? limit.duration : limit.amount}
                              onChange={(e) => updateLimit(limit.id, parseInt(e.target.value))}
                              className="bg-gray-800 border-gray-700"
                            />
                          </div>
                          <div>
                            <label className="text-sm text-gray-400 mb-2 block">Reset Date</label>
                            <div className="bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white">
                              {limit.nextResetDate}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}

              <Button className="w-full bg-emerald-500 hover:bg-emerald-600">
                Add New Limit
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="exclusion" className="space-y-6">
          <Card className="casino-card border-red-400/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Lock className="w-5 h-5 mr-2 text-red-400" />
                Self-Exclusion
              </CardTitle>
              <p className="text-gray-400">Temporarily or permanently exclude yourself from gambling</p>
            </CardHeader>
            <CardContent className="space-y-6">
              {!selfExclusion?.isActive ? (
                <div className="space-y-6">
                  <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-red-400 mb-2">Important Information</h4>
                        <ul className="text-sm text-gray-300 space-y-1">
                          <li>• Self-exclusion will immediately block access to all gambling features</li>
                          <li>• You can still access your account to withdraw funds</li>
                          <li>• Temporary exclusions have a minimum period of 24 hours</li>
                          <li>• Permanent exclusions cannot be reversed</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="border-orange-500/20">
                      <CardContent className="p-6 text-center">
                        <Clock className="w-12 h-12 text-orange-400 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-white mb-2">Temporary Exclusion</h3>
                        <p className="text-gray-400 mb-4">Take a break for a set period</p>
                        <Select>
                          <SelectTrigger className="bg-gray-800 border-gray-700 mb-4">
                            <SelectValue placeholder="Select duration" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="24h">24 Hours</SelectItem>
                            <SelectItem value="1w">1 Week</SelectItem>
                            <SelectItem value="1m">1 Month</SelectItem>
                            <SelectItem value="3m">3 Months</SelectItem>
                            <SelectItem value="6m">6 Months</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button className="w-full bg-orange-500 hover:bg-orange-600">
                          Start Temporary Exclusion
                        </Button>
                      </CardContent>
                    </Card>

                    <Card className="border-red-500/20">
                      <CardContent className="p-6 text-center">
                        <Lock className="w-12 h-12 text-red-400 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-white mb-2">Permanent Exclusion</h3>
                        <p className="text-gray-400 mb-4">Permanently block all gambling access</p>
                        <div className="bg-red-500/10 border border-red-500/20 rounded p-3 mb-4">
                          <p className="text-sm text-red-400">
                            This action cannot be undone. Please consider carefully.
                          </p>
                        </div>
                        <Button className="w-full bg-red-500 hover:bg-red-600">
                          Permanent Self-Exclusion
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-6">
                  <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-6">
                    <Lock className="w-16 h-16 text-red-400 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-white mb-2">You are Self-Excluded</h3>
                    <p className="text-gray-400 mb-4">
                      {selfExclusion.type === 'permanent' 
                        ? 'Your account is permanently excluded from gambling activities.'
                        : `Your exclusion will end on ${selfExclusion.endDate}.`
                      }
                    </p>
                    {selfExclusion.canReverse && (
                      <Button variant="outline" className="mt-4">
                        Request Early Reversal
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sessions" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Gaming Sessions</CardTitle>
              <p className="text-gray-400">Track your recent gambling activity</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentSessions.map((session) => (
                <Card key={session.id} className="border-gray-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${session.status === 'active' ? 'bg-green-400' : 'bg-gray-400'}`} />
                        <span className="font-semibold text-white">
                          {session.status === 'active' ? 'Active Session' : 'Completed Session'}
                        </span>
                        <Badge variant="outline">
                          {session.duration}m
                        </Badge>
                      </div>
                      <div className={`text-lg font-bold ${session.netResult >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {session.netResult >= 0 ? '+' : ''}${session.netResult}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-400">Start: </span>
                        <span className="text-white">{session.startTime}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Wagered: </span>
                        <span className="text-white">${session.totalWagered}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Games: </span>
                        <span className="text-white">{session.gamesPlayed.join(', ')}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Duration: </span>
                        <span className="text-white">{session.duration} minutes</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="support" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-white">Need Help?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <Button className="w-full bg-blue-500 hover:bg-blue-600">
                    Chat with Support Specialist
                  </Button>
                  <Button variant="outline" className="w-full">
                    Schedule Callback
                  </Button>
                  <Button variant="outline" className="w-full">
                    Email Support Team
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-white">External Resources</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <a href="https://www.gamcare.org.uk" target="_blank" rel="noopener noreferrer" 
                   className="block p-3 bg-gray-800 rounded hover:bg-gray-700 transition-colors">
                  <div className="font-semibold text-white">GamCare</div>
                  <div className="text-sm text-gray-400">Free support and advice</div>
                </a>
                <a href="https://www.gamblingtherapy.org" target="_blank" rel="noopener noreferrer"
                   className="block p-3 bg-gray-800 rounded hover:bg-gray-700 transition-colors">
                  <div className="font-semibold text-white">Gambling Therapy</div>
                  <div className="text-sm text-gray-400">Online support community</div>
                </a>
                <a href="https://www.gamblersanonymous.org" target="_blank" rel="noopener noreferrer"
                   className="block p-3 bg-gray-800 rounded hover:bg-gray-700 transition-colors">
                  <div className="font-semibold text-white">Gamblers Anonymous</div>
                  <div className="text-sm text-gray-400">Support groups worldwide</div>
                </a>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}