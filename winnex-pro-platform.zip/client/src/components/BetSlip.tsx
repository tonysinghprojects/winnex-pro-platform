import { useState, useEffect } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trash2, Ticket, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface BetSelection {
  matchId: number;
  match: string;
  market: string;
  selection: string;
  odds: string;
  stake: string;
}

export default function BetSlip() {
  const [selections, setSelections] = useState<BetSelection[]>([]);
  const [animatedTotal, setAnimatedTotal] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const placeBetMutation = useMutation({
    mutationFn: async (betData: any) => {
      await apiRequest("POST", "/api/bets", betData);
    },
    onSuccess: () => {
      toast({
        title: "Bet Placed Successfully!",
        description: "Your bet has been placed and is being processed.",
      });
      setSelections([]);
      queryClient.invalidateQueries({ queryKey: ["/api/user/balance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bets"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Bet Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addSelection = (selection: Omit<BetSelection, "stake">) => {
    const existingIndex = selections.findIndex(
      s => s.matchId === selection.matchId && s.selection === selection.selection
    );
    
    if (existingIndex >= 0) {
      const updated = [...selections];
      updated[existingIndex] = { ...selection, stake: updated[existingIndex].stake };
      setSelections(updated);
    } else {
      setSelections([...selections, { ...selection, stake: "" }]);
    }
  };

  const removeSelection = (index: number) => {
    setSelections(selections.filter((_, i) => i !== index));
  };

  const updateStake = (index: number, stake: string) => {
    const updated = [...selections];
    updated[index].stake = stake;
    setSelections(updated);
  };

  const calculateTotalStake = () => {
    return selections.reduce((total, selection) => {
      return total + (parseFloat(selection.stake) || 0);
    }, 0);
  };

  const calculatePotentialWin = () => {
    return selections.reduce((total, selection) => {
      const stake = parseFloat(selection.stake) || 0;
      const odds = parseFloat(selection.odds) || 0;
      return total + (stake * odds);
    }, 0);
  };

  const placeBet = () => {
    const validSelections = selections.filter(s => parseFloat(s.stake) > 0);
    
    if (validSelections.length === 0) {
      toast({
        title: "No Valid Bets",
        description: "Please add stakes to your selections.",
        variant: "destructive",
      });
      return;
    }

    validSelections.forEach(selection => {
      placeBetMutation.mutate({
        matchId: selection.matchId,
        market: selection.market,
        selection: selection.selection,
        odds: selection.odds,
        stake: selection.stake,
        potentialWin: (parseFloat(selection.stake) * parseFloat(selection.odds)).toFixed(2),
      });
    });
  };

  // Expose addSelection function globally for match cards to use
  (window as any).addToBetSlip = addSelection;

  return (
    <div className="bg-winnex-gray rounded-lg p-4 sticky top-20 max-h-[80vh] overflow-y-auto">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold flex items-center">
          <Ticket className="mr-2" size={18} />
          Enhanced Bet Slip
        </h3>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs">
            {selections.length} selection{selections.length !== 1 ? 's' : ''}
          </Badge>
          {selections.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelections([])}
              className="text-gray-400 hover:text-white"
            >
              Clear All
            </Button>
          )}
        </div>
      </div>

      {selections.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <Ticket size={48} className="mx-auto mb-4 opacity-50" />
          <p>Your bet slip is empty</p>
          <p className="text-sm mt-2">Add selections from matches to get started</p>
        </div>
      ) : (
        <>
          {/* Quick Stakes */}
          <Card className="bg-winnex-dark border-winnex-accent mb-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Zap size={16} />
                Quick Stakes
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-4 gap-2">
                {[5, 10, 25, 50].map(amount => (
                  <Button
                    key={amount}
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const updated = selections.map(selection => ({
                        ...selection,
                        stake: amount.toString()
                      }));
                      setSelections(updated);
                    }}
                    className="text-xs"
                  >
                    ${amount}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Individual Selections */}
          <div className="space-y-3 mb-4">
            {selections.map((selection, index) => (
              <Card key={index} className="bg-winnex-dark border-winnex-accent">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{selection.match}</h4>
                      <p className="text-xs text-gray-400">{selection.market}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-xs">
                          {selection.selection}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {selection.odds}
                        </Badge>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSelection(index)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        placeholder="Stake"
                        value={selection.stake}
                        onChange={(e) => updateStake(index, e.target.value)}
                        className="flex-1 bg-winnex-gray border-winnex-accent"
                      />
                      <span className="text-sm text-gray-400">$</span>
                    </div>
                    
                    {parseFloat(selection.stake) > 0 && (
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">Potential Win:</span>
                        <span className="text-winnex-accent font-medium">
                          ${(parseFloat(selection.stake) * parseFloat(selection.odds)).toFixed(2)}
                        </span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Betting Summary */}
          <Card className="bg-gradient-to-r from-winnex-accent/20 to-winnex-primary/20 border-winnex-accent mb-4">
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-300">Total Stake:</span>
                  <span className="font-bold text-lg">
                    ${calculateTotalStake().toFixed(2)}
                  </span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-300">Potential Win:</span>
                  <span className="font-bold text-lg text-winnex-accent">
                    ${calculatePotentialWin().toFixed(2)}
                  </span>
                </div>
                
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Potential Profit:</span>
                  <span className="text-green-400 font-medium">
                    ${(calculatePotentialWin() - calculateTotalStake()).toFixed(2)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Place Bet Button */}
          <Button
            onClick={placeBet}
            disabled={placeBetMutation.isPending || calculateTotalStake() === 0}
            className="w-full bg-gradient-to-r from-winnex-accent to-winnex-primary hover:from-winnex-primary hover:to-winnex-accent transition-all duration-300"
            size="lg"
          >
            {placeBetMutation.isPending ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                Placing Bet...
              </div>
            ) : (
              "Place Bet"
            )}
          </Button>
        </>
      )}
    </div>
  );
}