import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { MapPin, Globe, Clock, AlertTriangle, CheckCircle, Shield } from "lucide-react";

interface LocationData {
  country: string;
  state: string;
  city: string;
  timezone: string;
  coordinates: { lat: number; lng: number };
  isAllowed: boolean;
  restrictions: string[];
  localCurrency: string;
  legalAge: number;
  availableMarkets: string[];
  licensedOperator: boolean;
}

interface LocalContent {
  popularSports: Array<{
    sport: string;
    matches: number;
    popularity: number;
  }>;
  localTeams: Array<{
    name: string;
    league: string;
    nextMatch?: string;
  }>;
  timeZoneAdjustedMatches: Array<{
    match: string;
    localTime: string;
    utcTime: string;
    league: string;
  }>;
  regionalPromotions: Array<{
    title: string;
    description: string;
    validRegions: string[];
    terms: string;
  }>;
}

export default function GeolocationBetting() {
  const [locationPermission, setLocationPermission] = useState<'granted' | 'denied' | 'prompt'>('prompt');
  const [userLocation, setUserLocation] = useState<LocationData | null>(null);

  const { data: locationData } = useQuery<LocationData>({
    queryKey: ["/api/location/data"],
    enabled: locationPermission === 'granted',
  });

  const { data: localContent } = useQuery<LocalContent>({
    queryKey: ["/api/location/content", userLocation?.country, userLocation?.state],
    enabled: !!userLocation,
  });

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.permissions.query({ name: "geolocation" }).then((result) => {
        setLocationPermission(result.state);
      });
    }
  }, []);

  const requestLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          // In a real implementation, you'd send these coordinates to your backend
          // to determine location data and legal compliance
          setLocationPermission('granted');
        },
        (error) => {
          console.error("Geolocation error:", error);
          setLocationPermission('denied');
        }
      );
    }
  };

  const formatLocalTime = (utcTime: string, timezone: string) => {
    return new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      day: 'numeric',
      month: 'short',
    }).format(new Date(utcTime));
  };

  if (locationPermission === 'prompt') {
    return (
      <div className="card-modern p-8 text-center">
        <MapPin className="mx-auto mb-4 text-winnex-blue" size={48} />
        <h3 className="text-2xl font-bold mb-4">Enhance Your Betting Experience</h3>
        <p className="text-white/80 mb-6 max-w-md mx-auto">
          Allow location access to get personalized content, local team updates, 
          and matches in your timezone with region-specific offers.
        </p>
        <button onClick={requestLocation} className="btn-primary">
          Enable Location Services
        </button>
        <div className="mt-4 text-sm text-white/60">
          <Shield className="inline mr-1" size={14} />
          Your location data is secure and only used to enhance your experience
        </div>
      </div>
    );
  }

  if (locationPermission === 'denied' || !locationData) {
    return (
      <div className="card-modern p-8 text-center">
        <Globe className="mx-auto mb-4 text-winnex-orange" size={48} />
        <h3 className="text-xl font-bold mb-4">Location Access Disabled</h3>
        <p className="text-white/80 mb-6">
          You can still enjoy Winnex, but some personalized features may be limited.
        </p>
        <button onClick={requestLocation} className="btn-secondary">
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Location Status */}
      <div className="card-modern p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <MapPin className="text-winnex-green" size={24} />
            <div>
              <h3 className="font-bold text-lg">
                {locationData.city}, {locationData.state}
              </h3>
              <p className="text-white/60">{locationData.country}</p>
            </div>
          </div>
          <div className="text-right">
            <div className={`flex items-center space-x-2 ${
              locationData.isAllowed ? 'text-winnex-green' : 'text-red-400'
            }`}>
              {locationData.isAllowed ? <CheckCircle size={16} /> : <AlertTriangle size={16} />}
              <span className="font-medium">
                {locationData.isAllowed ? 'Betting Allowed' : 'Restricted Region'}
              </span>
            </div>
            <div className="text-sm text-white/60">
              Licensed Operator: {locationData.licensedOperator ? 'Yes' : 'No'}
            </div>
          </div>
        </div>

        {locationData.restrictions.length > 0 && (
          <div className="mt-4 p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
            <h4 className="font-semibold text-red-400 mb-2">Regional Restrictions</h4>
            <ul className="text-sm text-red-300 space-y-1">
              {locationData.restrictions.map((restriction, index) => (
                <li key={index}>• {restriction}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Local Time Zone Matches */}
      {localContent?.timeZoneAdjustedMatches && (
        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <Clock className="mr-2 text-winnex-blue" />
            Matches in Your Timezone
          </h3>
          <div className="space-y-3">
            {localContent.timeZoneAdjustedMatches.map((match, index) => (
              <div key={index} className="glass rounded-lg p-4 flex justify-between items-center">
                <div>
                  <div className="font-medium">{match.match}</div>
                  <div className="text-sm text-winnex-blue">{match.league}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-winnex-green">{match.localTime}</div>
                  <div className="text-xs text-white/60">Local time</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Popular Local Sports */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4">Popular Sports in {locationData.state}</h3>
          <div className="space-y-3">
            {localContent?.popularSports?.map((sport, index) => (
              <div key={index} className="flex justify-between items-center">
                <div>
                  <div className="font-medium">{sport.sport}</div>
                  <div className="text-sm text-white/60">{sport.matches} live matches</div>
                </div>
                <div className="text-right">
                  <div className="w-16 h-2 bg-white/10 rounded-full">
                    <div
                      className="h-2 bg-winnex-green rounded-full"
                      style={{ width: `${sport.popularity}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-winnex-green mt-1">{sport.popularity}%</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4">Local Teams</h3>
          <div className="space-y-3">
            {localContent?.localTeams?.map((team, index) => (
              <div key={index} className="glass rounded-lg p-3">
                <div className="font-medium">{team.name}</div>
                <div className="text-sm text-winnex-blue">{team.league}</div>
                {team.nextMatch && (
                  <div className="text-xs text-white/60 mt-1">
                    Next: {team.nextMatch}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Regional Promotions */}
      {localContent?.regionalPromotions && localContent.regionalPromotions.length > 0 && (
        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4">
            Exclusive Offers for {locationData.state}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {localContent.regionalPromotions.map((promo, index) => (
              <div key={index} className="glass rounded-lg p-4">
                <h4 className="font-bold mb-2">{promo.title}</h4>
                <p className="text-sm text-white/80 mb-3">{promo.description}</p>
                <div className="text-xs text-white/60">
                  Valid in: {promo.validRegions.join(', ')}
                </div>
                <button className="btn-primary w-full mt-3 text-sm">
                  Claim Offer
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Legal Compliance Info */}
      <div className="card-modern p-6 bg-winnex-blue/5 border border-winnex-blue/20">
        <h3 className="text-lg font-bold mb-4 text-winnex-blue">Legal Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div>
            <div className="font-medium">Legal Gambling Age</div>
            <div className="text-winnex-blue">{locationData.legalAge}+ years</div>
          </div>
          <div>
            <div className="font-medium">Local Currency</div>
            <div className="text-winnex-blue">{locationData.localCurrency}</div>
          </div>
          <div>
            <div className="font-medium">Available Markets</div>
            <div className="text-winnex-blue">{locationData.availableMarkets.length} markets</div>
          </div>
        </div>
        <div className="mt-4 text-xs text-white/60">
          Winnex operates under strict regulatory compliance. Gambling should be fun and responsible.
          If you need help, visit our responsible gaming page.
        </div>
      </div>
    </div>
  );
}