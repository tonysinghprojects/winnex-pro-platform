import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Shield, AlertTriangle, Clock, DollarSign, PauseCircle, Eye, BarChart3, Heart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ResponsibleGamingSettings {
  dailyDepositLimit: number | null;
  weeklyDepositLimit: number | null;
  monthlyDepositLimit: number | null;
  dailyBetLimit: number | null;
  weeklyBetLimit: number | null;
  sessionTimeLimit: number | null; // minutes
  lossLimit: number | null;
  realityCheckInterval: number | null; // minutes
  cooloffPeriod: Date | null;
  selfExclusionPeriod: Date | null;
  autoLogoutAfter: number | null; // minutes
}

interface GamingBehaviorData {
  sessionDuration: number;
  depositsToday: number;
  betsToday: number;
  lossesToday: number;
  weeklySpend: number;
  monthlySpend: number;
  avgSessionLength: number;
  biggestLoss: number;
  consecutiveLosses: number;
  riskScore: number; // 0-100
  behaviorAlerts: Array<{
    type: 'spending' | 'time' | 'pattern' | 'loss';
    severity: 'low' | 'medium' | 'high';
    message: string;
    timestamp: string;
  }>;
}

interface SupportResource {
  organization: string;
  type: 'hotline' | 'website' | 'chat' | 'local';
  contact: string;
  description: string;
  available24h: boolean;
  language: string[];
}

export default function ResponsibleGamingTools() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'limits' | 'tools' | 'support'>('dashboard');
  const [showRealityCheck, setShowRealityCheck] = useState(false);
  const [sessionStartTime] = useState(Date.now());
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings } = useQuery<ResponsibleGamingSettings>({
    queryKey: ["/api/responsible-gaming/settings"],
  });

  const { data: behaviorData } = useQuery<GamingBehaviorData>({
    queryKey: ["/api/responsible-gaming/behavior"],
    refetchInterval: 60000, // Update every minute
  });

  const { data: supportResources = [] } = useQuery<SupportResource[]>({
    queryKey: ["/api/responsible-gaming/support"],
  });

  const updateSettings = useMutation({
    mutationFn: async (data: Partial<ResponsibleGamingSettings>) => {
      return apiRequest("/api/responsible-gaming/settings", "PUT", data);
    },
    onSuccess: () => {
      toast({
        title: "Settings Updated",
        description: "Your responsible gaming limits have been updated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/responsible-gaming/settings"] });
    },
  });

  const takeCooloff = useMutation({
    mutationFn: async (hours: number) => {
      return apiRequest("/api/responsible-gaming/cooloff", "POST", { hours });
    },
    onSuccess: () => {
      toast({
        title: "Cool-off Period Activated",
        description: "Your account has been temporarily restricted",
      });
    },
  });

  const selfExclude = useMutation({
    mutationFn: async (days: number) => {
      return apiRequest("/api/responsible-gaming/self-exclude", "POST", { days });
    },
    onSuccess: () => {
      toast({
        title: "Self-Exclusion Activated",
        description: "Your account will be suspended for the selected period",
      });
    },
  });

  // Reality check timer
  useEffect(() => {
    if (settings?.realityCheckInterval) {
      const interval = setInterval(() => {
        setShowRealityCheck(true);
      }, settings.realityCheckInterval * 60000);
      
      return () => clearInterval(interval);
    }
  }, [settings?.realityCheckInterval]);

  const currentSessionTime = Math.floor((Date.now() - sessionStartTime) / 60000);
  
  const getRiskColor = (score: number) => {
    if (score >= 70) return 'text-red-400';
    if (score >= 40) return 'text-winnex-orange';
    return 'text-winnex-green';
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-500/20 border-red-500/30 text-red-400';
      case 'medium': return 'bg-winnex-orange/20 border-winnex-orange/30 text-winnex-orange';
      case 'low': return 'bg-winnex-green/20 border-winnex-green/30 text-winnex-green';
      default: return 'bg-white/10 border-white/20 text-white';
    }
  };

  return (
    <div className="space-y-6">
      {/* Reality Check Modal */}
      {showRealityCheck && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="card-modern p-8 max-w-md mx-4">
            <div className="text-center">
              <Clock className="mx-auto mb-4 text-winnex-orange" size={48} />
              <h3 className="text-2xl font-bold mb-4">Reality Check</h3>
              <p className="text-white/80 mb-2">
                You've been playing for {currentSessionTime} minutes
              </p>
              <p className="text-sm text-white/60 mb-6">
                Today's spending: ${behaviorData?.depositsToday || 0}
              </p>
              <div className="flex space-x-3">
                <button 
                  onClick={() => setShowRealityCheck(false)}
                  className="btn-secondary flex-1"
                >
                  Continue Playing
                </button>
                <button 
                  onClick={() => {
                    setShowRealityCheck(false);
                    takeCooloff.mutate(1);
                  }}
                  className="btn-primary flex-1"
                >
                  Take a Break
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="card-modern p-6 bg-gradient-to-r from-green-900/50 to-blue-900/50 border border-green-500/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Shield className="text-winnex-green" size={32} />
            <div>
              <h2 className="text-2xl font-bold text-white">Responsible Gaming</h2>
              <p className="text-white/80">Stay in control of your betting with our safety tools</p>
            </div>
          </div>
          <div className="text-right">
            <div className={`text-2xl font-bold ${getRiskColor(behaviorData?.riskScore || 0)}`}>
              {behaviorData?.riskScore || 0}/100
            </div>
            <div className="text-white/70 text-sm">Risk Score</div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="glass rounded-xl p-1 flex">
        {(['dashboard', 'limits', 'tools', 'support'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all capitalize ${
              activeTab === tab ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Dashboard Tab */}
      {activeTab === 'dashboard' && behaviorData && (
        <div className="space-y-6">
          {/* Behavior Alerts */}
          {behaviorData.behaviorAlerts.length > 0 && (
            <div className="space-y-3">
              {behaviorData.behaviorAlerts.map((alert, index) => (
                <div key={index} className={`p-4 rounded-lg border ${getSeverityColor(alert.severity)}`}>
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertTriangle size={16} />
                    <span className="font-medium capitalize">{alert.severity} Risk Alert</span>
                  </div>
                  <p className="text-sm">{alert.message}</p>
                  <div className="text-xs opacity-70 mt-1">
                    {new Date(alert.timestamp).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Current Session Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="card-modern p-6 text-center">
              <Clock className="mx-auto mb-2 text-winnex-blue" size={24} />
              <div className="text-2xl font-bold">{currentSessionTime}m</div>
              <div className="text-white/60 text-sm">Session Time</div>
            </div>
            <div className="card-modern p-6 text-center">
              <DollarSign className="mx-auto mb-2 text-winnex-green" size={24} />
              <div className="text-2xl font-bold">${behaviorData.depositsToday}</div>
              <div className="text-white/60 text-sm">Today's Deposits</div>
            </div>
            <div className="card-modern p-6 text-center">
              <BarChart3 className="mx-auto mb-2 text-winnex-orange" size={24} />
              <div className="text-2xl font-bold">{behaviorData.betsToday}</div>
              <div className="text-white/60 text-sm">Bets Today</div>
            </div>
            <div className="card-modern p-6 text-center">
              <Heart className="mx-auto mb-2 text-red-400" size={24} />
              <div className="text-2xl font-bold">${behaviorData.lossesToday}</div>
              <div className="text-white/60 text-sm">Today's Losses</div>
            </div>
          </div>

          {/* Weekly/Monthly Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4">Spending Trends</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>This Week</span>
                  <span className="font-bold text-winnex-orange">${behaviorData.weeklySpend}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>This Month</span>
                  <span className="font-bold text-winnex-orange">${behaviorData.monthlySpend}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Average Session</span>
                  <span className="font-bold">{behaviorData.avgSessionLength}m</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Biggest Loss</span>
                  <span className="font-bold text-red-400">${behaviorData.biggestLoss}</span>
                </div>
              </div>
            </div>

            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4">Behavior Patterns</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Consecutive Losses</span>
                  <span className={`font-bold ${behaviorData.consecutiveLosses > 5 ? 'text-red-400' : 'text-white'}`}>
                    {behaviorData.consecutiveLosses}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Risk Assessment</span>
                  <span className={`font-bold ${getRiskColor(behaviorData.riskScore)}`}>
                    {behaviorData.riskScore < 30 ? 'Low' : 
                     behaviorData.riskScore < 70 ? 'Medium' : 'High'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Limits Tab */}
      {activeTab === 'limits' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4">Deposit Limits</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Daily Limit</label>
                  <input
                    type="number"
                    value={settings?.dailyDepositLimit || ''}
                    onChange={(e) => updateSettings.mutate({ dailyDepositLimit: parseFloat(e.target.value) || null })}
                    placeholder="No limit set"
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Weekly Limit</label>
                  <input
                    type="number"
                    value={settings?.weeklyDepositLimit || ''}
                    onChange={(e) => updateSettings.mutate({ weeklyDepositLimit: parseFloat(e.target.value) || null })}
                    placeholder="No limit set"
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Monthly Limit</label>
                  <input
                    type="number"
                    value={settings?.monthlyDepositLimit || ''}
                    onChange={(e) => updateSettings.mutate({ monthlyDepositLimit: parseFloat(e.target.value) || null })}
                    placeholder="No limit set"
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  />
                </div>
              </div>
            </div>

            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4">Betting Limits</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Daily Bet Limit</label>
                  <input
                    type="number"
                    value={settings?.dailyBetLimit || ''}
                    onChange={(e) => updateSettings.mutate({ dailyBetLimit: parseFloat(e.target.value) || null })}
                    placeholder="No limit set"
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Weekly Bet Limit</label>
                  <input
                    type="number"
                    value={settings?.weeklyBetLimit || ''}
                    onChange={(e) => updateSettings.mutate({ weeklyBetLimit: parseFloat(e.target.value) || null })}
                    placeholder="No limit set"
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Loss Limit</label>
                  <input
                    type="number"
                    value={settings?.lossLimit || ''}
                    onChange={(e) => updateSettings.mutate({ lossLimit: parseFloat(e.target.value) || null })}
                    placeholder="No limit set"
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="card-modern p-6">
            <h3 className="text-lg font-bold mb-4">Session Management</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Session Time Limit (minutes)</label>
                <input
                  type="number"
                  value={settings?.sessionTimeLimit || ''}
                  onChange={(e) => updateSettings.mutate({ sessionTimeLimit: parseFloat(e.target.value) || null })}
                  placeholder="No limit"
                  className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Reality Check Interval (minutes)</label>
                <input
                  type="number"
                  value={settings?.realityCheckInterval || ''}
                  onChange={(e) => updateSettings.mutate({ realityCheckInterval: parseFloat(e.target.value) || null })}
                  placeholder="No reminders"
                  className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Auto Logout (minutes)</label>
                <input
                  type="number"
                  value={settings?.autoLogoutAfter || ''}
                  onChange={(e) => updateSettings.mutate({ autoLogoutAfter: parseFloat(e.target.value) || null })}
                  placeholder="No auto logout"
                  className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tools Tab */}
      {activeTab === 'tools' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <PauseCircle className="mr-2 text-winnex-orange" />
                Take a Break
              </h3>
              <p className="text-white/80 mb-6">
                Temporarily restrict your account access to help you take a break from betting.
              </p>
              <div className="space-y-3">
                <button
                  onClick={() => takeCooloff.mutate(1)}
                  className="btn-secondary w-full"
                  disabled={takeCooloff.isPending}
                >
                  1 Hour Break
                </button>
                <button
                  onClick={() => takeCooloff.mutate(24)}
                  className="btn-secondary w-full"
                  disabled={takeCooloff.isPending}
                >
                  24 Hour Break
                </button>
                <button
                  onClick={() => takeCooloff.mutate(168)}
                  className="btn-secondary w-full"
                  disabled={takeCooloff.isPending}
                >
                  7 Day Break
                </button>
              </div>
            </div>

            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <Eye className="mr-2 text-red-400" />
                Self-Exclusion
              </h3>
              <p className="text-white/80 mb-6">
                Permanently exclude yourself from Winnex for a set period. This cannot be reversed.
              </p>
              <div className="space-y-3">
                <button
                  onClick={() => selfExclude.mutate(30)}
                  className="btn-outline w-full border-red-500 text-red-400 hover:bg-red-500/10"
                  disabled={selfExclude.isPending}
                >
                  30 Days
                </button>
                <button
                  onClick={() => selfExclude.mutate(90)}
                  className="btn-outline w-full border-red-500 text-red-400 hover:bg-red-500/10"
                  disabled={selfExclude.isPending}
                >
                  3 Months
                </button>
                <button
                  onClick={() => selfExclude.mutate(365)}
                  className="btn-outline w-full border-red-500 text-red-400 hover:bg-red-500/10"
                  disabled={selfExclude.isPending}
                >
                  1 Year
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Support Tab */}
      {activeTab === 'support' && (
        <div className="space-y-6">
          <div className="card-modern p-6 bg-gradient-to-r from-blue-900/30 to-purple-900/30 border border-blue-500/20">
            <h3 className="text-xl font-bold mb-4">Remember: Gambling Should Be Fun</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2">Signs of Problem Gambling:</h4>
                <ul className="text-sm text-white/80 space-y-1">
                  <li>• Betting more than you can afford</li>
                  <li>• Chasing losses with bigger bets</li>
                  <li>• Neglecting responsibilities</li>
                  <li>• Borrowing money to gamble</li>
                  <li>• Feeling anxious when not betting</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Healthy Gambling Tips:</h4>
                <ul className="text-sm text-white/80 space-y-1">
                  <li>• Set limits before you start</li>
                  <li>• Never chase your losses</li>
                  <li>• Take regular breaks</li>
                  <li>• Don't gamble when upset</li>
                  <li>• Keep gambling social and fun</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {supportResources.map((resource, index) => (
              <div key={index} className="card-modern p-6">
                <h4 className="font-bold text-lg mb-2">{resource.organization}</h4>
                <p className="text-white/80 text-sm mb-4">{resource.description}</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Contact:</span>
                    <span className="font-medium text-winnex-blue">{resource.contact}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Type:</span>
                    <span className="capitalize">{resource.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Available:</span>
                    <span className={resource.available24h ? 'text-winnex-green' : 'text-winnex-orange'}>
                      {resource.available24h ? '24/7' : 'Business Hours'}
                    </span>
                  </div>
                </div>
                <button className="btn-primary w-full mt-4">
                  Contact Support
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}