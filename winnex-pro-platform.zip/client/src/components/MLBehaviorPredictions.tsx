import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Brain, TrendingUp, Target, Zap, Clock, DollarSign, BarChart3, AlertCircle } from "lucide-react";

interface BehaviorPrediction {
  type: 'betting_pattern' | 'risk_assessment' | 'churn_probability' | 'value_prediction';
  confidence: number;
  prediction: string;
  reasoning: string[];
  timeframe: string;
  actionable_insights: string[];
  risk_level: 'low' | 'medium' | 'high';
}

interface UserBehaviorAnalysis {
  userId: string;
  analysisTimestamp: string;
  behaviorScore: number;
  riskProfile: 'conservative' | 'moderate' | 'aggressive';
  predictedActions: {
    nextBetProbability: number;
    preferredSports: string[];
    optimalBettingTime: string;
    suggestedStake: number;
    churnRisk: number;
  };
  seasonalPatterns: {
    month: string;
    activity: number;
    avgStake: number;
    winRate: number;
  }[];
  predictions: BehaviorPrediction[];
}

interface MLInsight {
  id: string;
  title: string;
  description: string;
  impact: 'positive' | 'negative' | 'neutral';
  confidence: number;
  category: 'engagement' | 'risk' | 'profitability' | 'retention';
  recommendation: string;
  metrics: {
    current: number;
    predicted: number;
    change: number;
  };
}

export default function MLBehaviorPredictions() {
  const [selectedTimeframe, setSelectedTimeframe] = useState<'1d' | '7d' | '30d' | '90d'>('7d');
  
  const { data: behaviorAnalysis } = useQuery<UserBehaviorAnalysis>({
    queryKey: ["/api/ml/behavior-analysis", selectedTimeframe],
    refetchInterval: 300000, // Update every 5 minutes
  });

  const { data: mlInsights = [] } = useQuery<MLInsight[]>({
    queryKey: ["/api/ml/insights"],
    refetchInterval: 600000, // Update every 10 minutes
  });

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-winnex-green';
    if (confidence >= 0.6) return 'text-winnex-orange';
    return 'text-red-400';
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-winnex-green';
      case 'medium': return 'text-winnex-orange';
      case 'high': return 'text-red-400';
      default: return 'text-white';
    }
  };

  const getImpactIcon = (impact: string) => {
    switch (impact) {
      case 'positive': return <TrendingUp className="text-winnex-green" size={16} />;
      case 'negative': return <AlertCircle className="text-red-400" size={16} />;
      default: return <BarChart3 className="text-winnex-blue" size={16} />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card-modern p-6 gradient-accent">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Brain className="text-winnex-purple" size={32} />
            <div>
              <h2 className="text-2xl font-bold text-white">AI Behavior Analysis</h2>
              <p className="text-white/80">Machine learning insights into your betting patterns and preferences</p>
            </div>
          </div>
          <div className="glass rounded-2xl p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-winnex-purple">
                {behaviorAnalysis?.behaviorScore || 0}
              </div>
              <div className="text-white/70 text-sm">Behavior Score</div>
            </div>
          </div>
        </div>
      </div>

      {/* Timeframe Selector */}
      <div className="flex justify-center">
        <div className="glass rounded-xl p-1 flex">
          {(['1d', '7d', '30d', '90d'] as const).map((timeframe) => (
            <button
              key={timeframe}
              onClick={() => setSelectedTimeframe(timeframe)}
              className={`px-6 py-2 rounded-lg font-medium transition-all ${
                selectedTimeframe === timeframe ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
              }`}
            >
              {timeframe}
            </button>
          ))}
        </div>
      </div>

      {/* Predicted Actions */}
      {behaviorAnalysis && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="card-modern p-6 text-center">
            <Target className="mx-auto mb-3 text-winnex-green" size={24} />
            <div className="text-2xl font-bold text-winnex-green">
              {Math.round(behaviorAnalysis.predictedActions.nextBetProbability * 100)}%
            </div>
            <div className="text-white/60 text-sm">Next Bet Probability</div>
            <div className="text-xs text-white/50 mt-1">Within 24 hours</div>
          </div>

          <div className="card-modern p-6 text-center">
            <DollarSign className="mx-auto mb-3 text-winnex-blue" size={24} />
            <div className="text-2xl font-bold text-winnex-blue">
              ${behaviorAnalysis.predictedActions.suggestedStake}
            </div>
            <div className="text-white/60 text-sm">Optimal Stake</div>
            <div className="text-xs text-white/50 mt-1">Based on bankroll</div>
          </div>

          <div className="card-modern p-6 text-center">
            <Clock className="mx-auto mb-3 text-winnex-orange" size={24} />
            <div className="text-lg font-bold text-winnex-orange">
              {behaviorAnalysis.predictedActions.optimalBettingTime}
            </div>
            <div className="text-white/60 text-sm">Best Time to Bet</div>
            <div className="text-xs text-white/50 mt-1">Highest win rate</div>
          </div>

          <div className="card-modern p-6 text-center">
            <AlertCircle className="mx-auto mb-3 text-red-400" size={24} />
            <div className="text-2xl font-bold text-red-400">
              {Math.round(behaviorAnalysis.predictedActions.churnRisk * 100)}%
            </div>
            <div className="text-white/60 text-sm">Churn Risk</div>
            <div className="text-xs text-white/50 mt-1">Next 30 days</div>
          </div>
        </div>
      )}

      {/* Behavior Predictions */}
      {behaviorAnalysis?.predictions && (
        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4">AI Predictions</h3>
          <div className="space-y-4">
            {behaviorAnalysis.predictions.map((prediction, index) => (
              <div key={index} className="glass rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="capitalize font-medium">{prediction.type.replace('_', ' ')}</span>
                      <span className={`text-sm px-2 py-1 rounded-full ${getRiskColor(prediction.risk_level)} bg-current/10`}>
                        {prediction.risk_level} risk
                      </span>
                    </div>
                    <p className="text-white/80 mb-2">{prediction.prediction}</p>
                    <div className="text-sm text-white/60">Timeframe: {prediction.timeframe}</div>
                  </div>
                  <div className="text-right">
                    <div className={`text-lg font-bold ${getConfidenceColor(prediction.confidence)}`}>
                      {Math.round(prediction.confidence * 100)}%
                    </div>
                    <div className="text-xs text-white/60">Confidence</div>
                  </div>
                </div>

                <div className="mb-3">
                  <h4 className="font-medium mb-2">Reasoning:</h4>
                  <ul className="text-sm text-white/70 space-y-1">
                    {prediction.reasoning.map((reason, idx) => (
                      <li key={idx}>• {reason}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Actionable Insights:</h4>
                  <ul className="text-sm text-winnex-green space-y-1">
                    {prediction.actionable_insights.map((insight, idx) => (
                      <li key={idx}>→ {insight}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ML Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {mlInsights.map((insight) => (
          <div key={insight.id} className="card-modern p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-2">
                {getImpactIcon(insight.impact)}
                <h3 className="font-bold">{insight.title}</h3>
              </div>
              <div className="text-right">
                <div className={`text-lg font-bold ${getConfidenceColor(insight.confidence)}`}>
                  {Math.round(insight.confidence * 100)}%
                </div>
                <div className="text-xs text-white/60">Confidence</div>
              </div>
            </div>

            <p className="text-white/80 mb-4">{insight.description}</p>

            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="text-center">
                <div className="text-lg font-bold">{insight.metrics.current}</div>
                <div className="text-xs text-white/60">Current</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-winnex-blue">{insight.metrics.predicted}</div>
                <div className="text-xs text-white/60">Predicted</div>
              </div>
              <div className="text-center">
                <div className={`text-lg font-bold ${
                  insight.metrics.change > 0 ? 'text-winnex-green' : 'text-red-400'
                }`}>
                  {insight.metrics.change > 0 ? '+' : ''}{insight.metrics.change}%
                </div>
                <div className="text-xs text-white/60">Change</div>
              </div>
            </div>

            <div className="glass rounded-lg p-3">
              <div className="font-medium mb-1">Recommendation:</div>
              <div className="text-sm text-winnex-green">{insight.recommendation}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Seasonal Patterns */}
      {behaviorAnalysis?.seasonalPatterns && (
        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4">Seasonal Betting Patterns</h3>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            {behaviorAnalysis.seasonalPatterns.map((pattern, index) => (
              <div key={index} className="text-center">
                <div className="glass rounded-lg p-3 mb-2">
                  <div className="font-medium text-sm">{pattern.month}</div>
                  <div className="text-xs text-white/60 mt-1">Activity: {pattern.activity}%</div>
                  <div className="text-xs text-white/60">Stake: ${pattern.avgStake}</div>
                  <div className="text-xs text-winnex-green">Win: {pattern.winRate}%</div>
                </div>
                <div
                  className="w-full bg-winnex-green rounded"
                  style={{ height: `${Math.max(pattern.activity / 2, 4)}px` }}
                ></div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Risk Profile */}
      {behaviorAnalysis && (
        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4">Risk Profile Analysis</h3>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold capitalize mb-2">
                {behaviorAnalysis.riskProfile} Bettor
              </div>
              <p className="text-white/80">
                Based on your betting patterns, stake sizes, and market preferences
              </p>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold">Preferred Sports:</div>
              <div className="flex flex-wrap gap-1 mt-2">
                {behaviorAnalysis.predictedActions.preferredSports.map((sport, index) => (
                  <span key={index} className="text-xs bg-winnex-blue/20 text-winnex-blue px-2 py-1 rounded">
                    {sport}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}