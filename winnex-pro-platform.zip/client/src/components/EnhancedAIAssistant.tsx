import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Brain, TrendingUp, Target, AlertTriangle, Star, 
  DollarSign, Trophy, Zap, Mail, MessageSquare, Phone,
  ExternalLink, ArrowRight, Gift
} from 'lucide-react';

interface AIPrediction {
  id: string;
  match: string;
  sport: string;
  prediction: string;
  confidence: number;
  odds: number;
  expectedValue: number;
  reasoning: string[];
  ctaButtons: {
    text: string;
    action: string;
    variant: 'primary' | 'secondary' | 'success';
  }[];
}

interface PersonalizedOffer {
  id: string;
  type: 'bonus' | 'cashback' | 'vip_upgrade' | 'free_bet';
  title: string;
  description: string;
  value: string;
  expiresIn: string;
  requirements: string;
  ctaButton: {
    text: string;
    action: string;
    variant: 'primary' | 'secondary' | 'success';
  };
}

interface SmartAlert {
  id: string;
  type: 'value_bet' | 'arbitrage' | 'cashout_recommend' | 'risk_warning';
  title: string;
  message: string;
  urgency: 'low' | 'medium' | 'high';
  actionRequired: boolean;
  ctaButton?: {
    text: string;
    action: string;
    variant: 'primary' | 'secondary' | 'destructive';
  };
}

export default function EnhancedAIAssistant() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('predictions');
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const aiPredictions: AIPrediction[] = [
    {
      id: '1',
      match: 'Lakers vs Celtics',
      sport: 'Basketball',
      prediction: 'Over 220.5 Points',
      confidence: 94,
      odds: 1.95,
      expectedValue: 18.7,
      reasoning: [
        'Both teams averaging 115+ points per game',
        'Fast-paced matchup with weak defensive stats',
        'Historical head-to-head favors high-scoring games'
      ],
      ctaButtons: [
        { text: 'Bet Now', action: 'place_bet_over_220', variant: 'primary' },
        { text: 'Add to Betslip', action: 'add_betslip', variant: 'secondary' }
      ]
    },
    {
      id: '2',
      match: 'Arsenal vs Chelsea',
      sport: 'Soccer',
      prediction: 'Arsenal Win',
      confidence: 87,
      odds: 2.10,
      expectedValue: 23.4,
      reasoning: [
        'Arsenal unbeaten in last 8 home games',
        'Chelsea missing 3 key defenders',
        'Momentum strongly favors Arsenal'
      ],
      ctaButtons: [
        { text: 'Back Arsenal', action: 'bet_arsenal_win', variant: 'success' },
        { text: 'View Full Analysis', action: 'detailed_analysis', variant: 'secondary' }
      ]
    }
  ];

  const personalizedOffers: PersonalizedOffer[] = [
    {
      id: '1',
      type: 'bonus',
      title: '200% Crypto Deposit Bonus',
      description: 'Triple your first crypto deposit up to 1 BTC',
      value: '1 BTC',
      expiresIn: '23 hours',
      requirements: 'Minimum 0.01 BTC deposit',
      ctaButton: { text: 'Claim Bonus', action: 'claim_deposit_bonus', variant: 'primary' }
    },
    {
      id: '2',
      type: 'vip_upgrade',
      title: 'Instant VIP Upgrade',
      description: 'Get VIP status with exclusive benefits and higher limits',
      value: 'Premium Access',
      expiresIn: '3 days',
      requirements: 'Complete 5 more bets',
      ctaButton: { text: 'Upgrade Now', action: 'upgrade_vip', variant: 'success' }
    },
    {
      id: '3',
      type: 'cashback',
      title: '50% Loss Cashback',
      description: 'Get back half of your losses from yesterday',
      value: '$127.50',
      expiresIn: '12 hours',
      requirements: 'Auto-credited to account',
      ctaButton: { text: 'Claim Cashback', action: 'claim_cashback', variant: 'primary' }
    }
  ];

  const smartAlerts: SmartAlert[] = [
    {
      id: '1',
      type: 'value_bet',
      title: 'High Value Opportunity',
      message: 'Chiefs vs Bills Over 47.5 - 15% edge detected',
      urgency: 'high',
      actionRequired: true,
      ctaButton: { text: 'Bet Now', action: 'bet_chiefs_over', variant: 'primary' }
    },
    {
      id: '2',
      type: 'cashout_recommend',
      title: 'Cash Out Recommended',
      message: 'Your Lakers bet has 89% win probability - secure profit now',
      urgency: 'medium',
      actionRequired: true,
      ctaButton: { text: 'Cash Out', action: 'cashout_lakers', variant: 'success' }
    },
    {
      id: '3',
      type: 'arbitrage',
      title: 'Arbitrage Opportunity',
      message: 'Risk-free profit opportunity detected - act within 8 minutes',
      urgency: 'high',
      actionRequired: true,
      ctaButton: { text: 'View Details', action: 'arbitrage_details', variant: 'primary' }
    }
  ];

  const handleCTAClick = (action: string) => {
    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      
      switch (action) {
        case 'place_bet_over_220':
        case 'bet_arsenal_win':
        case 'bet_chiefs_over':
          toast({
            title: "Bet Placed Successfully",
            description: "Your bet has been added to the betslip",
          });
          break;
        case 'claim_deposit_bonus':
        case 'claim_cashback':
          toast({
            title: "Bonus Claimed!",
            description: "Your bonus has been credited to your account",
          });
          break;
        case 'upgrade_vip':
          toast({
            title: "VIP Upgrade Complete",
            description: "Welcome to VIP! Enjoy exclusive benefits",
          });
          break;
        case 'cashout_lakers':
          toast({
            title: "Cash Out Successful",
            description: "Your winnings have been secured",
          });
          break;
        default:
          toast({
            title: "Action Completed",
            description: "Your request has been processed",
          });
      }
    }, 1500);
  };

  const handleAIQuery = () => {
    if (!query.trim()) return;
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "AI Analysis Complete",
        description: "Your personalized recommendations are ready",
      });
    }, 2000);
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 border-red-300 text-red-800';
      case 'medium': return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      default: return 'bg-blue-100 border-blue-300 text-blue-800';
    }
  };

  const getOfferIcon = (type: string) => {
    switch (type) {
      case 'bonus': return <Gift className="h-5 w-5 text-green-500" />;
      case 'vip_upgrade': return <Star className="h-5 w-5 text-purple-500" />;
      case 'cashback': return <DollarSign className="h-5 w-5 text-blue-500" />;
      default: return <Trophy className="h-5 w-5 text-gold-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-2">AI Betting Assistant</h1>
          <p className="text-gray-300">Powered by advanced machine learning with 94.2% accuracy</p>
        </div>

        {/* AI Query Input */}
        <Card className="bg-black/40 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <Brain className="h-8 w-8 text-purple-400" />
              <div className="flex-1">
                <Input
                  placeholder="Ask me anything... 'Which bets have the best value today?' or 'Should I cash out my Lakers bet?'"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAIQuery()}
                  className="bg-gray-800 border-gray-600 text-white text-lg"
                />
              </div>
              <Button 
                onClick={handleAIQuery}
                disabled={isLoading}
                className="px-6"
              >
                {isLoading ? 'Analyzing...' : 'Ask AI'}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-black/40 border-gray-700">
            <TabsTrigger value="predictions" className="text-white">AI Predictions</TabsTrigger>
            <TabsTrigger value="alerts" className="text-white">Smart Alerts</TabsTrigger>
            <TabsTrigger value="offers" className="text-white">Personal Offers</TabsTrigger>
            <TabsTrigger value="communication" className="text-white">Communication</TabsTrigger>
          </TabsList>

          {/* AI Predictions Tab */}
          <TabsContent value="predictions">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {aiPredictions.map((prediction) => (
                <Card key={prediction.id} className="bg-black/40 border-gray-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white">{prediction.match}</CardTitle>
                      <Badge variant="secondary">{prediction.sport}</Badge>
                    </div>
                    <CardDescription className="text-gray-400">
                      AI Prediction: {prediction.prediction}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-green-400">{prediction.confidence}%</div>
                        <div className="text-sm text-gray-400">Confidence</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-blue-400">{prediction.odds}</div>
                        <div className="text-sm text-gray-400">Odds</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-purple-400">+{prediction.expectedValue}%</div>
                        <div className="text-sm text-gray-400">Expected Value</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-white font-medium">AI Reasoning:</h4>
                      {prediction.reasoning.map((reason, index) => (
                        <div key={index} className="flex items-center text-gray-300 text-sm">
                          <Target className="h-3 w-3 text-green-400 mr-2" />
                          {reason}
                        </div>
                      ))}
                    </div>

                    <div className="flex space-x-2">
                      {prediction.ctaButtons.map((button, index) => (
                        <Button
                          key={index}
                          variant={button.variant === 'primary' ? 'default' : 'outline'}
                          onClick={() => handleCTAClick(button.action)}
                          disabled={isLoading}
                          className="flex-1"
                        >
                          {button.text}
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Smart Alerts Tab */}
          <TabsContent value="alerts">
            <div className="space-y-4">
              {smartAlerts.map((alert) => (
                <Card key={alert.id} className={`border-l-4 ${getUrgencyColor(alert.urgency)}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <AlertTriangle className={`h-5 w-5 ${
                          alert.urgency === 'high' ? 'text-red-500' : 
                          alert.urgency === 'medium' ? 'text-yellow-500' : 'text-blue-500'
                        }`} />
                        <div>
                          <h3 className="font-semibold text-gray-900">{alert.title}</h3>
                          <p className="text-gray-600">{alert.message}</p>
                        </div>
                      </div>
                      {alert.ctaButton && (
                        <Button
                          variant={alert.ctaButton.variant === 'destructive' ? 'destructive' : 'default'}
                          onClick={() => handleCTAClick(alert.ctaButton!.action)}
                          disabled={isLoading}
                        >
                          {alert.ctaButton.text}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Personal Offers Tab */}
          <TabsContent value="offers">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {personalizedOffers.map((offer) => (
                <Card key={offer.id} className="bg-gradient-to-br from-white to-gray-50 border-2 border-blue-200">
                  <CardHeader className="text-center">
                    <div className="flex justify-center mb-2">
                      {getOfferIcon(offer.type)}
                    </div>
                    <CardTitle className="text-gray-900">{offer.title}</CardTitle>
                    <CardDescription>{offer.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600">{offer.value}</div>
                      <div className="text-sm text-gray-500">Value</div>
                    </div>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Expires in:</span>
                        <span className="font-medium text-red-600">{offer.expiresIn}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Requirements:</span>
                        <span className="font-medium">{offer.requirements}</span>
                      </div>
                    </div>

                    <Button
                      className="w-full"
                      onClick={() => handleCTAClick(offer.ctaButton.action)}
                      disabled={isLoading}
                    >
                      {offer.ctaButton.text}
                      <Zap className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Communication Tab */}
          <TabsContent value="communication">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Mail className="h-5 w-5 mr-2 text-blue-400" />
                    Email Notifications
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-300">Get AI predictions and alerts via email</p>
                  <div className="space-y-2">
                    <Button className="w-full" onClick={() => handleCTAClick('subscribe_email')}>
                      Subscribe to Daily Tips
                    </Button>
                    <Button variant="outline" className="w-full" onClick={() => handleCTAClick('test_email')}>
                      Send Test Email
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <MessageSquare className="h-5 w-5 mr-2 text-green-400" />
                    SMS Alerts
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-300">Instant SMS for high-value opportunities</p>
                  <div className="space-y-2">
                    <Button className="w-full" onClick={() => handleCTAClick('enable_sms')}>
                      Enable SMS Alerts
                    </Button>
                    <Button variant="outline" className="w-full" onClick={() => handleCTAClick('test_sms')}>
                      Send Test SMS
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Phone className="h-5 w-5 mr-2 text-purple-400" />
                    VIP Support
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-300">Direct line to our expert betting analysts</p>
                  <div className="space-y-2">
                    <Button className="w-full" onClick={() => handleCTAClick('call_support')}>
                      Call VIP Line
                    </Button>
                    <Button variant="outline" className="w-full" onClick={() => handleCTAClick('schedule_call')}>
                      Schedule Callback
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}