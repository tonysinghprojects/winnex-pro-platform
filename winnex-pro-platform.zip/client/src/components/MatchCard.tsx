import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Plus } from "lucide-react";
import type { Match, Odds } from "@shared/schema";

interface MatchCardProps {
  match: Match;
  odds: Odds[];
}

export default function MatchCard({ match, odds }: MatchCardProps) {
  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "live":
        return "bg-red-500";
      case "scheduled":
        return "bg-winnex-blue";
      case "finished":
        return "bg-gray-500";
      default:
        return "bg-gray-500";
    }
  };

  const addToBetSlip = (selection: string, selectionOdds: string, market: string) => {
    const betSlipData = {
      matchId: match.id,
      match: `${match.team1} vs ${match.team2}`,
      market,
      selection,
      odds: selectionOdds,
    };
    
    if ((window as any).addToBetSlip) {
      (window as any).addToBetSlip(betSlipData);
    }
  };

  const homeOdds = odds.find(o => o.market === "1x2" && o.selection === "home");
  const drawOdds = odds.find(o => o.market === "1x2" && o.selection === "draw");
  const awayOdds = odds.find(o => o.market === "1x2" && o.selection === "away");

  return (
    <div className="bg-winnex-gray rounded-lg p-4 hover:bg-gray-700 transition-colors">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="text-sm text-gray-400 flex items-center">
            <Clock size={14} className="mr-1" />
            {match.status === "live" ? "LIVE" : formatTime(match.startTime)}
          </div>
          <div className="flex items-center space-x-2">
            <span className="font-semibold">{match.team1}</span>
            {match.isLive && (
              <span className="text-winnex-green font-bold text-lg">
                {match.score1}
              </span>
            )}
            <span className="text-gray-400">vs</span>
            {match.isLive && (
              <span className="text-winnex-green font-bold text-lg">
                {match.score2}
              </span>
            )}
            <span className="font-semibold">{match.team2}</span>
          </div>
          {match.league && (
            <Badge className={getStatusColor(match.status)} variant="secondary">
              {match.league}
            </Badge>
          )}
          {match.isLive && (
            <Badge className="bg-red-500 animate-pulse" variant="secondary">
              LIVE
            </Badge>
          )}
        </div>
        
        <div className="flex space-x-2">
          {homeOdds && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => addToBetSlip(`${match.team1} Win`, homeOdds.odds, "1x2")}
              className="bg-winnex-dark border-gray-600 hover:bg-gray-800 transition-colors"
            >
              <div className="text-center">
                <div className="text-xs text-gray-400">{match.team1}</div>
                <div className="font-bold text-winnex-green">{homeOdds.odds}</div>
              </div>
            </Button>
          )}
          
          {drawOdds && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => addToBetSlip("Draw", drawOdds.odds, "1x2")}
              className="bg-winnex-dark border-gray-600 hover:bg-gray-800 transition-colors"
            >
              <div className="text-center">
                <div className="text-xs text-gray-400">Draw</div>
                <div className="font-bold text-winnex-green">{drawOdds.odds}</div>
              </div>
            </Button>
          )}
          
          {awayOdds && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => addToBetSlip(`${match.team2} Win`, awayOdds.odds, "1x2")}
              className="bg-winnex-dark border-gray-600 hover:bg-gray-800 transition-colors"
            >
              <div className="text-center">
                <div className="text-xs text-gray-400">{match.team2}</div>
                <div className="font-bold text-winnex-green">{awayOdds.odds}</div>
              </div>
            </Button>
          )}
          
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white"
          >
            <Plus size={16} />
            <span className="ml-1 text-xs">+{odds.length}</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
