import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TrendingUp, TrendingDown, Activity, Zap, Database, RefreshCw, AlertCircle, CheckCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface OddsProvider {
  id: string;
  name: string;
  type: 'primary' | 'backup' | 'comparison';
  status: 'connected' | 'disconnected' | 'error' | 'maintenance';
  latency: number;
  uptime: number;
  accuracy: number;
  coverage: number;
  lastUpdate: string;
  apiCalls: number;
  rateLimit: number;
  costPerCall: number;
  monthlyUsage: number;
  dataFeeds: string[];
  supportedSports: string[];
}

interface LiveOdds {
  matchId: number;
  match: string;
  sport: string;
  market: string;
  selections: Array<{
    name: string;
    odds: number;
    movement: 'up' | 'down' | 'stable';
    volume: number;
    lastChanged: string;
    source: string;
  }>;
  margin: number;
  liquidity: number;
  riskExposure: number;
  lastUpdated: string;
  updateFrequency: number;
}

interface MarginSettings {
  sport: string;
  market: string;
  baseMargin: number;
  minMargin: number;
  maxMargin: number;
  dynamicAdjustment: boolean;
  riskMultiplier: number;
  liquidityThreshold: number;
  autoSuspend: boolean;
  maxExposure: number;
}

interface OddsMovement {
  matchId: number;
  market: string;
  selection: string;
  previousOdds: number;
  currentOdds: number;
  movement: number;
  timestamp: string;
  volume: number;
  trigger: 'manual' | 'automatic' | 'competitor' | 'liability' | 'news';
  reason: string;
}

interface RiskAlert {
  id: string;
  type: 'exposure' | 'movement' | 'volume' | 'margin' | 'liability';
  severity: 'low' | 'medium' | 'high' | 'critical';
  matchId: number;
  market: string;
  description: string;
  currentValue: number;
  threshold: number;
  action: string;
  status: 'active' | 'acknowledged' | 'resolved';
  createdAt: string;
}

export default function OddsEngineCenter() {
  const [selectedProvider, setSelectedProvider] = useState<string>('');
  const [selectedSport, setSelectedSport] = useState<string>('all');
  const [autoRefresh, setAutoRefresh] = useState<boolean>(true);
  const queryClient = useQueryClient();

  const { data: oddsProviders } = useQuery({
    queryKey: ['/api/odds/providers'],
    queryFn: () => apiRequest('/api/odds/providers'),
    refetchInterval: autoRefresh ? 5000 : false,
  });

  const { data: liveOdds } = useQuery({
    queryKey: ['/api/odds/live', selectedSport],
    queryFn: () => apiRequest(`/api/odds/live?sport=${selectedSport}`),
    refetchInterval: autoRefresh ? 2000 : false,
  });

  const { data: marginSettings } = useQuery({
    queryKey: ['/api/odds/margin-settings'],
    queryFn: () => apiRequest('/api/odds/margin-settings'),
  });

  const { data: oddsMovements } = useQuery({
    queryKey: ['/api/odds/movements'],
    queryFn: () => apiRequest('/api/odds/movements'),
    refetchInterval: autoRefresh ? 3000 : false,
  });

  const { data: riskAlerts } = useQuery({
    queryKey: ['/api/odds/risk-alerts'],
    queryFn: () => apiRequest('/api/odds/risk-alerts'),
    refetchInterval: autoRefresh ? 5000 : false,
  });

  const updateOddsMutation = useMutation({
    mutationFn: (data: { matchId: number; market: string; selection: string; newOdds: number; reason: string }) =>
      apiRequest('/api/odds/update', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/odds/live'] });
      queryClient.invalidateQueries({ queryKey: ['/api/odds/movements'] });
    },
  });

  const updateMarginMutation = useMutation({
    mutationFn: (data: Partial<MarginSettings>) =>
      apiRequest('/api/odds/update-margin', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/odds/margin-settings'] });
    },
  });

  const suspendMarketMutation = useMutation({
    mutationFn: (data: { matchId: number; market: string; reason: string }) =>
      apiRequest('/api/odds/suspend-market', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/odds/live'] });
    },
  });

  const acknowledgeAlertMutation = useMutation({
    mutationFn: (alertId: string) =>
      apiRequest(`/api/odds/acknowledge-alert/${alertId}`, 'POST'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/odds/risk-alerts'] });
    },
  });

  const getProviderStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-500/20 text-green-400 border-green-500/20';
      case 'error': return 'bg-red-500/20 text-red-400 border-red-500/20';
      case 'maintenance': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/20';
      case 'disconnected': return 'bg-gray-500/20 text-gray-400 border-gray-500/20';
      default: return 'bg-blue-500/20 text-blue-400 border-blue-500/20';
    }
  };

  const getMovementIcon = (movement: string) => {
    switch (movement) {
      case 'up': return <TrendingUp className="h-4 w-4 text-green-400" />;
      case 'down': return <TrendingDown className="h-4 w-4 text-red-400" />;
      default: return <Activity className="h-4 w-4 text-gray-400" />;
    }
  };

  const connectedProviders = oddsProviders?.filter((p: OddsProvider) => p.status === 'connected') || [];
  const criticalAlerts = riskAlerts?.filter((a: RiskAlert) => a.severity === 'critical' && a.status === 'active') || [];

  // Auto-refresh counter
  const [refreshCounter, setRefreshCounter] = useState(0);
  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(() => {
        setRefreshCounter((prev) => (prev + 1) % 30);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Odds Engine Center</h1>
              <p className="text-slate-300">Real-time odds management, risk control, and data feed monitoring</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button
                variant={autoRefresh ? 'default' : 'outline'}
                onClick={() => setAutoRefresh(!autoRefresh)}
                className="flex items-center space-x-2"
              >
                <RefreshCw className={`h-4 w-4 ${autoRefresh ? 'animate-spin' : ''}`} />
                <span>{autoRefresh ? 'Auto Refresh' : 'Manual Refresh'}</span>
              </Button>
              {autoRefresh && (
                <div className="text-slate-400 text-sm">
                  Next update: {30 - refreshCounter}s
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <Card className="bg-black/20 border-green-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Active Providers</p>
                  <p className="text-3xl font-bold text-white">{connectedProviders.length}</p>
                </div>
                <Database className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-blue-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 text-sm font-medium">Live Markets</p>
                  <p className="text-3xl font-bold text-white">{liveOdds?.length || 0}</p>
                </div>
                <Activity className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-yellow-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-400 text-sm font-medium">Avg Latency</p>
                  <p className="text-3xl font-bold text-white">
                    {connectedProviders.length > 0 
                      ? Math.round(connectedProviders.reduce((acc: number, p: OddsProvider) => acc + p.latency, 0) / connectedProviders.length)
                      : 0}ms
                  </p>
                </div>
                <Zap className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-red-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-400 text-sm font-medium">Risk Alerts</p>
                  <p className="text-3xl font-bold text-white">{criticalAlerts.length}</p>
                </div>
                <AlertCircle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-purple-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-400 text-sm font-medium">Updates/Min</p>
                  <p className="text-3xl font-bold text-white">
                    {liveOdds?.reduce((acc: number, odds: LiveOdds) => acc + odds.updateFrequency, 0) || 0}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="live-odds" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="live-odds" className="data-[state=active]:bg-green-500/20">
              Live Odds
            </TabsTrigger>
            <TabsTrigger value="providers" className="data-[state=active]:bg-green-500/20">
              Data Providers
            </TabsTrigger>
            <TabsTrigger value="margins" className="data-[state=active]:bg-green-500/20">
              Margin Control
            </TabsTrigger>
            <TabsTrigger value="movements" className="data-[state=active]:bg-green-500/20">
              Odds Movements
            </TabsTrigger>
            <TabsTrigger value="risk" className="data-[state=active]:bg-green-500/20">
              Risk Management
            </TabsTrigger>
          </TabsList>

          <TabsContent value="live-odds" className="space-y-6">
            <div className="flex justify-between items-center">
              <Select value={selectedSport} onValueChange={setSelectedSport}>
                <SelectTrigger className="w-48 bg-slate-800/50 border-slate-600">
                  <SelectValue placeholder="Filter by sport" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sports</SelectItem>
                  <SelectItem value="football">Football</SelectItem>
                  <SelectItem value="basketball">Basketball</SelectItem>
                  <SelectItem value="soccer">Soccer</SelectItem>
                  <SelectItem value="tennis">Tennis</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex items-center space-x-2 text-slate-400 text-sm">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span>Live updates active</span>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6">
              {liveOdds?.map((odds: LiveOdds) => (
                <Card key={`${odds.matchId}-${odds.market}`} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle className="text-white text-lg">{odds.match}</CardTitle>
                        <p className="text-slate-400">{odds.sport} • {odds.market}</p>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge className="bg-blue-500/20 text-blue-400">
                          Margin: {odds.margin.toFixed(1)}%
                        </Badge>
                        <Badge className={`${
                          odds.riskExposure > 80 ? 'bg-red-500/20 text-red-400' :
                          odds.riskExposure > 60 ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-green-500/20 text-green-400'
                        }`}>
                          Risk: {odds.riskExposure.toFixed(1)}%
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {odds.selections.map((selection, index) => (
                        <div key={index} className="p-4 bg-slate-800/30 rounded-lg border border-slate-600/30">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-white font-medium">{selection.name}</span>
                            {getMovementIcon(selection.movement)}
                          </div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-3xl font-bold text-green-400">{selection.odds.toFixed(2)}</span>
                            <div className="text-right">
                              <p className="text-slate-400 text-sm">Volume</p>
                              <p className="text-white font-bold">${selection.volume.toLocaleString()}</p>
                            </div>
                          </div>
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-slate-400">Source: {selection.source}</span>
                            <span className="text-slate-400">{new Date(selection.lastChanged).toLocaleTimeString()}</span>
                          </div>
                          <div className="mt-3 flex space-x-2">
                            <Input
                              type="number"
                              step="0.01"
                              placeholder="New odds"
                              className="bg-slate-700/50 border-slate-600 text-white text-sm"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  const newOdds = parseFloat((e.target as HTMLInputElement).value);
                                  if (newOdds > 0) {
                                    updateOddsMutation.mutate({
                                      matchId: odds.matchId,
                                      market: odds.market,
                                      selection: selection.name,
                                      newOdds,
                                      reason: 'Manual adjustment'
                                    });
                                  }
                                }
                              }}
                            />
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-red-500/20 text-red-400 hover:bg-red-500/10"
                              onClick={() => suspendMarketMutation.mutate({
                                matchId: odds.matchId,
                                market: odds.market,
                                reason: 'Manual suspension'
                              })}
                            >
                              Suspend
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 grid grid-cols-3 gap-4 pt-4 border-t border-slate-600">
                      <div className="text-center">
                        <p className="text-slate-400 text-sm">Liquidity</p>
                        <p className="text-white font-bold">${odds.liquidity.toLocaleString()}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-slate-400 text-sm">Last Updated</p>
                        <p className="text-white font-bold">{new Date(odds.lastUpdated).toLocaleTimeString()}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-slate-400 text-sm">Update Frequency</p>
                        <p className="text-white font-bold">{odds.updateFrequency}/min</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="providers" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {oddsProviders?.map((provider: OddsProvider) => (
                <Card key={provider.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-white">{provider.name}</CardTitle>
                      <Badge className={getProviderStatusColor(provider.status)}>
                        {provider.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Latency</p>
                        <p className="text-white font-bold">{provider.latency}ms</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Uptime</p>
                        <p className="text-white font-bold">{provider.uptime.toFixed(1)}%</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Accuracy</p>
                        <p className="text-white font-bold">{provider.accuracy.toFixed(1)}%</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Coverage</p>
                        <p className="text-white font-bold">{provider.coverage.toFixed(1)}%</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">API Usage</p>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-300">Calls Today</span>
                          <span className="text-white">{provider.apiCalls.toLocaleString()}</span>
                        </div>
                        <Progress 
                          value={(provider.apiCalls / provider.rateLimit) * 100} 
                          className="h-2 bg-slate-800" 
                        />
                        <div className="flex justify-between text-xs text-slate-400">
                          <span>Rate Limit: {provider.rateLimit.toLocaleString()}</span>
                          <span>Cost: ${(provider.apiCalls * provider.costPerCall).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">Supported Sports</p>
                      <div className="flex flex-wrap gap-1">
                        {provider.supportedSports.slice(0, 3).map((sport) => (
                          <Badge key={sport} variant="secondary" className="text-xs">
                            {sport}
                          </Badge>
                        ))}
                        {provider.supportedSports.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{provider.supportedSports.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button size="sm" className="flex-1 bg-green-500/20 border border-green-500/30 text-green-400 hover:bg-green-500/30">
                        Test Connection
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1">
                        Configure
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="margins" className="space-y-6">
            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Margin Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {marginSettings?.map((setting: MarginSettings, index: number) => (
                    <div key={index} className="p-4 bg-slate-800/30 rounded-lg border border-slate-600/30">
                      <div className="flex justify-between items-center mb-4">
                        <div>
                          <h3 className="text-white font-medium">{setting.sport} - {setting.market}</h3>
                          <p className="text-slate-400 text-sm">
                            Base Margin: {setting.baseMargin}% • Dynamic: {setting.dynamicAdjustment ? 'On' : 'Off'}
                          </p>
                        </div>
                        <Badge className={setting.autoSuspend ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}>
                          {setting.autoSuspend ? 'Auto Suspend' : 'Manual Only'}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label className="text-slate-300">Base Margin (%)</Label>
                          <Input
                            type="number"
                            step="0.1"
                            defaultValue={setting.baseMargin}
                            className="bg-slate-700/50 border-slate-600"
                            onChange={(e) => {
                              const newMargin = parseFloat(e.target.value);
                              if (!isNaN(newMargin)) {
                                updateMarginMutation.mutate({
                                  ...setting,
                                  baseMargin: newMargin
                                });
                              }
                            }}
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label className="text-slate-300">Min Margin (%)</Label>
                          <Input
                            type="number"
                            step="0.1"
                            defaultValue={setting.minMargin}
                            className="bg-slate-700/50 border-slate-600"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label className="text-slate-300">Max Margin (%)</Label>
                          <Input
                            type="number"
                            step="0.1"
                            defaultValue={setting.maxMargin}
                            className="bg-slate-700/50 border-slate-600"
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div className="space-y-2">
                          <Label className="text-slate-300">Risk Multiplier</Label>
                          <Input
                            type="number"
                            step="0.1"
                            defaultValue={setting.riskMultiplier}
                            className="bg-slate-700/50 border-slate-600"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label className="text-slate-300">Max Exposure ($)</Label>
                          <Input
                            type="number"
                            defaultValue={setting.maxExposure}
                            className="bg-slate-700/50 border-slate-600"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="movements" className="space-y-6">
            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Recent Odds Movements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {oddsMovements?.map((movement: OddsMovement, index: number) => (
                    <div key={index} className="p-4 bg-slate-800/30 rounded-lg border border-slate-600/30">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          {getMovementIcon(movement.movement > 0 ? 'up' : movement.movement < 0 ? 'down' : 'stable')}
                          <div>
                            <p className="text-white font-medium">
                              Match {movement.matchId} - {movement.market}
                            </p>
                            <p className="text-slate-400 text-sm">{movement.selection}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`text-lg font-bold ${
                            movement.movement > 0 ? 'text-green-400' : 
                            movement.movement < 0 ? 'text-red-400' : 'text-gray-400'
                          }`}>
                            {movement.previousOdds.toFixed(2)} → {movement.currentOdds.toFixed(2)}
                          </p>
                          <p className={`text-sm ${
                            movement.movement > 0 ? 'text-green-400' : 
                            movement.movement < 0 ? 'text-red-400' : 'text-gray-400'
                          }`}>
                            {movement.movement > 0 ? '+' : ''}{(movement.movement * 100).toFixed(1)}%
                          </p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-slate-400">Trigger</p>
                          <p className="text-white capitalize">{movement.trigger}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Volume</p>
                          <p className="text-white">${movement.volume.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Time</p>
                          <p className="text-white">{new Date(movement.timestamp).toLocaleTimeString()}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Reason</p>
                          <p className="text-white">{movement.reason}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="risk" className="space-y-6">
            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Risk Alerts & Monitoring</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {riskAlerts?.map((alert: RiskAlert) => (
                    <div key={alert.id} className="p-4 bg-slate-800/30 rounded-lg border border-slate-600/30">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${
                            alert.severity === 'critical' ? 'bg-red-500' :
                            alert.severity === 'high' ? 'bg-orange-500' :
                            alert.severity === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'
                          }`} />
                          <div>
                            <p className="text-white font-medium">{alert.description}</p>
                            <p className="text-slate-400 text-sm">
                              Match {alert.matchId} • {alert.market} • {alert.type}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={`${
                            alert.severity === 'critical' ? 'bg-red-500/20 text-red-400' :
                            alert.severity === 'high' ? 'bg-orange-500/20 text-orange-400' :
                            alert.severity === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-blue-500/20 text-blue-400'
                          }`}>
                            {alert.severity}
                          </Badge>
                          <p className="text-slate-400 text-sm mt-1">
                            {new Date(alert.createdAt).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-3 text-sm">
                        <div>
                          <p className="text-slate-400">Current Value</p>
                          <p className="text-white font-bold">{alert.currentValue.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Threshold</p>
                          <p className="text-white font-bold">{alert.threshold.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Recommended Action</p>
                          <p className="text-white">{alert.action}</p>
                        </div>
                      </div>

                      {alert.status === 'active' && (
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            className="bg-green-500/20 border border-green-500/30 text-green-400 hover:bg-green-500/30"
                            onClick={() => acknowledgeAlertMutation.mutate(alert.id)}
                          >
                            Acknowledge
                          </Button>
                          <Button 
                            size="sm" 
                            className="bg-blue-500/20 border border-blue-500/30 text-blue-400 hover:bg-blue-500/30"
                          >
                            Take Action
                          </Button>
                          <Button 
                            size="sm" 
                            className="bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30"
                          >
                            Escalate
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}