import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Zap, Target, Crown, Gem, Star, TrendingUp, Activity } from "lucide-react";

export default function LogoSamples() {
  const logoVariations = [
    {
      id: 1,
      name: "Classic Trophy",
      description: "Traditional gaming symbol with modern styling",
      component: (
        <div className="flex items-center">
          <Trophy className="text-3xl text-yellow-400 mr-3" />
          <span className="text-3xl font-black bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
            WINNEX
          </span>
        </div>
      )
    },
    {
      id: 2,
      name: "Lightning Strike",
      description: "High-energy design emphasizing speed and excitement",
      component: (
        <div className="flex items-center">
          <div className="relative">
            <Zap className="text-3xl text-blue-400 mr-3 animate-pulse" />
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-yellow-400 rounded-full animate-ping"></div>
          </div>
          <span className="text-3xl font-black bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            WINNEX
          </span>
        </div>
      )
    },
    {
      id: 3,
      name: "Target Precision",
      description: "Focus on accuracy and winning strategies",
      component: (
        <div className="flex items-center">
          <div className="relative">
            <Target className="text-3xl text-red-500 mr-3" />
            <div className="absolute inset-0 animate-spin-slow">
              <div className="w-1 h-1 bg-green-400 rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
            </div>
          </div>
          <span className="text-3xl font-black bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent">
            WINNEX
          </span>
        </div>
      )
    },
    {
      id: 4,
      name: "Royal Crown",
      description: "Premium VIP experience with luxury appeal",
      component: (
        <div className="flex items-center">
          <Crown className="text-3xl text-yellow-500 mr-3 animate-bounce" style={{animationDuration: '3s'}} />
          <span className="text-3xl font-black bg-gradient-to-r from-yellow-500 via-yellow-400 to-amber-400 bg-clip-text text-transparent">
            WINNEX
          </span>
        </div>
      )
    },
    {
      id: 5,
      name: "Diamond Elite",
      description: "Exclusive and sophisticated design",
      component: (
        <div className="flex items-center">
          <Gem className="text-3xl text-cyan-400 mr-3 animate-pulse" />
          <span className="text-3xl font-black bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            WINNEX
          </span>
        </div>
      )
    },
    {
      id: 6,
      name: "Star Champion",
      description: "Achievement and success focused branding",
      component: (
        <div className="flex items-center">
          <div className="relative">
            <Star className="text-3xl text-yellow-400 mr-3 fill-current" />
            <div className="absolute inset-0 animate-ping">
              <Star className="text-3xl text-yellow-300 opacity-20 fill-current" />
            </div>
          </div>
          <span className="text-3xl font-black bg-gradient-to-r from-yellow-400 to-red-500 bg-clip-text text-transparent">
            WINNEX
          </span>
        </div>
      )
    },
    {
      id: 7,
      name: "Trending Up",
      description: "Growth and success trajectory emphasis",
      component: (
        <div className="flex items-center">
          <TrendingUp className="text-3xl text-green-400 mr-3 animate-bounce" />
          <span className="text-3xl font-black bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
            WINNEX
          </span>
        </div>
      )
    },
    {
      id: 8,
      name: "Activity Pulse",
      description: "Live action and real-time betting focus",
      component: (
        <div className="flex items-center">
          <Activity className="text-3xl text-pink-500 mr-3 animate-pulse" />
          <span className="text-3xl font-black bg-gradient-to-r from-pink-500 via-red-500 to-orange-500 bg-clip-text text-transparent">
            WINNEX
          </span>
        </div>
      )
    },
    {
      id: 9,
      name: "Custom Symbol",
      description: "Unique geometric design representing winning",
      component: (
        <div className="flex items-center">
          <div className="w-10 h-10 mr-3 relative">
            <svg viewBox="0 0 40 40" className="w-full h-full">
              <defs>
                <linearGradient id="winGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#10B981" />
                  <stop offset="50%" stopColor="#3B82F6" />
                  <stop offset="100%" stopColor="#8B5CF6" />
                </linearGradient>
              </defs>
              <polygon 
                points="20,2 35,15 35,25 20,38 5,25 5,15" 
                fill="url(#winGradient)" 
                className="animate-pulse"
              />
              <text x="20" y="24" textAnchor="middle" fill="white" fontSize="16" fontWeight="bold">W</text>
            </svg>
          </div>
          <span className="text-3xl font-black bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 bg-clip-text text-transparent">
            WINNEX
          </span>
        </div>
      )
    },
    {
      id: 10,
      name: "Minimalist Modern",
      description: "Clean, contemporary design for universal appeal",
      component: (
        <div className="flex items-center">
          <div className="w-10 h-10 mr-3 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center">
            <span className="text-white font-black text-lg">W</span>
          </div>
          <span className="text-3xl font-light text-white tracking-wide">
            WIN<span className="font-black text-green-400">NEX</span>
          </span>
        </div>
      )
    }
  ];

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-white mb-4">Winnex Logo Design Samples</h1>
        <p className="text-gray-400 text-lg">Choose from these professionally designed logo variations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {logoVariations.map((logo) => (
          <Card key={logo.id} className="bg-winnex-gray border-gray-600 hover:border-green-400 transition-all duration-300 cursor-pointer hover:scale-105">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white text-lg">{logo.name}</CardTitle>
                <Badge className="bg-green-500 text-black">Sample {logo.id}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-winnex-dark p-8 rounded-lg mb-4 flex items-center justify-center min-h-[120px]">
                {logo.component}
              </div>
              <p className="text-gray-400 text-sm">{logo.description}</p>
              
              {/* Preview on different backgrounds */}
              <div className="mt-4 space-y-2">
                <div className="text-xs text-gray-500 mb-2">Preview on different backgrounds:</div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-black p-2 rounded flex justify-center">
                    <div className="scale-50 origin-center">
                      {logo.component}
                    </div>
                  </div>
                  <div className="bg-white p-2 rounded flex justify-center">
                    <div className="scale-50 origin-center">
                      {logo.component}
                    </div>
                  </div>
                  <div className="bg-gray-800 p-2 rounded flex justify-center">
                    <div className="scale-50 origin-center">
                      {logo.component}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Implementation Guide */}
      <div className="mt-12">
        <Card className="bg-winnex-dark border-gray-600">
          <CardHeader>
            <CardTitle className="text-white">Implementation Guide</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-gray-300 space-y-4">
              <p>Each logo design is fully responsive and includes:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Animated elements for enhanced user engagement</li>
                <li>Gradient color schemes matching the Winnex brand</li>
                <li>Multiple size variations for different use cases</li>
                <li>Dark and light theme compatibility</li>
                <li>SVG-based graphics for crisp scaling</li>
              </ul>
              <div className="mt-6 p-4 bg-gray-800 rounded-lg">
                <p className="text-sm text-yellow-400 mb-2">🎨 Design Recommendation:</p>
                <p className="text-sm">The "Lightning Strike" and "Custom Symbol" designs offer the best balance of modernity, uniqueness, and brand recognition for a cutting-edge betting platform.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}