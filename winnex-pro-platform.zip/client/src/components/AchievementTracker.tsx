import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Trophy, Star, Target, Zap, Crown, Gift, TrendingUp, Award } from "lucide-react";

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'betting' | 'social' | 'exploration' | 'milestone';
  xpReward: number;
  progress: number;
  maxProgress: number;
  completed: boolean;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt?: string;
}

interface PlayerLevel {
  currentLevel: number;
  currentXP: number;
  xpToNextLevel: number;
  totalXP: number;
  title: string;
  nextTitle: string;
  perks: string[];
}

export default function AchievementTracker() {
  const [newAchievements, setNewAchievements] = useState<string[]>([]);
  const [levelUpAnimation, setLevelUpAnimation] = useState(false);

  const { data: achievements } = useQuery({
    queryKey: ['/api/user/achievements'],
    refetchInterval: 30000,
  });

  const { data: playerLevel } = useQuery({
    queryKey: ['/api/user/level'],
    refetchInterval: 30000,
  });

  // Mock data for demonstration
  const mockAchievements: Achievement[] = [
    {
      id: "first_bet",
      title: "First Bet",
      description: "Place your first bet",
      icon: "🎯",
      category: "betting",
      xpReward: 100,
      progress: 1,
      maxProgress: 1,
      completed: true,
      rarity: "common",
      unlockedAt: "2024-01-15"
    },
    {
      id: "lucky_streak",
      title: "Lucky Streak",
      description: "Win 5 bets in a row",
      icon: "🍀",
      category: "betting",
      xpReward: 500,
      progress: 3,
      maxProgress: 5,
      completed: false,
      rarity: "rare"
    },
    {
      id: "big_winner",
      title: "Big Winner",
      description: "Win $1000 in a single bet",
      icon: "💰",
      category: "milestone",
      xpReward: 1000,
      progress: 750,
      maxProgress: 1000,
      completed: false,
      rarity: "epic"
    },
    {
      id: "social_butterfly",
      title: "Social Butterfly",
      description: "Share 10 winning bets",
      icon: "🦋",
      category: "social",
      xpReward: 300,
      progress: 7,
      maxProgress: 10,
      completed: false,
      rarity: "common"
    },
    {
      id: "perfect_week",
      title: "Perfect Week",
      description: "Win every bet for 7 days",
      icon: "👑",
      category: "betting",
      xpReward: 2000,
      progress: 0,
      maxProgress: 7,
      completed: false,
      rarity: "legendary"
    }
  ];

  const mockLevel: PlayerLevel = {
    currentLevel: 12,
    currentXP: 2450,
    xpToNextLevel: 550,
    totalXP: 14750,
    title: "Skilled Bettor",
    nextTitle: "Expert Gambler",
    perks: ["5% Bonus on Wins", "Early Access to Promotions", "Custom Avatar"]
  };

  const data = achievements || mockAchievements;
  const level = playerLevel || mockLevel;

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'border-gray-500 bg-gray-500/10';
      case 'rare': return 'border-blue-500 bg-blue-500/10';
      case 'epic': return 'border-purple-500 bg-purple-500/10';
      case 'legendary': return 'border-yellow-500 bg-yellow-500/10 animate-pulse';
      default: return 'border-gray-500 bg-gray-500/10';
    }
  };

  const getRarityBadgeColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-gray-600';
      case 'rare': return 'bg-blue-600';
      case 'epic': return 'bg-purple-600';
      case 'legendary': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  const xpProgress = (level.currentXP / (level.currentXP + level.xpToNextLevel)) * 100;

  return (
    <div className="space-y-6">
      {/* Player Level Card */}
      <Card className="bg-winnex-dark border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Crown className="w-5 h-5 text-yellow-500" />
            Player Level & Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Level Display */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-full border-4 border-yellow-500 bg-gradient-to-br from-yellow-400 to-orange-600 flex items-center justify-center text-2xl font-bold text-black ${levelUpAnimation ? 'animate-bounce' : ''}`}>
                  {level.currentLevel}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">{level.title}</h3>
                  <p className="text-gray-400">Next: {level.nextTitle}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-winnex-green">
                  {level.currentXP.toLocaleString()} XP
                </div>
                <div className="text-sm text-gray-400">
                  {level.xpToNextLevel} XP to next level
                </div>
              </div>
            </div>

            {/* XP Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Level {level.currentLevel}</span>
                <span className="text-gray-400">Level {level.currentLevel + 1}</span>
              </div>
              <Progress 
                value={xpProgress} 
                className="h-3 bg-gray-700"
              />
            </div>

            {/* Current Perks */}
            <div>
              <h4 className="text-sm font-semibold text-white mb-2 flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500" />
                Current Perks
              </h4>
              <div className="flex flex-wrap gap-2">
                {level.perks.map((perk, index) => (
                  <Badge key={index} className="bg-winnex-green text-black">
                    {perk}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Achievements Grid */}
      <Card className="bg-winnex-dark border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            Achievements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-4 rounded-lg border-2 transition-all duration-300 hover:scale-105 ${getRarityColor(achievement.rarity)} ${achievement.completed ? 'opacity-100' : 'opacity-70'}`}
              >
                {/* Achievement Icon & Badge */}
                <div className="flex items-start justify-between mb-3">
                  <div className={`text-4xl ${achievement.completed ? 'animate-pulse' : 'grayscale'}`}>
                    {achievement.icon}
                  </div>
                  <Badge className={`${getRarityBadgeColor(achievement.rarity)} text-white capitalize`}>
                    {achievement.rarity}
                  </Badge>
                </div>

                {/* Achievement Info */}
                <div className="space-y-2">
                  <h3 className={`font-bold ${achievement.completed ? 'text-white' : 'text-gray-400'}`}>
                    {achievement.title}
                  </h3>
                  <p className="text-sm text-gray-400">
                    {achievement.description}
                  </p>

                  {/* Progress Bar */}
                  {!achievement.completed && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-gray-400">
                        <span>{achievement.progress}</span>
                        <span>{achievement.maxProgress}</span>
                      </div>
                      <Progress 
                        value={(achievement.progress / achievement.maxProgress) * 100}
                        className="h-2 bg-gray-700"
                      />
                    </div>
                  )}

                  {/* XP Reward */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-sm">
                      <Zap className="w-4 h-4 text-yellow-500" />
                      <span className="text-yellow-500">{achievement.xpReward} XP</span>
                    </div>
                    {achievement.completed && (
                      <div className="flex items-center gap-1 text-sm text-green-400">
                        <Award className="w-4 h-4" />
                        <span>Completed</span>
                      </div>
                    )}
                  </div>

                  {/* Unlock Date */}
                  {achievement.completed && achievement.unlockedAt && (
                    <div className="text-xs text-gray-500">
                      Unlocked: {new Date(achievement.unlockedAt).toLocaleDateString()}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Achievement Categories */}
      <Card className="bg-winnex-dark border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-blue-500" />
            Achievement Categories
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4">
            {['betting', 'social', 'exploration', 'milestone'].map((category) => {
              const categoryAchievements = data.filter(a => a.category === category);
              const completed = categoryAchievements.filter(a => a.completed).length;
              const total = categoryAchievements.length;
              const progress = total > 0 ? (completed / total) * 100 : 0;

              return (
                <div key={category} className="text-center p-4 bg-gray-800 rounded-lg">
                  <div className="text-2xl mb-2">
                    {category === 'betting' && '🎯'}
                    {category === 'social' && '👥'}
                    {category === 'exploration' && '🔍'}
                    {category === 'milestone' && '🏆'}
                  </div>
                  <h3 className="text-white font-semibold capitalize mb-2">{category}</h3>
                  <div className="text-sm text-gray-400 mb-2">
                    {completed}/{total} completed
                  </div>
                  <Progress value={progress} className="h-2 bg-gray-700" />
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}