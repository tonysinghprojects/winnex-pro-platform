import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  AlertTriangle, Activity, Zap, TrendingUp, 
  Clock, Database, Wifi, Shield, RefreshCw
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

interface ErrorEvent {
  id: string;
  timestamp: Date;
  type: 'api_error' | 'database_error' | 'network_error' | 'security_error' | 'performance_error';
  severity: 'low' | 'medium' | 'high' | 'critical';
  component: string;
  message: string;
  resolved: boolean;
  responseTime?: number;
  affectedUsers?: number;
}

interface PerformanceMetric {
  timestamp: Date;
  responseTime: number;
  throughput: number;
  errorRate: number;
  activeUsers: number;
}

export default function RealTimeErrorTracker() {
  const [errors, setErrors] = useState<ErrorEvent[]>([]);
  const [performanceData, setPerformanceData] = useState<PerformanceMetric[]>([]);
  const [systemHealth, setSystemHealth] = useState(98.5);
  const [isMonitoring, setIsMonitoring] = useState(true);

  // Simulate real-time error tracking
  useEffect(() => {
    if (!isMonitoring) return;

    const interval = setInterval(() => {
      // Generate realistic error events
      const errorTypes = ['api_error', 'database_error', 'network_error', 'security_error', 'performance_error'] as const;
      const severities = ['low', 'medium', 'high', 'critical'] as const;
      const components = ['Payment API', 'Sports Data Feed', 'Crypto Service', 'User Auth', 'Database', 'WebSocket'];

      // Simulate occasional errors (10% chance)
      if (Math.random() < 0.1) {
        const newError: ErrorEvent = {
          id: Date.now().toString(),
          timestamp: new Date(),
          type: errorTypes[Math.floor(Math.random() * errorTypes.length)],
          severity: severities[Math.floor(Math.random() * severities.length)],
          component: components[Math.floor(Math.random() * components.length)],
          message: 'Connection timeout after 5000ms',
          resolved: false,
          responseTime: Math.floor(Math.random() * 2000) + 500,
          affectedUsers: Math.floor(Math.random() * 50) + 1
        };

        setErrors(prev => [newError, ...prev.slice(0, 49)]); // Keep last 50 errors
      }

      // Generate performance metrics
      const newMetric: PerformanceMetric = {
        timestamp: new Date(),
        responseTime: Math.floor(Math.random() * 200) + 100,
        throughput: Math.floor(Math.random() * 1000) + 500,
        errorRate: Math.random() * 2,
        activeUsers: Math.floor(Math.random() * 100) + 850
      };

      setPerformanceData(prev => [...prev.slice(-19), newMetric]); // Keep last 20 points

      // Update system health based on errors
      const recentErrors = errors.filter(e => !e.resolved && Date.now() - e.timestamp.getTime() < 300000);
      const criticalErrors = recentErrors.filter(e => e.severity === 'critical').length;
      const highErrors = recentErrors.filter(e => e.severity === 'high').length;
      
      let newHealth = 100 - (criticalErrors * 10) - (highErrors * 5) - (recentErrors.length * 0.5);
      setSystemHealth(Math.max(85, Math.min(100, newHealth)));

    }, 3000);

    return () => clearInterval(interval);
  }, [isMonitoring, errors]);

  const resolveError = (errorId: string) => {
    setErrors(prev => prev.map(error => 
      error.id === errorId ? { ...error, resolved: true } : error
    ));
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500 text-white';
      case 'high': return 'bg-orange-500 text-white';
      case 'medium': return 'bg-yellow-500 text-black';
      case 'low': return 'bg-blue-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getErrorIcon = (type: string) => {
    switch (type) {
      case 'api_error': return <Wifi className="h-4 w-4" />;
      case 'database_error': return <Database className="h-4 w-4" />;
      case 'network_error': return <Activity className="h-4 w-4" />;
      case 'security_error': return <Shield className="h-4 w-4" />;
      case 'performance_error': return <Zap className="h-4 w-4" />;
      default: return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const unresolvedErrors = errors.filter(e => !e.resolved);
  const criticalErrors = unresolvedErrors.filter(e => e.severity === 'critical');
  const avgResponseTime = performanceData.length > 0 
    ? Math.round(performanceData.reduce((sum, m) => sum + m.responseTime, 0) / performanceData.length)
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Real-Time Error Tracking</h1>
            <p className="text-gray-300">Advanced monitoring and performance visualization</p>
          </div>
          <div className="flex items-center space-x-4">
            <Badge className={systemHealth >= 95 ? 'bg-green-500' : systemHealth >= 85 ? 'bg-yellow-500' : 'bg-red-500'}>
              System Health: {systemHealth.toFixed(1)}%
            </Badge>
            <Button 
              onClick={() => setIsMonitoring(!isMonitoring)} 
              variant={isMonitoring ? "destructive" : "default"}
            >
              {isMonitoring ? 'Stop Monitoring' : 'Start Monitoring'}
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Active Errors</p>
                  <p className="text-2xl font-bold text-red-400">{unresolvedErrors.length}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Critical Issues</p>
                  <p className="text-2xl font-bold text-orange-400">{criticalErrors.length}</p>
                </div>
                <Zap className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Avg Response</p>
                  <p className="text-2xl font-bold text-blue-400">{avgResponseTime}ms</p>
                </div>
                <Clock className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">System Health</p>
                  <p className="text-2xl font-bold text-green-400">{systemHealth.toFixed(1)}%</p>
                </div>
                <Activity className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-black/40 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Response Time Trend</CardTitle>
              <CardDescription className="text-gray-400">
                Average API response times over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="timestamp" 
                    tickFormatter={(time) => new Date(time).toLocaleTimeString()}
                    stroke="#9CA3AF"
                  />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip 
                    labelFormatter={(time) => new Date(time).toLocaleTimeString()}
                    contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="responseTime" 
                    stroke="#3B82F6" 
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Error Rate & Throughput</CardTitle>
              <CardDescription className="text-gray-400">
                System performance metrics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="timestamp" 
                    tickFormatter={(time) => new Date(time).toLocaleTimeString()}
                    stroke="#9CA3AF"
                  />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip 
                    labelFormatter={(time) => new Date(time).toLocaleTimeString()}
                    contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="errorRate" 
                    stackId="1"
                    stroke="#EF4444" 
                    fill="#EF4444"
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Error Log */}
        <Card className="bg-black/40 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2" />
              Live Error Stream
            </CardTitle>
            <CardDescription className="text-gray-400">
              Real-time error events and system alerts
            </CardDescription>
          </CardHeader>
          <CardContent className="max-h-96 overflow-y-auto">
            {errors.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                No errors detected. System running smoothly.
              </div>
            ) : (
              <div className="space-y-3">
                {errors.slice(0, 10).map((error) => (
                  <div 
                    key={error.id} 
                    className={`p-4 rounded-lg border ${
                      error.resolved ? 'bg-green-900/20 border-green-700' : 'bg-gray-800/50 border-gray-600'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        {getErrorIcon(error.type)}
                        <span className="text-white font-medium">{error.component}</span>
                        <Badge className={getSeverityColor(error.severity)}>
                          {error.severity}
                        </Badge>
                        {error.resolved && (
                          <Badge className="bg-green-500 text-white">Resolved</Badge>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-400">
                          {error.timestamp.toLocaleTimeString()}
                        </span>
                        {!error.resolved && (
                          <Button 
                            size="sm" 
                            onClick={() => resolveError(error.id)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            Resolve
                          </Button>
                        )}
                      </div>
                    </div>
                    <p className="text-gray-300 text-sm mb-2">{error.message}</p>
                    <div className="flex items-center space-x-4 text-xs text-gray-400">
                      {error.responseTime && (
                        <span>Response: {error.responseTime}ms</span>
                      )}
                      {error.affectedUsers && (
                        <span>Affected: {error.affectedUsers} users</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}