import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Copy, QrCode, Wallet, TrendingUp, DollarSign, Bitcoin, Zap } from 'lucide-react';

interface CryptoBalance {
  currency: string;
  symbol: string;
  balance: number;
  usdValue: number;
  change24h: number;
  icon: string;
}

interface CryptoTransaction {
  id: string;
  type: 'deposit' | 'withdrawal' | 'bet' | 'win';
  currency: string;
  amount: number;
  usdValue: number;
  status: 'pending' | 'confirmed' | 'failed';
  timestamp: string;
  txHash?: string;
}

interface DepositAddress {
  currency: string;
  address: string;
  qrCode: string;
  network: string;
}

export default function CryptoWallet() {
  const { toast } = useToast();
  const [balances, setBalances] = useState<CryptoBalance[]>([]);
  const [transactions, setTransactions] = useState<CryptoTransaction[]>([]);
  const [depositAddresses, setDepositAddresses] = useState<DepositAddress[]>([]);
  const [selectedCurrency, setSelectedCurrency] = useState('BTC');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Mock data - replace with real API calls
  useEffect(() => {
    const mockBalances: CryptoBalance[] = [
      {
        currency: 'Bitcoin',
        symbol: 'BTC',
        balance: 0.15420000,
        usdValue: 6842.50,
        change24h: 2.34,
        icon: '₿'
      },
      {
        currency: 'Ethereum',
        symbol: 'ETH',
        balance: 2.85300000,
        usdValue: 5628.75,
        change24h: -1.23,
        icon: 'Ξ'
      },
      {
        currency: 'USDT',
        symbol: 'USDT',
        balance: 1250.00,
        usdValue: 1250.00,
        change24h: 0.02,
        icon: '₮'
      },
      {
        currency: 'Litecoin',
        symbol: 'LTC',
        balance: 8.45000000,
        usdValue: 758.25,
        change24h: 1.87,
        icon: 'Ł'
      }
    ];

    const mockTransactions: CryptoTransaction[] = [
      {
        id: 'tx_001',
        type: 'deposit',
        currency: 'BTC',
        amount: 0.05000000,
        usdValue: 2215.50,
        status: 'confirmed',
        timestamp: '2024-01-15T10:30:00Z',
        txHash: '1a2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890'
      },
      {
        id: 'tx_002',
        type: 'bet',
        currency: 'ETH',
        amount: -0.25000000,
        usdValue: -492.75,
        status: 'confirmed',
        timestamp: '2024-01-15T09:15:00Z'
      },
      {
        id: 'tx_003',
        type: 'win',
        currency: 'ETH',
        amount: 0.45000000,
        usdValue: 887.25,
        status: 'confirmed',
        timestamp: '2024-01-15T09:45:00Z'
      }
    ];

    const mockAddresses: DepositAddress[] = [
      {
        currency: 'BTC',
        address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
        qrCode: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
        network: 'Bitcoin Network'
      },
      {
        currency: 'ETH',
        address: '0x742d35Cc6634C0532925a3b8D8BF4F3F',
        qrCode: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
        network: 'Ethereum Network'
      },
      {
        currency: 'USDT',
        address: '0x742d35Cc6634C0532925a3b8D8BF4F3F',
        qrCode: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
        network: 'Ethereum Network (ERC-20)'
      },
      {
        currency: 'LTC',
        address: 'ltc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4',
        qrCode: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
        network: 'Litecoin Network'
      }
    ];

    setBalances(mockBalances);
    setTransactions(mockTransactions);
    setDepositAddresses(mockAddresses);
  }, []);

  const totalUsdValue = balances.reduce((sum, balance) => sum + balance.usdValue, 0);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "Address copied successfully",
    });
  };

  const handleWithdraw = async () => {
    if (!withdrawAmount || !withdrawAddress) {
      toast({
        title: "Error",
        description: "Please enter both amount and address",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Withdrawal Initiated",
        description: `Withdrawal of ${withdrawAmount} ${selectedCurrency} has been submitted for processing`,
      });
      setWithdrawAmount('');
      setWithdrawAddress('');
      setIsLoading(false);
    }, 2000);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'deposit': return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'withdrawal': return <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />;
      case 'bet': return <DollarSign className="h-4 w-4 text-blue-500" />;
      case 'win': return <Zap className="h-4 w-4 text-yellow-500" />;
      default: return <DollarSign className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'deposit': return 'text-green-500';
      case 'withdrawal': return 'text-red-500';
      case 'bet': return 'text-blue-500';
      case 'win': return 'text-yellow-500';
      default: return 'text-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-2">Crypto Wallet</h1>
          <p className="text-gray-300">Secure cryptocurrency management for betting</p>
        </div>

        {/* Total Balance */}
        <Card className="bg-black/40 border-gray-700">
          <CardContent className="p-8 text-center">
            <div className="flex items-center justify-center mb-4">
              <Wallet className="h-8 w-8 text-yellow-400 mr-3" />
              <span className="text-2xl font-bold text-white">Total Portfolio Value</span>
            </div>
            <div className="text-5xl font-bold text-green-400 mb-2">
              ${totalUsdValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-gray-400">Across all cryptocurrencies</div>
          </CardContent>
        </Card>

        <Tabs defaultValue="balances" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-black/40 border-gray-700">
            <TabsTrigger value="balances" className="text-white">Balances</TabsTrigger>
            <TabsTrigger value="deposit" className="text-white">Deposit</TabsTrigger>
            <TabsTrigger value="withdraw" className="text-white">Withdraw</TabsTrigger>
            <TabsTrigger value="history" className="text-white">History</TabsTrigger>
          </TabsList>

          {/* Balances Tab */}
          <TabsContent value="balances">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {balances.map((balance) => (
                <Card key={balance.symbol} className="bg-black/40 border-gray-700 hover:bg-black/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="text-2xl mr-2">{balance.icon}</span>
                        <div>
                          <CardTitle className="text-white text-lg">{balance.symbol}</CardTitle>
                          <CardDescription className="text-gray-400">{balance.currency}</CardDescription>
                        </div>
                      </div>
                      <Badge variant={balance.change24h >= 0 ? "default" : "destructive"}>
                        {balance.change24h >= 0 ? '+' : ''}{balance.change24h.toFixed(2)}%
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="text-2xl font-bold text-white">
                        {balance.balance.toFixed(8)}
                      </div>
                      <div className="text-lg text-green-400">
                        ${balance.usdValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Deposit Tab */}
          <TabsContent value="deposit">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Select Cryptocurrency</CardTitle>
                  <CardDescription className="text-gray-400">
                    Choose which cryptocurrency you want to deposit
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-3">
                    {depositAddresses.map((addr) => (
                      <Button
                        key={addr.currency}
                        variant={selectedCurrency === addr.currency ? "default" : "outline"}
                        onClick={() => setSelectedCurrency(addr.currency)}
                        className="h-16 flex flex-col"
                      >
                        <span className="font-bold">{addr.currency}</span>
                        <span className="text-xs opacity-70">{addr.network}</span>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Deposit Address</CardTitle>
                  <CardDescription className="text-gray-400">
                    Send {selectedCurrency} to this address
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {depositAddresses
                    .filter(addr => addr.currency === selectedCurrency)
                    .map((addr) => (
                      <div key={addr.currency} className="space-y-4">
                        <div className="flex items-center justify-center p-4 bg-white rounded-lg">
                          <QrCode className="h-32 w-32 text-black" />
                        </div>
                        <div className="space-y-2">
                          <div className="text-sm text-gray-400">Network: {addr.network}</div>
                          <div className="flex items-center space-x-2">
                            <Input
                              value={addr.address}
                              readOnly
                              className="bg-gray-800 border-gray-600 text-white"
                            />
                            <Button
                              size="sm"
                              onClick={() => copyToClipboard(addr.address)}
                              className="px-3"
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Withdraw Tab */}
          <TabsContent value="withdraw">
            <Card className="bg-black/40 border-gray-700 max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle className="text-white">Withdraw Cryptocurrency</CardTitle>
                <CardDescription className="text-gray-400">
                  Send your crypto to an external wallet
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Currency</label>
                  <div className="grid grid-cols-4 gap-2">
                    {['BTC', 'ETH', 'USDT', 'LTC'].map((currency) => (
                      <Button
                        key={currency}
                        variant={selectedCurrency === currency ? "default" : "outline"}
                        onClick={() => setSelectedCurrency(currency)}
                      >
                        {currency}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Amount</label>
                  <Input
                    type="number"
                    placeholder="0.00000000"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Destination Address</label>
                  <Input
                    placeholder="Enter wallet address"
                    value={withdrawAddress}
                    onChange={(e) => setWithdrawAddress(e.target.value)}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>

                <Button
                  className="w-full"
                  onClick={handleWithdraw}
                  disabled={isLoading}
                >
                  {isLoading ? 'Processing...' : 'Withdraw'}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <Card className="bg-black/40 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Transaction History</CardTitle>
                <CardDescription className="text-gray-400">
                  Your recent cryptocurrency transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        {getTypeIcon(tx.type)}
                        <div>
                          <div className="font-medium text-white capitalize">{tx.type}</div>
                          <div className="text-sm text-gray-400">
                            {new Date(tx.timestamp).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`font-medium ${getTypeColor(tx.type)}`}>
                          {tx.amount > 0 ? '+' : ''}{tx.amount.toFixed(8)} {tx.currency}
                        </div>
                        <div className="text-sm text-gray-400">
                          ${Math.abs(tx.usdValue).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                      <Badge variant={tx.status === 'confirmed' ? 'default' : 'secondary'}>
                        {tx.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}