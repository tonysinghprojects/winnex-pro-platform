import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Flame, TrendingUp, Users, Zap } from "lucide-react";

interface GamePopularity {
  sport: string;
  emoji: string;
  popularity: number;
  trend: 'up' | 'down' | 'stable';
  activeUsers: number;
  todayBets: number;
  heatLevel: number;
}

export default function PopularityHeatMap() {
  const [animatedValues, setAnimatedValues] = useState<{ [key: string]: number }>({});

  const { data: popularityData } = useQuery({
    queryKey: ['/api/games/popularity'],
    refetchInterval: 30000, // Update every 30 seconds
  });

  useEffect(() => {
    if (popularityData) {
      // Animate values on data update
      const newValues: { [key: string]: number } = {};
      popularityData.forEach((game: GamePopularity) => {
        newValues[game.sport] = Math.random() * 20 + 80; // Simulate real-time changes
      });
      setAnimatedValues(newValues);
    }
  }, [popularityData]);

  const getHeatIntensity = (level: number) => {
    if (level >= 90) return 'bg-red-500/80 animate-pulse';
    if (level >= 70) return 'bg-orange-500/70 animate-pulse';
    if (level >= 50) return 'bg-yellow-500/60';
    if (level >= 30) return 'bg-green-500/50';
    return 'bg-blue-500/40';
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-400 animate-bounce" />;
      case 'down': return <TrendingUp className="w-4 h-4 text-red-400 rotate-180 animate-bounce" />;
      default: return <Zap className="w-4 h-4 text-yellow-400" />;
    }
  };

  const mockData: GamePopularity[] = [
    {
      sport: "Football",
      emoji: "🏈",
      popularity: 95,
      trend: 'up',
      activeUsers: 2847,
      todayBets: 15420,
      heatLevel: 95
    },
    {
      sport: "Basketball",
      emoji: "🏀",
      popularity: 87,
      trend: 'up',
      activeUsers: 1923,
      todayBets: 8765,
      heatLevel: 87
    },
    {
      sport: "Soccer",
      emoji: "⚽",
      popularity: 92,
      trend: 'stable',
      activeUsers: 3156,
      todayBets: 12340,
      heatLevel: 92
    },
    {
      sport: "Tennis",
      emoji: "🎾",
      popularity: 74,
      trend: 'down',
      activeUsers: 987,
      todayBets: 4521,
      heatLevel: 74
    },
    {
      sport: "Baseball",
      emoji: "⚾",
      popularity: 68,
      trend: 'up',
      activeUsers: 1234,
      todayBets: 6789,
      heatLevel: 68
    },
    {
      sport: "Esports",
      emoji: "🎮",
      popularity: 89,
      trend: 'up',
      activeUsers: 2156,
      todayBets: 9876,
      heatLevel: 89
    }
  ];

  const data = popularityData || mockData;

  return (
    <Card className="bg-winnex-dark border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Flame className="w-5 h-5 text-orange-500 animate-pulse" />
          Live Game Popularity Heat Map
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {data.map((game) => (
            <div
              key={game.sport}
              className={`relative rounded-lg p-4 ${getHeatIntensity(game.heatLevel)} 
                         hover:scale-105 transition-all duration-300 cursor-pointer`}
            >
              {/* Heat indicator */}
              <div className="absolute top-1 right-1">
                {getTrendIcon(game.trend)}
              </div>
              
              {/* Main content */}
              <div className="text-center">
                <div className="text-4xl mb-2 animate-bounce" style={{animationDelay: `${Math.random() * 2}s`}}>
                  {game.emoji}
                </div>
                <div className="text-white font-semibold text-sm mb-1">
                  {game.sport}
                </div>
                <div className="text-xs text-white/80 mb-2">
                  {game.popularity}% Hot
                </div>
                
                {/* Stats */}
                <div className="space-y-1 text-xs">
                  <div className="flex items-center justify-between text-white/70">
                    <Users className="w-3 h-3" />
                    <span>{game.activeUsers.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between text-white/70">
                    <span>📊</span>
                    <span>{game.todayBets.toLocaleString()}</span>
                  </div>
                </div>
              </div>
              
              {/* Popularity bar */}
              <div className="mt-3 bg-black/30 rounded-full h-2 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-400 to-purple-600 transition-all duration-1000 ease-out"
                  style={{ 
                    width: `${animatedValues[game.sport] || game.popularity}%`,
                    animation: 'pulse 2s infinite'
                  }}
                ></div>
              </div>
              
              {/* Heat level badge */}
              {game.heatLevel >= 90 && (
                <Badge className="absolute -top-2 -left-2 bg-red-500 text-white animate-pulse">
                  🔥 HOT
                </Badge>
              )}
            </div>
          ))}
        </div>
        
        {/* Legend */}
        <div className="mt-6 flex flex-wrap gap-4 text-xs text-gray-400">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded"></div>
            <span>90-100% - Extremely Hot</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-orange-500 rounded"></div>
            <span>70-89% - Very Popular</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-yellow-500 rounded"></div>
            <span>50-69% - Popular</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span>30-49% - Moderate</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded"></div>
            <span>0-29% - Low Activity</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}