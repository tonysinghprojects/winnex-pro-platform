import { useState } from "react";
import { DollarSign, TrendingUp, Clock } from "lucide-react";

interface CashOutWidgetProps {
  betId: number;
  originalStake: number;
  currentValue: number;
  potentialWin: number;
  isLive: boolean;
}

export default function CashOutWidget({ 
  betId, 
  originalStake, 
  currentValue, 
  potentialWin, 
  isLive 
}: CashOutWidgetProps) {
  const [isPartial, setIsPartial] = useState(false);
  const [partialAmount, setPartialAmount] = useState("");

  const profit = currentValue - originalStake;
  const profitPercentage = ((profit / originalStake) * 100).toFixed(1);

  const handleCashOut = () => {
    // Implementation for cash out API call
    console.log("Cash out:", { betId, amount: isPartial ? partialAmount : currentValue });
  };

  return (
    <div className="card-modern p-4 border border-winnex-green/30">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <DollarSign className="text-winnex-green" size={16} />
          <span className="font-bold text-sm">Cash Out Available</span>
          {isLive && (
            <div className="flex items-center space-x-1 text-xs text-red-500">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span>LIVE</span>
            </div>
          )}
        </div>
        {isLive && <Clock className="text-yellow-400 animate-pulse" size={14} />}
      </div>

      <div className="space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-white/60">Original Stake:</span>
          <span>${originalStake.toFixed(2)}</span>
        </div>
        
        <div className="flex justify-between text-sm">
          <span className="text-white/60">Current Value:</span>
          <span className="font-bold text-winnex-green">${currentValue.toFixed(2)}</span>
        </div>
        
        <div className="flex justify-between text-sm">
          <span className="text-white/60">Profit/Loss:</span>
          <span className={`font-bold flex items-center ${profit >= 0 ? 'text-winnex-green' : 'text-red-400'}`}>
            <TrendingUp size={12} className="mr-1" />
            ${profit.toFixed(2)} ({profitPercentage}%)
          </span>
        </div>

        <div className="border-t border-white/10 pt-3">
          <div className="flex items-center space-x-2 mb-3">
            <input
              type="checkbox"
              id="partial"
              checked={isPartial}
              onChange={(e) => setIsPartial(e.target.checked)}
              className="rounded border-white/20"
            />
            <label htmlFor="partial" className="text-sm text-white/80">
              Partial Cash Out
            </label>
          </div>

          {isPartial && (
            <input
              type="number"
              placeholder="Enter amount"
              value={partialAmount}
              onChange={(e) => setPartialAmount(e.target.value)}
              max={currentValue}
              className="w-full p-2 mb-3 bg-secondary rounded border border-white/10 text-white text-sm"
            />
          )}

          <button
            onClick={handleCashOut}
            className="btn-primary w-full text-sm py-2"
            disabled={isPartial && (!partialAmount || parseFloat(partialAmount) <= 0)}
          >
            Cash Out ${isPartial && partialAmount ? partialAmount : currentValue.toFixed(2)}
          </button>
        </div>
      </div>
    </div>
  );
}