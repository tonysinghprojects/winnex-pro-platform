import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Crown, Star, Gift, Users, Calendar, Trophy, Zap, Clock, MessageCircle } from "lucide-react";

interface VIPTier {
  id: string;
  name: string;
  level: number;
  icon: React.ReactNode;
  color: string;
  requiredPoints: number;
  benefits: string[];
  perks: VIPPerk[];
  exclusiveFeatures: string[];
}

interface VIPPerk {
  id: string;
  name: string;
  description: string;
  type: 'cashback' | 'bonus' | 'exclusive' | 'priority' | 'personal';
  value: number | string;
  available: boolean;
}

interface VIPEvent {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  type: 'sports' | 'casino' | 'travel' | 'dining';
  minTier: number;
  participants: number;
  maxParticipants: number;
  status: 'upcoming' | 'ongoing' | 'completed';
}

interface PersonalManager {
  id: string;
  name: string;
  title: string;
  avatar: string;
  specialties: string[];
  availability: 'online' | 'busy' | 'offline';
  responseTime: string;
}

interface VIPStats {
  currentTier: VIPTier;
  totalPoints: number;
  pointsToNext: number;
  lifetimeSpent: number;
  cashbackEarned: number;
  exclusiveEventsAttended: number;
  personalManagerSessions: number;
}

export default function EnhancedVIPProgram() {
  const [vipTiers, setVipTiers] = useState<VIPTier[]>([]);
  const [userStats, setUserStats] = useState<VIPStats | null>(null);
  const [vipEvents, setVipEvents] = useState<VIPEvent[]>([]);
  const [personalManager, setPersonalManager] = useState<PersonalManager | null>(null);
  const [selectedTab, setSelectedTab] = useState('overview');

  useEffect(() => {
    const mockVipTiers: VIPTier[] = [
      {
        id: 'bronze',
        name: 'Bronze',
        level: 1,
        icon: <Trophy className="w-6 h-6" />,
        color: 'text-orange-400',
        requiredPoints: 0,
        benefits: ['5% cashback on losses', 'Monthly bonus', 'Email support'],
        perks: [
          { id: 'bronze_cashback', name: '5% Loss Cashback', description: 'Get 5% back on your losses', type: 'cashback', value: 5, available: true },
          { id: 'bronze_bonus', name: 'Monthly Bonus', description: '$50 monthly bonus', type: 'bonus', value: 50, available: true }
        ],
        exclusiveFeatures: ['Standard betting limits', 'Regular promotions']
      },
      {
        id: 'silver',
        name: 'Silver',
        level: 2,
        icon: <Star className="w-6 h-6" />,
        color: 'text-gray-400',
        requiredPoints: 1000,
        benefits: ['8% cashback on losses', 'Bi-weekly bonuses', 'Priority support', 'Exclusive tournaments'],
        perks: [
          { id: 'silver_cashback', name: '8% Loss Cashback', description: 'Get 8% back on your losses', type: 'cashback', value: 8, available: true },
          { id: 'silver_bonus', name: 'Bi-weekly Bonus', description: '$100 bi-weekly bonus', type: 'bonus', value: 100, available: true },
          { id: 'silver_support', name: 'Priority Support', description: 'Skip the queue', type: 'priority', value: 'enabled', available: true }
        ],
        exclusiveFeatures: ['Higher betting limits', 'Exclusive tournaments', 'Early odds access']
      },
      {
        id: 'gold',
        name: 'Gold',
        level: 3,
        icon: <Crown className="w-6 h-6" />,
        color: 'text-yellow-400',
        requiredPoints: 5000,
        benefits: ['12% cashback on losses', 'Weekly bonuses', 'Personal account manager', 'VIP events'],
        perks: [
          { id: 'gold_cashback', name: '12% Loss Cashback', description: 'Get 12% back on your losses', type: 'cashback', value: 12, available: true },
          { id: 'gold_bonus', name: 'Weekly Bonus', description: '$250 weekly bonus', type: 'bonus', value: 250, available: true },
          { id: 'gold_manager', name: 'Personal Manager', description: 'Dedicated account manager', type: 'personal', value: 'assigned', available: true }
        ],
        exclusiveFeatures: ['Premium betting limits', 'VIP events access', 'Custom promotions', 'Faster withdrawals']
      },
      {
        id: 'platinum',
        name: 'Platinum',
        level: 4,
        icon: <Crown className="w-6 h-6" />,
        color: 'text-purple-400',
        requiredPoints: 15000,
        benefits: ['15% cashback on losses', 'Daily bonuses', 'Concierge service', 'Luxury experiences'],
        perks: [
          { id: 'platinum_cashback', name: '15% Loss Cashback', description: 'Get 15% back on your losses', type: 'cashback', value: 15, available: true },
          { id: 'platinum_bonus', name: 'Daily Bonus', description: '$100 daily bonus', type: 'bonus', value: 100, available: true },
          { id: 'platinum_concierge', name: 'Concierge Service', description: '24/7 personal concierge', type: 'personal', value: '24/7', available: true }
        ],
        exclusiveFeatures: ['Unlimited betting limits', 'Luxury travel packages', 'Private events', 'Instant withdrawals']
      }
    ];

    const mockUserStats: VIPStats = {
      currentTier: mockVipTiers[2], // Gold tier
      totalPoints: 7350,
      pointsToNext: 7650,
      lifetimeSpent: 25840,
      cashbackEarned: 3100,
      exclusiveEventsAttended: 4,
      personalManagerSessions: 12
    };

    const mockVipEvents: VIPEvent[] = [
      {
        id: 'event_1',
        title: 'Champions League Final VIP Experience',
        description: 'Watch the Champions League Final with premium hospitality, meet & greet with legends',
        date: '2024-06-01',
        location: 'Wembley Stadium, London',
        type: 'sports',
        minTier: 3,
        participants: 45,
        maxParticipants: 50,
        status: 'upcoming'
      },
      {
        id: 'event_2',
        title: 'Monte Carlo Casino Weekend',
        description: 'Exclusive weekend at Monte Carlo Casino with luxury accommodation',
        date: '2024-05-15',
        location: 'Monte Carlo, Monaco',
        type: 'casino',
        minTier: 4,
        participants: 20,
        maxParticipants: 25,
        status: 'upcoming'
      },
      {
        id: 'event_3',
        title: 'Private Poker Tournament',
        description: 'High-stakes private poker tournament with professional dealers',
        date: '2024-02-20',
        location: 'Private Club, Las Vegas',
        type: 'casino',
        minTier: 3,
        participants: 30,
        maxParticipants: 32,
        status: 'upcoming'
      }
    ];

    const mockPersonalManager: PersonalManager = {
      id: 'manager_1',
      name: 'Sarah Mitchell',
      title: 'Senior VIP Account Manager',
      avatar: '/api/placeholder/60/60',
      specialties: ['High-roller betting', 'Investment strategies', 'Exclusive events'],
      availability: 'online',
      responseTime: '< 5 minutes'
    };

    setVipTiers(mockVipTiers);
    setUserStats(mockUserStats);
    setVipEvents(mockVipEvents);
    setPersonalManager(mockPersonalManager);
  }, []);

  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case 'sports': return <Trophy className="w-5 h-5" />;
      case 'casino': return <Crown className="w-5 h-5" />;
      case 'travel': return <Calendar className="w-5 h-5" />;
      case 'dining': return <Gift className="w-5 h-5" />;
      default: return <Star className="w-5 h-5" />;
    }
  };

  if (!userStats) return null;

  const progressToNext = ((userStats.totalPoints - userStats.currentTier.requiredPoints) / (userStats.pointsToNext - userStats.currentTier.requiredPoints)) * 100;

  return (
    <div className="p-6 space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <Crown className="w-12 h-12 text-emerald-400 mr-3" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            VIP Elite Program
          </h1>
        </div>
        <p className="text-gray-400 text-lg">Exclusive benefits and luxury experiences for our valued members</p>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center">
            <Star className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="benefits" className="flex items-center">
            <Gift className="w-4 h-4 mr-2" />
            Benefits
          </TabsTrigger>
          <TabsTrigger value="events" className="flex items-center">
            <Calendar className="w-4 h-4 mr-2" />
            Events
          </TabsTrigger>
          <TabsTrigger value="manager" className="flex items-center">
            <Users className="w-4 h-4 mr-2" />
            Manager
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Current Status */}
          <Card className="casino-card border-yellow-400/20 bg-gradient-to-r from-yellow-500/10 to-orange-500/10">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={userStats.currentTier.color}>
                    {userStats.currentTier.icon}
                  </div>
                  <div>
                    <CardTitle className={`text-2xl ${userStats.currentTier.color}`}>
                      {userStats.currentTier.name} Member
                    </CardTitle>
                    <p className="text-gray-400">Level {userStats.currentTier.level} VIP Status</p>
                  </div>
                </div>
                <Badge className="bg-yellow-500/20 text-yellow-400 text-lg px-4 py-2">
                  {userStats.totalPoints.toLocaleString()} Points
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-400">Progress to Platinum</span>
                  <span className="text-white">{userStats.pointsToNext - userStats.totalPoints} points needed</span>
                </div>
                <Progress value={progressToNext} className="h-3" />
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-400">${userStats.lifetimeSpent.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">Lifetime Spent</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">${userStats.cashbackEarned.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">Cashback Earned</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-400">{userStats.exclusiveEventsAttended}</div>
                  <div className="text-sm text-gray-400">Events Attended</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-400">{userStats.personalManagerSessions}</div>
                  <div className="text-sm text-gray-400">Manager Sessions</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* VIP Tiers Overview */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {vipTiers.map((tier) => (
              <Card 
                key={tier.id} 
                className={`${tier.id === userStats.currentTier.id ? 'border-yellow-400 bg-yellow-500/10' : 'casino-card'}`}
              >
                <CardHeader className="text-center">
                  <div className={`mx-auto mb-2 ${tier.color}`}>
                    {tier.icon}
                  </div>
                  <CardTitle className={tier.color}>{tier.name}</CardTitle>
                  <p className="text-sm text-gray-400">{tier.requiredPoints.toLocaleString()} points</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1 text-sm">
                    {tier.benefits.slice(0, 3).map((benefit, index) => (
                      <li key={index} className="text-gray-300 flex items-start">
                        <Zap className="w-3 h-3 text-emerald-400 mr-2 mt-0.5 flex-shrink-0" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                  {tier.level > userStats.currentTier.level && (
                    <Badge variant="outline" className="mt-3 w-full justify-center">
                      Locked
                    </Badge>
                  )}
                  {tier.id === userStats.currentTier.id && (
                    <Badge className="mt-3 w-full justify-center bg-yellow-500/20 text-yellow-400">
                      Current Tier
                    </Badge>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="benefits" className="space-y-6">
          <div className="grid gap-6">
            {userStats.currentTier.perks.map((perk) => (
              <Card key={perk.id} className="casino-card">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-white mb-2">{perk.name}</h3>
                      <p className="text-gray-400 mb-4">{perk.description}</p>
                      <div className="flex items-center space-x-4">
                        <Badge variant={perk.available ? 'default' : 'secondary'}>
                          {perk.available ? 'Available' : 'Used'}
                        </Badge>
                        <span className="text-emerald-400 font-semibold">
                          {typeof perk.value === 'number' ? `${perk.value}%` : perk.value}
                        </span>
                      </div>
                    </div>
                    <Button 
                      className={perk.available ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-gray-600'}
                      disabled={!perk.available}
                    >
                      {perk.available ? 'Claim' : 'Claimed'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="casino-card border-purple-400/20">
            <CardHeader>
              <CardTitle className="text-white">Exclusive Features</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                {userStats.currentTier.exclusiveFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <Crown className="w-5 h-5 text-purple-400" />
                    <span className="text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="events" className="space-y-6">
          <div className="grid gap-6">
            {vipEvents.filter(event => event.minTier <= userStats.currentTier.level).map((event) => (
              <Card key={event.id} className="casino-card">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-3">
                      <div className="text-emerald-400">
                        {getEventTypeIcon(event.type)}
                      </div>
                      <div>
                        <CardTitle className="text-white">{event.title}</CardTitle>
                        <p className="text-gray-400">{event.location}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="capitalize">
                      {event.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-300">{event.description}</p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Date: </span>
                      <span className="text-white">{new Date(event.date).toLocaleDateString()}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Min Tier: </span>
                      <span className="text-yellow-400">{vipTiers.find(t => t.level === event.minTier)?.name}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Participants: </span>
                      <span className="text-white">{event.participants}/{event.maxParticipants}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Type: </span>
                      <span className="text-emerald-400 capitalize">{event.type}</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <Progress 
                      value={(event.participants / event.maxParticipants) * 100} 
                      className="flex-1 mr-4 h-2"
                    />
                    <Button 
                      className="bg-emerald-500 hover:bg-emerald-600"
                      disabled={event.participants >= event.maxParticipants}
                    >
                      {event.participants >= event.maxParticipants ? 'Full' : 'Register'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="manager" className="space-y-6">
          {personalManager && (
            <Card className="casino-card border-emerald-400/20">
              <CardHeader>
                <CardTitle className="text-white">Your Personal Account Manager</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-4">
                  <img 
                    src={personalManager.avatar} 
                    alt={personalManager.name}
                    className="w-16 h-16 rounded-full"
                  />
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-white">{personalManager.name}</h3>
                    <p className="text-gray-400">{personalManager.title}</p>
                    <div className="flex items-center space-x-2 mt-2">
                      <div className={`w-3 h-3 rounded-full ${
                        personalManager.availability === 'online' ? 'bg-green-400' :
                        personalManager.availability === 'busy' ? 'bg-yellow-400' : 'bg-gray-400'
                      }`} />
                      <span className="text-sm text-gray-400 capitalize">
                        {personalManager.availability} • Response: {personalManager.responseTime}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-white mb-3">Specialties</h4>
                  <div className="flex flex-wrap gap-2">
                    {personalManager.specialties.map((specialty, index) => (
                      <Badge key={index} variant="outline">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Button className="bg-emerald-500 hover:bg-emerald-600">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Start Chat
                  </Button>
                  <Button variant="outline">
                    <Calendar className="w-4 h-4 mr-2" />
                    Schedule Call
                  </Button>
                </div>

                <Card className="border-gray-700 bg-gray-800/50">
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-white mb-2">Quick Services</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-emerald-400" />
                        <span className="text-gray-300">Instant withdrawals</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Zap className="w-4 h-4 text-blue-400" />
                        <span className="text-gray-300">Custom betting limits</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Gift className="w-4 h-4 text-purple-400" />
                        <span className="text-gray-300">Personalized bonuses</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Crown className="w-4 h-4 text-yellow-400" />
                        <span className="text-gray-300">Exclusive events</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}