import { useState, useRef, useEffect } from "react";
import { Play, Pause, Volume2, VolumeX, Maximize, Settings, Users, MessageCircle } from "lucide-react";

interface LiveStreamPlayerProps {
  matchId: number;
  streamUrl?: string;
  isLive: boolean;
  viewerCount?: number;
}

export default function LiveStreamPlayer({ matchId, streamUrl, isLive, viewerCount = 0 }: LiveStreamPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [showChat, setShowChat] = useState(false);
  const [quality, setQuality] = useState("HD");
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    if (isPlaying && showControls) {
      timeout = setTimeout(() => setShowControls(false), 3000);
    }
    return () => clearTimeout(timeout);
  }, [isPlaying, showControls]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const enterFullscreen = () => {
    if (videoRef.current) {
      videoRef.current.requestFullscreen();
    }
  };

  return (
    <div className="relative bg-black rounded-xl overflow-hidden group">
      {/* Live Badge */}
      {isLive && (
        <div className="absolute top-4 left-4 z-20 flex items-center space-x-2 bg-red-500 px-3 py-1 rounded-full">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
          <span className="text-white text-sm font-bold">LIVE</span>
        </div>
      )}

      {/* Viewer Count */}
      <div className="absolute top-4 right-4 z-20 flex items-center space-x-1 glass rounded-full px-3 py-1">
        <Users size={14} className="text-white" />
        <span className="text-white text-sm">{viewerCount.toLocaleString()}</span>
      </div>

      {/* Video Player */}
      <div 
        className="relative aspect-video cursor-pointer"
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => !isPlaying && setShowControls(false)}
        onClick={togglePlay}
      >
        {streamUrl ? (
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            poster="https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=800&h=450&fit=crop"
          >
            <source src={streamUrl} type="video/mp4" />
          </video>
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-800 to-gray-900">
            <div className="text-center">
              <div className="text-6xl mb-4">📺</div>
              <h3 className="text-xl font-bold text-white mb-2">Stream Starting Soon</h3>
              <p className="text-white/60">Live coverage will begin when the match starts</p>
            </div>
          </div>
        )}

        {/* Play/Pause Overlay */}
        {!isPlaying && streamUrl && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/20">
            <button className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm hover:bg-white/30 transition-all">
              <Play size={24} className="text-white ml-1" />
            </button>
          </div>
        )}

        {/* Controls */}
        <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 transition-opacity ${showControls ? 'opacity-100' : 'opacity-0'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button onClick={togglePlay} className="text-white hover:text-winnex-green transition-colors">
                {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              </button>
              <button onClick={toggleMute} className="text-white hover:text-winnex-green transition-colors">
                {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
              </button>
              <div className="text-white text-sm">
                {isLive ? 'LIVE' : '00:00 / 00:00'}
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="relative">
                <button className="text-white hover:text-winnex-green transition-colors">
                  <Settings size={20} />
                </button>
                <div className="absolute bottom-full right-0 mb-2 bg-black/90 rounded-lg p-2 text-white text-sm whitespace-nowrap">
                  Quality: {quality}
                </div>
              </div>
              <button 
                onClick={() => setShowChat(!showChat)}
                className={`text-white hover:text-winnex-green transition-colors ${showChat ? 'text-winnex-green' : ''}`}
              >
                <MessageCircle size={20} />
              </button>
              <button onClick={enterFullscreen} className="text-white hover:text-winnex-green transition-colors">
                <Maximize size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Live Chat Sidebar */}
      {showChat && (
        <div className="absolute top-0 right-0 w-80 h-full bg-black/90 backdrop-blur-sm p-4 overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-white">Live Chat</h3>
            <button 
              onClick={() => setShowChat(false)}
              className="text-white/60 hover:text-white"
            >
              ✕
            </button>
          </div>
          
          <div className="h-full flex flex-col">
            <div className="flex-1 space-y-2 overflow-y-auto mb-4">
              {[
                { user: "SportsFan99", message: "Great match so far!", time: "2m" },
                { user: "BetMaster", message: "Going for over 2.5 goals", time: "3m" },
                { user: "LiveBetter", message: "What odds are you getting?", time: "5m" },
              ].map((chat, index) => (
                <div key={index} className="text-sm">
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-winnex-green">{chat.user}</span>
                    <span className="text-white/40 text-xs">{chat.time}</span>
                  </div>
                  <div className="text-white/80">{chat.message}</div>
                </div>
              ))}
            </div>
            
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Type a message..."
                className="flex-1 p-2 bg-white/10 rounded border border-white/20 text-white text-sm"
              />
              <button className="px-4 py-2 bg-winnex-green text-black rounded font-medium text-sm">
                Send
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Stream Stats */}
      <div className="absolute bottom-4 left-4 flex space-x-4 text-xs text-white/80">
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span>1080p</span>
        </div>
        <div>Latency: 2.1s</div>
        <div>Bitrate: 6000 kbps</div>
      </div>
    </div>
  );
}