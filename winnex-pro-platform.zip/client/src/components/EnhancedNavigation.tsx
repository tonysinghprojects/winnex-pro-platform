import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { 
  Activity, BarChart3, Settings, Shield, Zap, 
  Database, Wifi, TrendingUp, AlertTriangle,
  Home, DollarSign, Trophy, Users, Gamepad2
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function EnhancedNavigation() {
  const [location] = useLocation();
  const [isMonitoringOpen, setIsMonitoringOpen] = useState(false);

  const isActive = (path: string) => location === path;

  const mainNavItems = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/sports', label: 'Sports', icon: Trophy },
    { path: '/live', label: 'Live Betting', icon: Activity },
    { path: '/casino', label: 'Casino', icon: Gamepad2 },
    { path: '/deposit', label: 'Deposit', icon: DollarSign },
    { path: '/social', label: 'Social', icon: Users },
  ];

  const monitoringItems = [
    { path: '/system-health', label: 'System Health', icon: Activity, status: 'operational' },
    { path: '/error-tracking', label: 'Error Tracking', icon: AlertTriangle, status: 'monitoring' },
    { path: '/system-diagnostics', label: 'Diagnostics', icon: Database, status: 'active' },
    { path: '/performance-optimizer', label: 'Performance', icon: Zap, status: 'optimizing' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': return 'bg-green-500';
      case 'monitoring': return 'bg-blue-500';
      case 'active': return 'bg-purple-500';
      case 'optimizing': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <nav className="bg-black/90 backdrop-blur-sm border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/">
              <div className="flex items-center space-x-2 cursor-pointer">
                <div className="w-8 h-8 bg-gradient-to-r from-green-400 to-blue-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">W</span>
                </div>
                <span className="text-white font-bold text-xl">Winnex Pro</span>
                <Badge className="bg-green-500 text-white text-xs">100% Operational</Badge>
              </div>
            </Link>
          </div>

          {/* Main Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {mainNavItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.path} href={item.path}>
                    <div
                      className={`px-3 py-2 rounded-md text-sm font-medium flex items-center space-x-2 transition-colors cursor-pointer ${
                        isActive(item.path)
                          ? 'bg-blue-600 text-white'
                          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Monitoring & System Controls */}
          <div className="flex items-center space-x-4">
            {/* System Monitoring Dropdown */}
            <DropdownMenu open={isMonitoringOpen} onOpenChange={setIsMonitoringOpen}>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center space-x-2">
                  <Activity className="h-4 w-4" />
                  <span className="hidden md:block">System Monitor</span>
                  <Badge className="bg-green-500 text-white">98.7%</Badge>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-64 bg-gray-900 border-gray-700">
                <DropdownMenuLabel className="text-white">System Monitoring</DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-gray-700" />
                
                {monitoringItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link key={item.path} href={item.path}>
                      <DropdownMenuItem 
                        className="text-gray-300 hover:bg-gray-800 cursor-pointer"
                        onClick={() => setIsMonitoringOpen(false)}
                      >
                        <div className="flex items-center justify-between w-full">
                          <div className="flex items-center space-x-2">
                            <Icon className="h-4 w-4" />
                            <span>{item.label}</span>
                          </div>
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(item.status)}`} />
                        </div>
                      </DropdownMenuItem>
                    </Link>
                  );
                })}
                
                <DropdownMenuSeparator className="bg-gray-700" />
                <DropdownMenuItem className="text-gray-300 hover:bg-gray-800">
                  <div className="flex items-center justify-between w-full">
                    <span>System Status</span>
                    <Badge className="bg-green-500 text-white text-xs">All Systems GO</Badge>
                  </div>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Quick Stats */}
            <div className="hidden lg:flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-1 text-green-400">
                <Activity className="h-3 w-3" />
                <span>145ms</span>
              </div>
              <div className="flex items-center space-x-1 text-blue-400">
                <Users className="h-3 w-3" />
                <span>1,247</span>
              </div>
              <div className="flex items-center space-x-1 text-purple-400">
                <TrendingUp className="h-3 w-3" />
                <span>99.97%</span>
              </div>
            </div>

            {/* Profile/Settings */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Settings className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-48 bg-gray-900 border-gray-700">
                <DropdownMenuLabel className="text-white">Platform Settings</DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-gray-700" />
                
                <Link href="/profile">
                  <DropdownMenuItem className="text-gray-300 hover:bg-gray-800 cursor-pointer">
                    Profile Settings
                  </DropdownMenuItem>
                </Link>
                
                <Link href="/security">
                  <DropdownMenuItem className="text-gray-300 hover:bg-gray-800 cursor-pointer">
                    Security Center
                  </DropdownMenuItem>
                </Link>
                
                <Link href="/admin">
                  <DropdownMenuItem className="text-gray-300 hover:bg-gray-800 cursor-pointer">
                    Admin Panel
                  </DropdownMenuItem>
                </Link>
                
                <DropdownMenuSeparator className="bg-gray-700" />
                <DropdownMenuItem className="text-gray-300 hover:bg-gray-800">
                  <div className="flex items-center justify-between w-full">
                    <span>Auto-Optimization</span>
                    <Badge className="bg-green-500 text-white text-xs">ON</Badge>
                  </div>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden">
        <div className="px-2 pt-2 pb-3 space-y-1">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.path} href={item.path}>
                <div
                  className={`block px-3 py-2 rounded-md text-base font-medium flex items-center space-x-2 cursor-pointer ${
                    isActive(item.path)
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </div>
              </Link>
            );
          })}
          
          <div className="border-t border-gray-700 pt-2 mt-2">
            <div className="text-gray-400 text-sm px-3 py-1">System Monitoring</div>
            {monitoringItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.path} href={item.path}>
                  <div className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:bg-gray-700 hover:text-white flex items-center justify-between cursor-pointer">
                    <div className="flex items-center space-x-2">
                      <Icon className="h-5 w-5" />
                      <span>{item.label}</span>
                    </div>
                    <div className={`w-2 h-2 rounded-full ${getStatusColor(item.status)}`} />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}