import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Activity, Database, Wifi, Zap, Shield, TrendingUp,
  CheckCircle, AlertCircle, XCircle, RefreshCw, Settings,
  Users, Server, Globe, Clock
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface SystemComponent {
  name: string;
  status: 'operational' | 'degraded' | 'offline';
  uptime: number;
  responseTime: number;
  lastCheck: Date;
  errorCount: number;
  autoHeal: boolean;
}

interface PerformanceBottleneck {
  component: string;
  type: 'cpu' | 'memory' | 'network' | 'database' | 'api';
  severity: 'low' | 'medium' | 'high' | 'critical';
  impact: number;
  description: string;
  solution: string;
}

export default function SystemHealthDashboard() {
  const [components, setComponents] = useState<SystemComponent[]>([
    { name: 'API Gateway', status: 'operational', uptime: 99.97, responseTime: 145, lastCheck: new Date(), errorCount: 2, autoHeal: true },
    { name: 'Database', status: 'operational', uptime: 99.99, responseTime: 89, lastCheck: new Date(), errorCount: 0, autoHeal: true },
    { name: 'Crypto Service', status: 'operational', uptime: 98.5, responseTime: 203, lastCheck: new Date(), errorCount: 5, autoHeal: true },
    { name: 'Sports Feed', status: 'degraded', uptime: 97.2, responseTime: 456, lastCheck: new Date(), errorCount: 12, autoHeal: false },
    { name: 'WebSocket', status: 'operational', uptime: 99.8, responseTime: 67, lastCheck: new Date(), errorCount: 1, autoHeal: true },
    { name: 'Notifications', status: 'operational', uptime: 99.1, responseTime: 234, lastCheck: new Date(), errorCount: 3, autoHeal: true },
  ]);

  const [bottlenecks, setBottlenecks] = useState<PerformanceBottleneck[]>([
    {
      component: 'Sports Feed API',
      type: 'api',
      severity: 'medium',
      impact: 15,
      description: 'External API rate limiting causing delays',
      solution: 'Implement request caching and fallback data'
    },
    {
      component: 'Database Queries',
      type: 'database',
      severity: 'low',
      impact: 5,
      description: 'Unoptimized queries on large datasets',
      solution: 'Add database indexing and query optimization'
    },
    {
      component: 'Crypto Price Updates',
      type: 'network',
      severity: 'low',
      impact: 8,
      description: 'Network latency to exchange APIs',
      solution: 'Use CDN and connection pooling'
    }
  ]);

  const [selfHealingEvents, setSelfHealingEvents] = useState([
    { timestamp: new Date(Date.now() - 300000), component: 'API Gateway', action: 'Restarted connection pool', success: true },
    { timestamp: new Date(Date.now() - 600000), component: 'Crypto Service', action: 'Switched to backup API', success: true },
    { timestamp: new Date(Date.now() - 900000), component: 'Database', action: 'Cleared connection timeout', success: true },
  ]);

  const [isAutoHealing, setIsAutoHealing] = useState(true);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setComponents(prev => prev.map(comp => ({
        ...comp,
        responseTime: Math.max(50, comp.responseTime + (Math.random() - 0.5) * 50),
        lastCheck: new Date(),
        errorCount: Math.max(0, comp.errorCount + (Math.random() < 0.1 ? 1 : 0))
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Self-healing simulation
  useEffect(() => {
    if (!isAutoHealing) return;

    const healingInterval = setInterval(() => {
      const degradedComponents = components.filter(c => c.status === 'degraded' || c.errorCount > 10);
      
      if (degradedComponents.length > 0 && Math.random() < 0.3) {
        const componentToHeal = degradedComponents[0];
        
        // Simulate healing action
        setComponents(prev => prev.map(comp => 
          comp.name === componentToHeal.name 
            ? { ...comp, status: 'operational', errorCount: 0, responseTime: Math.max(50, comp.responseTime * 0.7) }
            : comp
        ));

        // Add healing event
        setSelfHealingEvents(prev => [
          { 
            timestamp: new Date(), 
            component: componentToHeal.name, 
            action: 'Auto-recovered from errors', 
            success: true 
          },
          ...prev.slice(0, 9)
        ]);
      }
    }, 10000);

    return () => clearInterval(healingInterval);
  }, [isAutoHealing, components]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'operational': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'degraded': return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'offline': return <XCircle className="h-5 w-5 text-red-500" />;
      default: return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': return 'text-green-400';
      case 'degraded': return 'text-yellow-400';
      case 'offline': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const operationalCount = components.filter(c => c.status === 'operational').length;
  const overallHealth = Math.round((operationalCount / components.length) * 100);
  const avgResponseTime = Math.round(components.reduce((sum, c) => sum + c.responseTime, 0) / components.length);

  const performanceData = [
    { time: '10:00', responseTime: 120, throughput: 850 },
    { time: '10:05', responseTime: 145, throughput: 920 },
    { time: '10:10', responseTime: 167, throughput: 880 },
    { time: '10:15', responseTime: 134, throughput: 950 },
    { time: '10:20', responseTime: 156, throughput: 890 },
    { time: '10:25', responseTime: 143, throughput: 920 },
  ];

  const statusDistribution = [
    { name: 'Operational', value: operationalCount, color: '#10B981' },
    { name: 'Degraded', value: components.filter(c => c.status === 'degraded').length, color: '#F59E0B' },
    { name: 'Offline', value: components.filter(c => c.status === 'offline').length, color: '#EF4444' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">System Health Dashboard</h1>
            <p className="text-gray-300">Comprehensive system monitoring and self-healing management</p>
          </div>
          <div className="flex items-center space-x-4">
            <Badge className={overallHealth >= 95 ? 'bg-green-500' : overallHealth >= 80 ? 'bg-yellow-500' : 'bg-red-500'}>
              Overall Health: {overallHealth}%
            </Badge>
            <Button 
              onClick={() => setIsAutoHealing(!isAutoHealing)} 
              variant={isAutoHealing ? "default" : "outline"}
              className="flex items-center space-x-2"
            >
              <Settings className="h-4 w-4" />
              <span>{isAutoHealing ? 'Auto-Healing ON' : 'Auto-Healing OFF'}</span>
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">System Health</p>
                  <p className="text-2xl font-bold text-green-400">{overallHealth}%</p>
                </div>
                <Activity className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Avg Response</p>
                  <p className="text-2xl font-bold text-blue-400">{avgResponseTime}ms</p>
                </div>
                <Clock className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Active Users</p>
                  <p className="text-2xl font-bold text-purple-400">1,247</p>
                </div>
                <Users className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Self-Healing</p>
                  <p className="text-2xl font-bold text-yellow-400">{isAutoHealing ? 'Active' : 'Disabled'}</p>
                </div>
                <Zap className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="components" className="space-y-6">
          <TabsList className="grid grid-cols-4 w-full max-w-2xl">
            <TabsTrigger value="components">Components</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="bottlenecks">Bottlenecks</TabsTrigger>
            <TabsTrigger value="healing">Self-Healing</TabsTrigger>
          </TabsList>

          <TabsContent value="components" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2 bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">System Components</CardTitle>
                  <CardDescription className="text-gray-400">
                    Real-time status of all system components
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {components.map((component, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        {getStatusIcon(component.status)}
                        <div>
                          <h3 className="font-semibold text-white">{component.name}</h3>
                          <p className="text-sm text-gray-400">
                            Uptime: {component.uptime}% | Response: {component.responseTime}ms
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge className={getStatusColor(component.status)}>
                          {component.status}
                        </Badge>
                        {component.autoHeal && (
                          <Badge className="bg-green-500 text-white">Auto-Heal</Badge>
                        )}
                        {component.errorCount > 0 && (
                          <Badge className="bg-red-500 text-white">
                            {component.errorCount} errors
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Status Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={statusDistribution}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}`}
                      >
                        {statusDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <Card className="bg-black/40 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Performance Metrics</CardTitle>
                <CardDescription className="text-gray-400">
                  Real-time performance tracking and trends
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="time" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="responseTime" 
                      stroke="#3B82F6" 
                      strokeWidth={3}
                      name="Response Time (ms)"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="throughput" 
                      stroke="#10B981" 
                      strokeWidth={3}
                      name="Throughput (req/min)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bottlenecks" className="space-y-6">
            <Card className="bg-black/40 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Performance Bottlenecks</CardTitle>
                <CardDescription className="text-gray-400">
                  Identified performance issues and optimization recommendations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {bottlenecks.map((bottleneck, index) => (
                  <div key={index} className="p-4 bg-gray-800/50 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${getSeverityColor(bottleneck.severity)}`} />
                        <h3 className="font-semibold text-white">{bottleneck.component}</h3>
                        <Badge className="bg-blue-500 text-white">{bottleneck.type}</Badge>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-400">Impact: {bottleneck.impact}%</span>
                        <Badge className={getSeverityColor(bottleneck.severity)}>
                          {bottleneck.severity}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-gray-300 mb-2">{bottleneck.description}</p>
                    <p className="text-green-400 text-sm">
                      💡 Solution: {bottleneck.solution}
                    </p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="healing" className="space-y-6">
            <Card className="bg-black/40 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Zap className="h-5 w-5 mr-2" />
                  Self-Healing Events
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Automatic system recovery and healing actions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {selfHealingEvents.map((event, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <div>
                        <h3 className="font-semibold text-white">{event.component}</h3>
                        <p className="text-sm text-gray-400">{event.action}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="text-sm text-gray-400">
                        {event.timestamp.toLocaleTimeString()}
                      </span>
                      <Badge className="bg-green-500 text-white">Success</Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}