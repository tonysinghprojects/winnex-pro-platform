import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { CreditCard, DollarSign, Bitcoin, Zap, Shield, Clock, Globe } from "lucide-react";

interface PaymentMethod {
  id: string;
  type: 'card' | 'crypto' | 'bank' | 'ewallet' | 'mobile';
  name: string;
  icon: React.ReactNode;
  isDefault: boolean;
  isEnabled: boolean;
  fees: {
    deposit: number;
    withdrawal: number;
  };
  limits: {
    minDeposit: number;
    maxDeposit: number;
    minWithdrawal: number;
    maxWithdrawal: number;
  };
  processingTime: {
    deposit: string;
    withdrawal: string;
  };
  currencies: string[];
}

interface CryptoCurrency {
  symbol: string;
  name: string;
  icon: string;
  price: number;
  change24h: number;
  network: string;
  confirmations: number;
  address?: string;
  qrCode?: string;
}

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  method: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
  timestamp: string;
  txHash?: string;
  fee: number;
  exchangeRate?: number;
}

export default function AdvancedPaymentSystem() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [cryptoCurrencies, setCryptoCurrencies] = useState<CryptoCurrency[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [amount, setAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('');

  useEffect(() => {
    const mockPaymentMethods: PaymentMethod[] = [
      {
        id: 'visa',
        type: 'card',
        name: 'Visa/Mastercard',
        icon: <CreditCard className="w-6 h-6" />,
        isDefault: true,
        isEnabled: true,
        fees: { deposit: 2.5, withdrawal: 1.5 },
        limits: { minDeposit: 10, maxDeposit: 10000, minWithdrawal: 20, maxWithdrawal: 5000 },
        processingTime: { deposit: 'Instant', withdrawal: '1-3 business days' },
        currencies: ['USD', 'EUR', 'GBP', 'CAD', 'AUD']
      },
      {
        id: 'bitcoin',
        type: 'crypto',
        name: 'Bitcoin',
        icon: <Bitcoin className="w-6 h-6" />,
        isDefault: false,
        isEnabled: true,
        fees: { deposit: 0, withdrawal: 0.0005 },
        limits: { minDeposit: 0.001, maxDeposit: 10, minWithdrawal: 0.001, maxWithdrawal: 5 },
        processingTime: { deposit: '1-6 confirmations', withdrawal: '30-60 minutes' },
        currencies: ['BTC']
      },
      {
        id: 'ethereum',
        type: 'crypto',
        name: 'Ethereum',
        icon: <Globe className="w-6 h-6" />,
        isDefault: false,
        isEnabled: true,
        fees: { deposit: 0, withdrawal: 0.01 },
        limits: { minDeposit: 0.01, maxDeposit: 100, minWithdrawal: 0.01, maxWithdrawal: 50 },
        processingTime: { deposit: '12-35 confirmations', withdrawal: '15-30 minutes' },
        currencies: ['ETH']
      },
      {
        id: 'paypal',
        type: 'ewallet',
        name: 'PayPal',
        icon: <DollarSign className="w-6 h-6" />,
        isDefault: false,
        isEnabled: true,
        fees: { deposit: 3.5, withdrawal: 2.0 },
        limits: { minDeposit: 5, maxDeposit: 5000, minWithdrawal: 10, maxWithdrawal: 2500 },
        processingTime: { deposit: 'Instant', withdrawal: '1-2 business days' },
        currencies: ['USD', 'EUR', 'GBP']
      }
    ];

    const mockCryptoCurrencies: CryptoCurrency[] = [
      {
        symbol: 'BTC',
        name: 'Bitcoin',
        icon: '₿',
        price: 43250.50,
        change24h: 2.34,
        network: 'Bitcoin',
        confirmations: 3,
        address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'
      },
      {
        symbol: 'ETH',
        name: 'Ethereum',
        icon: 'Ξ',
        price: 2650.75,
        change24h: -1.25,
        network: 'Ethereum',
        confirmations: 12,
        address: '0x742d35Cc6634C0532925a3b8D0C4E8D8z1c8B9A'
      },
      {
        symbol: 'USDT',
        name: 'Tether',
        icon: '₮',
        price: 1.00,
        change24h: 0.01,
        network: 'Ethereum',
        confirmations: 12,
        address: '0x742d35Cc6634C0532925a3b8D0C4E8D8z1c8B9A'
      }
    ];

    const mockTransactions: Transaction[] = [
      {
        id: 'tx_001',
        type: 'deposit',
        method: 'Bitcoin',
        amount: 500,
        currency: 'USD',
        status: 'completed',
        timestamp: '2024-01-15 14:30:25',
        txHash: '7d8a9b2c1e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t8u9v0w1x2y3z',
        fee: 0,
        exchangeRate: 43250.50
      },
      {
        id: 'tx_002',
        type: 'withdrawal',
        method: 'Visa',
        amount: 250,
        currency: 'USD',
        status: 'processing',
        timestamp: '2024-01-15 16:45:12',
        fee: 3.75
      },
      {
        id: 'tx_003',
        type: 'deposit',
        method: 'Ethereum',
        amount: 1000,
        currency: 'USD',
        status: 'pending',
        timestamp: '2024-01-15 18:20:08',
        txHash: '0x9f8e7d6c5b4a39281726354859603948576839201847362819',
        fee: 0,
        exchangeRate: 2650.75
      }
    ];

    setPaymentMethods(mockPaymentMethods);
    setCryptoCurrencies(mockCryptoCurrencies);
    setTransactions(mockTransactions);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500/20 text-green-400';
      case 'processing': return 'bg-yellow-500/20 text-yellow-400';
      case 'pending': return 'bg-blue-500/20 text-blue-400';
      case 'failed': return 'bg-red-500/20 text-red-400';
      case 'cancelled': return 'bg-gray-500/20 text-gray-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const currencies = [
    { code: 'USD', name: 'US Dollar', symbol: '$' },
    { code: 'EUR', name: 'Euro', symbol: '€' },
    { code: 'GBP', name: 'British Pound', symbol: '£' },
    { code: 'BTC', name: 'Bitcoin', symbol: '₿' },
    { code: 'ETH', name: 'Ethereum', symbol: 'Ξ' },
    { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
    { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' }
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <DollarSign className="w-12 h-12 text-emerald-400 mr-3" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            Advanced Payment Center
          </h1>
        </div>
        <p className="text-gray-400 text-lg">Secure, fast, and flexible payment solutions</p>
      </div>

      <Tabs defaultValue="deposit" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="deposit" className="flex items-center">
            <Zap className="w-4 h-4 mr-2" />
            Deposit
          </TabsTrigger>
          <TabsTrigger value="withdraw" className="flex items-center">
            <Clock className="w-4 h-4 mr-2" />
            Withdraw
          </TabsTrigger>
          <TabsTrigger value="crypto" className="flex items-center">
            <Bitcoin className="w-4 h-4 mr-2" />
            Crypto
          </TabsTrigger>
          <TabsTrigger value="transactions" className="flex items-center">
            <Shield className="w-4 h-4 mr-2" />
            Transactions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="deposit" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Zap className="w-6 h-6 mr-2 text-emerald-400" />
                Instant Deposit
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Amount</label>
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Currency</label>
                  <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
                    <SelectTrigger className="bg-gray-800 border-gray-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.symbol} {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4">
                <h3 className="text-lg font-semibold text-white">Select Payment Method</h3>
                {paymentMethods.map((method) => (
                  <Card 
                    key={method.id} 
                    className={`cursor-pointer transition-all ${
                      selectedMethod === method.id 
                        ? 'border-emerald-400 bg-emerald-500/10' 
                        : 'casino-card hover:border-emerald-400/50'
                    }`}
                    onClick={() => setSelectedMethod(method.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4">
                          <div className="text-emerald-400">{method.icon}</div>
                          <div>
                            <div className="font-semibold text-white">{method.name}</div>
                            <div className="text-sm text-gray-400">
                              Fee: {method.fees.deposit}% • Processing: {method.processingTime.deposit}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-gray-400">Limits</div>
                          <div className="text-white font-semibold">
                            ${method.limits.minDeposit} - ${method.limits.maxDeposit}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {selectedMethod && amount && (
                <Card className="border-emerald-400/20 bg-emerald-500/5">
                  <CardContent className="p-4">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-sm text-gray-400">You Pay</div>
                        <div className="text-xl font-bold text-white">{amount} {selectedCurrency}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-400">Fee</div>
                        <div className="text-lg font-semibold text-orange-400">
                          {(parseFloat(amount) * 0.025).toFixed(2)} {selectedCurrency}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-400">You Receive</div>
                        <div className="text-xl font-bold text-emerald-400">
                          {(parseFloat(amount) - parseFloat(amount) * 0.025).toFixed(2)} {selectedCurrency}
                        </div>
                      </div>
                    </div>
                    <Button className="w-full mt-4 bg-emerald-500 hover:bg-emerald-600">
                      Continue to Payment
                    </Button>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="withdraw" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Clock className="w-6 h-6 mr-2 text-blue-400" />
                Withdrawal Request
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <div className="text-blue-400 font-semibold mb-2">Available Balance</div>
                <div className="text-3xl font-bold text-white">$2,847.50</div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Withdrawal Amount</label>
                  <Input
                    type="number"
                    placeholder="0.00"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Currency</label>
                  <Select defaultValue="USD">
                    <SelectTrigger className="bg-gray-800 border-gray-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.symbol} {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Withdrawal Methods</h3>
                {paymentMethods.filter(m => m.type !== 'crypto').map((method) => (
                  <Card key={method.id} className="casino-card cursor-pointer hover:border-blue-400/50">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4">
                          <div className="text-blue-400">{method.icon}</div>
                          <div>
                            <div className="font-semibold text-white">{method.name}</div>
                            <div className="text-sm text-gray-400">
                              Fee: {method.fees.withdrawal}% • Processing: {method.processingTime.withdrawal}
                            </div>
                          </div>
                        </div>
                        <Badge variant="outline">
                          {method.processingTime.withdrawal}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="crypto" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-3">
            {cryptoCurrencies.map((crypto) => (
              <Card key={crypto.symbol} className="casino-card">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-3">
                      <div className="text-2xl">{crypto.icon}</div>
                      <div>
                        <CardTitle className="text-white">{crypto.name}</CardTitle>
                        <div className="text-sm text-gray-400">{crypto.symbol}</div>
                      </div>
                    </div>
                    <Badge variant={crypto.change24h > 0 ? 'default' : 'destructive'}>
                      {crypto.change24h > 0 ? '+' : ''}{crypto.change24h}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="text-2xl font-bold text-emerald-400">
                      ${crypto.price.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-400">Current Price</div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm text-gray-400">Network: {crypto.network}</div>
                    <div className="text-sm text-gray-400">Confirmations: {crypto.confirmations}</div>
                  </div>

                  {crypto.address && (
                    <div className="p-3 bg-gray-800 rounded border">
                      <div className="text-xs text-gray-400 mb-1">Deposit Address:</div>
                      <div className="text-xs text-white font-mono break-all">{crypto.address}</div>
                    </div>
                  )}

                  <div className="flex space-x-2">
                    <Button className="flex-1 bg-emerald-500 hover:bg-emerald-600">
                      Deposit {crypto.symbol}
                    </Button>
                    <Button variant="outline" className="flex-1">
                      Withdraw
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Transaction History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {transactions.map((tx) => (
                  <Card key={tx.id} className="border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <Badge variant={tx.type === 'deposit' ? 'default' : 'secondary'}>
                              {tx.type.toUpperCase()}
                            </Badge>
                            <span className="font-semibold text-white">{tx.method}</span>
                            <Badge className={getStatusColor(tx.status)}>
                              {tx.status.toUpperCase()}
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-400 space-y-1">
                            <div>Amount: {tx.amount} {tx.currency}</div>
                            <div>Fee: {tx.fee} {tx.currency}</div>
                            <div>Date: {tx.timestamp}</div>
                            {tx.txHash && (
                              <div className="font-mono text-xs">Hash: {tx.txHash.substring(0, 20)}...</div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`text-2xl font-bold ${
                            tx.type === 'deposit' ? 'text-emerald-400' : 'text-red-400'
                          }`}>
                            {tx.type === 'deposit' ? '+' : '-'}{tx.amount} {tx.currency}
                          </div>
                          {tx.status === 'processing' && (
                            <Progress value={65} className="w-20 h-2 mt-2" />
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}