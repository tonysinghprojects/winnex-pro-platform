import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { 
  Trophy, Users, TrendingUp, MessageCircle, Heart, Share2, 
  Crown, Medal, Award, Flame, Star, Target, Zap 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface LeaderboardUser {
  id: string;
  username: string;
  avatar: string;
  rank: number;
  profit: number;
  roi: number;
  winRate: number;
  totalBets: number;
  streak: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
  badges: string[];
  followers: number;
  following: boolean;
}

interface BettingTip {
  id: string;
  author: {
    id: string;
    username: string;
    avatar: string;
    tier: string;
    verified: boolean;
  };
  content: string;
  prediction: {
    match: string;
    selection: string;
    odds: number;
    confidence: number;
    reasoning: string[];
  };
  engagement: {
    likes: number;
    comments: number;
    shares: number;
    follows: number;
  };
  timestamp: string;
  liked: boolean;
  performance: {
    accuracy: number;
    profit: number;
    followers: number;
  };
}

interface Challenge {
  id: string;
  title: string;
  description: string;
  prize: number;
  participants: number;
  maxParticipants: number;
  duration: string;
  type: 'weekly' | 'monthly' | 'tournament';
  requirements: string[];
  leaderboard: LeaderboardUser[];
  joined: boolean;
  status: 'active' | 'upcoming' | 'completed';
}

export default function SocialBettingCommunity() {
  const [activeTab, setActiveTab] = useState('feed');
  const [newTipContent, setNewTipContent] = useState('');
  const [selectedChallenge, setSelectedChallenge] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock leaderboard data
  const leaderboard: LeaderboardUser[] = [
    {
      id: '1',
      username: 'BettingKing',
      avatar: '/avatars/user1.jpg',
      rank: 1,
      profit: 15420,
      roi: 34.2,
      winRate: 68.5,
      totalBets: 247,
      streak: 12,
      tier: 'diamond',
      badges: ['🔥', '🎯', '👑'],
      followers: 2847,
      following: false
    },
    {
      id: '2',
      username: 'SportsProphet',
      avatar: '/avatars/user2.jpg',
      rank: 2,
      profit: 12350,
      roi: 28.7,
      winRate: 64.2,
      totalBets: 189,
      streak: 8,
      tier: 'platinum',
      badges: ['⚡', '🎯', '📈'],
      followers: 1923,
      following: true
    },
    {
      id: '3',
      username: 'OddsWizard',
      avatar: '/avatars/user3.jpg',
      rank: 3,
      profit: 9875,
      roi: 22.1,
      winRate: 61.8,
      totalBets: 156,
      streak: 5,
      tier: 'gold',
      badges: ['🧙‍♂️', '📊', '💫'],
      followers: 1456,
      following: false
    }
  ];

  // Mock betting tips feed
  const bettingTips: BettingTip[] = [
    {
      id: '1',
      author: {
        id: '1',
        username: 'BettingKing',
        avatar: '/avatars/user1.jpg',
        tier: 'diamond',
        verified: true
      },
      content: "Strong value play incoming! Liverpool's defensive injuries create a perfect storm for goals.",
      prediction: {
        match: 'Liverpool vs Arsenal',
        selection: 'Over 2.5 Goals',
        odds: 1.85,
        confidence: 92,
        reasoning: [
          'Liverpool missing 3 key defenders',
          'Arsenal scored 2+ in last 6 away games',
          'Both teams need the points'
        ]
      },
      engagement: {
        likes: 127,
        comments: 23,
        shares: 45,
        follows: 12
      },
      timestamp: '2024-06-14T16:30:00Z',
      liked: false,
      performance: {
        accuracy: 78.5,
        profit: 2450,
        followers: 2847
      }
    },
    {
      id: '2',
      author: {
        id: '2',
        username: 'SportsProphet',
        avatar: '/avatars/user2.jpg',
        tier: 'platinum',
        verified: true
      },
      content: "AI model showing 89% confidence on this NBA total. The pace metrics are screaming over!",
      prediction: {
        match: 'Lakers vs Celtics',
        selection: 'Over 218.5 Points',
        odds: 1.92,
        confidence: 89,
        reasoning: [
          'Both teams top 5 in pace',
          'Defensive injuries on both sides',
          'Recent H2H averaging 225+ points'
        ]
      },
      engagement: {
        likes: 89,
        comments: 16,
        shares: 28,
        follows: 8
      },
      timestamp: '2024-06-14T15:45:00Z',
      liked: true,
      performance: {
        accuracy: 82.1,
        profit: 1923,
        followers: 1923
      }
    }
  ];

  // Mock challenges
  const challenges: Challenge[] = [
    {
      id: '1',
      title: 'Weekly Profit Challenge',
      description: 'Highest profit wins $500 + VIP status',
      prize: 500,
      participants: 1247,
      maxParticipants: 2000,
      duration: '4 days left',
      type: 'weekly',
      requirements: ['Min 10 bets', 'Min $5 stake'],
      leaderboard: leaderboard.slice(0, 5),
      joined: true,
      status: 'active'
    },
    {
      id: '2',
      title: 'NBA Prediction Tournament',
      description: 'Predict NBA game outcomes for big prizes',
      prize: 1000,
      participants: 845,
      maxParticipants: 1000,
      duration: '2 weeks left',
      type: 'tournament',
      requirements: ['NBA games only', 'Min 3 predictions/week'],
      leaderboard: leaderboard.slice(0, 3),
      joined: false,
      status: 'active'
    }
  ];

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'diamond': return 'text-cyan-400';
      case 'platinum': return 'text-gray-300';
      case 'gold': return 'text-yellow-400';
      case 'silver': return 'text-gray-400';
      case 'bronze': return 'text-orange-400';
      default: return 'text-gray-500';
    }
  };

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'diamond': return <Crown className="w-4 h-4" />;
      case 'platinum': return <Medal className="w-4 h-4" />;
      case 'gold': return <Trophy className="w-4 h-4" />;
      case 'silver': return <Award className="w-4 h-4" />;
      case 'bronze': return <Target className="w-4 h-4" />;
      default: return <Star className="w-4 h-4" />;
    }
  };

  // Follow/unfollow user mutation
  const followMutation = useMutation({
    mutationFn: async (userId: string) => {
      return apiRequest('POST', `/api/users/${userId}/follow`);
    },
    onSuccess: () => {
      toast({
        title: "Following User",
        description: "You'll now see their tips in your feed",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/social/feed'] });
    }
  });

  // Like tip mutation
  const likeMutation = useMutation({
    mutationFn: async (tipId: string) => {
      return apiRequest('POST', `/api/tips/${tipId}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/social/feed'] });
    }
  });

  // Join challenge mutation
  const joinChallengeMutation = useMutation({
    mutationFn: async (challengeId: string) => {
      return apiRequest('POST', `/api/challenges/${challengeId}/join`);
    },
    onSuccess: () => {
      toast({
        title: "Challenge Joined!",
        description: "Good luck in the competition!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/challenges'] });
    }
  });

  return (
    <div className="space-y-6">
      {/* Community Header */}
      <Card className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border-blue-500/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Users className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <CardTitle className="text-xl">Betting Community</CardTitle>
                <p className="text-sm text-gray-400">Connect • Compete • Win Together</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-center">
              <div>
                <div className="text-lg font-bold text-winnex-green">12.4K</div>
                <div className="text-xs text-gray-400">Active Bettors</div>
              </div>
              <div>
                <div className="text-lg font-bold text-blue-400">$2.1M</div>
                <div className="text-xs text-gray-400">Community Profit</div>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 bg-winnex-dark">
          <TabsTrigger value="feed">Live Feed</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
          <TabsTrigger value="challenges">Challenges</TabsTrigger>
          <TabsTrigger value="tipsters">Top Tipsters</TabsTrigger>
        </TabsList>

        <TabsContent value="feed" className="space-y-4">
          {/* Post New Tip */}
          <Card className="bg-winnex-gray border-gray-600">
            <CardHeader>
              <CardTitle className="text-lg">Share Your Prediction</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Share your betting insight with the community..."
                value={newTipContent}
                onChange={(e) => setNewTipContent(e.target.value)}
                className="bg-winnex-dark border-gray-600 min-h-[100px]"
              />
              <div className="flex justify-between items-center">
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" className="border-gray-600">
                    Add Match
                  </Button>
                  <Button size="sm" variant="outline" className="border-gray-600">
                    Add Odds
                  </Button>
                </div>
                <Button className="bg-winnex-blue text-white hover:bg-blue-400">
                  Post Tip
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Tips Feed */}
          <div className="space-y-4">
            {bettingTips.map((tip) => (
              <Card key={tip.id} className="bg-winnex-gray border-gray-600">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={tip.author.avatar} />
                        <AvatarFallback>{tip.author.username[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-medium">{tip.author.username}</span>
                          {tip.author.verified && (
                            <Badge className={`${getTierColor(tip.author.tier)} border-current`}>
                              {getTierIcon(tip.author.tier)}
                              {tip.author.tier.toUpperCase()}
                            </Badge>
                          )}
                        </div>
                        <div className="text-xs text-gray-400">
                          {new Date(tip.timestamp).toLocaleDateString()} • 
                          {tip.performance.accuracy}% accuracy • 
                          ${tip.performance.profit}+ profit
                        </div>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant={tip.author.id === '2' ? 'default' : 'outline'}
                      className={tip.author.id === '2' ? 'bg-winnex-blue text-white' : 'border-gray-600'}
                      onClick={() => followMutation.mutate(tip.author.id)}
                    >
                      {tip.author.id === '2' ? 'Following' : 'Follow'}
                    </Button>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <p className="text-gray-200">{tip.content}</p>

                  {/* Prediction Card */}
                  <Card className="bg-gradient-to-r from-winnex-green/10 to-winnex-blue/10 border-winnex-green/30">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">{tip.prediction.match}</h4>
                        <Badge className="bg-winnex-green text-black">
                          {tip.prediction.confidence}% Confidence
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mb-3">
                        <div>
                          <div className="text-sm text-gray-400">Selection</div>
                          <div className="font-medium text-winnex-green">{tip.prediction.selection}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400">Odds</div>
                          <div className="font-medium">{tip.prediction.odds}</div>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="text-sm font-medium">Reasoning:</div>
                        {tip.prediction.reasoning.map((reason, idx) => (
                          <div key={idx} className="text-sm text-gray-300 flex items-start">
                            <span className="text-winnex-green mr-2">•</span>
                            {reason}
                          </div>
                        ))}
                      </div>

                      <Button className="w-full mt-3 bg-winnex-green text-black hover:bg-green-400">
                        Copy to Bet Slip
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Engagement */}
                  <div className="flex items-center justify-between pt-3 border-t border-gray-600">
                    <div className="flex space-x-4">
                      <Button
                        size="sm"
                        variant="ghost"
                        className={`flex items-center space-x-1 ${tip.liked ? 'text-red-400' : 'text-gray-400'}`}
                        onClick={() => likeMutation.mutate(tip.id)}
                      >
                        <Heart className={`w-4 h-4 ${tip.liked ? 'fill-current' : ''}`} />
                        <span>{tip.engagement.likes}</span>
                      </Button>
                      <Button size="sm" variant="ghost" className="flex items-center space-x-1 text-gray-400">
                        <MessageCircle className="w-4 h-4" />
                        <span>{tip.engagement.comments}</span>
                      </Button>
                      <Button size="sm" variant="ghost" className="flex items-center space-x-1 text-gray-400">
                        <Share2 className="w-4 h-4" />
                        <span>{tip.engagement.shares}</span>
                      </Button>
                    </div>
                    <div className="text-xs text-gray-400">
                      {tip.engagement.follows} people followed this tip
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="leaderboard" className="space-y-4">
          <div className="grid gap-4">
            {leaderboard.map((user, index) => (
              <Card key={user.id} className={`bg-winnex-gray border-gray-600 ${index < 3 ? 'border-l-4' : ''} ${
                index === 0 ? 'border-l-yellow-400' : 
                index === 1 ? 'border-l-gray-300' : 
                index === 2 ? 'border-l-orange-400' : ''
              }`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-center">
                        <div className={`text-2xl font-bold ${getTierColor(user.tier)}`}>
                          #{user.rank}
                        </div>
                        {index < 3 && (
                          <div className="flex justify-center mt-1">
                            {index === 0 && <Crown className="w-5 h-5 text-yellow-400" />}
                            {index === 1 && <Medal className="w-5 h-5 text-gray-300" />}
                            {index === 2 && <Trophy className="w-5 h-5 text-orange-400" />}
                          </div>
                        )}
                      </div>

                      <Avatar className="h-12 w-12">
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback>{user.username[0]}</AvatarFallback>
                      </Avatar>

                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-medium">{user.username}</span>
                          <Badge className={`${getTierColor(user.tier)} border-current`}>
                            {getTierIcon(user.tier)}
                            {user.tier.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-1 mt-1">
                          {user.badges.map((badge, idx) => (
                            <span key={idx} className="text-sm">{badge}</span>
                          ))}
                        </div>
                        <div className="text-sm text-gray-400">
                          {user.followers.toLocaleString()} followers
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-6 text-center">
                      <div>
                        <div className="text-lg font-bold text-winnex-green">
                          ${user.profit.toLocaleString()}
                        </div>
                        <div className="text-xs text-gray-400">Profit</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-blue-400">
                          {user.roi}%
                        </div>
                        <div className="text-xs text-gray-400">ROI</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-yellow-400">
                          {user.winRate}%
                        </div>
                        <div className="text-xs text-gray-400">Win Rate</div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="flex items-center space-x-1 mb-2">
                        <Flame className="w-4 h-4 text-orange-400" />
                        <span className="text-sm font-medium">{user.streak} streak</span>
                      </div>
                      <Button
                        size="sm"
                        variant={user.following ? 'default' : 'outline'}
                        className={user.following ? 'bg-winnex-blue text-white' : 'border-gray-600'}
                        onClick={() => followMutation.mutate(user.id)}
                      >
                        {user.following ? 'Following' : 'Follow'}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="challenges" className="space-y-4">
          <div className="grid gap-4">
            {challenges.map((challenge) => (
              <Card key={challenge.id} className="bg-winnex-gray border-gray-600">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{challenge.title}</CardTitle>
                      <p className="text-sm text-gray-400">{challenge.description}</p>
                    </div>
                    <Badge className={`${
                      challenge.status === 'active' ? 'bg-green-500' : 
                      challenge.status === 'upcoming' ? 'bg-blue-500' : 'bg-gray-500'
                    } text-white`}>
                      {challenge.status.toUpperCase()}
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-xl font-bold text-winnex-green">${challenge.prize}</div>
                      <div className="text-xs text-gray-400">Prize Pool</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-bold text-blue-400">{challenge.participants}</div>
                      <div className="text-xs text-gray-400">Participants</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-bold text-yellow-400">{challenge.duration}</div>
                      <div className="text-xs text-gray-400">Time Left</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Requirements:</h4>
                    {challenge.requirements.map((req, idx) => (
                      <div key={idx} className="text-sm text-gray-300 flex items-start">
                        <span className="text-winnex-blue mr-2">•</span>
                        {req}
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Current Leaders:</h4>
                    {challenge.leaderboard.slice(0, 3).map((user, idx) => (
                      <div key={user.id} className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          <span className="text-gray-400">#{idx + 1}</span>
                          <span>{user.username}</span>
                        </div>
                        <span className="text-winnex-green">${user.profit.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>

                  <Button
                    onClick={() => joinChallengeMutation.mutate(challenge.id)}
                    disabled={challenge.joined || joinChallengeMutation.isPending}
                    className={`w-full ${
                      challenge.joined 
                        ? 'bg-gray-600 text-gray-400' 
                        : 'bg-winnex-green text-black hover:bg-green-400'
                    }`}
                  >
                    {challenge.joined ? 'Already Joined' : 'Join Challenge'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tipsters" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            {leaderboard.slice(0, 6).map((tipster) => (
              <Card key={tipster.id} className="bg-winnex-gray border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 mb-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={tipster.avatar} />
                      <AvatarFallback>{tipster.username[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{tipster.username}</span>
                        <Badge className={`${getTierColor(tipster.tier)} border-current`}>
                          {getTierIcon(tipster.tier)}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-400">
                        {tipster.followers.toLocaleString()} followers
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant={tipster.following ? 'default' : 'outline'}
                      className={tipster.following ? 'bg-winnex-blue text-white' : 'border-gray-600'}
                      onClick={() => followMutation.mutate(tipster.id)}
                    >
                      {tipster.following ? 'Following' : 'Follow'}
                    </Button>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-center text-sm">
                    <div>
                      <div className="font-bold text-winnex-green">{tipster.winRate}%</div>
                      <div className="text-gray-400">Win Rate</div>
                    </div>
                    <div>
                      <div className="font-bold text-blue-400">{tipster.roi}%</div>
                      <div className="text-gray-400">ROI</div>
                    </div>
                    <div>
                      <div className="font-bold text-yellow-400">{tipster.totalBets}</div>
                      <div className="text-gray-400">Bets</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center space-x-1 mt-3">
                    {tipster.badges.map((badge, idx) => (
                      <span key={idx} className="text-lg">{badge}</span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}