import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Shield, 
  FileText, 
  Upload, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  User, 
  CreditCard,
  MapPin,
  Flag
} from "lucide-react";

interface KYCStatus {
  tier: 'tier0' | 'tier1' | 'tier2' | 'tier3';
  completionPercentage: number;
  status: 'pending' | 'verified' | 'rejected' | 'requires_action';
  lastUpdated: string;
  nextReviewDate?: string;
  documents: DocumentStatus[];
  limits: AccountLimits;
}

interface DocumentStatus {
  type: 'identity' | 'address' | 'financial' | 'source_of_funds';
  name: string;
  status: 'not_uploaded' | 'uploaded' | 'verified' | 'rejected';
  uploadDate?: string;
  expiryDate?: string;
  rejectionReason?: string;
  required: boolean;
}

interface AccountLimits {
  dailyDeposit: number;
  monthlyDeposit: number;
  dailyWithdrawal: number;
  monthlyWithdrawal: number;
  maxBetAmount: number;
  withdrawalRequiresApproval: boolean;
}

interface ComplianceAlert {
  id: string;
  type: 'aml' | 'kyc' | 'regulatory' | 'suspicious_activity';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  timestamp: string;
  status: 'open' | 'acknowledged' | 'resolved';
  actionRequired: boolean;
}

interface TaxReporting {
  year: number;
  totalDeposits: number;
  totalWithdrawals: number;
  netGamingRevenue: number;
  taxableWinnings: number;
  withheldTax: number;
  reportStatus: 'pending' | 'generated' | 'submitted';
  reportId?: string;
}

export default function ComplianceCenter() {
  const [kycStatus, setKycStatus] = useState<KYCStatus | null>(null);
  const [complianceAlerts, setComplianceAlerts] = useState<ComplianceAlert[]>([]);
  const [taxReports, setTaxReports] = useState<TaxReporting[]>([]);
  const [uploadingDoc, setUploadingDoc] = useState<string | null>(null);
  const [selectedCountry, setSelectedCountry] = useState('US');

  useEffect(() => {
    const mockKYCStatus: KYCStatus = {
      tier: 'tier1',
      completionPercentage: 65,
      status: 'requires_action',
      lastUpdated: '2024-01-15',
      nextReviewDate: '2024-02-15',
      documents: [
        {
          type: 'identity',
          name: 'Government ID',
          status: 'verified',
          uploadDate: '2024-01-10',
          expiryDate: '2027-03-15',
          required: true
        },
        {
          type: 'address',
          name: 'Proof of Address',
          status: 'rejected',
          uploadDate: '2024-01-12',
          rejectionReason: 'Document older than 3 months',
          required: true
        },
        {
          type: 'financial',
          name: 'Bank Statement',
          status: 'not_uploaded',
          required: false
        },
        {
          type: 'source_of_funds',
          name: 'Source of Wealth',
          status: 'not_uploaded',
          required: false
        }
      ],
      limits: {
        dailyDeposit: 2500,
        monthlyDeposit: 10000,
        dailyWithdrawal: 1000,
        monthlyWithdrawal: 5000,
        maxBetAmount: 500,
        withdrawalRequiresApproval: true
      }
    };

    const mockAlerts: ComplianceAlert[] = [
      {
        id: 'alert_1',
        type: 'kyc',
        severity: 'medium',
        title: 'Address Verification Required',
        description: 'Your proof of address document was rejected. Please upload a recent utility bill or bank statement.',
        timestamp: '2024-01-15 10:30',
        status: 'open',
        actionRequired: true
      },
      {
        id: 'alert_2',
        type: 'aml',
        severity: 'low',
        title: 'Transaction Pattern Review',
        description: 'Routine review of recent transaction patterns. No action required.',
        timestamp: '2024-01-14 15:45',
        status: 'acknowledged',
        actionRequired: false
      },
      {
        id: 'alert_3',
        type: 'regulatory',
        severity: 'high',
        title: 'Enhanced Due Diligence',
        description: 'Additional verification required due to transaction volume. Please provide source of funds documentation.',
        timestamp: '2024-01-13 09:15',
        status: 'open',
        actionRequired: true
      }
    ];

    const mockTaxReports: TaxReporting[] = [
      {
        year: 2024,
        totalDeposits: 15000,
        totalWithdrawals: 12500,
        netGamingRevenue: -2500,
        taxableWinnings: 3200,
        withheldTax: 640,
        reportStatus: 'pending'
      },
      {
        year: 2023,
        totalDeposits: 22000,
        totalWithdrawals: 18500,
        netGamingRevenue: -3500,
        taxableWinnings: 5100,
        withheldTax: 1020,
        reportStatus: 'submitted',
        reportId: 'TAX-2023-001'
      }
    ];

    setKycStatus(mockKYCStatus);
    setComplianceAlerts(mockAlerts);
    setTaxReports(mockTaxReports);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified': case 'resolved': case 'submitted': return 'text-green-400';
      case 'pending': case 'uploaded': case 'acknowledged': return 'text-yellow-400';
      case 'rejected': case 'open': return 'text-red-400';
      case 'requires_action': return 'text-orange-400';
      default: return 'text-gray-400';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'border-red-500 bg-red-500/10';
      case 'high': return 'border-orange-500 bg-orange-500/10';
      case 'medium': return 'border-yellow-500 bg-yellow-500/10';
      case 'low': return 'border-blue-500 bg-blue-500/10';
      default: return 'border-gray-500 bg-gray-500/10';
    }
  };

  const getTierName = (tier: string) => {
    switch (tier) {
      case 'tier0': return 'Basic';
      case 'tier1': return 'Verified';
      case 'tier2': return 'Enhanced';
      case 'tier3': return 'Premium';
      default: return 'Unknown';
    }
  };

  const handleDocumentUpload = (docType: string) => {
    setUploadingDoc(docType);
    // Simulate upload process
    setTimeout(() => {
      setUploadingDoc(null);
    }, 2000);
  };

  if (!kycStatus) return null;

  return (
    <div className="p-6 space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <Shield className="w-12 h-12 text-emerald-400 mr-3" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            Compliance Center
          </h1>
        </div>
        <p className="text-gray-400 text-lg">Manage your verification status and regulatory compliance</p>
      </div>

      {/* KYC Status Overview */}
      <Card className="casino-card border-emerald-400/20">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-white text-2xl">
                {getTierName(kycStatus.tier)} Account Status
              </CardTitle>
              <p className="text-gray-400 mt-1">
                Verification Level: {kycStatus.completionPercentage}% Complete
              </p>
            </div>
            <Badge className={getStatusColor(kycStatus.status)}>
              {kycStatus.status.replace('_', ' ').toUpperCase()}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">Verification Progress</span>
              <span className="text-white">{kycStatus.completionPercentage}%</span>
            </div>
            <Progress value={kycStatus.completionPercentage} className="h-3" />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-xl font-bold text-emerald-400">
                ${kycStatus.limits.dailyDeposit.toLocaleString()}
              </div>
              <div className="text-sm text-gray-400">Daily Deposit Limit</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-blue-400">
                ${kycStatus.limits.dailyWithdrawal.toLocaleString()}
              </div>
              <div className="text-sm text-gray-400">Daily Withdrawal Limit</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-purple-400">
                ${kycStatus.limits.maxBetAmount.toLocaleString()}
              </div>
              <div className="text-sm text-gray-400">Max Bet Amount</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-orange-400">
                {kycStatus.limits.withdrawalRequiresApproval ? 'YES' : 'NO'}
              </div>
              <div className="text-sm text-gray-400">Manual Approval</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Alerts */}
      {complianceAlerts.filter(alert => alert.status === 'open').length > 0 && (
        <Card className="casino-card border-red-400/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-red-400" />
              Action Required
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {complianceAlerts.filter(alert => alert.status === 'open').map((alert) => (
              <div key={alert.id} className={`p-4 rounded-lg border ${getSeverityColor(alert.severity)}`}>
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-white">{alert.title}</h4>
                  <Badge variant="outline" className="text-xs">
                    {alert.severity.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-sm text-gray-300 mb-3">{alert.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-400">{alert.timestamp}</span>
                  {alert.actionRequired && (
                    <Button size="sm" className="bg-red-500 hover:bg-red-600">
                      Take Action
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="documents" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="documents" className="flex items-center">
            <FileText className="w-4 h-4 mr-2" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="limits" className="flex items-center">
            <CreditCard className="w-4 h-4 mr-2" />
            Limits
          </TabsTrigger>
          <TabsTrigger value="tax" className="flex items-center">
            <Flag className="w-4 h-4 mr-2" />
            Tax Reports
          </TabsTrigger>
          <TabsTrigger value="alerts" className="flex items-center">
            <AlertTriangle className="w-4 h-4 mr-2" />
            All Alerts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="documents" className="space-y-6">
          <div className="grid gap-6">
            {kycStatus.documents.map((doc, index) => (
              <Card key={index} className="casino-card">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="text-emerald-400">
                        {doc.type === 'identity' && <User className="w-5 h-5" />}
                        {doc.type === 'address' && <MapPin className="w-5 h-5" />}
                        {doc.type === 'financial' && <CreditCard className="w-5 h-5" />}
                        {doc.type === 'source_of_funds' && <FileText className="w-5 h-5" />}
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{doc.name}</h3>
                        <p className="text-sm text-gray-400 capitalize">
                          {doc.type.replace('_', ' ')} Document
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {doc.required && (
                        <Badge variant="destructive" className="text-xs">
                          REQUIRED
                        </Badge>
                      )}
                      <Badge className={getStatusColor(doc.status)}>
                        {doc.status.replace('_', ' ').toUpperCase()}
                      </Badge>
                    </div>
                  </div>

                  {doc.status === 'verified' && (
                    <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                      <div>
                        <span className="text-gray-400">Uploaded: </span>
                        <span className="text-white">{doc.uploadDate}</span>
                      </div>
                      {doc.expiryDate && (
                        <div>
                          <span className="text-gray-400">Expires: </span>
                          <span className="text-white">{doc.expiryDate}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {doc.status === 'rejected' && doc.rejectionReason && (
                    <div className="bg-red-500/10 border border-red-500/20 rounded p-3 mb-4">
                      <p className="text-sm text-red-400">{doc.rejectionReason}</p>
                    </div>
                  )}

                  <div className="flex space-x-3">
                    {doc.status === 'not_uploaded' || doc.status === 'rejected' ? (
                      <Button 
                        onClick={() => handleDocumentUpload(doc.type)}
                        disabled={uploadingDoc === doc.type}
                        className="bg-emerald-500 hover:bg-emerald-600"
                      >
                        {uploadingDoc === doc.type ? (
                          <>
                            <Clock className="w-4 h-4 mr-2 animate-spin" />
                            Uploading...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4 mr-2" />
                            Upload Document
                          </>
                        )}
                      </Button>
                    ) : (
                      <Button variant="outline" className="flex-1">
                        <FileText className="w-4 h-4 mr-2" />
                        View Document
                      </Button>
                    )}
                    
                    {(doc.status === 'uploaded' || doc.status === 'verified') && (
                      <Button variant="outline">
                        Replace
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="limits" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Current Account Limits</CardTitle>
              <p className="text-gray-400">Limits based on your verification level</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Deposit Limits</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between p-3 bg-gray-800 rounded">
                      <span className="text-gray-400">Daily Limit</span>
                      <span className="text-emerald-400 font-semibold">
                        ${kycStatus.limits.dailyDeposit.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between p-3 bg-gray-800 rounded">
                      <span className="text-gray-400">Monthly Limit</span>
                      <span className="text-emerald-400 font-semibold">
                        ${kycStatus.limits.monthlyDeposit.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Withdrawal Limits</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between p-3 bg-gray-800 rounded">
                      <span className="text-gray-400">Daily Limit</span>
                      <span className="text-blue-400 font-semibold">
                        ${kycStatus.limits.dailyWithdrawal.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between p-3 bg-gray-800 rounded">
                      <span className="text-gray-400">Monthly Limit</span>
                      <span className="text-blue-400 font-semibold">
                        ${kycStatus.limits.monthlyWithdrawal.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-700 pt-6">
                <h3 className="text-lg font-semibold text-white mb-4">Betting Limits</h3>
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="flex justify-between p-3 bg-gray-800 rounded">
                    <span className="text-gray-400">Maximum Bet Amount</span>
                    <span className="text-purple-400 font-semibold">
                      ${kycStatus.limits.maxBetAmount.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between p-3 bg-gray-800 rounded">
                    <span className="text-gray-400">Manual Approval Required</span>
                    <span className={kycStatus.limits.withdrawalRequiresApproval ? 'text-orange-400' : 'text-green-400'}>
                      {kycStatus.limits.withdrawalRequiresApproval ? 'Yes' : 'No'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <p className="text-blue-400 font-semibold mb-2">Increase Your Limits</p>
                <p className="text-sm text-gray-300 mb-3">
                  Complete additional verification steps to increase your account limits and unlock premium features.
                </p>
                <Button className="bg-blue-500 hover:bg-blue-600">
                  Upgrade Verification Level
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tax" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-white">Tax Reporting</CardTitle>
                  <p className="text-gray-400">Annual tax reports and documentation</p>
                </div>
                <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                  <SelectTrigger className="w-32 bg-gray-800 border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="US">United States</SelectItem>
                    <SelectItem value="UK">United Kingdom</SelectItem>
                    <SelectItem value="CA">Canada</SelectItem>
                    <SelectItem value="AU">Australia</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {taxReports.map((report) => (
                <Card key={report.year} className="border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-white">Tax Year {report.year}</h3>
                        <Badge className={getStatusColor(report.reportStatus)}>
                          {report.reportStatus.toUpperCase()}
                        </Badge>
                      </div>
                      {report.reportId && (
                        <div className="text-right">
                          <div className="text-sm text-gray-400">Report ID</div>
                          <div className="font-mono text-white text-sm">{report.reportId}</div>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="text-center">
                        <div className="text-lg font-bold text-emerald-400">
                          ${report.totalDeposits.toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-400">Total Deposits</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-blue-400">
                          ${report.totalWithdrawals.toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-400">Total Withdrawals</div>
                      </div>
                      <div className="text-center">
                        <div className={`text-lg font-bold ${report.netGamingRevenue >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {report.netGamingRevenue >= 0 ? '+' : ''}${report.netGamingRevenue.toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-400">Net Gaming Revenue</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-400">
                          ${report.taxableWinnings.toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-400">Taxable Winnings</div>
                      </div>
                    </div>

                    <div className="flex space-x-3">
                      {report.reportStatus === 'pending' ? (
                        <Button className="bg-emerald-500 hover:bg-emerald-600">
                          Generate Report
                        </Button>
                      ) : (
                        <>
                          <Button variant="outline" className="flex-1">
                            Download PDF
                          </Button>
                          <Button variant="outline" className="flex-1">
                            Download CSV
                          </Button>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Compliance Alerts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {complianceAlerts.map((alert) => (
                <Card key={alert.id} className={`border ${getSeverityColor(alert.severity)}`}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center space-x-3">
                        <div className="text-emerald-400">
                          {alert.type === 'kyc' && <User className="w-5 h-5" />}
                          {alert.type === 'aml' && <Shield className="w-5 h-5" />}
                          {alert.type === 'regulatory' && <Flag className="w-5 h-5" />}
                          {alert.type === 'suspicious_activity' && <AlertTriangle className="w-5 h-5" />}
                        </div>
                        <div>
                          <h4 className="font-semibold text-white">{alert.title}</h4>
                          <p className="text-sm text-gray-400 capitalize">{alert.type.replace('_', ' ')}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="text-xs">
                          {alert.severity.toUpperCase()}
                        </Badge>
                        <Badge className={getStatusColor(alert.status)}>
                          {alert.status.toUpperCase()}
                        </Badge>
                      </div>
                    </div>

                    <p className="text-sm text-gray-300 mb-3">{alert.description}</p>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-400">{alert.timestamp}</span>
                      <div className="flex space-x-2">
                        {alert.status === 'open' && (
                          <Button size="sm" variant="outline">
                            Acknowledge
                          </Button>
                        )}
                        {alert.actionRequired && alert.status === 'open' && (
                          <Button size="sm" className="bg-red-500 hover:bg-red-600">
                            Take Action
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}