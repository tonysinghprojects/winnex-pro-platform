import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Crown, 
  Star, 
  Trophy, 
  Gift, 
  Coins, 
  TrendingUp,
  Calendar,
  Users,
  Zap,
  Diamond,
  Award
} from "lucide-react";

interface VIPTier {
  id: string;
  name: string;
  level: number;
  minPoints: number;
  color: string;
  icon: React.ReactNode;
  benefits: string[];
  cashbackRate: number;
  bonusMultiplier: number;
  withdrawalLimit: number;
  personalManager: boolean;
}

interface UserLoyalty {
  currentTier: string;
  points: number;
  nextTierPoints: number;
  lifetimePoints: number;
  monthlySpent: number;
  cashbackEarned: number;
  bonusesReceived: number;
  vipEventInvites: number;
  personalManagerAccess: boolean;
  achievements: Achievement[];
  recentActivity: LoyaltyActivity[];
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  pointsReward: number;
  completed: boolean;
  completedAt?: string;
  progress: number;
  maxProgress: number;
}

interface LoyaltyActivity {
  id: string;
  type: 'points_earned' | 'tier_upgrade' | 'cashback' | 'bonus' | 'achievement';
  title: string;
  description: string;
  points: number;
  timestamp: string;
  icon: React.ReactNode;
}

export default function VIPLoyaltyProgram() {
  const [selectedTab, setSelectedTab] = useState('overview');

  const { data: loyaltyData } = useQuery({
    queryKey: ['/api/user/loyalty'],
    refetchInterval: 60000,
  });

  const vipTiers: VIPTier[] = [
    {
      id: 'bronze',
      name: 'Bronze',
      level: 1,
      minPoints: 0,
      color: 'from-amber-600 to-orange-600',
      icon: <Award className="w-6 h-6" />,
      benefits: ['Basic customer support', '1% cashback', 'Weekly bonus'],
      cashbackRate: 1.0,
      bonusMultiplier: 1.0,
      withdrawalLimit: 5000,
      personalManager: false
    },
    {
      id: 'silver',
      name: 'Silver',
      level: 2,
      minPoints: 1000,
      color: 'from-gray-400 to-gray-600',
      icon: <Star className="w-6 h-6" />,
      benefits: ['Priority support', '1.5% cashback', 'Bi-weekly bonus', 'Exclusive tournaments'],
      cashbackRate: 1.5,
      bonusMultiplier: 1.2,
      withdrawalLimit: 10000,
      personalManager: false
    },
    {
      id: 'gold',
      name: 'Gold',
      level: 3,
      minPoints: 5000,
      color: 'from-yellow-400 to-yellow-600',
      icon: <Trophy className="w-6 h-6" />,
      benefits: ['VIP support', '2% cashback', 'Daily bonus', 'VIP events', 'Higher limits'],
      cashbackRate: 2.0,
      bonusMultiplier: 1.5,
      withdrawalLimit: 25000,
      personalManager: false
    },
    {
      id: 'platinum',
      name: 'Platinum',
      level: 4,
      minPoints: 15000,
      color: 'from-slate-300 to-slate-500',
      icon: <Diamond className="w-6 h-6" />,
      benefits: ['Personal manager', '3% cashback', 'Custom bonuses', 'Private events', 'No limits'],
      cashbackRate: 3.0,
      bonusMultiplier: 2.0,
      withdrawalLimit: 100000,
      personalManager: true
    },
    {
      id: 'diamond',
      name: 'Diamond',
      level: 5,
      minPoints: 50000,
      color: 'from-cyan-300 to-blue-500',
      icon: <Crown className="w-6 h-6" />,
      benefits: ['Dedicated manager', '5% cashback', 'Unlimited bonuses', 'Exclusive access', 'Custom terms'],
      cashbackRate: 5.0,
      bonusMultiplier: 3.0,
      withdrawalLimit: 0, // No limit
      personalManager: true
    }
  ];

  const mockUserData: UserLoyalty = {
    currentTier: 'silver',
    points: 2450,
    nextTierPoints: 5000,
    lifetimePoints: 12340,
    monthlySpent: 2800,
    cashbackEarned: 156.50,
    bonusesReceived: 12,
    vipEventInvites: 3,
    personalManagerAccess: false,
    achievements: [
      {
        id: '1',
        title: 'First Bet',
        description: 'Place your first bet',
        icon: '🎯',
        pointsReward: 100,
        completed: true,
        completedAt: '2024-01-15',
        progress: 1,
        maxProgress: 1
      },
      {
        id: '2',
        title: 'High Roller',
        description: 'Bet $1000+ in a single wager',
        icon: '💎',
        pointsReward: 500,
        completed: true,
        completedAt: '2024-01-20',
        progress: 1,
        maxProgress: 1
      },
      {
        id: '3',
        title: 'Win Streak',
        description: 'Win 10 consecutive bets',
        icon: '🔥',
        pointsReward: 300,
        completed: false,
        progress: 7,
        maxProgress: 10
      },
      {
        id: '4',
        title: 'Monthly Spender',
        description: 'Spend $5000+ in a month',
        icon: '💰',
        pointsReward: 750,
        completed: false,
        progress: 2800,
        maxProgress: 5000
      }
    ],
    recentActivity: [
      {
        id: '1',
        type: 'points_earned',
        title: 'Points Earned',
        description: 'Earned 50 points from betting activity',
        points: 50,
        timestamp: '2 hours ago',
        icon: <Coins className="w-4 h-4 text-yellow-500" />
      },
      {
        id: '2',
        type: 'cashback',
        title: 'Cashback Received',
        description: '$12.50 cashback credited',
        points: 0,
        timestamp: '1 day ago',
        icon: <TrendingUp className="w-4 h-4 text-green-500" />
      },
      {
        id: '3',
        type: 'achievement',
        title: 'Achievement Unlocked',
        description: 'High Roller achievement completed',
        points: 500,
        timestamp: '3 days ago',
        icon: <Trophy className="w-4 h-4 text-purple-500" />
      }
    ]
  };

  // Use API data with mock fallback
  const safeUserData = {
    currentTier: (loyaltyData as any)?.currentTier || mockUserData.currentTier,
    points: (loyaltyData as any)?.points || mockUserData.points,
    nextTierPoints: (loyaltyData as any)?.nextTierPoints || mockUserData.nextTierPoints,
    lifetimePoints: (loyaltyData as any)?.lifetimePoints || mockUserData.lifetimePoints,
    monthlySpent: (loyaltyData as any)?.monthlySpent || mockUserData.monthlySpent,
    cashbackEarned: (loyaltyData as any)?.cashbackEarned || mockUserData.cashbackEarned,
    bonusesReceived: (loyaltyData as any)?.bonusesReceived || mockUserData.bonusesReceived,
    vipEventInvites: (loyaltyData as any)?.vipEventInvites || mockUserData.vipEventInvites,
    personalManagerAccess: (loyaltyData as any)?.personalManagerAccess || mockUserData.personalManagerAccess,
    achievements: (loyaltyData as any)?.achievements || mockUserData.achievements,
    recentActivity: (loyaltyData as any)?.recentActivity || mockUserData.recentActivity
  };
  
  const currentTier = vipTiers.find(tier => tier.id === safeUserData.currentTier) || vipTiers[0];
  const nextTier = vipTiers.find(tier => tier.minPoints > safeUserData.points);
  const progressToNext = nextTier && currentTier ? ((safeUserData.points - currentTier.minPoints) / (nextTier.minPoints - currentTier.minPoints)) * 100 : 100;

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">VIP Loyalty Program</h1>
        <p className="text-gray-400">Exclusive rewards for our valued players</p>
      </div>

      {/* Current Status */}
      <Card className="bg-winnex-dark border-gray-700">
        <CardContent className="p-6">
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className={`w-20 h-20 mx-auto mb-4 bg-gradient-to-br ${currentTier?.color} rounded-full flex items-center justify-center`}>
                {currentTier?.icon}
              </div>
              <h3 className="text-xl font-bold text-white">{currentTier?.name} Member</h3>
              <p className="text-gray-400">Current Tier</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-500 mb-2">{safeUserData.points.toLocaleString()}</div>
              <p className="text-gray-400">Loyalty Points</p>
              {nextTier && (
                <div className="mt-2">
                  <Progress value={progressToNext} className="h-2" />
                  <p className="text-xs text-gray-500 mt-1">
                    {(nextTier.minPoints - safeUserData.points).toLocaleString()} points to {nextTier.name}
                  </p>
                </div>
              )}
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-green-500 mb-2">${safeUserData.cashbackEarned}</div>
              <p className="text-gray-400">Total Cashback</p>
              <p className="text-xs text-gray-500 mt-1">{currentTier?.cashbackRate}% rate</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-500 mb-2">{safeUserData.bonusesReceived}</div>
              <p className="text-gray-400">Bonuses Received</p>
              <p className="text-xs text-gray-500 mt-1">{currentTier?.bonusMultiplier}x multiplier</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed View */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-winnex-gray">
          <TabsTrigger value="overview" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Overview
          </TabsTrigger>
          <TabsTrigger value="tiers" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            VIP Tiers
          </TabsTrigger>
          <TabsTrigger value="achievements" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Achievements
          </TabsTrigger>
          <TabsTrigger value="activity" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Activity
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Current Benefits */}
            <Card className="bg-winnex-dark border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Gift className="w-5 h-5" />
                  Your Current Benefits
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {currentTier?.benefits.map((benefit, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-gray-800 rounded-lg">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <span className="text-white">{benefit}</span>
                    </div>
                  ))}
                </div>
                
                {safeUserData.personalManagerAccess && (
                  <div className="mt-6 p-4 bg-gradient-to-r from-purple-900 to-pink-900 rounded-lg">
                    <h4 className="text-white font-semibold mb-2">Personal VIP Manager</h4>
                    <p className="text-purple-200 text-sm mb-3">Sarah Johnson - Your dedicated account manager</p>
                    <Button className="bg-white text-purple-600 hover:bg-gray-100">
                      Contact Manager
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Monthly Summary */}
            <Card className="bg-winnex-dark border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  This Month
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
                    <span className="text-gray-400">Total Spent</span>
                    <span className="text-white font-semibold">${safeUserData.monthlySpent.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
                    <span className="text-gray-400">Points Earned</span>
                    <span className="text-yellow-500 font-semibold">+{Math.floor(safeUserData.monthlySpent / 10)}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
                    <span className="text-gray-400">Cashback</span>
                    <span className="text-green-500 font-semibold">+${(safeUserData.monthlySpent * (currentTier?.cashbackRate || 0) / 100).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
                    <span className="text-gray-400">VIP Events</span>
                    <span className="text-purple-500 font-semibold">{safeUserData.vipEventInvites} invites</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tiers" className="mt-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vipTiers.map((tier) => (
              <Card 
                key={tier.id} 
                className={`border-2 transition-all duration-300 ${
                  tier.id === safeUserData.currentTier 
                    ? 'border-green-500 bg-green-900/20' 
                    : 'border-gray-600 bg-winnex-dark hover:border-gray-500'
                }`}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                      <div className={`w-8 h-8 bg-gradient-to-br ${tier.color} rounded-full flex items-center justify-center`}>
                        {tier.icon}
                      </div>
                      {tier.name}
                    </CardTitle>
                    {tier.id === safeUserData.currentTier && (
                      <Badge className="bg-green-600">Current</Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-500">
                        {tier.minPoints.toLocaleString()}+ pts
                      </div>
                      <div className="text-sm text-gray-400">Required Points</div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-sm">
                        <span className="text-gray-400">Cashback: </span>
                        <span className="text-green-400 font-semibold">{tier.cashbackRate}%</span>
                      </div>
                      <div className="text-sm">
                        <span className="text-gray-400">Bonus Multiplier: </span>
                        <span className="text-purple-400 font-semibold">{tier.bonusMultiplier}x</span>
                      </div>
                      <div className="text-sm">
                        <span className="text-gray-400">Withdrawal Limit: </span>
                        <span className="text-blue-400 font-semibold">
                          {tier.withdrawalLimit === 0 ? 'Unlimited' : `$${tier.withdrawalLimit.toLocaleString()}`}
                        </span>
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      {tier.benefits.map((benefit, index) => (
                        <div key={index} className="flex items-center gap-2 text-xs text-gray-300">
                          <div className="w-1 h-1 bg-green-400 rounded-full"></div>
                          {benefit}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="mt-6">
          <div className="grid md:grid-cols-2 gap-6">
            {safeUserData.achievements.map((achievement: any) => (
              <Card key={achievement.id} className="bg-winnex-dark border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="text-4xl">{achievement.icon}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-white font-semibold">{achievement.title}</h3>
                        {achievement.completed && (
                          <Badge className="bg-green-600">Completed</Badge>
                        )}
                      </div>
                      <p className="text-gray-400 text-sm mb-3">{achievement.description}</p>
                      
                      {achievement.completed ? (
                        <div className="text-xs text-green-400">
                          Completed {achievement.completedAt} • +{achievement.pointsReward} points
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-400">Progress</span>
                            <span className="text-white">{achievement.progress}/{achievement.maxProgress}</span>
                          </div>
                          <Progress 
                            value={(achievement.progress / achievement.maxProgress) * 100} 
                            className="h-2" 
                          />
                          <div className="text-xs text-yellow-400">
                            Reward: +{achievement.pointsReward} points
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="activity" className="mt-6">
          <Card className="bg-winnex-dark border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Recent Loyalty Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {safeUserData.recentActivity.map((activity: any) => (
                  <div key={activity.id} className="flex items-center gap-4 p-4 bg-gray-800 rounded-lg">
                    <div className="flex-shrink-0">
                      {activity.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-white font-semibold">{activity.title}</h4>
                        <span className="text-xs text-gray-400">{activity.timestamp}</span>
                      </div>
                      <p className="text-gray-400 text-sm">{activity.description}</p>
                    </div>
                    {activity.points > 0 && (
                      <div className="text-yellow-500 font-semibold">+{activity.points}</div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}