import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, XCircle, Clock, AlertTriangle, FileText, Upload, Shield, Eye } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface KYCUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  nationality: string;
  address: {
    street: string;
    city: string;
    postalCode: string;
    country: string;
  };
  phone: string;
  status: 'pending' | 'approved' | 'rejected' | 'under_review' | 'requires_documents';
  riskLevel: 'low' | 'medium' | 'high';
  verificationLevel: 'basic' | 'enhanced' | 'full';
  documents: Array<{
    type: 'passport' | 'drivers_license' | 'national_id' | 'proof_of_address' | 'bank_statement';
    status: 'pending' | 'approved' | 'rejected';
    uploadedAt: string;
    reviewedAt?: string;
    rejectionReason?: string;
  }>;
  flags: string[];
  lastActivity: string;
  registrationDate: string;
  ipAddress: string;
  deviceFingerprint: string;
  sourceOfFunds: string;
  estimatedWorth: string;
  politicallyExposed: boolean;
  sanctions: boolean;
}

interface AMLAlert {
  id: string;
  userId: string;
  type: 'suspicious_transaction' | 'velocity_alert' | 'pattern_detection' | 'pep_match' | 'sanctions_match';
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  details: any;
  status: 'open' | 'investigating' | 'closed' | 'false_positive';
  assignedTo?: string;
  createdAt: string;
  resolvedAt?: string;
  notes: string[];
}

interface ComplianceStats {
  totalUsers: number;
  pendingReviews: number;
  completedToday: number;
  rejectionRate: number;
  averageProcessingTime: number;
  highRiskUsers: number;
  activeAlerts: number;
  sankctionsMatches: number;
}

export default function KYCComplianceCenter() {
  const [selectedUser, setSelectedUser] = useState<string>('');
  const [documentFilter, setDocumentFilter] = useState<string>('all');
  const queryClient = useQueryClient();

  const { data: complianceStats } = useQuery({
    queryKey: ['/api/compliance/stats'],
    queryFn: () => apiRequest('/api/compliance/stats'),
  });

  const { data: kycUsers } = useQuery({
    queryKey: ['/api/compliance/kyc-users'],
    queryFn: () => apiRequest('/api/compliance/kyc-users'),
  });

  const { data: amlAlerts } = useQuery({
    queryKey: ['/api/compliance/aml-alerts'],
    queryFn: () => apiRequest('/api/compliance/aml-alerts'),
  });

  const { data: selectedUserDetails } = useQuery({
    queryKey: ['/api/compliance/user', selectedUser],
    queryFn: () => apiRequest(`/api/compliance/user/${selectedUser}`),
    enabled: !!selectedUser,
  });

  const approveUserMutation = useMutation({
    mutationFn: (data: { userId: string; level: string }) =>
      apiRequest('/api/compliance/approve-user', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/compliance/kyc-users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/compliance/stats'] });
    },
  });

  const rejectUserMutation = useMutation({
    mutationFn: (data: { userId: string; reason: string }) =>
      apiRequest('/api/compliance/reject-user', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/compliance/kyc-users'] });
    },
  });

  const resolveAlertMutation = useMutation({
    mutationFn: (data: { alertId: string; resolution: string; notes: string }) =>
      apiRequest('/api/compliance/resolve-alert', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/compliance/aml-alerts'] });
    },
  });

  const pendingUsers = kycUsers?.filter((user: KYCUser) => 
    user.status === 'pending' || user.status === 'under_review'
  ) || [];

  const criticalAlerts = amlAlerts?.filter((alert: AMLAlert) => 
    alert.severity === 'critical' && alert.status === 'open'
  ) || [];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-500/20 text-green-400 border-green-500/20';
      case 'rejected': return 'bg-red-500/20 text-red-400 border-red-500/20';
      case 'pending': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/20';
      case 'under_review': return 'bg-blue-500/20 text-blue-400 border-blue-500/20';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/20';
    }
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-green-500/20 text-green-400';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400';
      case 'high': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Basic Verification Center</h1>
          <p className="text-slate-300">Streamlined identity verification for quick account activation</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/20 border-blue-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 text-sm font-medium">Pending Reviews</p>
                  <p className="text-3xl font-bold text-white">{complianceStats?.pendingReviews || 0}</p>
                </div>
                <Clock className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-red-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-400 text-sm font-medium">Critical Alerts</p>
                  <p className="text-3xl font-bold text-white">{criticalAlerts.length}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-green-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Completed Today</p>
                  <p className="text-3xl font-bold text-white">{complianceStats?.completedToday || 0}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-orange-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-400 text-sm font-medium">High Risk Users</p>
                  <p className="text-3xl font-bold text-white">{complianceStats?.highRiskUsers || 0}</p>
                </div>
                <Shield className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="reviews" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="reviews" className="data-[state=active]:bg-green-500/20">
              Quick Verification
            </TabsTrigger>
            <TabsTrigger value="alerts" className="data-[state=active]:bg-green-500/20">
              Security Alerts
            </TabsTrigger>
            <TabsTrigger value="monitoring" className="data-[state=active]:bg-green-500/20">
              Basic Monitoring
            </TabsTrigger>
            <TabsTrigger value="reports" className="data-[state=active]:bg-green-500/20">
              Simple Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="reviews" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="text-white">Pending KYC Reviews</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {pendingUsers.map((user: KYCUser) => (
                        <div 
                          key={user.id} 
                          className={`p-4 rounded-lg border cursor-pointer transition-all ${
                            selectedUser === user.id 
                              ? 'bg-green-500/10 border-green-500/30' 
                              : 'bg-slate-800/30 border-slate-600/30 hover:border-slate-500/50'
                          }`}
                          onClick={() => setSelectedUser(user.id)}
                        >
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <p className="text-white font-medium">{user.firstName} {user.lastName}</p>
                              <p className="text-slate-400 text-sm">{user.email}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge className={getRiskLevelColor(user.riskLevel)}>
                                {user.riskLevel} risk
                              </Badge>
                              <Badge className={getStatusColor(user.status)}>
                                {user.status}
                              </Badge>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-slate-400">Registration</p>
                              <p className="text-white">{new Date(user.registrationDate).toLocaleDateString()}</p>
                            </div>
                            <div>
                              <p className="text-slate-400">Verification Level</p>
                              <p className="text-white capitalize">{user.verificationLevel}</p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between mt-3">
                            <div className="flex items-center space-x-2">
                              {user.documents.map((doc, index) => (
                                <div key={index} className="flex items-center space-x-1">
                                  {doc.status === 'approved' ? (
                                    <CheckCircle className="h-4 w-4 text-green-400" />
                                  ) : doc.status === 'rejected' ? (
                                    <XCircle className="h-4 w-4 text-red-400" />
                                  ) : (
                                    <Clock className="h-4 w-4 text-yellow-400" />
                                  )}
                                  <span className="text-xs text-slate-400 capitalize">
                                    {doc.type.replace('_', ' ')}
                                  </span>
                                </div>
                              ))}
                            </div>
                            <p className="text-xs text-slate-400">
                              {user.flags.length > 0 && `${user.flags.length} flags`}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                {selectedUser && selectedUserDetails && (
                  <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                    <CardHeader>
                      <CardTitle className="text-white">User Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-slate-400 text-sm">Personal Information</p>
                        <div className="mt-2 space-y-2">
                          <p className="text-white">
                            {selectedUserDetails.firstName} {selectedUserDetails.lastName}
                          </p>
                          <p className="text-slate-300 text-sm">{selectedUserDetails.email}</p>
                          <p className="text-slate-300 text-sm">
                            DOB: {new Date(selectedUserDetails.dateOfBirth).toLocaleDateString()}
                          </p>
                          <p className="text-slate-300 text-sm">
                            Nationality: {selectedUserDetails.nationality}
                          </p>
                        </div>
                      </div>

                      <div>
                        <p className="text-slate-400 text-sm">Address</p>
                        <div className="mt-2">
                          <p className="text-slate-300 text-sm">
                            {selectedUserDetails.address.street}
                          </p>
                          <p className="text-slate-300 text-sm">
                            {selectedUserDetails.address.city}, {selectedUserDetails.address.postalCode}
                          </p>
                          <p className="text-slate-300 text-sm">
                            {selectedUserDetails.address.country}
                          </p>
                        </div>
                      </div>

                      <div>
                        <p className="text-slate-400 text-sm">Risk Factors</p>
                        <div className="mt-2 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">PEP Status</span>
                            <Badge className={selectedUserDetails.politicallyExposed ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'}>
                              {selectedUserDetails.politicallyExposed ? 'Yes' : 'No'}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Sanctions</span>
                            <Badge className={selectedUserDetails.sanctions ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'}>
                              {selectedUserDetails.sanctions ? 'Match' : 'Clear'}
                            </Badge>
                          </div>
                        </div>
                      </div>

                      <div>
                        <p className="text-slate-400 text-sm">Financial Information</p>
                        <div className="mt-2 space-y-1">
                          <p className="text-slate-300 text-sm">
                            Source of Funds: {selectedUserDetails.sourceOfFunds}
                          </p>
                          <p className="text-slate-300 text-sm">
                            Estimated Worth: {selectedUserDetails.estimatedWorth}
                          </p>
                        </div>
                      </div>

                      <div className="pt-4 space-y-2">
                        <Button 
                          className="w-full bg-green-500 hover:bg-green-600 text-white"
                          onClick={() => approveUserMutation.mutate({
                            userId: selectedUser,
                            level: 'full'
                          })}
                        >
                          Approve KYC
                        </Button>
                        <Button 
                          variant="outline" 
                          className="w-full border-red-500/20 text-red-400 hover:bg-red-500/10"
                          onClick={() => rejectUserMutation.mutate({
                            userId: selectedUser,
                            reason: 'Failed verification requirements'
                          })}
                        >
                          Reject Application
                        </Button>
                        <Button 
                          variant="outline" 
                          className="w-full border-blue-500/20 text-blue-400 hover:bg-blue-500/10"
                        >
                          Request More Documents
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="alerts" className="space-y-6">
            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">AML Alerts & Suspicious Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {amlAlerts?.map((alert: AMLAlert) => (
                    <div key={alert.id} className="p-4 bg-slate-800/30 rounded-lg border border-slate-600/30">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${
                            alert.severity === 'critical' ? 'bg-red-500' :
                            alert.severity === 'high' ? 'bg-orange-500' :
                            alert.severity === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'
                          }`} />
                          <div>
                            <p className="text-white font-medium">{alert.description}</p>
                            <p className="text-slate-400 text-sm">User: {alert.userId}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={`${
                            alert.severity === 'critical' ? 'bg-red-500/20 text-red-400' :
                            alert.severity === 'high' ? 'bg-orange-500/20 text-orange-400' :
                            alert.severity === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-blue-500/20 text-blue-400'
                          }`}>
                            {alert.severity}
                          </Badge>
                          <Badge className={getStatusColor(alert.status)}>
                            {alert.status}
                          </Badge>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-3 text-sm">
                        <div>
                          <p className="text-slate-400">Alert Type</p>
                          <p className="text-white capitalize">{alert.type.replace('_', ' ')}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Created</p>
                          <p className="text-white">{new Date(alert.createdAt).toLocaleString()}</p>
                        </div>
                      </div>

                      {alert.status === 'open' && (
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            className="bg-green-500/20 border border-green-500/30 text-green-400 hover:bg-green-500/30"
                            onClick={() => resolveAlertMutation.mutate({
                              alertId: alert.id,
                              resolution: 'false_positive',
                              notes: 'Reviewed and determined to be false positive'
                            })}
                          >
                            Mark False Positive
                          </Button>
                          <Button 
                            size="sm" 
                            className="bg-blue-500/20 border border-blue-500/30 text-blue-400 hover:bg-blue-500/30"
                          >
                            Investigate
                          </Button>
                          <Button 
                            size="sm" 
                            className="bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30"
                          >
                            Escalate
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monitoring" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Transaction Monitoring Rules</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                      <div>
                        <p className="text-white font-medium">High Value Transactions</p>
                        <p className="text-slate-400 text-sm">Threshold: $10,000+</p>
                      </div>
                      <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                      <div>
                        <p className="text-white font-medium">Rapid Fire Betting</p>
                        <p className="text-slate-400 text-sm">Threshold: 20+ bets/hour</p>
                      </div>
                      <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                      <div>
                        <p className="text-white font-medium">Unusual Deposit Patterns</p>
                        <p className="text-slate-400 text-sm">Multiple sources detection</p>
                      </div>
                      <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                      <div>
                        <p className="text-white font-medium">Cross-Border Monitoring</p>
                        <p className="text-slate-400 text-sm">Geo-location tracking</p>
                      </div>
                      <Badge className="bg-yellow-500/20 text-yellow-400">Alert</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Sanctions & PEP Screening</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-slate-800/30 rounded-lg">
                      <p className="text-2xl font-bold text-white">0</p>
                      <p className="text-slate-400 text-sm">Sanctions Matches</p>
                    </div>
                    <div className="text-center p-4 bg-slate-800/30 rounded-lg">
                      <p className="text-2xl font-bold text-yellow-400">3</p>
                      <p className="text-slate-400 text-sm">PEP Matches</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-slate-300 font-medium">Latest Screenings</p>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-400">OFAC Sanctions List</span>
                        <span className="text-green-400">Clear</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-400">EU Sanctions List</span>
                        <span className="text-green-400">Clear</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-400">PEP Database</span>
                        <span className="text-yellow-400">3 Matches</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-400">Adverse Media</span>
                        <span className="text-green-400">Clear</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Regulatory Reports</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full justify-between bg-slate-800/50 hover:bg-slate-700/50 text-white">
                    <span>Suspicious Activity Report (SAR)</span>
                    <FileText className="h-4 w-4" />
                  </Button>
                  <Button className="w-full justify-between bg-slate-800/50 hover:bg-slate-700/50 text-white">
                    <span>Currency Transaction Report (CTR)</span>
                    <FileText className="h-4 w-4" />
                  </Button>
                  <Button className="w-full justify-between bg-slate-800/50 hover:bg-slate-700/50 text-white">
                    <span>Monthly Compliance Summary</span>
                    <FileText className="h-4 w-4" />
                  </Button>
                  <Button className="w-full justify-between bg-slate-800/50 hover:bg-slate-700/50 text-white">
                    <span>KYC Completion Report</span>
                    <FileText className="h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Compliance Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">KYC Completion Rate</span>
                      <span className="text-white font-bold">94.2%</span>
                    </div>
                    <Progress value={94.2} className="h-2 bg-slate-800" />
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">AML Alert Resolution</span>
                      <span className="text-white font-bold">87.5%</span>
                    </div>
                    <Progress value={87.5} className="h-2 bg-slate-800" />
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Document Verification</span>
                      <span className="text-white font-bold">91.8%</span>
                    </div>
                    <Progress value={91.8} className="h-2 bg-slate-800" />
                  </div>

                  <div className="pt-4">
                    <p className="text-slate-400 text-sm">
                      Last audit: {new Date().toLocaleDateString()}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}