import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Play, Pause, Volume2, VolumeX, Maximize, MessageCircle, 
  Users, Eye, Heart, TrendingUp, Zap, Crown
} from "lucide-react";

interface LiveStream {
  id: string;
  title: string;
  sport: string;
  league: string;
  teams: [string, string];
  score: [number, number];
  time: string;
  status: 'live' | 'upcoming' | 'halftime' | 'ended';
  viewers: number;
  quality: '720p' | '1080p' | '4K';
  thumbnail: string;
  streamUrl: string;
  featured: boolean;
  betting: {
    available: boolean;
    markets: number;
    volume: number;
  };
}

interface ChatMessage {
  id: string;
  user: {
    username: string;
    tier: string;
    avatar: string;
  };
  message: string;
  timestamp: string;
  type: 'message' | 'bet' | 'prediction' | 'celebration';
}

export default function LiveStreamingHub() {
  const [selectedStream, setSelectedStream] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [quality, setQuality] = useState('1080p');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');

  // Mock live streams data
  const liveStreams: LiveStream[] = [
    {
      id: '1',
      title: 'Premier League: Liverpool vs Arsenal',
      sport: 'Football',
      league: 'Premier League',
      teams: ['Liverpool', 'Arsenal'],
      score: [2, 1],
      time: '67\'',
      status: 'live',
      viewers: 45672,
      quality: '1080p',
      thumbnail: '/streams/liverpool-arsenal.jpg',
      streamUrl: 'https://stream.winnex.com/live/1',
      featured: true,
      betting: {
        available: true,
        markets: 127,
        volume: 2450000
      }
    },
    {
      id: '2',
      title: 'NBA: Lakers vs Celtics',
      sport: 'Basketball',
      league: 'NBA',
      teams: ['Lakers', 'Celtics'],
      score: [89, 76],
      time: 'Q3 8:34',
      status: 'live',
      viewers: 32145,
      quality: '1080p',
      thumbnail: '/streams/lakers-celtics.jpg',
      streamUrl: 'https://stream.winnex.com/live/2',
      featured: false,
      betting: {
        available: true,
        markets: 89,
        volume: 1850000
      }
    },
    {
      id: '3',
      title: 'Champions League: Barcelona vs PSG',
      sport: 'Football',
      league: 'Champions League',
      teams: ['Barcelona', 'PSG'],
      score: [0, 0],
      time: 'HT',
      status: 'halftime',
      viewers: 67890,
      quality: '4K',
      thumbnail: '/streams/barca-psg.jpg',
      streamUrl: 'https://stream.winnex.com/live/3',
      featured: true,
      betting: {
        available: true,
        markets: 156,
        volume: 3200000
      }
    }
  ];

  // Mock chat messages
  const mockChatMessages: ChatMessage[] = [
    {
      id: '1',
      user: {
        username: 'BettingKing',
        tier: 'diamond',
        avatar: '/avatars/user1.jpg'
      },
      message: 'Liverpool looking strong! Just backed them @1.85',
      timestamp: '18:45:23',
      type: 'bet'
    },
    {
      id: '2',
      user: {
        username: 'SportsFan92',
        tier: 'gold',
        avatar: '/avatars/user2.jpg'
      },
      message: 'What a goal! Salah is incredible! 🔥',
      timestamp: '18:45:45',
      type: 'celebration'
    },
    {
      id: '3',
      user: {
        username: 'OddsWizard',
        tier: 'platinum',
        avatar: '/avatars/user3.jpg'
      },
      message: 'Next goal under 15 minutes - calling it now',
      timestamp: '18:46:12',
      type: 'prediction'
    }
  ];

  const selectedStreamData = liveStreams.find(stream => stream.id === selectedStream) || liveStreams[0];

  useEffect(() => {
    setChatMessages(mockChatMessages);
    
    // Simulate real-time chat messages
    const interval = setInterval(() => {
      const newMsg: ChatMessage = {
        id: Math.random().toString(),
        user: {
          username: `User${Math.floor(Math.random() * 1000)}`,
          tier: ['bronze', 'silver', 'gold', 'platinum', 'diamond'][Math.floor(Math.random() * 5)],
          avatar: `/avatars/user${Math.floor(Math.random() * 5) + 1}.jpg`
        },
        message: [
          'Great match!',
          'What a save!',
          'Betting on next goal',
          'Liverpool to win this',
          'Arsenal comeback incoming',
          'Cash out time?'
        ][Math.floor(Math.random() * 6)],
        timestamp: new Date().toLocaleTimeString(),
        type: ['message', 'bet', 'prediction'][Math.floor(Math.random() * 3)] as any
      };
      
      setChatMessages(prev => [...prev.slice(-20), newMsg]);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'diamond': return 'text-cyan-400';
      case 'platinum': return 'text-gray-300';
      case 'gold': return 'text-yellow-400';
      case 'silver': return 'text-gray-400';
      case 'bronze': return 'text-orange-400';
      default: return 'text-gray-500';
    }
  };

  const getMessageTypeIcon = (type: string) => {
    switch (type) {
      case 'bet': return '💰';
      case 'prediction': return '🔮';
      case 'celebration': return '🎉';
      default: return '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Featured Streams */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {liveStreams.filter(stream => stream.featured).map((stream) => (
          <Card 
            key={stream.id} 
            className={`bg-winnex-gray border-gray-600 cursor-pointer transition-all hover:border-winnex-blue ${
              selectedStream === stream.id ? 'border-winnex-blue bg-winnex-blue/10' : ''
            }`}
            onClick={() => setSelectedStream(stream.id)}
          >
            <CardContent className="p-4">
              <div className="relative mb-3">
                <div className="aspect-video bg-gradient-to-r from-winnex-blue/20 to-winnex-green/20 rounded-lg flex items-center justify-center">
                  <Play className="w-12 h-12 text-white opacity-75" />
                </div>
                <div className="absolute top-2 left-2 flex space-x-2">
                  <Badge className="bg-red-500 text-white animate-pulse">LIVE</Badge>
                  <Badge className="bg-black/50 text-white">{stream.quality}</Badge>
                </div>
                <div className="absolute top-2 right-2">
                  <Badge className="bg-black/50 text-white flex items-center">
                    <Eye className="w-3 h-3 mr-1" />
                    {stream.viewers.toLocaleString()}
                  </Badge>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="font-medium text-sm">{stream.title}</h3>
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span>{stream.league}</span>
                  <span>{stream.time}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-lg font-bold">
                    {stream.teams[0]} {stream.score[0]} - {stream.score[1]} {stream.teams[1]}
                  </div>
                </div>
                {stream.betting.available && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-winnex-green">{stream.betting.markets} markets</span>
                    <span className="text-gray-400">${(stream.betting.volume / 1000000).toFixed(1)}M volume</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Streaming Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Video Player */}
        <div className="lg:col-span-3">
          <Card className="bg-winnex-gray border-gray-600">
            <CardContent className="p-0">
              {/* Video Container */}
              <div className="relative aspect-video bg-black rounded-t-lg overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-winnex-blue/20 to-winnex-green/20 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-6xl mb-4">🏆</div>
                    <h2 className="text-2xl font-bold mb-2">{selectedStreamData.title}</h2>
                    <div className="text-4xl font-bold mb-4">
                      {selectedStreamData.teams[0]} {selectedStreamData.score[0]} - {selectedStreamData.score[1]} {selectedStreamData.teams[1]}
                    </div>
                    <Badge className="bg-red-500 text-white text-lg px-4 py-2">
                      {selectedStreamData.status === 'live' ? 'LIVE' : selectedStreamData.status.toUpperCase()}
                    </Badge>
                  </div>
                </div>

                {/* Video Overlay */}
                <div className="absolute top-4 left-4 flex space-x-2">
                  <Badge className="bg-red-500 text-white animate-pulse">LIVE</Badge>
                  <Badge className="bg-black/50 text-white">{selectedStreamData.quality}</Badge>
                  <Badge className="bg-black/50 text-white flex items-center">
                    <Eye className="w-3 h-3 mr-1" />
                    {selectedStreamData.viewers.toLocaleString()}
                  </Badge>
                </div>

                {/* Video Controls */}
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-black/50 backdrop-blur-sm rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setIsPlaying(!isPlaying)}
                          className="text-white hover:bg-white/20"
                        >
                          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setIsMuted(!isMuted)}
                          className="text-white hover:bg-white/20"
                        >
                          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                        </Button>
                        <span className="text-white text-sm">{selectedStreamData.time}</span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Select value={quality} onValueChange={setQuality}>
                          <SelectTrigger className="w-20 h-8 text-white border-white/20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="720p">720p</SelectItem>
                            <SelectItem value="1080p">1080p</SelectItem>
                            <SelectItem value="4K">4K</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-white hover:bg-white/20"
                        >
                          <Maximize className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Betting Interface */}
              {selectedStreamData.betting.available && (
                <div className="p-4 border-t border-gray-600">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium">Live Betting</h3>
                    <Badge className="bg-winnex-green text-black">
                      {selectedStreamData.betting.markets} Markets
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2">
                    <Button variant="outline" className="border-gray-600 hover:bg-winnex-green hover:text-black">
                      {selectedStreamData.teams[0]} Win
                      <span className="ml-2 font-bold">2.10</span>
                    </Button>
                    <Button variant="outline" className="border-gray-600 hover:bg-winnex-green hover:text-black">
                      Draw
                      <span className="ml-2 font-bold">3.40</span>
                    </Button>
                    <Button variant="outline" className="border-gray-600 hover:bg-winnex-green hover:text-black">
                      {selectedStreamData.teams[1]} Win
                      <span className="ml-2 font-bold">3.75</span>
                    </Button>
                  </div>
                  
                  <Button className="w-full mt-3 bg-winnex-blue text-white hover:bg-blue-400">
                    View All {selectedStreamData.betting.markets} Markets
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Live Chat */}
        <div className="lg:col-span-1">
          <Card className="bg-winnex-gray border-gray-600 h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Live Chat
                </CardTitle>
                <Badge className="bg-winnex-blue text-white flex items-center">
                  <Users className="w-3 h-3 mr-1" />
                  {selectedStreamData.viewers > 1000 ? `${(selectedStreamData.viewers/1000).toFixed(1)}K` : selectedStreamData.viewers}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="flex flex-col h-96">
              {/* Chat Messages */}
              <div className="flex-1 overflow-y-auto space-y-2 mb-4">
                {chatMessages.map((msg) => (
                  <div key={msg.id} className="text-sm">
                    <div className="flex items-start space-x-2">
                      <div className={`font-medium ${getTierColor(msg.user.tier)}`}>
                        {msg.user.username}
                        {msg.user.tier === 'diamond' && <Crown className="w-3 h-3 inline ml-1" />}
                      </div>
                      <span className="text-xs text-gray-400">{msg.timestamp}</span>
                    </div>
                    <div className="flex items-start space-x-1">
                      <span>{getMessageTypeIcon(msg.type)}</span>
                      <span className="text-gray-200 break-words">{msg.message}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Chat Input */}
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Join the conversation..."
                  className="flex-1 bg-winnex-dark border border-gray-600 rounded px-3 py-2 text-sm text-white placeholder-gray-400"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && newMessage.trim()) {
                      const msg: ChatMessage = {
                        id: Math.random().toString(),
                        user: {
                          username: 'You',
                          tier: 'gold',
                          avatar: '/avatars/user.jpg'
                        },
                        message: newMessage,
                        timestamp: new Date().toLocaleTimeString(),
                        type: 'message'
                      };
                      setChatMessages(prev => [...prev, msg]);
                      setNewMessage('');
                    }
                  }}
                />
                <Button 
                  size="sm" 
                  className="bg-winnex-blue text-white hover:bg-blue-400"
                  onClick={() => {
                    if (newMessage.trim()) {
                      const msg: ChatMessage = {
                        id: Math.random().toString(),
                        user: {
                          username: 'You',
                          tier: 'gold',
                          avatar: '/avatars/user.jpg'
                        },
                        message: newMessage,
                        timestamp: new Date().toLocaleTimeString(),
                        type: 'message'
                      };
                      setChatMessages(prev => [...prev, msg]);
                      setNewMessage('');
                    }
                  }}
                >
                  Send
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Other Live Streams */}
      <Card className="bg-winnex-gray border-gray-600">
        <CardHeader>
          <CardTitle>Other Live Streams</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {liveStreams.filter(stream => stream.id !== selectedStream).map((stream) => (
              <div 
                key={stream.id}
                className="cursor-pointer group"
                onClick={() => setSelectedStream(stream.id)}
              >
                <div className="relative aspect-video bg-gradient-to-r from-gray-700 to-gray-600 rounded-lg mb-2 overflow-hidden group-hover:scale-105 transition-transform">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Play className="w-8 h-8 text-white opacity-75" />
                  </div>
                  <div className="absolute top-2 left-2">
                    <Badge className="bg-red-500 text-white text-xs">LIVE</Badge>
                  </div>
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-black/50 text-white text-xs flex items-center">
                      <Eye className="w-2 h-2 mr-1" />
                      {stream.viewers > 1000 ? `${(stream.viewers/1000).toFixed(1)}K` : stream.viewers}
                    </Badge>
                  </div>
                </div>
                <h4 className="font-medium text-sm mb-1">{stream.title}</h4>
                <div className="text-xs text-gray-400">
                  {stream.teams[0]} {stream.score[0]} - {stream.score[1]} {stream.teams[1]} • {stream.time}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}