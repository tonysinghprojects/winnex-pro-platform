import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CreditCard, Wallet, DollarSign, ArrowUpCircle, ArrowDownCircle, Shield, Clock, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PaymentMethod {
  id: string;
  type: 'card' | 'bank' | 'crypto' | 'ewallet';
  last4?: string;
  brand?: string;
  expiryMonth?: number;
  expiryYear?: number;
  isDefault: boolean;
  verified: boolean;
}

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal' | 'bet_settlement';
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  method: string;
  createdAt: string;
  completedAt?: string;
}

const PAYMENT_METHODS = [
  { type: 'card', name: 'Credit/Debit Card', icon: CreditCard, processingTime: 'Instant', fees: 'Free' },
  { type: 'bank', name: 'Bank Transfer', icon: ArrowDownCircle, processingTime: '1-3 days', fees: 'Free' },
  { type: 'crypto', name: 'Cryptocurrency', icon: '₿', processingTime: '10-30 min', fees: '1%' },
  { type: 'ewallet', name: 'Digital Wallet', icon: Wallet, processingTime: 'Instant', fees: 'Free' },
];

export default function PaymentCenter() {
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw' | 'methods' | 'history'>('deposit');
  const [amount, setAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: balance } = useQuery({
    queryKey: ["/api/user/balance"],
  });

  const { data: paymentMethods = [] } = useQuery<PaymentMethod[]>({
    queryKey: ["/api/payment/methods"],
  });

  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const depositMutation = useMutation({
    mutationFn: async (data: { amount: number; methodId: string }) => {
      return apiRequest("/api/payment/deposit", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Deposit Initiated",
        description: "Your deposit is being processed",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/balance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      setAmount('');
    },
    onError: () => {
      toast({
        title: "Deposit Failed",
        description: "Please try again or contact support",
        variant: "destructive",
      });
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (data: { amount: number; methodId: string }) => {
      return apiRequest("/api/payment/withdraw", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal Initiated",
        description: "Your withdrawal request has been submitted",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/balance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      setAmount('');
    },
  });

  const handleDeposit = () => {
    if (!amount || !selectedMethod) return;
    depositMutation.mutate({ amount: parseFloat(amount), methodId: selectedMethod });
  };

  const handleWithdraw = () => {
    if (!amount || !selectedMethod) return;
    withdrawMutation.mutate({ amount: parseFloat(amount), methodId: selectedMethod });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-winnex-green';
      case 'pending': return 'text-winnex-orange';
      case 'failed': return 'text-red-400';
      default: return 'text-white/60';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle size={16} className="text-winnex-green" />;
      case 'pending': return <Clock size={16} className="text-winnex-orange" />;
      case 'failed': return <ArrowDownCircle size={16} className="text-red-400" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Balance Card */}
      <div className="card-modern p-6 gradient-accent">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Account Balance</h2>
            <div className="text-4xl font-black text-white">${balance || '0.00'}</div>
          </div>
          <div className="glass rounded-2xl p-4">
            <Wallet className="text-white" size={32} />
          </div>
        </div>
        <div className="flex justify-between items-center mt-6 pt-4 border-t border-white/20">
          <div className="text-center">
            <div className="text-sm text-white/70">Available</div>
            <div className="font-bold text-white">${balance || '0.00'}</div>
          </div>
          <div className="text-center">
            <div className="text-sm text-white/70">Pending</div>
            <div className="font-bold text-white">$0.00</div>
          </div>
          <div className="text-center">
            <div className="text-sm text-white/70">Bonus</div>
            <div className="font-bold text-winnex-green">$25.00</div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="glass rounded-xl p-1 flex">
        {(['deposit', 'withdraw', 'methods', 'history'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all capitalize ${
              activeTab === tab ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Deposit Tab */}
      {activeTab === 'deposit' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card-modern p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <ArrowUpCircle className="mr-2 text-winnex-green" size={20} />
              Deposit Funds
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Amount</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60" size={16} />
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full pl-10 pr-4 py-3 bg-secondary rounded-lg border border-white/10 text-white"
                  />
                </div>
                <div className="flex gap-2 mt-2">
                  {[25, 50, 100, 250].map((preset) => (
                    <button
                      key={preset}
                      onClick={() => setAmount(preset.toString())}
                      className="btn-secondary text-sm px-3 py-1"
                    >
                      ${preset}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Payment Method</label>
                <div className="space-y-2">
                  {PAYMENT_METHODS.map((method) => (
                    <button
                      key={method.type}
                      onClick={() => setSelectedMethod(method.type)}
                      className={`w-full p-4 rounded-lg border transition-all text-left ${
                        selectedMethod === method.type
                          ? 'border-winnex-green bg-winnex-green/10'
                          : 'border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <method.icon size={20} className="text-winnex-green" />
                          <div>
                            <div className="font-medium">{method.name}</div>
                            <div className="text-sm text-white/60">{method.processingTime}</div>
                          </div>
                        </div>
                        <div className="text-sm">
                          <div className="text-winnex-green">{method.fees}</div>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleDeposit}
                disabled={!amount || !selectedMethod || depositMutation.isPending}
                className="btn-primary w-full"
              >
                {depositMutation.isPending ? 'Processing...' : 'Deposit Funds'}
              </button>
            </div>
          </div>

          <div className="card-modern p-6">
            <h3 className="text-xl font-bold mb-4">Deposit Information</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3 p-3 glass rounded-lg">
                <Shield className="text-winnex-green" size={20} />
                <div>
                  <div className="font-medium">Secure & Encrypted</div>
                  <div className="text-sm text-white/60">SSL 256-bit encryption</div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-semibold">Deposit Limits</h4>
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-white/60">Minimum:</span>
                    <span>$10</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Maximum (Daily):</span>
                    <span>$10,000</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Maximum (Monthly):</span>
                    <span>$50,000</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold">Processing Times</h4>
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-white/60">Credit/Debit Card:</span>
                    <span className="text-winnex-green">Instant</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Bank Transfer:</span>
                    <span>1-3 business days</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Cryptocurrency:</span>
                    <span>10-30 minutes</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Withdraw Tab */}
      {activeTab === 'withdraw' && (
        <div className="card-modern p-6 max-w-2xl mx-auto">
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <ArrowDownCircle className="mr-2 text-winnex-blue" size={20} />
            Withdraw Funds
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Amount</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60" size={16} />
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount"
                  max={balance || 0}
                  className="w-full pl-10 pr-4 py-3 bg-secondary rounded-lg border border-white/10 text-white"
                />
              </div>
              <div className="text-sm text-white/60 mt-1">
                Available: ${balance || '0.00'}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Withdrawal Method</label>
              <div className="space-y-2">
                {paymentMethods.filter(m => m.verified).map((method) => (
                  <button
                    key={method.id}
                    onClick={() => setSelectedMethod(method.id)}
                    className={`w-full p-4 rounded-lg border transition-all text-left ${
                      selectedMethod === method.id
                        ? 'border-winnex-blue bg-winnex-blue/10'
                        : 'border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <CreditCard size={20} className="text-winnex-blue" />
                        <div>
                          <div className="font-medium">{method.brand} •••• {method.last4}</div>
                          <div className="text-sm text-white/60">
                            {method.isDefault && <span className="text-winnex-green">Default</span>}
                          </div>
                        </div>
                      </div>
                      <CheckCircle size={16} className="text-winnex-green" />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleWithdraw}
              disabled={!amount || !selectedMethod || withdrawMutation.isPending}
              className="btn-primary w-full"
            >
              {withdrawMutation.isPending ? 'Processing...' : 'Request Withdrawal'}
            </button>

            <div className="p-4 glass rounded-lg">
              <div className="text-sm text-white/80">
                <strong>Withdrawal Policy:</strong> Withdrawals are processed within 24-48 hours. 
                First-time withdrawals may require additional verification.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Transaction History */}
      {activeTab === 'history' && (
        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4">Transaction History</h3>
          <div className="space-y-3">
            {transactions.length === 0 ? (
              <div className="text-center py-8 text-white/60">
                <DollarSign className="mx-auto mb-3" size={24} />
                <p>No transactions yet</p>
              </div>
            ) : (
              transactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-4 glass-hover rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(transaction.status)}
                    <div>
                      <div className="font-medium capitalize">{transaction.type.replace('_', ' ')}</div>
                      <div className="text-sm text-white/60">
                        {new Date(transaction.createdAt).toLocaleDateString()} via {transaction.method}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold ${
                      transaction.type === 'deposit' ? 'text-winnex-green' : 
                      transaction.type === 'withdrawal' ? 'text-winnex-blue' : 
                      'text-winnex-orange'
                    }`}>
                      {transaction.type === 'withdrawal' ? '-' : '+'}${transaction.amount.toFixed(2)}
                    </div>
                    <div className={`text-sm ${getStatusColor(transaction.status)}`}>
                      {transaction.status}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}