import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Settings, Users, TrendingUp, Shield, AlertTriangle, Database, Globe, DollarSign, Activity, Clock } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface SystemHealth {
  status: 'healthy' | 'warning' | 'critical';
  uptime: number;
  memoryUsage: number;
  cpuUsage: number;
  diskUsage: number;
  activeConnections: number;
  databaseConnections: number;
  queueSize: number;
  errorRate: number;
  responseTime: number;
}

interface PlatformMetrics {
  totalUsers: number;
  activeUsers: number;
  totalBets: number;
  totalVolume: number;
  revenue: number;
  profit: number;
  conversionRate: number;
  retentionRate: number;
  dailyActiveUsers: number;
  monthlyActiveUsers: number;
  averageSessionTime: number;
  churnRate: number;
}

interface UserManagement {
  recentRegistrations: Array<{
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    registrationDate: string;
    status: string;
    verificationLevel: string;
    totalDeposits: number;
    totalBets: number;
    lastActivity: string;
  }>;
  suspendedUsers: Array<{
    id: string;
    email: string;
    suspensionReason: string;
    suspendedAt: string;
    suspendedBy: string;
  }>;
  vipUsers: Array<{
    id: string;
    email: string;
    totalVolume: number;
    profitability: number;
    tier: string;
  }>;
}

interface OperationalControls {
  maintenanceMode: boolean;
  registrationEnabled: boolean;
  depositsEnabled: boolean;
  withdrawalsEnabled: boolean;
  bettingEnabled: boolean;
  liveBettingEnabled: boolean;
  bonusesEnabled: boolean;
  affiliateEnabled: boolean;
  maxConcurrentUsers: number;
  emergencyMode: boolean;
}

interface AuditLog {
  id: string;
  timestamp: string;
  adminId: string;
  adminEmail: string;
  action: string;
  target: string;
  targetId: string;
  changes: any;
  ipAddress: string;
  userAgent: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export default function AdvancedAdminPanel() {
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>('24h');
  const [selectedUser, setSelectedUser] = useState<string>('');
  const queryClient = useQueryClient();

  const { data: systemHealth } = useQuery({
    queryKey: ['/api/admin/system-health'],
    queryFn: () => apiRequest('/api/admin/system-health'),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: platformMetrics } = useQuery({
    queryKey: ['/api/admin/metrics', selectedTimeframe],
    queryFn: () => apiRequest(`/api/admin/metrics?timeframe=${selectedTimeframe}`),
  });

  const { data: userManagement } = useQuery({
    queryKey: ['/api/admin/user-management'],
    queryFn: () => apiRequest('/api/admin/user-management'),
  });

  const { data: operationalControls } = useQuery({
    queryKey: ['/api/admin/operational-controls'],
    queryFn: () => apiRequest('/api/admin/operational-controls'),
  });

  const { data: auditLogs } = useQuery({
    queryKey: ['/api/admin/audit-logs'],
    queryFn: () => apiRequest('/api/admin/audit-logs'),
  });

  const updateControlsMutation = useMutation({
    mutationFn: (data: Partial<OperationalControls>) =>
      apiRequest('/api/admin/update-controls', 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/operational-controls'] });
    },
  });

  const suspendUserMutation = useMutation({
    mutationFn: (data: { userId: string; reason: string; duration?: number }) =>
      apiRequest('/api/admin/suspend-user', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/user-management'] });
    },
  });

  const voidBetMutation = useMutation({
    mutationFn: (data: { betId: string; reason: string }) =>
      apiRequest('/api/admin/void-bet', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/metrics'] });
    },
  });

  const manualAdjustmentMutation = useMutation({
    mutationFn: (data: { userId: string; amount: number; reason: string; type: 'credit' | 'debit' }) =>
      apiRequest('/api/admin/manual-adjustment', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/user-management'] });
    },
  });

  const getHealthStatus = (status: string) => {
    switch (status) {
      case 'healthy': return { color: 'text-green-400', bg: 'bg-green-500/20' };
      case 'warning': return { color: 'text-yellow-400', bg: 'bg-yellow-500/20' };
      case 'critical': return { color: 'text-red-400', bg: 'bg-red-500/20' };
      default: return { color: 'text-gray-400', bg: 'bg-gray-500/20' };
    }
  };

  const healthStyle = getHealthStatus(systemHealth?.status || 'healthy');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Advanced Admin Panel</h1>
          <p className="text-slate-300">Comprehensive platform management and operational controls</p>
        </div>

        {/* System Health Overview */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <Card className={`border-white/10 backdrop-blur-xl ${healthStyle.bg}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm font-medium ${healthStyle.color}`}>System Status</p>
                  <p className={`text-2xl font-bold ${healthStyle.color}`}>
                    {systemHealth?.status?.toUpperCase() || 'UNKNOWN'}
                  </p>
                </div>
                <Activity className={`h-8 w-8 ${healthStyle.color}`} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-blue-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 text-sm font-medium">Active Users</p>
                  <p className="text-2xl font-bold text-white">{platformMetrics?.activeUsers?.toLocaleString() || 0}</p>
                </div>
                <Users className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-green-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Revenue (24h)</p>
                  <p className="text-2xl font-bold text-white">${platformMetrics?.revenue?.toLocaleString() || 0}</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-orange-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-400 text-sm font-medium">CPU Usage</p>
                  <p className="text-2xl font-bold text-white">{systemHealth?.cpuUsage || 0}%</p>
                </div>
                <Settings className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-purple-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-400 text-sm font-medium">Uptime</p>
                  <p className="text-2xl font-bold text-white">{systemHealth?.uptime || 0}%</p>
                </div>
                <Clock className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-green-500/20">
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-green-500/20">
              User Management
            </TabsTrigger>
            <TabsTrigger value="controls" className="data-[state=active]:bg-green-500/20">
              Operational Controls
            </TabsTrigger>
            <TabsTrigger value="audit" className="data-[state=active]:bg-green-500/20">
              Audit & Logs
            </TabsTrigger>
            <TabsTrigger value="tools" className="data-[state=active]:bg-green-500/20">
              Admin Tools
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Platform Analytics</h2>
              <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                <SelectTrigger className="w-48 bg-slate-800/50 border-slate-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last Hour</SelectItem>
                  <SelectItem value="24h">Last 24 Hours</SelectItem>
                  <SelectItem value="7d">Last 7 Days</SelectItem>
                  <SelectItem value="30d">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Platform Performance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-slate-400 text-sm">Total Bets</p>
                      <p className="text-2xl font-bold text-white">{platformMetrics?.totalBets?.toLocaleString() || 0}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 text-sm">Total Volume</p>
                      <p className="text-2xl font-bold text-white">${platformMetrics?.totalVolume?.toLocaleString() || 0}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 text-sm">Conversion Rate</p>
                      <p className="text-2xl font-bold text-green-400">{platformMetrics?.conversionRate || 0}%</p>
                    </div>
                    <div>
                      <p className="text-slate-400 text-sm">Retention Rate</p>
                      <p className="text-2xl font-bold text-blue-400">{platformMetrics?.retentionRate || 0}%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">System Resources</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-300">Memory Usage</span>
                        <span className="text-white">{systemHealth?.memoryUsage || 0}%</span>
                      </div>
                      <Progress value={systemHealth?.memoryUsage || 0} className="h-2 bg-slate-800" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-300">Disk Usage</span>
                        <span className="text-white">{systemHealth?.diskUsage || 0}%</span>
                      </div>
                      <Progress value={systemHealth?.diskUsage || 0} className="h-2 bg-slate-800" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-300">Active Connections</span>
                        <span className="text-white">{systemHealth?.activeConnections || 0}</span>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-300">Response Time</span>
                        <span className="text-white">{systemHealth?.responseTime || 0}ms</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Financial Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <p className="text-slate-400 text-sm">Revenue</p>
                    <p className="text-3xl font-bold text-green-400">${platformMetrics?.revenue?.toLocaleString() || 0}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-slate-400 text-sm">Profit</p>
                    <p className="text-3xl font-bold text-blue-400">${platformMetrics?.profit?.toLocaleString() || 0}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-slate-400 text-sm">Daily Active Users</p>
                    <p className="text-3xl font-bold text-purple-400">{platformMetrics?.dailyActiveUsers?.toLocaleString() || 0}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-slate-400 text-sm">Monthly Active Users</p>
                    <p className="text-3xl font-bold text-orange-400">{platformMetrics?.monthlyActiveUsers?.toLocaleString() || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Recent Registrations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {userManagement?.recentRegistrations?.map((user: any) => (
                      <div key={user.id} className="p-3 bg-slate-800/30 rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="text-white font-medium">{user.firstName} {user.lastName}</p>
                            <p className="text-slate-400 text-sm">{user.email}</p>
                          </div>
                          <Badge className="bg-green-500/20 text-green-400">
                            {user.status}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <p className="text-slate-400">Deposits</p>
                            <p className="text-white">${user.totalDeposits}</p>
                          </div>
                          <div>
                            <p className="text-slate-400">Bets</p>
                            <p className="text-white">{user.totalBets}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">VIP Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {userManagement?.vipUsers?.map((user: any) => (
                      <div key={user.id} className="p-3 bg-slate-800/30 rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="text-white font-medium">{user.email}</p>
                            <p className="text-slate-400 text-sm">Tier: {user.tier}</p>
                          </div>
                          <Badge className="bg-purple-500/20 text-purple-400">
                            VIP
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <p className="text-slate-400">Volume</p>
                            <p className="text-white">${user.totalVolume.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-slate-400">Profitability</p>
                            <p className={user.profitability >= 0 ? 'text-green-400' : 'text-red-400'}>
                              {user.profitability >= 0 ? '+' : ''}${user.profitability.toLocaleString()}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Suspended Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {userManagement?.suspendedUsers?.map((user: any) => (
                      <div key={user.id} className="p-3 bg-slate-800/30 rounded-lg border border-red-500/20">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="text-white font-medium">{user.email}</p>
                            <p className="text-slate-400 text-sm">{user.suspensionReason}</p>
                          </div>
                          <Badge className="bg-red-500/20 text-red-400">
                            Suspended
                          </Badge>
                        </div>
                        <p className="text-xs text-slate-400">
                          By: {user.suspendedBy} • {new Date(user.suspendedAt).toLocaleDateString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">User Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium text-white">Suspend User</h3>
                    <div className="space-y-3">
                      <Input
                        placeholder="User ID or Email"
                        value={selectedUser}
                        onChange={(e) => setSelectedUser(e.target.value)}
                        className="bg-slate-800/50 border-slate-600"
                      />
                      <Input
                        placeholder="Suspension Reason"
                        className="bg-slate-800/50 border-slate-600"
                      />
                      <Button 
                        className="w-full bg-red-500 hover:bg-red-600"
                        onClick={() => suspendUserMutation.mutate({
                          userId: selectedUser,
                          reason: 'Administrative action'
                        })}
                      >
                        Suspend User
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium text-white">Manual Balance Adjustment</h3>
                    <div className="space-y-3">
                      <Input
                        placeholder="User ID"
                        className="bg-slate-800/50 border-slate-600"
                      />
                      <Input
                        placeholder="Amount"
                        type="number"
                        className="bg-slate-800/50 border-slate-600"
                      />
                      <Input
                        placeholder="Reason"
                        className="bg-slate-800/50 border-slate-600"
                      />
                      <div className="flex space-x-2">
                        <Button className="flex-1 bg-green-500 hover:bg-green-600">
                          Credit
                        </Button>
                        <Button className="flex-1 bg-red-500 hover:bg-red-600">
                          Debit
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="controls" className="space-y-6">
            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Platform Controls</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium text-white">System Controls</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <span className="text-slate-300">Maintenance Mode</span>
                        <Button
                          size="sm"
                          variant={operationalControls?.maintenanceMode ? 'destructive' : 'default'}
                          onClick={() => updateControlsMutation.mutate({
                            maintenanceMode: !operationalControls?.maintenanceMode
                          })}
                        >
                          {operationalControls?.maintenanceMode ? 'Disable' : 'Enable'}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <span className="text-slate-300">Emergency Mode</span>
                        <Button
                          size="sm"
                          variant={operationalControls?.emergencyMode ? 'destructive' : 'default'}
                          onClick={() => updateControlsMutation.mutate({
                            emergencyMode: !operationalControls?.emergencyMode
                          })}
                        >
                          {operationalControls?.emergencyMode ? 'Disable' : 'Enable'}
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium text-white">User Features</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <span className="text-slate-300">Registration</span>
                        <Button
                          size="sm"
                          variant={operationalControls?.registrationEnabled ? 'default' : 'destructive'}
                          onClick={() => updateControlsMutation.mutate({
                            registrationEnabled: !operationalControls?.registrationEnabled
                          })}
                        >
                          {operationalControls?.registrationEnabled ? 'Enabled' : 'Disabled'}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <span className="text-slate-300">Betting</span>
                        <Button
                          size="sm"
                          variant={operationalControls?.bettingEnabled ? 'default' : 'destructive'}
                          onClick={() => updateControlsMutation.mutate({
                            bettingEnabled: !operationalControls?.bettingEnabled
                          })}
                        >
                          {operationalControls?.bettingEnabled ? 'Enabled' : 'Disabled'}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <span className="text-slate-300">Live Betting</span>
                        <Button
                          size="sm"
                          variant={operationalControls?.liveBettingEnabled ? 'default' : 'destructive'}
                          onClick={() => updateControlsMutation.mutate({
                            liveBettingEnabled: !operationalControls?.liveBettingEnabled
                          })}
                        >
                          {operationalControls?.liveBettingEnabled ? 'Enabled' : 'Disabled'}
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium text-white">Financial Controls</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <span className="text-slate-300">Deposits</span>
                        <Button
                          size="sm"
                          variant={operationalControls?.depositsEnabled ? 'default' : 'destructive'}
                          onClick={() => updateControlsMutation.mutate({
                            depositsEnabled: !operationalControls?.depositsEnabled
                          })}
                        >
                          {operationalControls?.depositsEnabled ? 'Enabled' : 'Disabled'}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <span className="text-slate-300">Withdrawals</span>
                        <Button
                          size="sm"
                          variant={operationalControls?.withdrawalsEnabled ? 'default' : 'destructive'}
                          onClick={() => updateControlsMutation.mutate({
                            withdrawalsEnabled: !operationalControls?.withdrawalsEnabled
                          })}
                        >
                          {operationalControls?.withdrawalsEnabled ? 'Enabled' : 'Disabled'}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <span className="text-slate-300">Bonuses</span>
                        <Button
                          size="sm"
                          variant={operationalControls?.bonusesEnabled ? 'default' : 'destructive'}
                          onClick={() => updateControlsMutation.mutate({
                            bonusesEnabled: !operationalControls?.bonusesEnabled
                          })}
                        >
                          {operationalControls?.bonusesEnabled ? 'Enabled' : 'Disabled'}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audit" className="space-y-6">
            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Admin Activity Audit Log</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {auditLogs?.map((log: AuditLog) => (
                    <div key={log.id} className="p-4 bg-slate-800/30 rounded-lg border border-slate-600/30">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${
                            log.severity === 'critical' ? 'bg-red-500' :
                            log.severity === 'high' ? 'bg-orange-500' :
                            log.severity === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'
                          }`} />
                          <div>
                            <p className="text-white font-medium">{log.action}</p>
                            <p className="text-slate-400 text-sm">
                              Admin: {log.adminEmail} • Target: {log.target}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={`${
                            log.severity === 'critical' ? 'bg-red-500/20 text-red-400' :
                            log.severity === 'high' ? 'bg-orange-500/20 text-orange-400' :
                            log.severity === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-blue-500/20 text-blue-400'
                          }`}>
                            {log.severity}
                          </Badge>
                          <p className="text-slate-400 text-sm mt-1">
                            {new Date(log.timestamp).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      
                      {log.changes && (
                        <div className="text-sm">
                          <p className="text-slate-400 mb-1">Changes:</p>
                          <pre className="text-slate-300 bg-slate-900/50 p-2 rounded text-xs overflow-x-auto">
                            {JSON.stringify(log.changes, null, 2)}
                          </pre>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tools" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Bet Management Tools</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <Input
                      placeholder="Bet ID"
                      className="bg-slate-800/50 border-slate-600"
                    />
                    <Input
                      placeholder="Void Reason"
                      className="bg-slate-800/50 border-slate-600"
                    />
                    <Button className="w-full bg-red-500 hover:bg-red-600">
                      Void Bet
                    </Button>
                  </div>
                  
                  <div className="pt-4 border-t border-slate-600">
                    <Button className="w-full bg-blue-500 hover:bg-blue-600">
                      Manual Settlement
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">System Tools</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full bg-purple-500 hover:bg-purple-600">
                    Clear Cache
                  </Button>
                  <Button className="w-full bg-orange-500 hover:bg-orange-600">
                    Restart Services
                  </Button>
                  <Button className="w-full bg-green-500 hover:bg-green-600">
                    Generate Report
                  </Button>
                  <Button className="w-full bg-yellow-500 hover:bg-yellow-600">
                    Database Backup
                  </Button>
                  <Button className="w-full bg-red-500 hover:bg-red-600">
                    Emergency Shutdown
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}