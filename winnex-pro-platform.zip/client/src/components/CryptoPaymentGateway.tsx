import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Bitcoin, Coins, TrendingUp, Clock, CheckCircle, AlertCircle, Copy, QrCode } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface CryptoCurrency {
  symbol: string;
  name: string;
  network: string;
  address: string;
  rate: number;
  minDeposit: number;
  maxDeposit: number;
  confirmations: number;
  fees: number;
  icon: string;
  available: boolean;
}

interface CryptoTransaction {
  id: string;
  currency: string;
  amount: number;
  usdValue: number;
  address: string;
  txHash?: string;
  status: 'pending' | 'confirming' | 'completed' | 'failed';
  confirmations: number;
  requiredConfirmations: number;
  timestamp: string;
  type: 'deposit' | 'withdrawal';
}

interface WalletBalance {
  symbol: string;
  balance: number;
  usdValue: number;
  pending: number;
}

export default function CryptoPaymentGateway() {
  const [selectedCurrency, setSelectedCurrency] = useState<string>('BTC');
  const [depositAmount, setDepositAmount] = useState<number>(0);
  const [withdrawAmount, setWithdrawAmount] = useState<number>(0);
  const [withdrawAddress, setWithdrawAddress] = useState<string>('');
  const [activeTab, setActiveTab] = useState('deposit');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Supported cryptocurrencies with competitive rates
  const cryptoCurrencies: CryptoCurrency[] = [
    {
      symbol: 'BTC',
      name: 'Bitcoin',
      network: 'Bitcoin',
      address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
      rate: 67420.50,
      minDeposit: 0.0001,
      maxDeposit: 10,
      confirmations: 1,
      fees: 0.0005,
      icon: '₿',
      available: true
    },
    {
      symbol: 'ETH',
      name: 'Ethereum',
      network: 'Ethereum',
      address: '0x742d35Cc6634C0532925a3b8D15dB0b3d8CB5c2A',
      rate: 3847.25,
      minDeposit: 0.001,
      maxDeposit: 100,
      confirmations: 12,
      fees: 0.01,
      icon: 'Ξ',
      available: true
    },
    {
      symbol: 'USDT',
      name: 'Tether',
      network: 'TRC20',
      address: 'TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE',
      rate: 1.00,
      minDeposit: 10,
      maxDeposit: 50000,
      confirmations: 1,
      fees: 1.00,
      icon: '₮',
      available: true
    },
    {
      symbol: 'LTC',
      name: 'Litecoin',
      network: 'Litecoin',
      address: 'LQN2YnRgZKM5JwUF6Zw6b8YWd4V6uMn4Z2',
      rate: 142.85,
      minDeposit: 0.01,
      maxDeposit: 500,
      confirmations: 6,
      fees: 0.001,
      icon: 'Ł',
      available: true
    },
    {
      symbol: 'DOGE',
      name: 'Dogecoin',
      network: 'Dogecoin',
      address: 'DH5yaieqoZN36fDVciNyRueRGvGLR3mr7L',
      rate: 0.32,
      minDeposit: 50,
      maxDeposit: 100000,
      confirmations: 6,
      fees: 1,
      icon: 'Ð',
      available: true
    }
  ];

  // Mock transactions for demo
  const mockTransactions: CryptoTransaction[] = [
    {
      id: 'tx_001',
      currency: 'BTC',
      amount: 0.0025,
      usdValue: 168.55,
      address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
      txHash: 'a1b2c3d4e5f6789012345678901234567890abcdef',
      status: 'completed',
      confirmations: 6,
      requiredConfirmations: 1,
      timestamp: '2024-06-14T14:30:00Z',
      type: 'deposit'
    },
    {
      id: 'tx_002',
      currency: 'ETH',
      amount: 0.05,
      usdValue: 192.36,
      address: '0x742d35Cc6634C0532925a3b8D15dB0b3d8CB5c2A',
      status: 'confirming',
      confirmations: 8,
      requiredConfirmations: 12,
      timestamp: '2024-06-14T15:45:00Z',
      type: 'deposit'
    }
  ];

  const selectedCrypto = cryptoCurrencies.find(crypto => crypto.symbol === selectedCurrency);
  const usdValue = depositAmount * (selectedCrypto?.rate || 0);

  // Generate deposit address mutation
  const generateAddressMutation = useMutation({
    mutationFn: async (currency: string) => {
      return apiRequest('POST', '/api/crypto/generate-address', { currency });
    },
    onSuccess: (data) => {
      toast({
        title: "Deposit Address Generated",
        description: "Your unique deposit address has been created.",
      });
    }
  });

  // Process withdrawal mutation
  const withdrawMutation = useMutation({
    mutationFn: async (withdrawalData: any) => {
      return apiRequest('POST', '/api/crypto/withdraw', withdrawalData);
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal Initiated",
        description: "Your withdrawal has been submitted for processing.",
      });
      setWithdrawAmount(0);
      setWithdrawAddress('');
      queryClient.invalidateQueries({ queryKey: ['/api/user/balance'] });
    },
    onError: (error: any) => {
      toast({
        title: "Withdrawal Failed",
        description: error.message || "Unable to process withdrawal.",
        variant: "destructive",
      });
    }
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Address copied to clipboard",
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-400';
      case 'confirming': return 'text-yellow-400';
      case 'pending': return 'text-blue-400';
      case 'failed': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'confirming': return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'pending': return <Clock className="w-4 h-4 text-blue-400" />;
      case 'failed': return <AlertCircle className="w-4 h-4 text-red-400" />;
      default: return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Crypto Gateway Header */}
      <Card className="bg-gradient-to-r from-orange-500/20 to-yellow-500/20 border-orange-500/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-500/20 rounded-lg">
                <Bitcoin className="w-6 h-6 text-orange-400" />
              </div>
              <div>
                <CardTitle className="text-xl">Crypto Payment Gateway</CardTitle>
                <p className="text-sm text-gray-400">Instant deposits • Fast withdrawals • 5+ cryptocurrencies</p>
              </div>
            </div>
            <Badge className="bg-orange-500 text-white">
              <Coins className="w-3 h-3 mr-1" />
              LIVE
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Currency Rates */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {cryptoCurrencies.map((crypto) => (
          <Card 
            key={crypto.symbol} 
            className={`bg-winnex-gray border-gray-600 cursor-pointer transition-all hover:border-orange-400 ${
              selectedCurrency === crypto.symbol ? 'border-orange-400 bg-orange-500/10' : ''
            }`}
            onClick={() => setSelectedCurrency(crypto.symbol)}
          >
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold mb-1">{crypto.icon}</div>
              <div className="font-medium text-sm">{crypto.symbol}</div>
              <div className="text-xs text-gray-400">${crypto.rate.toLocaleString()}</div>
              {crypto.symbol === 'BTC' && (
                <div className="flex items-center justify-center mt-1">
                  <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
                  <span className="text-xs text-green-400">+2.4%</span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 bg-winnex-dark">
          <TabsTrigger value="deposit">Deposit</TabsTrigger>
          <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="deposit" className="space-y-4">
          <Card className="bg-winnex-gray border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Coins className="w-5 h-5 mr-2 text-orange-400" />
                Crypto Deposit
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-300">Currency</label>
                  <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
                    <SelectTrigger className="bg-winnex-dark border-gray-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {cryptoCurrencies.map((crypto) => (
                        <SelectItem key={crypto.symbol} value={crypto.symbol}>
                          <div className="flex items-center space-x-2">
                            <span>{crypto.icon}</span>
                            <span>{crypto.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-300">Amount</label>
                  <Input
                    type="number"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(parseFloat(e.target.value) || 0)}
                    className="bg-winnex-dark border-gray-600"
                    placeholder={`Min: ${selectedCrypto?.minDeposit}`}
                  />
                </div>
              </div>

              {depositAmount > 0 && selectedCrypto && (
                <div className="bg-winnex-dark rounded-lg p-4 space-y-2">
                  <div className="flex justify-between">
                    <span>Amount:</span>
                    <span className="font-medium">{depositAmount} {selectedCurrency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>USD Value:</span>
                    <span className="font-medium text-winnex-green">${usdValue.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Network:</span>
                    <span className="text-sm">{selectedCrypto.network}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Confirmations:</span>
                    <span className="text-sm">{selectedCrypto.confirmations}</span>
                  </div>
                </div>
              )}

              {selectedCrypto && (
                <div className="bg-gradient-to-r from-orange-500/10 to-yellow-500/10 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium">Deposit Address</h4>
                    <Button size="sm" variant="outline" className="border-gray-600">
                      <QrCode className="w-4 h-4 mr-2" />
                      QR Code
                    </Button>
                  </div>
                  <div className="bg-winnex-dark rounded p-3 flex items-center justify-between">
                    <code className="text-sm break-all">{selectedCrypto.address}</code>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(selectedCrypto.address)}
                      className="ml-2"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="mt-3 text-xs text-gray-400">
                    <p>• Send only {selectedCrypto.name} to this address</p>
                    <p>• Minimum deposit: {selectedCrypto.minDeposit} {selectedCurrency}</p>
                    <p>• Funds will be credited after {selectedCrypto.confirmations} confirmations</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="withdraw" className="space-y-4">
          <Card className="bg-winnex-gray border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-orange-400" />
                Crypto Withdrawal
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-300">Currency</label>
                  <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
                    <SelectTrigger className="bg-winnex-dark border-gray-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {cryptoCurrencies.map((crypto) => (
                        <SelectItem key={crypto.symbol} value={crypto.symbol}>
                          <div className="flex items-center space-x-2">
                            <span>{crypto.icon}</span>
                            <span>{crypto.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-300">Amount</label>
                  <Input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(parseFloat(e.target.value) || 0)}
                    className="bg-winnex-dark border-gray-600"
                    placeholder="Enter amount"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-300">Withdrawal Address</label>
                <Input
                  value={withdrawAddress}
                  onChange={(e) => setWithdrawAddress(e.target.value)}
                  className="bg-winnex-dark border-gray-600"
                  placeholder={`Enter ${selectedCurrency} address`}
                />
              </div>

              {withdrawAmount > 0 && selectedCrypto && (
                <div className="bg-winnex-dark rounded-lg p-4 space-y-2">
                  <div className="flex justify-between">
                    <span>Amount:</span>
                    <span className="font-medium">{withdrawAmount} {selectedCurrency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Network Fee:</span>
                    <span className="text-red-400">{selectedCrypto.fees} {selectedCurrency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>You'll Receive:</span>
                    <span className="font-medium text-winnex-green">
                      {(withdrawAmount - selectedCrypto.fees).toFixed(8)} {selectedCurrency}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>USD Value:</span>
                    <span className="font-medium">${((withdrawAmount - selectedCrypto.fees) * selectedCrypto.rate).toFixed(2)}</span>
                  </div>
                </div>
              )}

              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="w-4 h-4 text-yellow-400 mt-0.5" />
                  <div className="text-sm text-yellow-200">
                    <p className="font-medium">Important:</p>
                    <ul className="text-xs mt-1 space-y-1">
                      <li>• Withdrawals are processed within 10-30 minutes</li>
                      <li>• Double-check your address - transactions are irreversible</li>
                      <li>• Minimum withdrawal: {selectedCrypto?.minDeposit} {selectedCurrency}</li>
                    </ul>
                  </div>
                </div>
              </div>

              <Button
                onClick={() => withdrawMutation.mutate({
                  currency: selectedCurrency,
                  amount: withdrawAmount,
                  address: withdrawAddress
                })}
                disabled={withdrawMutation.isPending || !withdrawAddress || withdrawAmount <= 0}
                className="w-full bg-orange-500 text-white hover:bg-orange-400"
              >
                {withdrawMutation.isPending ? "Processing..." : "Withdraw Crypto"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <div className="space-y-4">
            {mockTransactions.map((tx) => (
              <Card key={tx.id} className="bg-winnex-gray border-gray-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="text-xl">
                        {cryptoCurrencies.find(c => c.symbol === tx.currency)?.icon}
                      </div>
                      <div>
                        <div className="font-medium">
                          {tx.type === 'deposit' ? 'Deposit' : 'Withdrawal'} • {tx.currency}
                        </div>
                        <div className="text-sm text-gray-400">
                          {new Date(tx.timestamp).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(tx.status)}
                        <span className={`text-sm font-medium ${getStatusColor(tx.status)}`}>
                          {tx.status.toUpperCase()}
                        </span>
                      </div>
                      <div className="text-sm font-medium">
                        {tx.amount} {tx.currency}
                      </div>
                      <div className="text-xs text-gray-400">
                        ${tx.usdValue.toFixed(2)}
                      </div>
                    </div>
                  </div>
                  
                  {tx.status === 'confirming' && (
                    <div className="mt-3">
                      <div className="flex justify-between text-xs text-gray-400 mb-1">
                        <span>Confirmations</span>
                        <span>{tx.confirmations}/{tx.requiredConfirmations}</span>
                      </div>
                      <Progress 
                        value={(tx.confirmations / tx.requiredConfirmations) * 100} 
                        className="h-2"
                      />
                    </div>
                  )}
                  
                  {tx.txHash && (
                    <div className="mt-3 text-xs">
                      <span className="text-gray-400">TX Hash: </span>
                      <code className="text-winnex-green">{tx.txHash.substring(0, 20)}...</code>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(tx.txHash!)}
                        className="ml-1 h-4 w-4 p-0"
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Crypto Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-winnex-gray border-gray-600 p-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-400">5</div>
            <div className="text-sm text-gray-400">Cryptocurrencies</div>
          </div>
        </Card>
        <Card className="bg-winnex-gray border-gray-600 p-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">$47.2K</div>
            <div className="text-sm text-gray-400">24h Volume</div>
          </div>
        </Card>
        <Card className="bg-winnex-gray border-gray-600 p-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400">98.9%</div>
            <div className="text-sm text-gray-400">Success Rate</div>
          </div>
        </Card>
        <Card className="bg-winnex-gray border-gray-600 p-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-winnex-green">~15min</div>
            <div className="text-sm text-gray-400">Avg Processing</div>
          </div>
        </Card>
      </div>
    </div>
  );
}