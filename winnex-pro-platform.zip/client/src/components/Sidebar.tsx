import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { 
  Volleyball, 
  Dumbbell, 
  Target, 
  Zap, 
  Gamepad2,
  Dice1,
  Coins,
  Spade
} from "lucide-react";
import type { Sport } from "@shared/schema";

interface SidebarProps {
  sports: Sport[];
}

const sportIcons: Record<string, any> = {
  football: Volleyball,
  basketball: Dumbbell,
  tennis: Target,
  hockey: Zap,
  esports: Gamepad2,
};

export default function Sidebar({ sports }: SidebarProps) {
  return (
    <aside className="w-64 bg-winnex-gray border-r border-gray-700 hidden lg:block">
      <div className="p-4">
        <div className="space-y-2">
          <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Popular Sports
          </div>
          <div className="space-y-1">
            {sports.map((sport) => {
              const Icon = sportIcons[sport.slug] || Volleyball;
              return (
                <Link 
                  key={sport.id} 
                  href="/sports"
                  className="flex items-center space-x-3 p-2 rounded-lg hover:bg-winnex-dark transition-colors cursor-pointer"
                >
                  <Icon className="text-winnex-orange" size={16} />
                  <span>{sport.name}</span>
                  <Badge variant="secondary" className="ml-auto bg-winnex-green text-black text-xs">
                    {Math.floor(Math.random() * 200) + 50}
                  </Badge>
                </Link>
              );
            })}
          </div>
        </div>

        <div className="mt-8 space-y-2">
          <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Casino
          </div>
          <div className="space-y-1">
            <Link href="/casino" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-winnex-dark transition-colors cursor-pointer">
              <Dice1 className="text-winnex-orange" size={16} />
              <span>Live Casino</span>
            </Link>
            <Link href="/casino" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-winnex-dark transition-colors cursor-pointer">
              <Coins className="text-winnex-orange" size={16} />
              <span>Slots</span>
            </Link>
            <Link href="/casino" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-winnex-dark transition-colors cursor-pointer">
              <Spade className="text-winnex-orange" size={16} />
              <span>Table Games</span>
            </Link>
          </div>
        </div>
      </div>
    </aside>
  );
}
