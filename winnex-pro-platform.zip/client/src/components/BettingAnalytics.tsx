import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, TrendingDown, DollarSign, Target, Calendar, Award } from "lucide-react";

interface BettingStats {
  totalBets: number;
  winRate: number;
  roi: number;
  totalStaked: number;
  totalWinnings: number;
  profit: number;
  avgOdds: number;
  longestWinStreak: number;
  longestLoseStreak: number;
  monthlyData: Array<{
    month: string;
    bets: number;
    profit: number;
    winRate: number;
  }>;
  sportBreakdown: Array<{
    sport: string;
    bets: number;
    profit: number;
    winRate: number;
  }>;
  recentPerformance: Array<{
    date: string;
    result: 'win' | 'loss';
    profit: number;
  }>;
}

const COLORS = ['#00ff9d', '#4299e1', '#f56565', '#ed8936', '#9f7aea'];

export default function BettingAnalytics() {
  const [timeFrame, setTimeFrame] = useState<'7d' | '30d' | '90d' | '1y'>('30d');

  const { data: stats } = useQuery<BettingStats>({
    queryKey: ["/api/analytics/betting", timeFrame],
  });

  if (!stats) {
    return (
      <div className="card-modern p-8 text-center">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-white/10 rounded"></div>
          <div className="h-32 bg-white/10 rounded"></div>
          <div className="h-32 bg-white/10 rounded"></div>
        </div>
      </div>
    );
  }

  const isProfit = stats.profit >= 0;

  return (
    <div className="space-y-6">
      {/* Header with Time Filter */}
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold gradient-accent bg-clip-text text-transparent">
          Betting Analytics
        </h2>
        <div className="flex bg-secondary rounded-xl p-1">
          {(['7d', '30d', '90d', '1y'] as const).map((period) => (
            <button
              key={period}
              onClick={() => setTimeFrame(period)}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                timeFrame === period ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
              }`}
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card-modern p-6">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="text-winnex-green" size={24} />
            <div className={`flex items-center ${isProfit ? 'text-winnex-green' : 'text-red-400'}`}>
              {isProfit ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            </div>
          </div>
          <div className={`text-2xl font-bold ${isProfit ? 'text-winnex-green' : 'text-red-400'}`}>
            ${Math.abs(stats.profit).toFixed(2)}
          </div>
          <div className="text-white/60 text-sm">
            {isProfit ? 'Total Profit' : 'Total Loss'}
          </div>
        </div>

        <div className="card-modern p-6">
          <div className="flex items-center justify-between mb-2">
            <Target className="text-winnex-blue" size={24} />
            <span className="text-xs bg-winnex-blue/20 text-winnex-blue px-2 py-1 rounded">
              WIN RATE
            </span>
          </div>
          <div className="text-2xl font-bold text-winnex-blue">
            {stats.winRate.toFixed(1)}%
          </div>
          <div className="text-white/60 text-sm">
            {stats.totalBets} total bets
          </div>
        </div>

        <div className="card-modern p-6">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="text-winnex-orange" size={24} />
            <span className="text-xs bg-winnex-orange/20 text-winnex-orange px-2 py-1 rounded">
              ROI
            </span>
          </div>
          <div className={`text-2xl font-bold ${stats.roi >= 0 ? 'text-winnex-orange' : 'text-red-400'}`}>
            {stats.roi >= 0 ? '+' : ''}{stats.roi.toFixed(1)}%
          </div>
          <div className="text-white/60 text-sm">
            Return on Investment
          </div>
        </div>

        <div className="card-modern p-6">
          <div className="flex items-center justify-between mb-2">
            <Award className="text-winnex-purple" size={24} />
            <span className="text-xs bg-winnex-purple/20 text-winnex-purple px-2 py-1 rounded">
              STREAK
            </span>
          </div>
          <div className="text-2xl font-bold text-winnex-purple">
            {stats.longestWinStreak}
          </div>
          <div className="text-white/60 text-sm">
            Longest win streak
          </div>
        </div>
      </div>

      {/* Performance Chart */}
      <div className="card-modern p-6">
        <h3 className="text-xl font-bold mb-4">Monthly Performance</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={stats.monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="month" stroke="rgba(255,255,255,0.6)" />
              <YAxis stroke="rgba(255,255,255,0.6)" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(0,0,0,0.8)', 
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="profit" 
                stroke="#00ff9d" 
                strokeWidth={2}
                dot={{ fill: '#00ff9d', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sports Breakdown */}
        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4">Sports Performance</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.sportBreakdown}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ sport, winRate }) => `${sport} (${winRate.toFixed(1)}%)`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="bets"
                >
                  {stats.sportBreakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0,0,0,0.8)', 
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Betting Volume */}
        <div className="card-modern p-6">
          <h3 className="text-xl font-bold mb-4">Monthly Betting Volume</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="month" stroke="rgba(255,255,255,0.6)" />
                <YAxis stroke="rgba(255,255,255,0.6)" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0,0,0,0.8)', 
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="bets" fill="#4299e1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Detailed Stats */}
      <div className="card-modern p-6">
        <h3 className="text-xl font-bold mb-4">Detailed Statistics</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-white mb-1">
              ${stats.totalStaked.toFixed(2)}
            </div>
            <div className="text-white/60 text-sm">Total Staked</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-winnex-green mb-1">
              ${stats.totalWinnings.toFixed(2)}
            </div>
            <div className="text-white/60 text-sm">Total Winnings</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-winnex-blue mb-1">
              {stats.avgOdds.toFixed(2)}
            </div>
            <div className="text-white/60 text-sm">Average Odds</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-400 mb-1">
              {stats.longestLoseStreak}
            </div>
            <div className="text-white/60 text-sm">Longest Lose Streak</div>
          </div>
        </div>
      </div>

      {/* Recent Performance */}
      <div className="card-modern p-6">
        <h3 className="text-xl font-bold mb-4">Recent Performance</h3>
        <div className="flex space-x-2 mb-4">
          {stats.recentPerformance.slice(-20).map((result, index) => (
            <div
              key={index}
              className={`w-4 h-4 rounded-full ${
                result.result === 'win' ? 'bg-winnex-green' : 'bg-red-400'
              }`}
              title={`${result.date}: ${result.result} (${result.profit >= 0 ? '+' : ''}$${result.profit.toFixed(2)})`}
            ></div>
          ))}
        </div>
        <div className="text-sm text-white/60">
          Last 20 bets • Green = Win, Red = Loss
        </div>
      </div>
    </div>
  );
}