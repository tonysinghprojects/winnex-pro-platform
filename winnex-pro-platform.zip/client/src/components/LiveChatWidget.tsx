import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Send, X, Bot, User, Phone, Mail, TrendingUp, Minimize2, Maximize2 } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  id: string;
  sender: 'user' | 'agent' | 'bot';
  message: string;
  timestamp: Date;
  type: 'text' | 'cta' | 'bet_suggestion' | 'promotion';
  ctaButton?: {
    text: string;
    action: string;
    variant: 'primary' | 'secondary' | 'success';
  };
}

interface QuickAction {
  id: string;
  icon: React.ReactNode;
  label: string;
  action: string;
  description: string;
}

export default function LiveChatWidget() {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [agentStatus, setAgentStatus] = useState<'online' | 'away' | 'busy'>('online');
  const [unreadCount, setUnreadCount] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickActions: QuickAction[] = [
    {
      id: 'deposit',
      icon: <TrendingUp className="h-4 w-4" />,
      label: 'Deposit Crypto',
      action: 'deposit',
      description: 'Add funds to your account'
    },
    {
      id: 'contact',
      icon: <Phone className="h-4 w-4" />,
      label: 'Contact Support',
      action: 'support',
      description: 'Speak with our team'
    },
    {
      id: 'promotions',
      icon: <Mail className="h-4 w-4" />,
      label: 'View Promotions',
      action: 'promotions',
      description: 'See current offers'
    }
  ];

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      // Welcome message with CTAs
      setMessages([
        {
          id: '1',
          sender: 'bot',
          message: 'Welcome to Winnex! I\'m your AI betting assistant. How can I help you today?',
          timestamp: new Date(),
          type: 'text'
        },
        {
          id: '2',
          sender: 'bot',
          message: 'Start betting with crypto today! Get a 100% deposit bonus on your first deposit.',
          timestamp: new Date(),
          type: 'cta',
          ctaButton: {
            text: 'Claim Bonus',
            action: 'deposit_bonus',
            variant: 'primary'
          }
        }
      ]);
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Simulate AI assistant responses
  useEffect(() => {
    if (messages.length > 0 && messages[messages.length - 1].sender === 'user') {
      const lastMessage = messages[messages.length - 1].message.toLowerCase();
      
      setTimeout(() => {
        let response: ChatMessage;
        
        if (lastMessage.includes('deposit') || lastMessage.includes('fund')) {
          response = {
            id: Date.now().toString(),
            sender: 'bot',
            message: 'I can help you deposit crypto! We support BTC, ETH, USDT, and LTC with instant processing.',
            timestamp: new Date(),
            type: 'cta',
            ctaButton: {
              text: 'Open Crypto Wallet',
              action: 'crypto_wallet',
              variant: 'primary'
            }
          };
        } else if (lastMessage.includes('bet') || lastMessage.includes('odds')) {
          response = {
            id: Date.now().toString(),
            sender: 'bot',
            message: 'Check out today\'s best value bets! Our AI has identified several high-confidence opportunities.',
            timestamp: new Date(),
            type: 'bet_suggestion',
            ctaButton: {
              text: 'View AI Predictions',
              action: 'ai_predictions',
              variant: 'success'
            }
          };
        } else if (lastMessage.includes('bonus') || lastMessage.includes('promotion')) {
          response = {
            id: Date.now().toString(),
            sender: 'bot',
            message: 'Exclusive offer for you! Get 50% cashback on losses this week + free VIP upgrade.',
            timestamp: new Date(),
            type: 'promotion',
            ctaButton: {
              text: 'Claim Now',
              action: 'claim_promotion',
              variant: 'primary'
            }
          };
        } else {
          response = {
            id: Date.now().toString(),
            sender: 'bot',
            message: 'I understand you need help. Let me connect you with our live support team for personalized assistance.',
            timestamp: new Date(),
            type: 'cta',
            ctaButton: {
              text: 'Connect to Agent',
              action: 'connect_agent',
              variant: 'secondary'
            }
          };
        }
        
        setMessages(prev => [...prev, response]);
        if (!isOpen) {
          setUnreadCount(prev => prev + 1);
        }
      }, 1500);
    }
  }, [messages, isOpen]);

  const sendMessage = () => {
    if (!inputMessage.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      message: inputMessage,
      timestamp: new Date(),
      type: 'text'
    };

    setMessages(prev => [...prev, newMessage]);
    setInputMessage('');
  };

  const handleQuickAction = (action: string) => {
    let message = '';
    switch (action) {
      case 'deposit':
        message = 'I want to deposit cryptocurrency';
        break;
      case 'support':
        message = 'I need to speak with support';
        break;
      case 'promotions':
        message = 'Show me current promotions';
        break;
    }
    
    if (message) {
      setInputMessage(message);
      sendMessage();
    }
  };

  const handleCTAClick = (action: string) => {
    switch (action) {
      case 'deposit_bonus':
      case 'crypto_wallet':
        window.location.href = '/deposit';
        break;
      case 'ai_predictions':
        window.location.href = '/enhanced-ai';
        break;
      case 'claim_promotion':
        window.location.href = '/promotions';
        break;
      case 'connect_agent':
        // Simulate agent connection
        setAgentStatus('online');
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: 'agent',
          message: 'Hi! I\'m Sarah from Winnex Pro support. For specialized help: accounts@winnexpro.io (transactions), traders@winnexpro.io (betting), support@winnexpro.io (technical).',
          timestamp: new Date(),
          type: 'text'
        }]);
        break;
    }
    
    toast({
      title: "Action Triggered",
      description: "Processing your request...",
    });
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      setUnreadCount(0);
    }
  };

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={toggleChat}
          className="relative h-14 w-14 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg"
          size="lg"
        >
          <MessageCircle className="h-6 w-6 text-white" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-red-500 text-white text-xs">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className={`w-80 bg-white shadow-2xl border-0 transition-all duration-300 ${isMinimized ? 'h-16' : 'h-96'}`}>
        <CardHeader className="p-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${agentStatus === 'online' ? 'bg-green-400' : 'bg-yellow-400'}`} />
              <CardTitle className="text-lg">Winnex Pro Support</CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleMinimize}
                className="text-white hover:bg-white/20 p-1"
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleChat}
                className="text-white hover:bg-white/20 p-1"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <p className="text-sm opacity-90">
            {agentStatus === 'online' ? 'We\'re online and ready to help!' : 'Typically replies in minutes'}
          </p>
        </CardHeader>

        {!isMinimized && (
          <CardContent className="p-0 flex flex-col h-80">
            {/* Quick Actions */}
            <div className="p-3 border-b bg-gray-50">
              <div className="grid grid-cols-3 gap-2">
                {quickActions.map((action) => (
                  <Button
                    key={action.id}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickAction(action.action)}
                    className="flex flex-col h-auto p-2 text-xs"
                  >
                    {action.icon}
                    <span className="mt-1">{action.label}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-xs ${message.sender === 'user' ? 'order-2' : 'order-1'}`}>
                    <div className="flex items-center space-x-2 mb-1">
                      {message.sender !== 'user' && (
                        message.sender === 'bot' ? 
                          <Bot className="h-4 w-4 text-blue-500" /> : 
                          <User className="h-4 w-4 text-green-500" />
                      )}
                      <span className="text-xs text-gray-500">
                        {message.sender === 'user' ? 'You' : message.sender === 'bot' ? 'AI Assistant' : 'Sarah'}
                      </span>
                    </div>
                    <div
                      className={`rounded-lg p-3 ${
                        message.sender === 'user'
                          ? 'bg-blue-600 text-white'
                          : message.type === 'promotion'
                          ? 'bg-gradient-to-r from-green-100 to-blue-100 border border-green-200'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      <p className="text-sm">{message.message}</p>
                      
                      {message.ctaButton && (
                        <Button
                          onClick={() => handleCTAClick(message.ctaButton!.action)}
                          variant={message.ctaButton.variant === 'primary' ? 'default' : 'outline'}
                          size="sm"
                          className="mt-2 w-full"
                        >
                          {message.ctaButton.text}
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-3 border-t">
              <div className="flex space-x-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Type your message..."
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  className="flex-1"
                />
                <Button onClick={sendMessage} size="sm">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}