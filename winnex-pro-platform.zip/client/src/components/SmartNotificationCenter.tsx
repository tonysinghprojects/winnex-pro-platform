import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Bell, BellOff, TrendingUp, Target, AlertTriangle, 
  DollarSign, Trophy, Zap, Mail, MessageSquare, 
  Smartphone, Settings, Calendar, Clock, Filter
} from 'lucide-react';

interface NotificationSettings {
  email: boolean;
  sms: boolean;
  push: boolean;
  inApp: boolean;
}

interface SmartNotification {
  id: string;
  type: 'bet_recommendation' | 'price_alert' | 'promotion' | 'security' | 'win' | 'cashout';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  actionRequired: boolean;
  category: string;
  metadata?: {
    amount?: number;
    odds?: number;
    sport?: string;
    match?: string;
    currency?: string;
  };
  actions?: {
    primary?: { label: string; action: string };
    secondary?: { label: string; action: string };
  };
}

interface NotificationRule {
  id: string;
  name: string;
  condition: string;
  enabled: boolean;
  channels: NotificationSettings;
  priority: 'low' | 'medium' | 'high';
}

export default function SmartNotificationCenter() {
  const { toast } = useToast();
  const [notifications, setNotifications] = useState<SmartNotification[]>([]);
  const [notificationRules, setNotificationRules] = useState<NotificationRule[]>([]);
  const [globalSettings, setGlobalSettings] = useState<NotificationSettings>({
    email: true,
    sms: true,
    push: true,
    inApp: true
  });
  const [activeTab, setActiveTab] = useState('notifications');
  const [filter, setFilter] = useState<'all' | 'unread' | 'high' | 'medium' | 'low'>('all');

  useEffect(() => {
    // Generate realistic notifications
    const generateNotifications = (): SmartNotification[] => [
      {
        id: '1',
        type: 'bet_recommendation',
        priority: 'high',
        title: 'High-Value Bet Opportunity',
        message: 'Lakers vs Celtics Over 220.5 points has 15% edge based on AI analysis',
        timestamp: new Date(Date.now() - 5 * 60 * 1000),
        read: false,
        actionRequired: true,
        category: 'AI Predictions',
        metadata: {
          odds: 1.95,
          sport: 'Basketball',
          match: 'Lakers vs Celtics'
        },
        actions: {
          primary: { label: 'Place Bet', action: 'place_bet' },
          secondary: { label: 'View Analysis', action: 'view_analysis' }
        }
      },
      {
        id: '2',
        type: 'price_alert',
        priority: 'medium',
        title: 'Bitcoin Price Alert',
        message: 'BTC reached your target price of $43,500. Consider your position.',
        timestamp: new Date(Date.now() - 15 * 60 * 1000),
        read: false,
        actionRequired: false,
        category: 'Price Alerts',
        metadata: {
          amount: 43500,
          currency: 'BTC'
        }
      },
      {
        id: '3',
        type: 'win',
        priority: 'high',
        title: 'Congratulations! You Won!',
        message: 'Your bet on Chiefs -3.5 won! $250.50 has been credited to your account.',
        timestamp: new Date(Date.now() - 30 * 60 * 1000),
        read: true,
        actionRequired: false,
        category: 'Winnings',
        metadata: {
          amount: 250.50,
          sport: 'Football',
          match: 'Chiefs vs Bills'
        }
      },
      {
        id: '4',
        type: 'cashout',
        priority: 'urgent',
        title: 'Cash Out Opportunity',
        message: 'Your Arsenal bet has 89% win probability. Secure $180 profit now?',
        timestamp: new Date(Date.now() - 2 * 60 * 1000),
        read: false,
        actionRequired: true,
        category: 'Cash Out',
        metadata: {
          amount: 180,
          sport: 'Soccer',
          match: 'Arsenal vs Chelsea'
        },
        actions: {
          primary: { label: 'Cash Out Now', action: 'cash_out' },
          secondary: { label: 'Let It Ride', action: 'dismiss' }
        }
      },
      {
        id: '5',
        type: 'promotion',
        priority: 'medium',
        title: 'VIP Upgrade Available',
        message: 'Complete 3 more bets to unlock VIP status with exclusive benefits!',
        timestamp: new Date(Date.now() - 45 * 60 * 1000),
        read: false,
        actionRequired: false,
        category: 'Promotions',
        actions: {
          primary: { label: 'View VIP Benefits', action: 'view_vip' },
          secondary: { label: 'Dismiss', action: 'dismiss' }
        }
      },
      {
        id: '6',
        type: 'security',
        priority: 'high',
        title: 'New Device Login',
        message: 'Someone logged into your account from a new device in London, UK.',
        timestamp: new Date(Date.now() - 60 * 60 * 1000),
        read: true,
        actionRequired: true,
        category: 'Security',
        actions: {
          primary: { label: 'Secure Account', action: 'security_check' },
          secondary: { label: 'It Was Me', action: 'confirm_login' }
        }
      }
    ];

    const generateRules = (): NotificationRule[] => [
      {
        id: '1',
        name: 'High-Value Betting Opportunities',
        condition: 'AI confidence > 85% AND expected value > 10%',
        enabled: true,
        channels: { email: true, sms: true, push: true, inApp: true },
        priority: 'high'
      },
      {
        id: '2',
        name: 'Price Alerts for Crypto Holdings',
        condition: 'Crypto price change > 5% in 24h',
        enabled: true,
        channels: { email: true, sms: false, push: true, inApp: true },
        priority: 'medium'
      },
      {
        id: '3',
        name: 'Winning Notifications',
        condition: 'Bet result = win AND amount > $50',
        enabled: true,
        channels: { email: true, sms: true, push: true, inApp: true },
        priority: 'high'
      },
      {
        id: '4',
        name: 'Cash Out Recommendations',
        condition: 'Win probability > 80% AND potential profit > $100',
        enabled: true,
        channels: { email: false, sms: true, push: true, inApp: true },
        priority: 'urgent'
      },
      {
        id: '5',
        name: 'Security Alerts',
        condition: 'Suspicious activity OR new device login',
        enabled: true,
        channels: { email: true, sms: true, push: true, inApp: true },
        priority: 'urgent'
      },
      {
        id: '6',
        name: 'VIP and Promotional Offers',
        condition: 'User eligible for upgrade OR special promotion available',
        enabled: true,
        channels: { email: true, sms: false, push: false, inApp: true },
        priority: 'low'
      }
    ];

    setNotifications(generateNotifications());
    setNotificationRules(generateRules());
  }, []);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 border-red-300 text-red-800';
      case 'high': return 'bg-orange-100 border-orange-300 text-orange-800';
      case 'medium': return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      default: return 'bg-blue-100 border-blue-300 text-blue-800';
    }
  };

  const getPriorityIcon = (type: string) => {
    switch (type) {
      case 'bet_recommendation': return <Target className="h-4 w-4" />;
      case 'price_alert': return <TrendingUp className="h-4 w-4" />;
      case 'promotion': return <Zap className="h-4 w-4" />;
      case 'security': return <AlertTriangle className="h-4 w-4" />;
      case 'win': return <Trophy className="h-4 w-4" />;
      case 'cashout': return <DollarSign className="h-4 w-4" />;
      default: return <Bell className="h-4 w-4" />;
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const handleAction = (action: string, notificationId: string) => {
    switch (action) {
      case 'place_bet':
        toast({ title: "Redirecting to bet placement...", description: "Opening bet slip" });
        break;
      case 'cash_out':
        toast({ title: "Cash out successful!", description: "Your winnings have been secured" });
        break;
      case 'view_analysis':
        toast({ title: "Opening AI analysis...", description: "Detailed prediction data" });
        break;
      case 'security_check':
        toast({ title: "Security review initiated", description: "Checking account activity" });
        break;
      default:
        toast({ title: "Action completed", description: "Your request has been processed" });
    }
    markAsRead(notificationId);
  };

  const toggleRule = (ruleId: string) => {
    setNotificationRules(prev =>
      prev.map(rule =>
        rule.id === ruleId ? { ...rule, enabled: !rule.enabled } : rule
      )
    );
  };

  const updateRuleChannels = (ruleId: string, channel: keyof NotificationSettings, enabled: boolean) => {
    setNotificationRules(prev =>
      prev.map(rule =>
        rule.id === ruleId
          ? { ...rule, channels: { ...rule.channels, [channel]: enabled } }
          : rule
      )
    );
  };

  const filteredNotifications = notifications.filter(notif => {
    if (filter === 'unread') return !notif.read;
    if (filter === 'high') return notif.priority === 'high' || notif.priority === 'urgent';
    if (filter === 'medium') return notif.priority === 'medium';
    if (filter === 'low') return notif.priority === 'low';
    return true;
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-4xl font-bold text-white">Notification Center</h1>
            {unreadCount > 0 && (
              <Badge variant="destructive" className="px-3 py-1">
                {unreadCount} unread
              </Badge>
            )}
          </div>
          <div className="flex items-center space-x-4">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as any)}
              className="bg-gray-800 text-white border border-gray-600 rounded-lg px-4 py-2"
            >
              <option value="all">All Notifications</option>
              <option value="unread">Unread Only</option>
              <option value="high">High Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="low">Low Priority</option>
            </select>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-black/40 border-gray-700">
            <TabsTrigger value="notifications" className="text-white">
              <Bell className="h-4 w-4 mr-2" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="rules" className="text-white">
              <Settings className="h-4 w-4 mr-2" />
              Smart Rules
            </TabsTrigger>
            <TabsTrigger value="settings" className="text-white">
              <Smartphone className="h-4 w-4 mr-2" />
              Preferences
            </TabsTrigger>
          </TabsList>

          {/* Notifications Tab */}
          <TabsContent value="notifications">
            <div className="space-y-4">
              {filteredNotifications.length === 0 ? (
                <Card className="bg-black/40 border-gray-700">
                  <CardContent className="p-8 text-center">
                    <BellOff className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">No notifications</h3>
                    <p className="text-gray-400">You're all caught up! No new notifications at the moment.</p>
                  </CardContent>
                </Card>
              ) : (
                filteredNotifications.map((notification) => (
                  <Card 
                    key={notification.id} 
                    className={`border-l-4 ${getPriorityColor(notification.priority)} ${
                      !notification.read ? 'bg-blue-50/10 border-blue-300' : 'bg-black/40 border-gray-700'
                    }`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3 flex-1">
                          <div className={`p-2 rounded-lg ${getPriorityColor(notification.priority)}`}>
                            {getPriorityIcon(notification.type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <h4 className="font-semibold text-white">{notification.title}</h4>
                              {!notification.read && (
                                <div className="w-2 h-2 bg-blue-500 rounded-full" />
                              )}
                              <Badge variant="outline" className="text-xs">
                                {notification.category}
                              </Badge>
                            </div>
                            <p className="text-gray-300 mb-2">{notification.message}</p>
                            {notification.metadata && (
                              <div className="flex items-center space-x-4 text-sm text-gray-400 mb-3">
                                {notification.metadata.sport && (
                                  <span>Sport: {notification.metadata.sport}</span>
                                )}
                                {notification.metadata.amount && (
                                  <span>Amount: ${notification.metadata.amount}</span>
                                )}
                                {notification.metadata.odds && (
                                  <span>Odds: {notification.metadata.odds}</span>
                                )}
                              </div>
                            )}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2 text-xs text-gray-400">
                                <Clock className="h-3 w-3" />
                                <span>{notification.timestamp.toLocaleTimeString()}</span>
                              </div>
                              {notification.actions && (
                                <div className="flex space-x-2">
                                  {notification.actions.secondary && (
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleAction(notification.actions!.secondary!.action, notification.id)}
                                    >
                                      {notification.actions.secondary.label}
                                    </Button>
                                  )}
                                  {notification.actions.primary && (
                                    <Button
                                      size="sm"
                                      onClick={() => handleAction(notification.actions!.primary!.action, notification.id)}
                                    >
                                      {notification.actions.primary.label}
                                    </Button>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Smart Rules Tab */}
          <TabsContent value="rules">
            <div className="space-y-4">
              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Smart Notification Rules</CardTitle>
                  <CardDescription className="text-gray-400">
                    Configure automated notifications based on AI analysis and market conditions
                  </CardDescription>
                </CardHeader>
              </Card>

              {notificationRules.map((rule) => (
                <Card key={rule.id} className="bg-black/40 border-gray-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Switch
                          checked={rule.enabled}
                          onCheckedChange={() => toggleRule(rule.id)}
                        />
                        <div>
                          <h4 className="font-semibold text-white">{rule.name}</h4>
                          <p className="text-sm text-gray-400">{rule.condition}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className={getPriorityColor(rule.priority)}>
                        {rule.priority}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-4 gap-4">
                      <div className="flex items-center space-x-2">
                        <Mail className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-300">Email</span>
                        <Switch
                          checked={rule.channels.email}
                          onCheckedChange={(checked) => updateRuleChannels(rule.id, 'email', checked)}
                          disabled={!rule.enabled}
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <MessageSquare className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-300">SMS</span>
                        <Switch
                          checked={rule.channels.sms}
                          onCheckedChange={(checked) => updateRuleChannels(rule.id, 'sms', checked)}
                          disabled={!rule.enabled}
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Smartphone className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-300">Push</span>
                        <Switch
                          checked={rule.channels.push}
                          onCheckedChange={(checked) => updateRuleChannels(rule.id, 'push', checked)}
                          disabled={!rule.enabled}
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Bell className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-300">In-App</span>
                        <Switch
                          checked={rule.channels.inApp}
                          onCheckedChange={(checked) => updateRuleChannels(rule.id, 'inApp', checked)}
                          disabled={!rule.enabled}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="space-y-6">
              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Global Notification Preferences</CardTitle>
                  <CardDescription className="text-gray-400">
                    Master controls for all notification channels
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Mail className="h-5 w-5 text-blue-400" />
                          <div>
                            <p className="font-medium text-white">Email Notifications</p>
                            <p className="text-sm text-gray-400">Receive detailed notifications via email</p>
                          </div>
                        </div>
                        <Switch
                          checked={globalSettings.email}
                          onCheckedChange={(checked) => 
                            setGlobalSettings(prev => ({ ...prev, email: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <MessageSquare className="h-5 w-5 text-green-400" />
                          <div>
                            <p className="font-medium text-white">SMS Notifications</p>
                            <p className="text-sm text-gray-400">Urgent alerts via text message</p>
                          </div>
                        </div>
                        <Switch
                          checked={globalSettings.sms}
                          onCheckedChange={(checked) => 
                            setGlobalSettings(prev => ({ ...prev, sms: checked }))
                          }
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Smartphone className="h-5 w-5 text-purple-400" />
                          <div>
                            <p className="font-medium text-white">Push Notifications</p>
                            <p className="text-sm text-gray-400">Real-time alerts on your device</p>
                          </div>
                        </div>
                        <Switch
                          checked={globalSettings.push}
                          onCheckedChange={(checked) => 
                            setGlobalSettings(prev => ({ ...prev, push: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Bell className="h-5 w-5 text-yellow-400" />
                          <div>
                            <p className="font-medium text-white">In-App Notifications</p>
                            <p className="text-sm text-gray-400">Notifications within the platform</p>
                          </div>
                        </div>
                        <Switch
                          checked={globalSettings.inApp}
                          onCheckedChange={(checked) => 
                            setGlobalSettings(prev => ({ ...prev, inApp: checked }))
                          }
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Notification Schedule</CardTitle>
                  <CardDescription className="text-gray-400">
                    Set quiet hours and frequency limits
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-white mb-2">
                        Quiet Hours Start
                      </label>
                      <input
                        type="time"
                        defaultValue="22:00"
                        className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-white mb-2">
                        Quiet Hours End
                      </label>
                      <input
                        type="time"
                        defaultValue="08:00"
                        className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-white mb-2">
                      Maximum Notifications Per Hour
                    </label>
                    <select className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white">
                      <option value="unlimited">Unlimited</option>
                      <option value="10">10 notifications</option>
                      <option value="5">5 notifications</option>
                      <option value="3">3 notifications</option>
                      <option value="1">1 notification</option>
                    </select>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}