import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, TrendingUp, Shield, Target, DollarSign } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface RiskProfile {
  userId: string;
  riskScore: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  exposureLimit: number;
  currentExposure: number;
  winLossRatio: number;
  avgBetSize: number;
  largestWin: number;
  largestLoss: number;
  consecutiveLosses: number;
  bettingVelocity: number; // bets per hour
  flags: Array<{
    type: string;
    severity: 'warning' | 'danger';
    message: string;
    timestamp: string;
  }>;
}

interface ExposureData {
  totalExposure: number;
  sportExposure: Array<{
    sport: string;
    exposure: number;
    limit: number;
    percentage: number;
  }>;
  marketExposure: Array<{
    market: string;
    exposure: number;
    limit: number;
    riskLevel: string;
  }>;
  largestSingleBet: number;
  worstCaseScenario: number;
}

interface LimitSettings {
  maxSingleBet: number;
  maxDailyExposure: number;
  maxWeeklyExposure: number;
  maxUserWinnings: number;
  suspiciousPatternThreshold: number;
  velocityLimit: number;
}

export default function RiskManagement() {
  const [selectedUser, setSelectedUser] = useState<string>('');
  const queryClient = useQueryClient();

  const { data: riskProfiles } = useQuery({
    queryKey: ['/api/risk/profiles'],
    queryFn: () => apiRequest('/api/risk/profiles'),
  });

  const { data: exposureData } = useQuery({
    queryKey: ['/api/risk/exposure'],
    queryFn: () => apiRequest('/api/risk/exposure'),
  });

  const { data: limitSettings } = useQuery({
    queryKey: ['/api/risk/limits'],
    queryFn: () => apiRequest('/api/risk/limits'),
  });

  const updateLimitsMutation = useMutation({
    mutationFn: (data: Partial<LimitSettings>) => 
      apiRequest('/api/risk/limits', 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/risk/limits'] });
    },
  });

  const flagUserMutation = useMutation({
    mutationFn: (data: { userId: string; flag: string; reason: string }) =>
      apiRequest('/api/risk/flag-user', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/risk/profiles'] });
    },
  });

  const highRiskUsers = riskProfiles?.filter((profile: RiskProfile) => 
    profile.riskLevel === 'high' || profile.riskLevel === 'critical'
  ) || [];

  const totalExposure = exposureData?.totalExposure || 0;
  const maxExposure = limitSettings?.maxDailyExposure || 1000000;
  const exposurePercentage = (totalExposure / maxExposure) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Risk Management Center</h1>
          <p className="text-slate-300">Monitor exposure, manage limits, and control operational risk</p>
        </div>

        {/* Alert Summary */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/20 border-red-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-400 text-sm font-medium">Critical Alerts</p>
                  <p className="text-3xl font-bold text-white">{highRiskUsers.length}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-orange-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-400 text-sm font-medium">Total Exposure</p>
                  <p className="text-3xl font-bold text-white">${totalExposure.toLocaleString()}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-blue-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 text-sm font-medium">Active Limits</p>
                  <p className="text-3xl font-bold text-white">12</p>
                </div>
                <Shield className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-green-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Exposure Utilization</p>
                  <p className="text-3xl font-bold text-white">{exposurePercentage.toFixed(1)}%</p>
                </div>
                <Target className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="exposure" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="exposure" className="data-[state=active]:bg-green-500/20">
              Exposure Management
            </TabsTrigger>
            <TabsTrigger value="profiles" className="data-[state=active]:bg-green-500/20">
              Risk Profiles
            </TabsTrigger>
            <TabsTrigger value="limits" className="data-[state=active]:bg-green-500/20">
              Limit Settings
            </TabsTrigger>
            <TabsTrigger value="monitoring" className="data-[state=active]:bg-green-500/20">
              Live Monitoring
            </TabsTrigger>
          </TabsList>

          <TabsContent value="exposure" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Exposure by Sport</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {exposureData?.sportExposure?.map((sport: any, index: number) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-300">{sport.sport}</span>
                        <span className="text-white">${sport.exposure.toLocaleString()}</span>
                      </div>
                      <Progress 
                        value={sport.percentage} 
                        className="h-2 bg-slate-800"
                      />
                      <div className="flex justify-between text-xs text-slate-400">
                        <span>Limit: ${sport.limit.toLocaleString()}</span>
                        <span>{sport.percentage.toFixed(1)}% utilized</span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Market Risk Analysis</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {exposureData?.marketExposure?.map((market: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                      <div>
                        <p className="text-white font-medium">{market.market}</p>
                        <p className="text-slate-400 text-sm">${market.exposure.toLocaleString()} exposure</p>
                      </div>
                      <Badge 
                        variant={market.riskLevel === 'high' ? 'destructive' : 'secondary'}
                        className="bg-opacity-20"
                      >
                        {market.riskLevel}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Exposure Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Total Exposure</span>
                    <span className="text-2xl font-bold text-white">${totalExposure.toLocaleString()}</span>
                  </div>
                  <Progress value={exposurePercentage} className="h-3 bg-slate-800" />
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4">
                    <div className="text-center">
                      <p className="text-slate-400 text-sm">Largest Single Bet</p>
                      <p className="text-white font-bold">${exposureData?.largestSingleBet?.toLocaleString() || 0}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-slate-400 text-sm">Worst Case Scenario</p>
                      <p className="text-red-400 font-bold">${exposureData?.worstCaseScenario?.toLocaleString() || 0}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-slate-400 text-sm">Available Capacity</p>
                      <p className="text-green-400 font-bold">${(maxExposure - totalExposure).toLocaleString()}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-slate-400 text-sm">Utilization</p>
                      <p className="text-blue-400 font-bold">{exposurePercentage.toFixed(1)}%</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profiles" className="space-y-6">
            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">High Risk User Profiles</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {highRiskUsers.map((profile: RiskProfile, index: number) => (
                    <div key={index} className="p-4 bg-slate-800/30 rounded-lg border border-red-500/20">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-pink-500 rounded-full flex items-center justify-center">
                            <span className="text-white font-bold text-sm">
                              {profile.userId.slice(0, 2).toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <p className="text-white font-medium">User {profile.userId}</p>
                            <p className="text-slate-400 text-sm">Risk Score: {profile.riskScore}</p>
                          </div>
                        </div>
                        <Badge 
                          variant={profile.riskLevel === 'critical' ? 'destructive' : 'secondary'}
                          className="bg-opacity-20"
                        >
                          {profile.riskLevel}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                        <div>
                          <p className="text-slate-400 text-xs">Current Exposure</p>
                          <p className="text-white font-bold">${profile.currentExposure?.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-xs">Win/Loss Ratio</p>
                          <p className="text-white font-bold">{profile.winLossRatio?.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-xs">Avg Bet Size</p>
                          <p className="text-white font-bold">${profile.avgBetSize?.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-xs">Consecutive Losses</p>
                          <p className="text-red-400 font-bold">{profile.consecutiveLosses}</p>
                        </div>
                      </div>

                      {profile.flags && profile.flags.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-slate-300 text-sm font-medium">Active Flags:</p>
                          {profile.flags.map((flag: any, flagIndex: number) => (
                            <Alert key={flagIndex} className="bg-red-900/20 border-red-500/20">
                              <AlertTriangle className="h-4 w-4" />
                              <AlertDescription className="text-red-300">
                                {flag.message}
                              </AlertDescription>
                            </Alert>
                          ))}
                        </div>
                      )}

                      <div className="flex space-x-2 mt-3">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-red-500/20 text-red-400 hover:bg-red-500/10"
                          onClick={() => flagUserMutation.mutate({
                            userId: profile.userId,
                            flag: 'manual_review',
                            reason: 'High risk profile flagged for manual review'
                          })}
                        >
                          Flag for Review
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-orange-500/20 text-orange-400 hover:bg-orange-500/10"
                        >
                          Apply Limits
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="limits" className="space-y-6">
            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Risk Limit Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="maxSingleBet" className="text-slate-300">Maximum Single Bet</Label>
                      <Input
                        id="maxSingleBet"
                        type="number"
                        defaultValue={limitSettings?.maxSingleBet || 10000}
                        className="bg-slate-800/50 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <Label htmlFor="maxDailyExposure" className="text-slate-300">Maximum Daily Exposure</Label>
                      <Input
                        id="maxDailyExposure"
                        type="number"
                        defaultValue={limitSettings?.maxDailyExposure || 1000000}
                        className="bg-slate-800/50 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <Label htmlFor="maxWeeklyExposure" className="text-slate-300">Maximum Weekly Exposure</Label>
                      <Input
                        id="maxWeeklyExposure"
                        type="number"
                        defaultValue={limitSettings?.maxWeeklyExposure || 5000000}
                        className="bg-slate-800/50 border-slate-600 text-white"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="maxUserWinnings" className="text-slate-300">Maximum User Winnings</Label>
                      <Input
                        id="maxUserWinnings"
                        type="number"
                        defaultValue={limitSettings?.maxUserWinnings || 100000}
                        className="bg-slate-800/50 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <Label htmlFor="suspiciousThreshold" className="text-slate-300">Suspicious Pattern Threshold</Label>
                      <Input
                        id="suspiciousThreshold"
                        type="number"
                        defaultValue={limitSettings?.suspiciousPatternThreshold || 85}
                        className="bg-slate-800/50 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <Label htmlFor="velocityLimit" className="text-slate-300">Betting Velocity Limit (bets/hour)</Label>
                      <Input
                        id="velocityLimit"
                        type="number"
                        defaultValue={limitSettings?.velocityLimit || 20}
                        className="bg-slate-800/50 border-slate-600 text-white"
                      />
                    </div>
                  </div>
                </div>
                
                <Button 
                  className="w-full bg-green-500 hover:bg-green-600 text-white"
                  onClick={() => updateLimitsMutation.mutate(limitSettings)}
                >
                  Update Risk Limits
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monitoring" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Live Alerts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Alert className="bg-red-900/20 border-red-500/20">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-red-300">
                        User ABC123 exceeded velocity limit
                      </AlertDescription>
                    </Alert>
                    <Alert className="bg-orange-900/20 border-orange-500/20">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-orange-300">
                        Football exposure at 85% of daily limit
                      </AlertDescription>
                    </Alert>
                    <Alert className="bg-yellow-900/20 border-yellow-500/20">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-yellow-300">
                        Unusual betting pattern detected
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white text-lg">System Health</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Risk Engine</span>
                      <Badge className="bg-green-500/20 text-green-400">Online</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Fraud Detection</span>
                      <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Limit Monitoring</span>
                      <Badge className="bg-green-500/20 text-green-400">Running</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Auto-Balancing</span>
                      <Badge className="bg-blue-500/20 text-blue-400">Enabled</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30">
                    Emergency Stop
                  </Button>
                  <Button className="w-full bg-orange-500/20 border border-orange-500/30 text-orange-400 hover:bg-orange-500/30">
                    Tighten Limits
                  </Button>
                  <Button className="w-full bg-blue-500/20 border border-blue-500/30 text-blue-400 hover:bg-blue-500/30">
                    Generate Report
                  </Button>
                  <Button className="w-full bg-green-500/20 border border-green-500/30 text-green-400 hover:bg-green-500/30">
                    Manual Balance
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}