import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CreditCard, Banknote, Smartphone, Globe, Shield, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface PaymentProvider {
  id: string;
  name: string;
  type: 'card' | 'bank' | 'ewallet' | 'crypto' | 'mobile';
  status: 'active' | 'inactive' | 'maintenance' | 'error';
  processingFee: number;
  transactionLimit: number;
  dailyLimit: number;
  supportedCurrencies: string[];
  supportedCountries: string[];
  features: string[];
  lastUpdated: string;
  uptime: number;
  monthlyVolume: number;
  successRate: number;
}

interface PaymentTransaction {
  id: string;
  userId: string;
  type: 'deposit' | 'withdrawal' | 'refund' | 'chargeback';
  amount: number;
  currency: string;
  provider: string;
  method: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
  fees: number;
  netAmount: number;
  createdAt: string;
  completedAt?: string;
  failureReason?: string;
  reference: string;
  country: string;
  ipAddress: string;
}

interface PaymentStats {
  totalVolume: number;
  totalTransactions: number;
  successRate: number;
  averageProcessingTime: number;
  totalFees: number;
  chargebackRate: number;
  pendingAmount: number;
  failedTransactions: number;
  topProviders: Array<{
    name: string;
    volume: number;
    transactions: number;
    successRate: number;
  }>;
  volumeByMethod: Array<{
    method: string;
    volume: number;
    percentage: number;
  }>;
}

interface FraudAlert {
  id: string;
  transactionId: string;
  userId: string;
  type: 'velocity' | 'amount' | 'location' | 'device' | 'pattern';
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  riskScore: number;
  status: 'active' | 'resolved' | 'false_positive';
  createdAt: string;
  resolvedAt?: string;
}

export default function PaymentGatewayHub() {
  const [selectedProvider, setSelectedProvider] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const queryClient = useQueryClient();

  const { data: paymentStats } = useQuery({
    queryKey: ['/api/payments/stats'],
    queryFn: () => apiRequest('/api/payments/stats'),
  });

  const { data: providers } = useQuery({
    queryKey: ['/api/payments/providers'],
    queryFn: () => apiRequest('/api/payments/providers'),
  });

  const { data: transactions } = useQuery({
    queryKey: ['/api/payments/transactions', filterStatus],
    queryFn: () => apiRequest(`/api/payments/transactions?status=${filterStatus}`),
  });

  const { data: fraudAlerts } = useQuery({
    queryKey: ['/api/payments/fraud-alerts'],
    queryFn: () => apiRequest('/api/payments/fraud-alerts'),
  });

  const toggleProviderMutation = useMutation({
    mutationFn: (data: { providerId: string; status: string }) =>
      apiRequest('/api/payments/toggle-provider', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/payments/providers'] });
    },
  });

  const processTransactionMutation = useMutation({
    mutationFn: (data: { transactionId: string; action: string }) =>
      apiRequest('/api/payments/process-transaction', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/payments/transactions'] });
    },
  });

  const resolveFraudAlertMutation = useMutation({
    mutationFn: (data: { alertId: string; resolution: string }) =>
      apiRequest('/api/payments/resolve-fraud', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/payments/fraud-alerts'] });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': case 'completed': return 'bg-green-500/20 text-green-400 border-green-500/20';
      case 'failed': case 'error': return 'bg-red-500/20 text-red-400 border-red-500/20';
      case 'pending': case 'processing': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/20';
      case 'maintenance': return 'bg-orange-500/20 text-orange-400 border-orange-500/20';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/20';
    }
  };

  const getProviderIcon = (type: string) => {
    switch (type) {
      case 'card': return <CreditCard className="h-5 w-5" />;
      case 'bank': return <Banknote className="h-5 w-5" />;
      case 'mobile': return <Smartphone className="h-5 w-5" />;
      case 'ewallet': return <Globe className="h-5 w-5" />;
      default: return <Shield className="h-5 w-5" />;
    }
  };

  const activeProviders = providers?.filter((p: PaymentProvider) => p.status === 'active') || [];
  const criticalAlerts = fraudAlerts?.filter((a: FraudAlert) => a.severity === 'critical' && a.status === 'active') || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Payment Gateway Hub</h1>
          <p className="text-slate-300">Manage payment providers, monitor transactions, and detect fraud</p>
        </div>

        {/* Payment Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/20 border-green-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Total Volume (24h)</p>
                  <p className="text-3xl font-bold text-white">${paymentStats?.totalVolume?.toLocaleString() || 0}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-blue-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 text-sm font-medium">Success Rate</p>
                  <p className="text-3xl font-bold text-white">{paymentStats?.successRate?.toFixed(1) || 0}%</p>
                </div>
                <CheckCircle className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-yellow-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-400 text-sm font-medium">Pending Amount</p>
                  <p className="text-3xl font-bold text-white">${paymentStats?.pendingAmount?.toLocaleString() || 0}</p>
                </div>
                <AlertCircle className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-red-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-400 text-sm font-medium">Fraud Alerts</p>
                  <p className="text-3xl font-bold text-white">{criticalAlerts.length}</p>
                </div>
                <Shield className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="providers" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="providers" className="data-[state=active]:bg-green-500/20">
              Payment Providers
            </TabsTrigger>
            <TabsTrigger value="transactions" className="data-[state=active]:bg-green-500/20">
              Transaction Monitor
            </TabsTrigger>
            <TabsTrigger value="fraud" className="data-[state=active]:bg-green-500/20">
              Fraud Detection
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-green-500/20">
              Payment Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="providers" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {providers?.map((provider: PaymentProvider) => (
                <Card key={provider.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-slate-800/50 rounded-lg">
                          {getProviderIcon(provider.type)}
                        </div>
                        <div>
                          <CardTitle className="text-white text-lg">{provider.name}</CardTitle>
                          <p className="text-slate-400 text-sm capitalize">{provider.type} Provider</p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(provider.status)}>
                        {provider.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Processing Fee</p>
                        <p className="text-white font-bold">{provider.processingFee}%</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Success Rate</p>
                        <p className="text-white font-bold">{provider.successRate}%</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Daily Limit</p>
                        <p className="text-white font-bold">${provider.dailyLimit?.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Uptime</p>
                        <p className="text-white font-bold">{provider.uptime}%</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">Monthly Volume</p>
                      <p className="text-2xl font-bold text-green-400">${provider.monthlyVolume?.toLocaleString()}</p>
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">Supported Currencies</p>
                      <div className="flex flex-wrap gap-1">
                        {provider.supportedCurrencies?.slice(0, 4).map((currency: string) => (
                          <Badge key={currency} variant="secondary" className="text-xs">
                            {currency}
                          </Badge>
                        ))}
                        {provider.supportedCurrencies?.length > 4 && (
                          <Badge variant="secondary" className="text-xs">
                            +{provider.supportedCurrencies.length - 4}
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant={provider.status === 'active' ? 'destructive' : 'default'}
                        className="flex-1"
                        onClick={() => toggleProviderMutation.mutate({
                          providerId: provider.id,
                          status: provider.status === 'active' ? 'inactive' : 'active'
                        })}
                      >
                        {provider.status === 'active' ? 'Disable' : 'Enable'}
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1">
                        Configure
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex space-x-4">
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-48 bg-slate-800/50 border-slate-600">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Transactions</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="bg-green-500 hover:bg-green-600">
                Export Report
              </Button>
            </div>

            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions?.map((transaction: PaymentTransaction) => (
                    <div key={transaction.id} className="p-4 bg-slate-800/30 rounded-lg border border-slate-600/30">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                            <span className="text-white font-bold text-sm">
                              {transaction.type.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <p className="text-white font-medium">
                              {transaction.currency} {transaction.amount.toLocaleString()}
                            </p>
                            <p className="text-slate-400 text-sm">
                              {transaction.type} • {transaction.method} • {transaction.provider}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={getStatusColor(transaction.status)}>
                            {transaction.status}
                          </Badge>
                          <p className="text-slate-400 text-sm mt-1">
                            {new Date(transaction.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3 text-sm">
                        <div>
                          <p className="text-slate-400">Reference</p>
                          <p className="text-white font-mono">{transaction.reference}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Fees</p>
                          <p className="text-white">{transaction.currency} {transaction.fees}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Net Amount</p>
                          <p className="text-white">{transaction.currency} {transaction.netAmount}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Country</p>
                          <p className="text-white">{transaction.country}</p>
                        </div>
                      </div>

                      {transaction.status === 'failed' && transaction.failureReason && (
                        <Alert className="mb-3 bg-red-900/20 border-red-500/20">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription className="text-red-300">
                            {transaction.failureReason}
                          </AlertDescription>
                        </Alert>
                      )}

                      {transaction.status === 'pending' && (
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            className="bg-green-500/20 border border-green-500/30 text-green-400 hover:bg-green-500/30"
                            onClick={() => processTransactionMutation.mutate({
                              transactionId: transaction.id,
                              action: 'approve'
                            })}
                          >
                            Approve
                          </Button>
                          <Button 
                            size="sm" 
                            className="bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30"
                            onClick={() => processTransactionMutation.mutate({
                              transactionId: transaction.id,
                              action: 'reject'
                            })}
                          >
                            Reject
                          </Button>
                          <Button 
                            size="sm" 
                            className="bg-blue-500/20 border border-blue-500/30 text-blue-400 hover:bg-blue-500/30"
                          >
                            Investigate
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="fraud" className="space-y-6">
            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Fraud Detection Alerts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {fraudAlerts?.map((alert: FraudAlert) => (
                    <div key={alert.id} className="p-4 bg-slate-800/30 rounded-lg border border-slate-600/30">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${
                            alert.severity === 'critical' ? 'bg-red-500' :
                            alert.severity === 'high' ? 'bg-orange-500' :
                            alert.severity === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'
                          }`} />
                          <div>
                            <p className="text-white font-medium">{alert.description}</p>
                            <p className="text-slate-400 text-sm">
                              User: {alert.userId} • Transaction: {alert.transactionId}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={`${
                            alert.severity === 'critical' ? 'bg-red-500/20 text-red-400' :
                            alert.severity === 'high' ? 'bg-orange-500/20 text-orange-400' :
                            alert.severity === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-blue-500/20 text-blue-400'
                          }`}>
                            {alert.severity}
                          </Badge>
                          <p className="text-slate-400 text-sm mt-1">
                            Risk Score: {alert.riskScore}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <p className="text-slate-400 text-sm">
                          {new Date(alert.createdAt).toLocaleString()}
                        </p>
                        {alert.status === 'active' && (
                          <div className="flex space-x-2">
                            <Button 
                              size="sm" 
                              className="bg-green-500/20 border border-green-500/30 text-green-400 hover:bg-green-500/30"
                              onClick={() => resolveFraudAlertMutation.mutate({
                                alertId: alert.id,
                                resolution: 'false_positive'
                              })}
                            >
                              False Positive
                            </Button>
                            <Button 
                              size="sm" 
                              className="bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30"
                              onClick={() => resolveFraudAlertMutation.mutate({
                                alertId: alert.id,
                                resolution: 'confirmed_fraud'
                              })}
                            >
                              Confirm Fraud
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Payment Method Distribution</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {paymentStats?.volumeByMethod?.map((method: any, index: number) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-300 capitalize">{method.method}</span>
                        <span className="text-white">${method.volume.toLocaleString()}</span>
                      </div>
                      <Progress value={method.percentage} className="h-2 bg-slate-800" />
                      <div className="flex justify-between text-xs text-slate-400">
                        <span>{method.percentage.toFixed(1)}% of total volume</span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Top Performing Providers</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {paymentStats?.topProviders?.map((provider: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                      <div>
                        <p className="text-white font-medium">{provider.name}</p>
                        <p className="text-slate-400 text-sm">
                          {provider.transactions} transactions
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-bold">${provider.volume.toLocaleString()}</p>
                        <p className="text-green-400 text-sm">{provider.successRate}% success</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Payment Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <p className="text-slate-400 text-sm">Average Processing Time</p>
                    <p className="text-2xl font-bold text-white">
                      {paymentStats?.averageProcessingTime || 0}s
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-slate-400 text-sm">Chargeback Rate</p>
                    <p className="text-2xl font-bold text-orange-400">
                      {paymentStats?.chargebackRate || 0}%
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-slate-400 text-sm">Total Fees</p>
                    <p className="text-2xl font-bold text-blue-400">
                      ${paymentStats?.totalFees?.toLocaleString() || 0}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-slate-400 text-sm">Failed Transactions</p>
                    <p className="text-2xl font-bold text-red-400">
                      {paymentStats?.failedTransactions || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}