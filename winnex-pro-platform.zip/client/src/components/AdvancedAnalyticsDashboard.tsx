import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, TrendingDown, Target, Users, DollarSign, 
  Zap, Brain, Trophy, AlertTriangle, Activity, BarChart3,
  PieChart, LineChart, Calendar, Clock, MapPin
} from 'lucide-react';

interface AnalyticsData {
  userMetrics: {
    totalUsers: number;
    activeUsers24h: number;
    newUsers24h: number;
    userRetention: number;
    avgSessionTime: string;
    topCountries: { country: string; users: number; percentage: number }[];
  };
  bettingMetrics: {
    totalBets24h: number;
    totalVolume24h: number;
    winRate: number;
    avgBetSize: number;
    popularSports: { sport: string; volume: number; percentage: number }[];
    peakHours: { hour: number; volume: number }[];
  };
  financialMetrics: {
    revenue24h: number;
    deposits24h: number;
    withdrawals24h: number;
    profitMargin: number;
    cryptoBreakdown: { currency: string; amount: number; percentage: number }[];
  };
  performanceMetrics: {
    apiUptime: number;
    avgResponseTime: number;
    errorRate: number;
    throughput: number;
    systemLoad: number;
  };
}

export default function AdvancedAnalyticsDashboard() {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [timeRange, setTimeRange] = useState('24h');
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    // Simulate real-time analytics data
    const generateAnalytics = (): AnalyticsData => ({
      userMetrics: {
        totalUsers: 12847 + Math.floor(Math.random() * 100),
        activeUsers24h: 3241 + Math.floor(Math.random() * 50),
        newUsers24h: 287 + Math.floor(Math.random() * 20),
        userRetention: 78.5 + Math.random() * 5,
        avgSessionTime: '24m 35s',
        topCountries: [
          { country: 'United States', users: 4892, percentage: 38.1 },
          { country: 'United Kingdom', users: 2156, percentage: 16.8 },
          { country: 'Canada', users: 1834, percentage: 14.3 },
          { country: 'Australia', users: 1425, percentage: 11.1 },
          { country: 'Germany', users: 967, percentage: 7.5 }
        ]
      },
      bettingMetrics: {
        totalBets24h: 8945 + Math.floor(Math.random() * 200),
        totalVolume24h: 2847592 + Math.floor(Math.random() * 50000),
        winRate: 52.3 + Math.random() * 3,
        avgBetSize: 47.85 + Math.random() * 10,
        popularSports: [
          { sport: 'Football (NFL)', volume: 892450, percentage: 31.3 },
          { sport: 'Basketball (NBA)', volume: 645230, percentage: 22.7 },
          { sport: 'Soccer', volume: 523180, percentage: 18.4 },
          { sport: 'Baseball (MLB)', volume: 387920, percentage: 13.6 },
          { sport: 'Tennis', volume: 298760, percentage: 10.5 }
        ],
        peakHours: Array.from({ length: 24 }, (_, i) => ({
          hour: i,
          volume: Math.floor(50000 + Math.sin(i * Math.PI / 12) * 30000 + Math.random() * 10000)
        }))
      },
      financialMetrics: {
        revenue24h: 142879 + Math.floor(Math.random() * 5000),
        deposits24h: 789542 + Math.floor(Math.random() * 20000),
        withdrawals24h: 634218 + Math.floor(Math.random() * 15000),
        profitMargin: 23.7 + Math.random() * 2,
        cryptoBreakdown: [
          { currency: 'Bitcoin (BTC)', amount: 18.45, percentage: 42.3 },
          { currency: 'Ethereum (ETH)', amount: 234.7, percentage: 28.9 },
          { currency: 'USDT', amount: 156789, percentage: 19.8 },
          { currency: 'Litecoin (LTC)', amount: 892.3, percentage: 6.2 },
          { currency: 'Dogecoin (DOGE)', amount: 245670, percentage: 2.8 }
        ]
      },
      performanceMetrics: {
        apiUptime: 99.97 + Math.random() * 0.03,
        avgResponseTime: 145 + Math.floor(Math.random() * 20),
        errorRate: 0.12 + Math.random() * 0.05,
        throughput: 2847 + Math.floor(Math.random() * 100),
        systemLoad: 67 + Math.floor(Math.random() * 15)
      }
    });

    setAnalytics(generateAnalytics());
    
    // Update every 30 seconds
    const interval = setInterval(() => {
      setAnalytics(generateAnalytics());
    }, 30000);

    return () => clearInterval(interval);
  }, [timeRange]);

  if (!analytics) {
    return <div className="flex items-center justify-center h-96">Loading analytics...</div>;
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  const getStatusColor = (value: number, thresholds: { good: number; warning: number }) => {
    if (value >= thresholds.good) return 'text-green-600';
    if (value >= thresholds.warning) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Advanced Analytics</h1>
            <p className="text-gray-300">Real-time platform performance and business metrics</p>
          </div>
          <div className="flex items-center space-x-4">
            <select 
              value={timeRange} 
              onChange={(e) => setTimeRange(e.target.value)}
              className="bg-gray-800 text-white border border-gray-600 rounded-lg px-4 py-2"
            >
              <option value="1h">Last Hour</option>
              <option value="24h">Last 24 Hours</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
            </select>
            <Badge variant="outline" className="text-green-400 border-green-400">
              <Activity className="h-3 w-3 mr-1" />
              Live Data
            </Badge>
          </div>
        </div>

        {/* Key Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Revenue (24h)</p>
                  <p className="text-2xl font-bold text-green-400">
                    {formatCurrency(analytics.financialMetrics.revenue24h)}
                  </p>
                  <p className="text-green-400 text-sm flex items-center">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +12.5% vs yesterday
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Active Users</p>
                  <p className="text-2xl font-bold text-blue-400">
                    {formatNumber(analytics.userMetrics.activeUsers24h)}
                  </p>
                  <p className="text-blue-400 text-sm flex items-center">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +8.3% vs yesterday
                  </p>
                </div>
                <Users className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Total Bets (24h)</p>
                  <p className="text-2xl font-bold text-purple-400">
                    {formatNumber(analytics.bettingMetrics.totalBets24h)}
                  </p>
                  <p className="text-purple-400 text-sm flex items-center">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +15.7% vs yesterday
                  </p>
                </div>
                <Target className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">System Uptime</p>
                  <p className={`text-2xl font-bold ${getStatusColor(analytics.performanceMetrics.apiUptime, { good: 99.9, warning: 99.5 })}`}>
                    {analytics.performanceMetrics.apiUptime.toFixed(2)}%
                  </p>
                  <p className="text-green-400 text-sm flex items-center">
                    <Zap className="h-3 w-3 mr-1" />
                    Excellent
                  </p>
                </div>
                <Activity className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analytics Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-black/40 border-gray-700">
            <TabsTrigger value="overview" className="text-white">Overview</TabsTrigger>
            <TabsTrigger value="users" className="text-white">Users</TabsTrigger>
            <TabsTrigger value="betting" className="text-white">Betting</TabsTrigger>
            <TabsTrigger value="performance" className="text-white">Performance</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Financial Overview</CardTitle>
                  <CardDescription className="text-gray-400">24-hour financial metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Deposits</span>
                    <span className="text-green-400 font-semibold">
                      {formatCurrency(analytics.financialMetrics.deposits24h)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Withdrawals</span>
                    <span className="text-red-400 font-semibold">
                      {formatCurrency(analytics.financialMetrics.withdrawals24h)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Net Inflow</span>
                    <span className="text-blue-400 font-semibold">
                      {formatCurrency(analytics.financialMetrics.deposits24h - analytics.financialMetrics.withdrawals24h)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Profit Margin</span>
                    <span className="text-green-400 font-semibold">
                      {analytics.financialMetrics.profitMargin.toFixed(1)}%
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Cryptocurrency Breakdown</CardTitle>
                  <CardDescription className="text-gray-400">Volume by currency</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analytics.financialMetrics.cryptoBreakdown.map((crypto, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-300">{crypto.currency}</span>
                        <span className="text-white font-semibold">{crypto.percentage}%</span>
                      </div>
                      <Progress value={crypto.percentage} className="h-2" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">User Statistics</CardTitle>
                  <CardDescription className="text-gray-400">User engagement metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-blue-400">
                        {formatNumber(analytics.userMetrics.totalUsers)}
                      </p>
                      <p className="text-gray-400 text-sm">Total Users</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-400">
                        {formatNumber(analytics.userMetrics.newUsers24h)}
                      </p>
                      <p className="text-gray-400 text-sm">New Users (24h)</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-300">User Retention Rate</span>
                      <span className="text-green-400 font-semibold">
                        {analytics.userMetrics.userRetention.toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={analytics.userMetrics.userRetention} className="h-2" />
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Avg Session Time</span>
                    <span className="text-blue-400 font-semibold">
                      {analytics.userMetrics.avgSessionTime}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Geographic Distribution</CardTitle>
                  <CardDescription className="text-gray-400">Users by country</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analytics.userMetrics.topCountries.map((country, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <MapPin className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-300">{country.country}</span>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-semibold">{formatNumber(country.users)}</p>
                        <p className="text-gray-400 text-sm">{country.percentage}%</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Betting Tab */}
          <TabsContent value="betting">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Betting Performance</CardTitle>
                  <CardDescription className="text-gray-400">24-hour betting metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-purple-400">
                        {formatCurrency(analytics.bettingMetrics.totalVolume24h)}
                      </p>
                      <p className="text-gray-400 text-sm">Total Volume</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-400">
                        {analytics.bettingMetrics.winRate.toFixed(1)}%
                      </p>
                      <p className="text-gray-400 text-sm">Win Rate</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Average Bet Size</span>
                    <span className="text-blue-400 font-semibold">
                      {formatCurrency(analytics.bettingMetrics.avgBetSize)}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Popular Sports</CardTitle>
                  <CardDescription className="text-gray-400">Betting volume by sport</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analytics.bettingMetrics.popularSports.map((sport, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-300">{sport.sport}</span>
                        <span className="text-white font-semibold">
                          {formatCurrency(sport.volume)}
                        </span>
                      </div>
                      <Progress value={sport.percentage} className="h-2" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">System Performance</CardTitle>
                  <CardDescription className="text-gray-400">Real-time system metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-300">API Uptime</span>
                      <span className={`font-semibold ${getStatusColor(analytics.performanceMetrics.apiUptime, { good: 99.9, warning: 99.5 })}`}>
                        {analytics.performanceMetrics.apiUptime.toFixed(2)}%
                      </span>
                    </div>
                    <Progress value={analytics.performanceMetrics.apiUptime} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-300">System Load</span>
                      <span className={`font-semibold ${getStatusColor(100 - analytics.performanceMetrics.systemLoad, { good: 70, warning: 50 })}`}>
                        {analytics.performanceMetrics.systemLoad}%
                      </span>
                    </div>
                    <Progress value={analytics.performanceMetrics.systemLoad} className="h-2" />
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Avg Response Time</span>
                    <span className={`font-semibold ${getStatusColor(1000 - analytics.performanceMetrics.avgResponseTime, { good: 800, warning: 600 })}`}>
                      {analytics.performanceMetrics.avgResponseTime}ms
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Error Rate</span>
                    <span className={`font-semibold ${getStatusColor(100 - analytics.performanceMetrics.errorRate * 100, { good: 99.5, warning: 99 })}`}>
                      {analytics.performanceMetrics.errorRate.toFixed(2)}%
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Throughput</span>
                    <span className="text-blue-400 font-semibold">
                      {formatNumber(analytics.performanceMetrics.throughput)} req/min
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Peak Activity Hours</CardTitle>
                  <CardDescription className="text-gray-400">Betting volume by hour</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  {analytics.bettingMetrics.peakHours
                    .sort((a, b) => b.volume - a.volume)
                    .slice(0, 8)
                    .map((hour, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-300">
                          {hour.hour.toString().padStart(2, '0')}:00
                        </span>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-semibold">
                          {formatCurrency(hour.volume)}
                        </p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}