import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Users, 
  UserPlus, 
  MessageSquare, 
  Trophy, 
  Target, 
  Crown,
  Share2,
  Heart,
  ThumbsUp,
  TrendingUp,
  Zap,
  Star,
  Medal,
  Gift,
  Calendar,
  Eye,
  Lock,
  Globe
} from "lucide-react";

interface Friend {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  status: 'online' | 'offline' | 'betting';
  winRate: number;
  totalBets: number;
  profit: number;
  rank: number;
  lastActive: string;
  isFollowing: boolean;
  mutualFriends: number;
  achievements: string[];
}

interface BettingGroup {
  id: string;
  name: string;
  description: string;
  avatar: string;
  memberCount: number;
  isPrivate: boolean;
  adminId: string;
  adminName: string;
  totalVolume: number;
  avgWinRate: number;
  createdAt: string;
  tags: string[];
  recentActivity: GroupActivity[];
  leaderboard: GroupMember[];
  isJoined: boolean;
  joinRequests?: number;
}

interface GroupActivity {
  id: string;
  type: 'bet_shared' | 'big_win' | 'member_joined' | 'challenge_created';
  username: string;
  message: string;
  timestamp: string;
  data?: any;
}

interface GroupMember {
  id: string;
  username: string;
  avatar: string;
  winRate: number;
  profit: number;
  betsShared: number;
  rank: number;
  badges: string[];
}

interface SharedBet {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  match: string;
  selection: string;
  odds: number;
  stake: number;
  potentialWin: number;
  timestamp: string;
  status: 'pending' | 'won' | 'lost';
  likes: number;
  comments: number;
  isLiked: boolean;
  confidence: number;
  tags: string[];
  reasoning?: string;
}

interface Challenge {
  id: string;
  title: string;
  description: string;
  createdBy: string;
  creatorName: string;
  participants: number;
  maxParticipants: number;
  prize: number;
  entryFee: number;
  startDate: string;
  endDate: string;
  status: 'upcoming' | 'active' | 'completed';
  rules: string[];
  leaderboard: ChallengeParticipant[];
  isJoined: boolean;
}

interface ChallengeParticipant {
  id: string;
  username: string;
  avatar: string;
  score: number;
  bets: number;
  winRate: number;
  rank: number;
}

interface LeaderboardEntry {
  id: string;
  username: string;
  avatar: string;
  rank: number;
  previousRank: number;
  winRate: number;
  profit: number;
  totalBets: number;
  streak: number;
  badges: string[];
  tier: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
}

export default function SocialBettingPlatform() {
  const [selectedTab, setSelectedTab] = useState('feed');
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDescription, setNewGroupDescription] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: friends } = useQuery({
    queryKey: ['/api/social/friends'],
    refetchInterval: 60000,
  });

  const { data: groups } = useQuery({
    queryKey: ['/api/social/groups'],
  });

  const { data: sharedBets } = useQuery({
    queryKey: ['/api/social/shared-bets'],
    refetchInterval: 30000,
  });

  const { data: challenges } = useQuery({
    queryKey: ['/api/social/challenges'],
  });

  const { data: leaderboard } = useQuery({
    queryKey: ['/api/social/leaderboard'],
    refetchInterval: 300000,
  });

  // Mock data for demonstration
  const mockFriends: Friend[] = [
    {
      id: '1',
      username: 'betking_mike',
      displayName: 'Mike Rodriguez',
      avatar: 'https://via.placeholder.com/40',
      status: 'online',
      winRate: 68.5,
      totalBets: 247,
      profit: 2340.50,
      rank: 12,
      lastActive: 'Online now',
      isFollowing: true,
      mutualFriends: 15,
      achievements: ['🔥', '💎', '🏆']
    },
    {
      id: '2',
      username: 'sports_sarah',
      displayName: 'Sarah Chen',
      avatar: 'https://via.placeholder.com/40',
      status: 'betting',
      winRate: 72.1,
      totalBets: 189,
      profit: 1890.25,
      rank: 8,
      lastActive: '5 minutes ago',
      isFollowing: true,
      mutualFriends: 22,
      achievements: ['⭐', '🎯', '💰']
    }
  ];

  const mockGroups: BettingGroup[] = [
    {
      id: '1',
      name: 'NFL Pro Bettors',
      description: 'Elite NFL betting community with verified track records',
      avatar: 'https://via.placeholder.com/60',
      memberCount: 1247,
      isPrivate: false,
      adminId: 'admin1',
      adminName: 'ProFootballGuru',
      totalVolume: 2450000,
      avgWinRate: 64.2,
      createdAt: '2023-09-15',
      tags: ['NFL', 'Pro', 'High Stakes'],
      recentActivity: [
        {
          id: '1',
          type: 'big_win',
          username: 'betking_mike',
          message: 'Just hit a 10-leg parlay for $12,500!',
          timestamp: '2 hours ago'
        }
      ],
      leaderboard: [
        {
          id: '1',
          username: 'betking_mike',
          avatar: 'https://via.placeholder.com/40',
          winRate: 68.5,
          profit: 15240,
          betsShared: 45,
          rank: 1,
          badges: ['🔥', '💎']
        }
      ],
      isJoined: true,
      joinRequests: 0
    }
  ];

  const mockSharedBets: SharedBet[] = [
    {
      id: '1',
      userId: '1',
      username: 'betking_mike',
      avatar: 'https://via.placeholder.com/40',
      match: 'Chiefs vs Bills',
      selection: 'Chiefs -3.5',
      odds: 1.95,
      stake: 500,
      potentialWin: 975,
      timestamp: '2 hours ago',
      status: 'pending',
      likes: 24,
      comments: 8,
      isLiked: false,
      confidence: 85,
      tags: ['NFL', 'Playoffs'],
      reasoning: 'Chiefs have been dominant at home this season, and Bills struggling with injuries on defense.'
    }
  ];

  const mockChallenges: Challenge[] = [
    {
      id: '1',
      title: 'January Madness',
      description: 'Highest profit wins $10,000 prize pool',
      createdBy: 'admin',
      creatorName: 'Winnex',
      participants: 847,
      maxParticipants: 1000,
      prize: 10000,
      entryFee: 25,
      startDate: '2024-01-01',
      endDate: '2024-01-31',
      status: 'active',
      rules: [
        'Minimum 20 bets to qualify',
        'All sports eligible',
        'Live betting counts',
        'Must maintain 50%+ win rate'
      ],
      leaderboard: [
        {
          id: '1',
          username: 'sports_sarah',
          avatar: 'https://via.placeholder.com/40',
          score: 2450,
          bets: 34,
          winRate: 72.1,
          rank: 1
        }
      ],
      isJoined: true
    }
  ];

  const mockLeaderboard: LeaderboardEntry[] = [
    {
      id: '1',
      username: 'sports_sarah',
      avatar: 'https://via.placeholder.com/40',
      rank: 1,
      previousRank: 3,
      winRate: 72.1,
      profit: 15240.50,
      totalBets: 234,
      streak: 8,
      badges: ['👑', '🔥', '💎'],
      tier: 'diamond'
    },
    {
      id: '2',
      username: 'betking_mike',
      avatar: 'https://via.placeholder.com/40',
      rank: 2,
      previousRank: 1,
      winRate: 68.5,
      profit: 12890.25,
      totalBets: 247,
      streak: 3,
      badges: ['🏆', '⭐', '🎯'],
      tier: 'platinum'
    }
  ];

  const friendsList = friends || mockFriends;
  const groupsList = groups || mockGroups;
  const betsList = sharedBets || mockSharedBets;
  const challengesList = challenges || mockChallenges;
  const leaderboardList = leaderboard || mockLeaderboard;

  const addFriendMutation = useMutation({
    mutationFn: async (username: string) => {
      return apiRequest('POST', '/api/social/friends/add', { username });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/social/friends'] });
      toast({
        title: "Friend Request Sent",
        description: "Your friend request has been sent successfully",
      });
    },
  });

  const createGroupMutation = useMutation({
    mutationFn: async (groupData: { name: string; description: string; isPrivate: boolean }) => {
      return apiRequest('POST', '/api/social/groups', groupData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/social/groups'] });
      toast({
        title: "Group Created",
        description: "Your betting group has been created successfully",
      });
      setNewGroupName('');
      setNewGroupDescription('');
    },
  });

  const likeBetMutation = useMutation({
    mutationFn: async (betId: string) => {
      return apiRequest('POST', `/api/social/bets/${betId}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/social/shared-bets'] });
    },
  });

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'diamond': return 'from-cyan-400 to-blue-500';
      case 'platinum': return 'from-gray-300 to-gray-500';
      case 'gold': return 'from-yellow-400 to-yellow-600';
      case 'silver': return 'from-gray-400 to-gray-600';
      default: return 'from-amber-600 to-orange-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online': return <div className="w-3 h-3 bg-green-500 rounded-full"></div>;
      case 'betting': return <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse"></div>;
      default: return <div className="w-3 h-3 bg-gray-500 rounded-full"></div>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Social Betting Hub</h1>
        <p className="text-gray-400">Connect, compete, and share winning strategies</p>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-4 mb-8">
        <Card className="bg-winnex-dark border-gray-700">
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <div className="text-sm font-semibold text-white">Friends</div>
            <div className="text-2xl font-bold text-blue-500">{friendsList.length}</div>
          </CardContent>
        </Card>

        <Card className="bg-winnex-dark border-gray-700">
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 text-purple-500 mx-auto mb-2" />
            <div className="text-sm font-semibold text-white">Groups</div>
            <div className="text-2xl font-bold text-purple-500">{groupsList.filter(g => g.isJoined).length}</div>
          </CardContent>
        </Card>

        <Card className="bg-winnex-dark border-gray-700">
          <CardContent className="p-4 text-center">
            <Share2 className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <div className="text-sm font-semibold text-white">Shared Bets</div>
            <div className="text-2xl font-bold text-green-500">47</div>
          </CardContent>
        </Card>

        <Card className="bg-winnex-dark border-gray-700">
          <CardContent className="p-4 text-center">
            <Trophy className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
            <div className="text-sm font-semibold text-white">Global Rank</div>
            <div className="text-2xl font-bold text-yellow-500">#142</div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-winnex-gray">
          <TabsTrigger value="feed" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Social Feed
          </TabsTrigger>
          <TabsTrigger value="friends" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Friends
          </TabsTrigger>
          <TabsTrigger value="groups" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Groups
          </TabsTrigger>
          <TabsTrigger value="challenges" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Challenges
          </TabsTrigger>
          <TabsTrigger value="leaderboard" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
            Leaderboard
          </TabsTrigger>
        </TabsList>

        <TabsContent value="feed" className="mt-6">
          <div className="space-y-6">
            {betsList.map((bet) => (
              <Card key={bet.id} className="bg-winnex-dark border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <img
                      src={bet.avatar}
                      alt={bet.username}
                      className="w-12 h-12 rounded-full"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-white">{bet.username}</span>
                            <Badge className="bg-blue-600 text-xs">Shared a bet</Badge>
                          </div>
                          <div className="text-sm text-gray-400">{bet.timestamp}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={`text-xs ${
                            bet.confidence >= 80 ? 'bg-green-600' :
                            bet.confidence >= 60 ? 'bg-yellow-600' : 'bg-red-600'
                          }`}>
                            {bet.confidence}% confidence
                          </Badge>
                        </div>
                      </div>

                      <div className="bg-gray-800 rounded-lg p-4 mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="text-white font-semibold text-lg">{bet.match}</div>
                          <div className="flex gap-1">
                            {bet.tags.map((tag, index) => (
                              <Badge key={index} className="bg-purple-600 text-xs">{tag}</Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-gray-400">Selection:</span>
                            <div className="text-white font-semibold">{bet.selection}</div>
                          </div>
                          <div>
                            <span className="text-gray-400">Odds:</span>
                            <div className="text-white font-semibold">{bet.odds.toFixed(2)}</div>
                          </div>
                          <div>
                            <span className="text-gray-400">Stake:</span>
                            <div className="text-white font-semibold">${bet.stake}</div>
                          </div>
                          <div>
                            <span className="text-gray-400">To Win:</span>
                            <div className="text-green-500 font-semibold">${bet.potentialWin}</div>
                          </div>
                        </div>

                        {bet.reasoning && (
                          <div className="mt-3 p-3 bg-gray-700 rounded">
                            <div className="text-sm text-gray-300">{bet.reasoning}</div>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`flex items-center gap-2 ${bet.isLiked ? 'text-red-500' : 'text-gray-400'}`}
                            onClick={() => likeBetMutation.mutate(bet.id)}
                          >
                            <Heart className={`w-4 h-4 ${bet.isLiked ? 'fill-current' : ''}`} />
                            {bet.likes}
                          </Button>
                          <Button variant="ghost" size="sm" className="flex items-center gap-2 text-gray-400">
                            <MessageSquare className="w-4 h-4" />
                            {bet.comments}
                          </Button>
                          <Button variant="ghost" size="sm" className="flex items-center gap-2 text-gray-400">
                            <Share2 className="w-4 h-4" />
                            Share
                          </Button>
                        </div>
                        <Badge className={`${
                          bet.status === 'pending' ? 'bg-blue-600' :
                          bet.status === 'won' ? 'bg-green-600' : 'bg-red-600'
                        }`}>
                          {bet.status.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="friends" className="mt-6">
          <div className="mb-6">
            <Card className="bg-winnex-dark border-gray-700">
              <CardContent className="p-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Add friend by username..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-winnex-gray border-gray-600"
                  />
                  <Button 
                    className="bg-winnex-green text-black"
                    onClick={() => {
                      if (searchQuery.trim()) {
                        addFriendMutation.mutate(searchQuery.trim());
                        setSearchQuery('');
                      }
                    }}
                  >
                    <UserPlus className="w-4 h-4 mr-2" />
                    Add Friend
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {friendsList.map((friend) => (
              <Card key={friend.id} className="bg-winnex-dark border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="relative">
                      <img
                        src={friend.avatar}
                        alt={friend.username}
                        className="w-12 h-12 rounded-full"
                      />
                      <div className="absolute -bottom-1 -right-1">
                        {getStatusIcon(friend.status)}
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-white">{friend.displayName}</div>
                      <div className="text-sm text-gray-400">@{friend.username}</div>
                      <div className="text-xs text-gray-500">{friend.lastActive}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-400">Rank</div>
                      <div className="font-bold text-yellow-500">#{friend.rank}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                    <div>
                      <span className="text-gray-400">Win Rate:</span>
                      <div className="text-white font-semibold">{friend.winRate}%</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Profit:</span>
                      <div className="text-green-500 font-semibold">${friend.profit.toFixed(2)}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Total Bets:</span>
                      <div className="text-white font-semibold">{friend.totalBets}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Mutual:</span>
                      <div className="text-blue-500 font-semibold">{friend.mutualFriends}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex gap-1">
                      {friend.achievements.map((achievement, index) => (
                        <span key={index} className="text-lg">{achievement}</span>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        <MessageSquare className="w-4 h-4" />
                      </Button>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="groups" className="mt-6">
          <div className="mb-6">
            <Card className="bg-winnex-dark border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Create New Group</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Group name..."
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  className="bg-winnex-gray border-gray-600"
                />
                <Textarea
                  placeholder="Group description..."
                  value={newGroupDescription}
                  onChange={(e) => setNewGroupDescription(e.target.value)}
                  className="bg-winnex-gray border-gray-600"
                />
                <Button 
                  className="bg-winnex-green text-black"
                  onClick={() => createGroupMutation.mutate({
                    name: newGroupName,
                    description: newGroupDescription,
                    isPrivate: false
                  })}
                  disabled={!newGroupName.trim() || !newGroupDescription.trim()}
                >
                  Create Group
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {groupsList.map((group) => (
              <Card key={group.id} className="bg-winnex-dark border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <img
                      src={group.avatar}
                      alt={group.name}
                      className="w-16 h-16 rounded-lg"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-white font-semibold text-lg">{group.name}</h3>
                        {group.isPrivate ? <Lock className="w-4 h-4 text-gray-400" /> : <Globe className="w-4 h-4 text-green-400" />}
                      </div>
                      <p className="text-gray-400 text-sm mb-2">{group.description}</p>
                      <div className="flex gap-1 mb-2">
                        {group.tags.map((tag, index) => (
                          <Badge key={index} className="bg-purple-600 text-xs">{tag}</Badge>
                        ))}
                      </div>
                      <div className="text-xs text-gray-500">
                        Created by {group.adminName} • {group.createdAt}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-sm mb-4">
                    <div>
                      <span className="text-gray-400">Members:</span>
                      <div className="text-white font-semibold">{group.memberCount.toLocaleString()}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Win Rate:</span>
                      <div className="text-green-500 font-semibold">{group.avgWinRate}%</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Volume:</span>
                      <div className="text-blue-500 font-semibold">${(group.totalVolume / 1000000).toFixed(1)}M</div>
                    </div>
                  </div>

                  {group.recentActivity.length > 0 && (
                    <div className="mb-4 p-3 bg-gray-800 rounded-lg">
                      <div className="text-xs text-gray-400 mb-1">Recent Activity</div>
                      <div className="text-sm text-white">
                        <span className="font-semibold text-green-400">{group.recentActivity[0].username}</span>
                        {' '}{group.recentActivity[0].message}
                      </div>
                      <div className="text-xs text-gray-500">{group.recentActivity[0].timestamp}</div>
                    </div>
                  )}

                  <div className="flex gap-2">
                    {group.isJoined ? (
                      <>
                        <Button className="flex-1 bg-blue-600 hover:bg-blue-700">
                          <MessageSquare className="w-4 h-4 mr-2" />
                          Open Chat
                        </Button>
                        <Button variant="outline" className="border-red-500 text-red-500">
                          Leave
                        </Button>
                      </>
                    ) : (
                      <Button className="flex-1 bg-winnex-green text-black">
                        <Users className="w-4 h-4 mr-2" />
                        Join Group
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="challenges" className="mt-6">
          <div className="space-y-6">
            {challengesList.map((challenge) => (
              <Card key={challenge.id} className="bg-winnex-dark border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-white font-semibold text-xl mb-2">{challenge.title}</h3>
                      <p className="text-gray-400 mb-2">{challenge.description}</p>
                      <div className="text-sm text-gray-500">
                        Created by {challenge.creatorName}
                      </div>
                    </div>
                    <Badge className={`${
                      challenge.status === 'active' ? 'bg-green-600' :
                      challenge.status === 'upcoming' ? 'bg-blue-600' : 'bg-gray-600'
                    }`}>
                      {challenge.status.toUpperCase()}
                    </Badge>
                  </div>

                  <div className="grid md:grid-cols-4 gap-4 mb-4">
                    <div className="text-center p-3 bg-gray-800 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-500">${challenge.prize.toLocaleString()}</div>
                      <div className="text-sm text-gray-400">Prize Pool</div>
                    </div>
                    <div className="text-center p-3 bg-gray-800 rounded-lg">
                      <div className="text-2xl font-bold text-blue-500">{challenge.participants}</div>
                      <div className="text-sm text-gray-400">Participants</div>
                    </div>
                    <div className="text-center p-3 bg-gray-800 rounded-lg">
                      <div className="text-2xl font-bold text-purple-500">${challenge.entryFee}</div>
                      <div className="text-sm text-gray-400">Entry Fee</div>
                    </div>
                    <div className="text-center p-3 bg-gray-800 rounded-lg">
                      <div className="text-2xl font-bold text-green-500">
                        {Math.ceil((new Date(challenge.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}
                      </div>
                      <div className="text-sm text-gray-400">Days Left</div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <h4 className="text-white font-semibold mb-2">Rules:</h4>
                    <ul className="text-sm text-gray-400 space-y-1">
                      {challenge.rules.map((rule, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-green-400 mt-1">•</span>
                          {rule}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-400">
                      {challenge.startDate} - {challenge.endDate}
                    </div>
                    {challenge.isJoined ? (
                      <Badge className="bg-green-600">Joined</Badge>
                    ) : (
                      <Button className="bg-winnex-green text-black">
                        <Gift className="w-4 h-4 mr-2" />
                        Join Challenge
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="leaderboard" className="mt-6">
          <Card className="bg-winnex-dark border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                Global Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leaderboardList.map((entry, index) => (
                  <div key={entry.id} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <div className={`w-12 h-12 bg-gradient-to-br ${getTierColor(entry.tier)} rounded-full flex items-center justify-center text-white font-bold text-lg`}>
                          {entry.rank}
                        </div>
                        {entry.rank <= 3 && (
                          <div className="absolute -top-1 -right-1">
                            {entry.rank === 1 ? <Crown className="w-6 h-6 text-yellow-500" /> :
                             entry.rank === 2 ? <Medal className="w-6 h-6 text-gray-400" /> :
                             <Medal className="w-6 h-6 text-amber-600" />}
                          </div>
                        )}
                      </div>
                      
                      <img
                        src={entry.avatar}
                        alt={entry.username}
                        className="w-10 h-10 rounded-full"
                      />
                      
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-white font-semibold">{entry.username}</span>
                          <div className="flex gap-1">
                            {entry.badges.map((badge, index) => (
                              <span key={index} className="text-sm">{badge}</span>
                            ))}
                          </div>
                        </div>
                        <div className="text-sm text-gray-400">
                          {entry.totalBets} bets • {entry.streak} win streak
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-green-500 font-bold">${entry.profit.toFixed(2)}</span>
                        {entry.rank < entry.previousRank ? (
                          <TrendingUp className="w-4 h-4 text-green-500" />
                        ) : entry.rank > entry.previousRank ? (
                          <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />
                        ) : (
                          <div className="w-4 h-4"></div>
                        )}
                      </div>
                      <div className="text-sm text-gray-400">{entry.winRate}% win rate</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}