import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  DollarSign, 
  TrendingUp, 
  Link, 
  Share2, 
  Target, 
  Award,
  Calendar,
  Copy,
  ExternalLink
} from "lucide-react";

interface AffiliateStats {
  totalCommissions: number;
  monthlyCommissions: number;
  totalReferrals: number;
  activeReferrals: number;
  conversionRate: number;
  averagePlayerValue: number;
  clickThroughRate: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
}

interface ReferralData {
  id: string;
  username: string;
  joinDate: string;
  totalDeposits: number;
  totalBets: number;
  commissionEarned: number;
  status: 'active' | 'inactive' | 'churned';
  lastActivity: string;
}

interface CommissionTier {
  tier: string;
  minReferrals: number;
  commissionRate: number;
  bonusPerks: string[];
  color: string;
}

interface MarketingMaterial {
  id: string;
  type: 'banner' | 'text' | 'video' | 'email';
  title: string;
  description: string;
  dimensions?: string;
  format: string;
  clickThrough: number;
  conversionRate: number;
}

interface PayoutHistory {
  id: string;
  amount: number;
  date: string;
  method: string;
  status: 'pending' | 'processed' | 'failed';
  referenceId: string;
}

export default function AffiliateManagement() {
  const [stats, setStats] = useState<AffiliateStats | null>(null);
  const [referrals, setReferrals] = useState<ReferralData[]>([]);
  const [commissionTiers, setCommissionTiers] = useState<CommissionTier[]>([]);
  const [marketingMaterials, setMarketingMaterials] = useState<MarketingMaterial[]>([]);
  const [payoutHistory, setPayoutHistory] = useState<PayoutHistory[]>([]);
  const [affiliateCode, setAffiliateCode] = useState('WINNEX_USER123');

  useEffect(() => {
    const mockStats: AffiliateStats = {
      totalCommissions: 12840,
      monthlyCommissions: 2350,
      totalReferrals: 47,
      activeReferrals: 32,
      conversionRate: 24.5,
      averagePlayerValue: 850,
      clickThroughRate: 3.2,
      tier: 'gold'
    };

    const mockReferrals: ReferralData[] = [
      {
        id: 'ref_001',
        username: 'SportsFan2024',
        joinDate: '2024-01-10',
        totalDeposits: 1250,
        totalBets: 2840,
        commissionEarned: 156,
        status: 'active',
        lastActivity: '2024-01-15'
      },
      {
        id: 'ref_002',
        username: 'BetMaster',
        joinDate: '2024-01-08',
        totalDeposits: 890,
        totalBets: 1560,
        commissionEarned: 98,
        status: 'active',
        lastActivity: '2024-01-14'
      },
      {
        id: 'ref_003',
        username: 'LuckyPlayer',
        joinDate: '2024-01-05',
        totalDeposits: 450,
        totalBets: 780,
        commissionEarned: 45,
        status: 'inactive',
        lastActivity: '2024-01-12'
      }
    ];

    const mockTiers: CommissionTier[] = [
      {
        tier: 'Bronze',
        minReferrals: 0,
        commissionRate: 25,
        bonusPerks: ['Basic marketing materials', 'Monthly payouts'],
        color: 'text-orange-400'
      },
      {
        tier: 'Silver',
        minReferrals: 10,
        commissionRate: 30,
        bonusPerks: ['Advanced materials', 'Bi-weekly payouts', 'Performance bonus'],
        color: 'text-gray-400'
      },
      {
        tier: 'Gold',
        minReferrals: 25,
        commissionRate: 35,
        bonusPerks: ['Premium materials', 'Weekly payouts', 'Personal manager', 'Custom tracking'],
        color: 'text-yellow-400'
      },
      {
        tier: 'Platinum',
        minReferrals: 50,
        commissionRate: 40,
        bonusPerks: ['Exclusive materials', 'Daily payouts', 'VIP support', 'Revenue sharing'],
        color: 'text-purple-400'
      }
    ];

    const mockMaterials: MarketingMaterial[] = [
      {
        id: 'banner_001',
        type: 'banner',
        title: 'Winnex Main Banner',
        description: 'High-converting main promotional banner',
        dimensions: '728x90',
        format: 'PNG/GIF',
        clickThrough: 3.8,
        conversionRate: 12.5
      },
      {
        id: 'text_001',
        type: 'text',
        title: 'Welcome Bonus Text Ad',
        description: 'Compelling text ad focusing on welcome bonus',
        format: 'HTML/Text',
        clickThrough: 2.1,
        conversionRate: 8.7
      },
      {
        id: 'video_001',
        type: 'video',
        title: 'Sports Betting Promo',
        description: '30-second promotional video',
        format: 'MP4',
        clickThrough: 5.2,
        conversionRate: 18.3
      }
    ];

    const mockPayouts: PayoutHistory[] = [
      {
        id: 'payout_001',
        amount: 2350,
        date: '2024-01-15',
        method: 'Bank Transfer',
        status: 'processed',
        referenceId: 'TXN_20240115_001'
      },
      {
        id: 'payout_002',
        amount: 1890,
        date: '2024-01-08',
        method: 'PayPal',
        status: 'processed',
        referenceId: 'TXN_20240108_002'
      },
      {
        id: 'payout_003',
        amount: 1650,
        date: '2024-01-01',
        method: 'Cryptocurrency',
        status: 'processed',
        referenceId: 'TXN_20240101_003'
      }
    ];

    setStats(mockStats);
    setReferrals(mockReferrals);
    setCommissionTiers(mockTiers);
    setMarketingMaterials(mockMaterials);
    setPayoutHistory(mockPayouts);
  }, []);

  const copyAffiliateLink = () => {
    const link = `https://winnex.com/register?ref=${affiliateCode}`;
    navigator.clipboard.writeText(link);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'inactive': return 'text-yellow-400';
      case 'churned': return 'text-red-400';
      case 'processed': return 'text-green-400';
      case 'pending': return 'text-yellow-400';
      case 'failed': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getCurrentTier = () => {
    if (!stats) return commissionTiers[0];
    return commissionTiers.find(tier => tier.tier.toLowerCase() === stats.tier) || commissionTiers[0];
  };

  const getNextTier = () => {
    if (!stats) return commissionTiers[1];
    const currentIndex = commissionTiers.findIndex(tier => tier.tier.toLowerCase() === stats.tier);
    return commissionTiers[currentIndex + 1] || null;
  };

  if (!stats) return null;

  const currentTier = getCurrentTier();
  const nextTier = getNextTier();

  return (
    <div className="p-6 space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <Users className="w-12 h-12 text-emerald-400 mr-3" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            Affiliate Program
          </h1>
        </div>
        <p className="text-gray-400 text-lg">Earn commissions by referring new players to Winnex</p>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-3xl font-bold text-emerald-400">${stats.totalCommissions.toLocaleString()}</div>
            <div className="text-sm text-gray-400">Total Earned</div>
          </CardContent>
        </Card>
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-3xl font-bold text-blue-400">{stats.totalReferrals}</div>
            <div className="text-sm text-gray-400">Total Referrals</div>
          </CardContent>
        </Card>
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-3xl font-bold text-purple-400">{stats.conversionRate}%</div>
            <div className="text-sm text-gray-400">Conversion Rate</div>
          </CardContent>
        </Card>
        <Card className="casino-card text-center">
          <CardContent className="p-4">
            <div className="text-3xl font-bold text-orange-400">${stats.monthlyCommissions.toLocaleString()}</div>
            <div className="text-sm text-gray-400">This Month</div>
          </CardContent>
        </Card>
      </div>

      {/* Tier Progress */}
      <Card className={`casino-card border-${currentTier.color.split('-')[1]}-400/20`}>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className={`text-2xl ${currentTier.color}`}>
                {currentTier.tier} Affiliate
              </CardTitle>
              <p className="text-gray-400">{currentTier.commissionRate}% commission rate</p>
            </div>
            <Badge className={`${currentTier.color} border-current`}>
              {stats.activeReferrals} Active Referrals
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {nextTier && (
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Progress to {nextTier.tier}</span>
                <span className="text-white">
                  {stats.totalReferrals}/{nextTier.minReferrals} referrals
                </span>
              </div>
              <Progress 
                value={(stats.totalReferrals / nextTier.minReferrals) * 100} 
                className="h-3"
              />
              <p className="text-sm text-gray-400">
                {nextTier.minReferrals - stats.totalReferrals} more referrals to unlock {nextTier.commissionRate}% commission
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="referrals">Referrals</TabsTrigger>
          <TabsTrigger value="materials">Materials</TabsTrigger>
          <TabsTrigger value="payouts">Payouts</TabsTrigger>
          <TabsTrigger value="tracking">Tracking</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-white">Your Affiliate Link</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-gray-800 p-3 rounded border">
                  <div className="text-sm text-gray-400 mb-1">Affiliate Code:</div>
                  <div className="font-mono text-emerald-400">{affiliateCode}</div>
                </div>
                <div className="bg-gray-800 p-3 rounded border">
                  <div className="text-sm text-gray-400 mb-1">Referral Link:</div>
                  <div className="font-mono text-white text-sm break-all">
                    https://winnex.com/register?ref={affiliateCode}
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button onClick={copyAffiliateLink} className="flex-1 bg-emerald-500 hover:bg-emerald-600">
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Link
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-white">Commission Tiers</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {commissionTiers.map((tier) => (
                  <div 
                    key={tier.tier}
                    className={`p-3 rounded border ${
                      tier.tier.toLowerCase() === stats.tier 
                        ? 'border-emerald-400 bg-emerald-500/10' 
                        : 'border-gray-700'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <span className={`font-semibold ${tier.color}`}>{tier.tier}</span>
                        <span className="text-gray-400 ml-2">
                          {tier.minReferrals}+ referrals
                        </span>
                      </div>
                      <span className="font-bold text-white">{tier.commissionRate}%</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="referrals" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-white">Your Referrals</CardTitle>
                <div className="flex space-x-2">
                  <Select defaultValue="all">
                    <SelectTrigger className="w-32 bg-gray-800 border-gray-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {referrals.map((referral) => (
                  <Card key={referral.id} className="border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <span className="font-semibold text-white">{referral.username}</span>
                            <Badge className={getStatusColor(referral.status)}>
                              {referral.status.toUpperCase()}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-gray-400">Joined: </span>
                              <span className="text-white">{referral.joinDate}</span>
                            </div>
                            <div>
                              <span className="text-gray-400">Deposits: </span>
                              <span className="text-white">${referral.totalDeposits}</span>
                            </div>
                            <div>
                              <span className="text-gray-400">Bets: </span>
                              <span className="text-white">${referral.totalBets}</span>
                            </div>
                            <div>
                              <span className="text-gray-400">Last Active: </span>
                              <span className="text-white">{referral.lastActivity}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xl font-bold text-emerald-400">
                            ${referral.commissionEarned}
                          </div>
                          <div className="text-sm text-gray-400">Commission</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="materials" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Marketing Materials</CardTitle>
              <p className="text-gray-400">High-converting promotional materials for your campaigns</p>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {marketingMaterials.map((material) => (
                  <Card key={material.id} className="border-gray-700">
                    <CardContent className="p-4">
                      <div className="text-center mb-4">
                        <div className="w-full h-32 bg-gray-800 rounded mb-3 flex items-center justify-center">
                          <span className="text-gray-400 text-sm">
                            {material.type.toUpperCase()} Preview
                          </span>
                        </div>
                        <h3 className="font-semibold text-white">{material.title}</h3>
                        <p className="text-sm text-gray-400 mt-1">{material.description}</p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Format:</span>
                          <span className="text-white">{material.format}</span>
                        </div>
                        {material.dimensions && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Size:</span>
                            <span className="text-white">{material.dimensions}</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-gray-400">CTR:</span>
                          <span className="text-emerald-400">{material.clickThrough}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Conversion:</span>
                          <span className="text-emerald-400">{material.conversionRate}%</span>
                        </div>
                      </div>

                      <div className="flex space-x-2 mt-4">
                        <Button size="sm" className="flex-1 bg-emerald-500 hover:bg-emerald-600">
                          Download
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1">
                          Preview
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payouts" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Payout History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {payoutHistory.map((payout) => (
                  <Card key={payout.id} className="border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4">
                          <div>
                            <div className="font-semibold text-white">${payout.amount}</div>
                            <div className="text-sm text-gray-400">{payout.date}</div>
                          </div>
                          <div>
                            <div className="text-sm text-white">{payout.method}</div>
                            <div className="text-xs text-gray-400">{payout.referenceId}</div>
                          </div>
                        </div>
                        <Badge className={getStatusColor(payout.status)}>
                          {payout.status.toUpperCase()}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tracking" className="space-y-6">
          <Card className="casino-card">
            <CardHeader>
              <CardTitle className="text-white">Performance Tracking</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">{stats.clickThroughRate}%</div>
                  <div className="text-sm text-gray-400">Click-Through Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">{stats.conversionRate}%</div>
                  <div className="text-sm text-gray-400">Conversion Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-400">${stats.averagePlayerValue}</div>
                  <div className="text-sm text-gray-400">Avg Player Value</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-400">{stats.activeReferrals}</div>
                  <div className="text-sm text-gray-400">Active Players</div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Custom Tracking Links</h3>
                <div className="grid gap-4">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Campaign name (e.g., social-media, email)"
                      className="bg-gray-800 border-gray-700"
                    />
                    <Button className="bg-emerald-500 hover:bg-emerald-600">
                      Generate Link
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}