import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building2, Users, DollarSign, Settings, Globe, Palette, Code, BarChart3 } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface Partner {
  id: string;
  name: string;
  domain: string;
  status: 'active' | 'pending' | 'suspended';
  tier: 'starter' | 'professional' | 'enterprise';
  region: string;
  license: string;
  launchDate: string;
  monthlyRevenue: number;
  totalUsers: number;
  revenueShare: number;
  customizations: {
    branding: boolean;
    features: string[];
    integrations: string[];
  };
  performance: {
    uptime: number;
    avgResponseTime: number;
    userSatisfaction: number;
  };
}

interface RevenueShare {
  partnerId: string;
  partnerName: string;
  period: string;
  grossRevenue: number;
  partnerShare: number;
  platformFee: number;
  netPayout: number;
  status: 'pending' | 'processed' | 'disputed';
  transactions: number;
  activeUsers: number;
}

interface BrandingTemplate {
  id: string;
  name: string;
  category: 'sports' | 'casino' | 'esports' | 'minimal';
  preview: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
  };
  features: string[];
  customizable: string[];
  pricing: number;
  popularity: number;
}

interface FeatureModule {
  id: string;
  name: string;
  description: string;
  category: 'core' | 'premium' | 'enterprise';
  dependencies: string[];
  pricing: {
    setup: number;
    monthly: number;
    usage: number;
  };
  enabled: boolean;
  configuration: any;
  metrics: {
    adoption: number;
    performance: number;
    satisfaction: number;
  };
}

interface PartnerAnalytics {
  overview: {
    totalPartners: number;
    activePartners: number;
    totalRevenue: number;
    averageRevenue: number;
    growthRate: number;
  };
  performance: {
    topPerformers: Array<{
      name: string;
      revenue: number;
      growth: number;
    }>;
    regionBreakdown: Array<{
      region: string;
      partners: number;
      revenue: number;
    }>;
  };
  trends: {
    monthlyGrowth: Array<{
      month: string;
      newPartners: number;
      revenue: number;
      churn: number;
    }>;
  };
}

export default function WhiteLabelPlatform() {
  const [selectedPartner, setSelectedPartner] = useState<string>('');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const queryClient = useQueryClient();

  const { data: partners } = useQuery({
    queryKey: ['/api/whitelabel/partners'],
    queryFn: () => apiRequest('/api/whitelabel/partners'),
  });

  const { data: revenueShares } = useQuery({
    queryKey: ['/api/whitelabel/revenue-shares'],
    queryFn: () => apiRequest('/api/whitelabel/revenue-shares'),
  });

  const { data: brandingTemplates } = useQuery({
    queryKey: ['/api/whitelabel/branding-templates'],
    queryFn: () => apiRequest('/api/whitelabel/branding-templates'),
  });

  const { data: featureModules } = useQuery({
    queryKey: ['/api/whitelabel/feature-modules'],
    queryFn: () => apiRequest('/api/whitelabel/feature-modules'),
  });

  const { data: analytics } = useQuery({
    queryKey: ['/api/whitelabel/analytics'],
    queryFn: () => apiRequest('/api/whitelabel/analytics'),
  });

  const createPartnerMutation = useMutation({
    mutationFn: (data: any) =>
      apiRequest('/api/whitelabel/create-partner', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/whitelabel/partners'] });
    },
  });

  const updatePartnerMutation = useMutation({
    mutationFn: (data: { partnerId: string; updates: any }) =>
      apiRequest('/api/whitelabel/update-partner', 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/whitelabel/partners'] });
    },
  });

  const processPayoutMutation = useMutation({
    mutationFn: (payoutId: string) =>
      apiRequest('/api/whitelabel/process-payout', 'POST', { payoutId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/whitelabel/revenue-shares'] });
    },
  });

  const deployPartnerMutation = useMutation({
    mutationFn: (data: { partnerId: string; template: string; features: string[] }) =>
      apiRequest('/api/whitelabel/deploy-partner', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/whitelabel/partners'] });
    },
  });

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'enterprise': return 'bg-purple-500/20 text-purple-400 border-purple-500/20';
      case 'professional': return 'bg-blue-500/20 text-blue-400 border-blue-500/20';
      case 'starter': return 'bg-green-500/20 text-green-400 border-green-500/20';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/20';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-400';
      case 'pending': return 'bg-yellow-500/20 text-yellow-400';
      case 'suspended': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">White-Label Platform</h1>
          <p className="text-slate-300">Multi-tenant B2B solution for partner operators worldwide</p>
        </div>

        {/* Platform Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/20 border-blue-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 text-sm font-medium">Active Partners</p>
                  <p className="text-3xl font-bold text-white">{analytics?.overview?.activePartners || 0}</p>
                </div>
                <Building2 className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-green-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Monthly Revenue</p>
                  <p className="text-3xl font-bold text-white">${analytics?.overview?.totalRevenue?.toLocaleString() || 0}</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-purple-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-400 text-sm font-medium">Total Users</p>
                  <p className="text-3xl font-bold text-white">{partners?.reduce((sum: number, p: Partner) => sum + p.totalUsers, 0)?.toLocaleString() || 0}</p>
                </div>
                <Users className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-yellow-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-400 text-sm font-medium">Growth Rate</p>
                  <p className="text-3xl font-bold text-white">+{analytics?.overview?.growthRate || 0}%</p>
                </div>
                <BarChart3 className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="partners" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="partners" className="data-[state=active]:bg-green-500/20">
              Partner Management
            </TabsTrigger>
            <TabsTrigger value="branding" className="data-[state=active]:bg-green-500/20">
              Branding Templates
            </TabsTrigger>
            <TabsTrigger value="features" className="data-[state=active]:bg-green-500/20">
              Feature Modules
            </TabsTrigger>
            <TabsTrigger value="revenue" className="data-[state=active]:bg-green-500/20">
              Revenue Sharing
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-green-500/20">
              Partner Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="partners" className="space-y-6">
            <div className="flex justify-between items-center">
              <Button className="bg-green-500 hover:bg-green-600">
                <Building2 className="h-4 w-4 mr-2" />
                Add New Partner
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {partners?.map((partner: Partner) => (
                <Card key={partner.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-white">{partner.name}</CardTitle>
                        <p className="text-slate-400 text-sm">{partner.domain}</p>
                      </div>
                      <div className="flex flex-col space-y-1">
                        <Badge className={getTierColor(partner.tier)}>
                          {partner.tier}
                        </Badge>
                        <Badge className={getStatusColor(partner.status)}>
                          {partner.status}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Monthly Revenue</p>
                        <p className="text-green-400 font-bold">${partner.monthlyRevenue.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Total Users</p>
                        <p className="text-white font-bold">{partner.totalUsers.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Revenue Share</p>
                        <p className="text-blue-400 font-bold">{partner.revenueShare}%</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Region</p>
                        <p className="text-white font-bold">{partner.region}</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">Performance</p>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-300">Uptime</span>
                          <span className="text-green-400">{partner.performance.uptime}%</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-300">Response Time</span>
                          <span className="text-blue-400">{partner.performance.avgResponseTime}ms</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-300">User Satisfaction</span>
                          <span className="text-purple-400">{partner.performance.userSatisfaction}/5</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">Customizations</p>
                      <div className="flex flex-wrap gap-1">
                        {partner.customizations.features.slice(0, 3).map((feature, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                        {partner.customizations.features.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{partner.customizations.features.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" className="flex-1">
                        <Settings className="h-3 w-3 mr-1" />
                        Configure
                      </Button>
                      <Button size="sm" className="flex-1 bg-blue-500 hover:bg-blue-600">
                        <Globe className="h-3 w-3 mr-1" />
                        View Site
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="branding" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {brandingTemplates?.map((template: BrandingTemplate) => (
                <Card key={template.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-white">{template.name}</CardTitle>
                      <Badge className="bg-blue-500/20 text-blue-400">
                        {template.category}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="aspect-video bg-slate-800/50 rounded-lg flex items-center justify-center">
                      <Palette className="h-12 w-12 text-slate-400" />
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">Color Scheme</p>
                      <div className="flex space-x-2">
                        <div 
                          className="w-8 h-8 rounded border border-white/20"
                          style={{ backgroundColor: template.colors.primary }}
                        />
                        <div 
                          className="w-8 h-8 rounded border border-white/20"
                          style={{ backgroundColor: template.colors.secondary }}
                        />
                        <div 
                          className="w-8 h-8 rounded border border-white/20"
                          style={{ backgroundColor: template.colors.accent }}
                        />
                        <div 
                          className="w-8 h-8 rounded border border-white/20"
                          style={{ backgroundColor: template.colors.background }}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Pricing</p>
                        <p className="text-green-400 font-bold">${template.pricing}/month</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Popularity</p>
                        <p className="text-blue-400 font-bold">{template.popularity}%</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-slate-400 text-sm mb-2">Features</p>
                      <div className="flex flex-wrap gap-1">
                        {template.features.slice(0, 3).map((feature, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                        {template.features.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{template.features.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>

                    <Button 
                      className="w-full bg-purple-500 hover:bg-purple-600"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      Select Template
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="features" className="space-y-6">
            <div className="space-y-4">
              {featureModules?.map((module: FeatureModule) => (
                <Card key={module.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-white font-bold text-lg">{module.name}</h3>
                          <Badge className={`${
                            module.category === 'enterprise' ? 'bg-purple-500/20 text-purple-400' :
                            module.category === 'premium' ? 'bg-blue-500/20 text-blue-400' :
                            'bg-green-500/20 text-green-400'
                          }`}>
                            {module.category}
                          </Badge>
                          <Badge className={module.enabled ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}>
                            {module.enabled ? 'Enabled' : 'Disabled'}
                          </Badge>
                        </div>
                        <p className="text-slate-300">{module.description}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-slate-400 text-sm">Setup Fee</p>
                        <p className="text-white font-bold">${module.pricing.setup}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Monthly</p>
                        <p className="text-green-400 font-bold">${module.pricing.monthly}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Usage Fee</p>
                        <p className="text-blue-400 font-bold">${module.pricing.usage}/tx</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Adoption</p>
                        <p className="text-purple-400 font-bold">{module.metrics.adoption}%</p>
                      </div>
                    </div>

                    {module.dependencies.length > 0 && (
                      <div className="mb-4">
                        <p className="text-slate-400 text-sm mb-2">Dependencies</p>
                        <div className="flex flex-wrap gap-1">
                          {module.dependencies.map((dep, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {dep}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-600">
                      <div className="text-center">
                        <p className="text-slate-400 text-sm">Performance</p>
                        <p className="text-white font-bold">{module.metrics.performance}/10</p>
                      </div>
                      <div className="text-center">
                        <p className="text-slate-400 text-sm">Satisfaction</p>
                        <p className="text-green-400 font-bold">{module.metrics.satisfaction}/5</p>
                      </div>
                      <div className="text-center">
                        <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                          <Code className="h-3 w-3 mr-1" />
                          Configure
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="revenue" className="space-y-6">
            <div className="space-y-4">
              {revenueShares?.map((share: RevenueShare) => (
                <Card key={share.partnerId} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-white font-bold text-lg">{share.partnerName}</h3>
                        <p className="text-slate-400">{share.period}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={`${
                          share.status === 'processed' ? 'bg-green-500/20 text-green-400' :
                          share.status === 'disputed' ? 'bg-red-500/20 text-red-400' :
                          'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {share.status}
                        </Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
                      <div>
                        <p className="text-slate-400 text-sm">Gross Revenue</p>
                        <p className="text-white font-bold">${share.grossRevenue.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Partner Share</p>
                        <p className="text-green-400 font-bold">${share.partnerShare.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Platform Fee</p>
                        <p className="text-blue-400 font-bold">${share.platformFee.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Net Payout</p>
                        <p className="text-purple-400 font-bold">${share.netPayout.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Transactions</p>
                        <p className="text-white font-bold">{share.transactions.toLocaleString()}</p>
                      </div>
                    </div>

                    {share.status === 'pending' && (
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          className="bg-green-500 hover:bg-green-600"
                          onClick={() => processPayoutMutation.mutate(share.partnerId)}
                        >
                          Process Payout
                        </Button>
                        <Button size="sm" variant="outline">
                          Review Details
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Top Performing Partners</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analytics?.performance?.topPerformers?.map((performer: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                            index === 0 ? 'bg-yellow-500 text-black' :
                            index === 1 ? 'bg-gray-400 text-black' :
                            index === 2 ? 'bg-yellow-600 text-black' :
                            'bg-slate-600 text-white'
                          }`}>
                            {index + 1}
                          </div>
                          <span className="text-white font-medium">{performer.name}</span>
                        </div>
                        <div className="text-right">
                          <p className="text-green-400 font-bold">${performer.revenue.toLocaleString()}</p>
                          <p className="text-slate-400 text-sm">+{performer.growth}% growth</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="text-white">Regional Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analytics?.performance?.regionBreakdown?.map((region: any, index: number) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-300">{region.region}</span>
                          <span className="text-white">{region.partners} partners</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-400">Revenue</span>
                          <span className="text-green-400">${region.revenue.toLocaleString()}</span>
                        </div>
                        <Progress 
                          value={(region.revenue / analytics.overview.totalRevenue) * 100} 
                          className="h-2 bg-slate-800"
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/20 border-white/10 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Growth Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-slate-800/30 rounded-lg">
                    <p className="text-slate-400 text-sm">New Partners (Month)</p>
                    <p className="text-3xl font-bold text-green-400">
                      {analytics?.trends?.monthlyGrowth?.[analytics.trends.monthlyGrowth.length - 1]?.newPartners || 0}
                    </p>
                  </div>
                  <div className="text-center p-4 bg-slate-800/30 rounded-lg">
                    <p className="text-slate-400 text-sm">Revenue Growth</p>
                    <p className="text-3xl font-bold text-blue-400">+{analytics?.overview?.growthRate || 0}%</p>
                  </div>
                  <div className="text-center p-4 bg-slate-800/30 rounded-lg">
                    <p className="text-slate-400 text-sm">Churn Rate</p>
                    <p className="text-3xl font-bold text-red-400">
                      {analytics?.trends?.monthlyGrowth?.[analytics.trends.monthlyGrowth.length - 1]?.churn || 0}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}