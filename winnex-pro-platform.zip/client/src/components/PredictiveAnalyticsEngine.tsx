import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Brain, TrendingUp, Target, Zap, Trophy, AlertCircle,
  BarChart3, PieChart, LineChart, Activity, Cpu, 
  Database, Network, Eye, Lightbulb, Timer
} from 'lucide-react';

interface PredictionModel {
  id: string;
  name: string;
  type: 'neural_network' | 'random_forest' | 'svm' | 'ensemble';
  accuracy: number;
  confidence: number;
  trainingData: number;
  lastUpdated: Date;
  status: 'active' | 'training' | 'updating';
  predictions24h: number;
  successRate: number;
}

interface MarketPrediction {
  id: string;
  market: string;
  sport: string;
  match: string;
  prediction: string;
  confidence: number;
  expectedValue: number;
  odds: {
    current: number;
    predicted: number;
    edge: number;
  };
  factors: {
    name: string;
    weight: number;
    impact: 'positive' | 'negative' | 'neutral';
  }[];
  riskLevel: 'low' | 'medium' | 'high';
  timeToEvent: string;
  modelUsed: string;
}

interface UserBehaviorPrediction {
  userId: string;
  churnRisk: number;
  nextBetPrediction: {
    sport: string;
    probability: number;
    suggestedAmount: number;
  };
  lifetimeValue: number;
  engagement: {
    score: number;
    trend: 'increasing' | 'stable' | 'decreasing';
    riskFactors: string[];
  };
  personalizedOffers: {
    type: string;
    effectiveness: number;
    timing: string;
  }[];
}

interface MarketInefficiency {
  id: string;
  type: 'arbitrage' | 'value_bet' | 'pricing_error';
  confidence: number;
  expectedReturn: number;
  timeWindow: string;
  market1: { bookmaker: string; odds: number };
  market2?: { bookmaker: string; odds: number };
  riskAdjustedReturn: number;
  volume: number;
  expiryTime: Date;
}

export default function PredictiveAnalyticsEngine() {
  const { toast } = useToast();
  const [models, setModels] = useState<PredictionModel[]>([]);
  const [marketPredictions, setMarketPredictions] = useState<MarketPrediction[]>([]);
  const [userPredictions, setUserPredictions] = useState<UserBehaviorPrediction | null>(null);
  const [inefficiencies, setInefficiencies] = useState<MarketInefficiency[]>([]);
  const [activeTab, setActiveTab] = useState('predictions');

  useEffect(() => {
    // Generate realistic prediction data
    const generateModels = (): PredictionModel[] => [
      {
        id: '1',
        name: 'DeepSports Neural Network',
        type: 'neural_network',
        accuracy: 94.2,
        confidence: 87.5,
        trainingData: 1250000,
        lastUpdated: new Date(Date.now() - 2 * 60 * 60 * 1000),
        status: 'active',
        predictions24h: 847,
        successRate: 91.3
      },
      {
        id: '2',
        name: 'Ensemble Predictor v3.1',
        type: 'ensemble',
        accuracy: 92.8,
        confidence: 89.2,
        trainingData: 980000,
        lastUpdated: new Date(Date.now() - 1 * 60 * 60 * 1000),
        status: 'active',
        predictions24h: 654,
        successRate: 88.7
      },
      {
        id: '3',
        name: 'Market Volatility Forest',
        type: 'random_forest',
        accuracy: 89.5,
        confidence: 85.1,
        trainingData: 750000,
        lastUpdated: new Date(Date.now() - 30 * 60 * 1000),
        status: 'updating',
        predictions24h: 423,
        successRate: 86.2
      },
      {
        id: '4',
        name: 'Live Odds SVM',
        type: 'svm',
        accuracy: 87.3,
        confidence: 82.4,
        trainingData: 540000,
        lastUpdated: new Date(Date.now() - 15 * 60 * 1000),
        status: 'training',
        predictions24h: 312,
        successRate: 84.9
      }
    ];

    const generatePredictions = (): MarketPrediction[] => [
      {
        id: '1',
        market: 'Over/Under 220.5 Points',
        sport: 'Basketball',
        match: 'Lakers vs Celtics',
        prediction: 'Over 220.5',
        confidence: 94.5,
        expectedValue: 18.7,
        odds: {
          current: 1.95,
          predicted: 1.67,
          edge: 14.3
        },
        factors: [
          { name: 'Both teams avg 115+ PPG', weight: 28.5, impact: 'positive' },
          { name: 'Fast pace expected', weight: 22.1, impact: 'positive' },
          { name: 'Weak defensive stats', weight: 19.3, impact: 'positive' },
          { name: 'Historical H2H trends', weight: 15.7, impact: 'positive' },
          { name: 'Weather conditions', weight: 8.2, impact: 'neutral' },
          { name: 'Recent under trends', weight: 6.2, impact: 'negative' }
        ],
        riskLevel: 'low',
        timeToEvent: '2h 34m',
        modelUsed: 'DeepSports Neural Network'
      },
      {
        id: '2',
        market: 'Arsenal Win',
        sport: 'Soccer',
        match: 'Arsenal vs Chelsea',
        prediction: 'Arsenal Win',
        confidence: 87.2,
        expectedValue: 23.4,
        odds: {
          current: 2.10,
          predicted: 1.78,
          edge: 15.2
        },
        factors: [
          { name: 'Home advantage', weight: 25.8, impact: 'positive' },
          { name: '8-game home unbeaten', weight: 23.4, impact: 'positive' },
          { name: 'Chelsea injuries', weight: 21.1, impact: 'positive' },
          { name: 'Recent form', weight: 18.3, impact: 'positive' },
          { name: 'Head-to-head record', weight: 11.4, impact: 'negative' }
        ],
        riskLevel: 'medium',
        timeToEvent: '4h 12m',
        modelUsed: 'Ensemble Predictor v3.1'
      },
      {
        id: '3',
        market: 'Over 47.5 Points',
        sport: 'Football',
        match: 'Chiefs vs Bills',
        prediction: 'Over 47.5',
        confidence: 91.8,
        expectedValue: 16.9,
        odds: {
          current: 1.91,
          predicted: 1.71,
          edge: 10.5
        },
        factors: [
          { name: 'High-scoring offenses', weight: 32.1, impact: 'positive' },
          { name: 'Dome environment', weight: 18.7, impact: 'positive' },
          { name: 'Defensive weaknesses', weight: 16.4, impact: 'positive' },
          { name: 'Playoff intensity', weight: 15.2, impact: 'positive' },
          { name: 'Cold weather factor', weight: 12.8, impact: 'negative' },
          { name: 'Historical under bias', weight: 4.8, impact: 'negative' }
        ],
        riskLevel: 'low',
        timeToEvent: '18h 45m',
        modelUsed: 'DeepSports Neural Network'
      }
    ];

    const generateUserPrediction = (): UserBehaviorPrediction => ({
      userId: 'current-user',
      churnRisk: 15.3,
      nextBetPrediction: {
        sport: 'Basketball',
        probability: 78.5,
        suggestedAmount: 85.50
      },
      lifetimeValue: 2847.50,
      engagement: {
        score: 87.2,
        trend: 'increasing',
        riskFactors: ['Long session gaps', 'Decreasing bet frequency']
      },
      personalizedOffers: [
        { type: 'Deposit Bonus', effectiveness: 89.3, timing: 'Next 48 hours' },
        { type: 'Free Bet', effectiveness: 76.1, timing: 'After next loss' },
        { type: 'VIP Upgrade', effectiveness: 92.7, timing: 'Immediately' }
      ]
    });

    const generateInefficiencies = (): MarketInefficiency[] => [
      {
        id: '1',
        type: 'arbitrage',
        confidence: 97.2,
        expectedReturn: 4.3,
        timeWindow: '8 minutes',
        market1: { bookmaker: 'Bookmaker A', odds: 2.15 },
        market2: { bookmaker: 'Bookmaker B', odds: 1.95 },
        riskAdjustedReturn: 3.8,
        volume: 5000,
        expiryTime: new Date(Date.now() + 8 * 60 * 1000)
      },
      {
        id: '2',
        type: 'value_bet',
        confidence: 89.4,
        expectedReturn: 12.7,
        timeWindow: '2 hours',
        market1: { bookmaker: 'Market Leader', odds: 2.8 },
        riskAdjustedReturn: 9.2,
        volume: 2500,
        expiryTime: new Date(Date.now() + 2 * 60 * 60 * 1000)
      },
      {
        id: '3',
        type: 'pricing_error',
        confidence: 94.8,
        expectedReturn: 8.9,
        timeWindow: '15 minutes',
        market1: { bookmaker: 'Regional Book', odds: 3.2 },
        riskAdjustedReturn: 7.1,
        volume: 1000,
        expiryTime: new Date(Date.now() + 15 * 60 * 1000)
      }
    ];

    setModels(generateModels());
    setMarketPredictions(generatePredictions());
    setUserPredictions(generateUserPrediction());
    setInefficiencies(generateInefficiencies());

    // Update data every 30 seconds
    const interval = setInterval(() => {
      setMarketPredictions(generatePredictions());
      setInefficiencies(generateInefficiencies());
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'training': return 'text-yellow-400';
      case 'updating': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  const getModelIcon = (type: string) => {
    switch (type) {
      case 'neural_network': return <Brain className="h-5 w-5" />;
      case 'ensemble': return <Network className="h-5 w-5" />;
      case 'random_forest': return <Database className="h-5 w-5" />;
      case 'svm': return <Cpu className="h-5 w-5" />;
      default: return <Activity className="h-5 w-5" />;
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-400 bg-green-400/20';
      case 'medium': return 'text-yellow-400 bg-yellow-400/20';
      case 'high': return 'text-red-400 bg-red-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const handlePredictionAction = (action: string, predictionId: string) => {
    switch (action) {
      case 'place_bet':
        toast({ title: "Bet placed successfully", description: "Added to your bet slip" });
        break;
      case 'track':
        toast({ title: "Prediction tracked", description: "Added to your watchlist" });
        break;
      case 'exploit':
        toast({ title: "Inefficiency exploited", description: "Order placed automatically" });
        break;
      default:
        toast({ title: "Action completed", description: "Your request was processed" });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-2">Predictive Analytics Engine</h1>
          <p className="text-gray-300">Advanced AI-powered sports betting and user behavior prediction</p>
        </div>

        {/* Model Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {models.map((model) => (
            <Card key={model.id} className="bg-black/40 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <div className="text-blue-400">
                      {getModelIcon(model.type)}
                    </div>
                    <h3 className="font-semibold text-white text-sm">{model.name}</h3>
                  </div>
                  <Badge variant="outline" className={getStatusColor(model.status)}>
                    {model.status}
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Accuracy</span>
                    <span className="text-green-400 font-semibold">{model.accuracy}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Success Rate</span>
                    <span className="text-blue-400 font-semibold">{model.successRate}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Predictions 24h</span>
                    <span className="text-purple-400 font-semibold">{model.predictions24h}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-black/40 border-gray-700">
            <TabsTrigger value="predictions" className="text-white">Market Predictions</TabsTrigger>
            <TabsTrigger value="inefficiencies" className="text-white">Inefficiencies</TabsTrigger>
            <TabsTrigger value="behavior" className="text-white">User Behavior</TabsTrigger>
            <TabsTrigger value="models" className="text-white">Model Performance</TabsTrigger>
          </TabsList>

          {/* Market Predictions Tab */}
          <TabsContent value="predictions">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {marketPredictions.map((prediction) => (
                <Card key={prediction.id} className="bg-black/40 border-gray-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white">{prediction.match}</CardTitle>
                      <Badge variant="secondary">{prediction.sport}</Badge>
                    </div>
                    <CardDescription className="text-gray-400">
                      {prediction.market} • Model: {prediction.modelUsed}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-green-400">{prediction.confidence}%</div>
                        <div className="text-sm text-gray-400">Confidence</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-blue-400">+{prediction.expectedValue}%</div>
                        <div className="text-sm text-gray-400">Expected Value</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-purple-400">{prediction.odds.edge}%</div>
                        <div className="text-sm text-gray-400">Edge</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Prediction</span>
                        <span className="text-white font-semibold">{prediction.prediction}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Current Odds</span>
                        <span className="text-blue-400">{prediction.odds.current}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Fair Odds</span>
                        <span className="text-green-400">{prediction.odds.predicted}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Risk Level</span>
                        <Badge className={getRiskColor(prediction.riskLevel)}>
                          {prediction.riskLevel}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Time to Event</span>
                        <span className="text-yellow-400">{prediction.timeToEvent}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-white font-medium">Key Factors:</h4>
                      {prediction.factors.slice(0, 3).map((factor, index) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <span className="text-gray-300">{factor.name}</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-gray-400">{factor.weight}%</span>
                            <div className={`w-2 h-2 rounded-full ${
                              factor.impact === 'positive' ? 'bg-green-400' :
                              factor.impact === 'negative' ? 'bg-red-400' : 'bg-gray-400'
                            }`} />
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex space-x-2">
                      <Button 
                        className="flex-1"
                        onClick={() => handlePredictionAction('place_bet', prediction.id)}
                      >
                        <Target className="h-4 w-4 mr-2" />
                        Place Bet
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => handlePredictionAction('track', prediction.id)}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Track
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Market Inefficiencies Tab */}
          <TabsContent value="inefficiencies">
            <div className="space-y-4">
              {inefficiencies.map((inefficiency) => (
                <Card key={inefficiency.id} className="bg-black/40 border-gray-700 border-l-4 border-l-yellow-400">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Lightbulb className="h-5 w-5 text-yellow-400" />
                        <div>
                          <h3 className="font-semibold text-white capitalize">
                            {inefficiency.type.replace('_', ' ')} Opportunity
                          </h3>
                          <p className="text-sm text-gray-400">
                            {inefficiency.confidence}% confidence • {inefficiency.timeWindow} window
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-green-400">
                          +{inefficiency.expectedReturn}%
                        </div>
                        <div className="text-sm text-gray-400">Expected Return</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-gray-400">Risk-Adjusted Return</p>
                        <p className="font-semibold text-blue-400">{inefficiency.riskAdjustedReturn}%</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Volume Available</p>
                        <p className="font-semibold text-purple-400">${inefficiency.volume}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Primary Market</p>
                        <p className="font-semibold text-white">{inefficiency.market1.odds}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Expires In</p>
                        <p className="font-semibold text-red-400">
                          {Math.round((inefficiency.expiryTime.getTime() - Date.now()) / 1000 / 60)}m
                        </p>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2 text-sm text-gray-400">
                        <Timer className="h-3 w-3" />
                        <span>Time-sensitive opportunity</span>
                      </div>
                      <Button 
                        variant="destructive"
                        onClick={() => handlePredictionAction('exploit', inefficiency.id)}
                      >
                        <Zap className="h-4 w-4 mr-2" />
                        Exploit Now
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* User Behavior Tab */}
          <TabsContent value="behavior">
            {userPredictions && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-black/40 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">User Behavior Analysis</CardTitle>
                    <CardDescription className="text-gray-400">
                      AI-powered insights into user engagement and behavior patterns
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Churn Risk</span>
                        <span className="text-green-400 font-semibold">{userPredictions.churnRisk}%</span>
                      </div>
                      <Progress value={userPredictions.churnRisk} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Engagement Score</span>
                        <span className="text-blue-400 font-semibold">{userPredictions.engagement.score}</span>
                      </div>
                      <Progress value={userPredictions.engagement.score} className="h-2" />
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Engagement Trend</span>
                      <Badge className={
                        userPredictions.engagement.trend === 'increasing' ? 'text-green-400 bg-green-400/20' :
                        userPredictions.engagement.trend === 'stable' ? 'text-blue-400 bg-blue-400/20' :
                        'text-red-400 bg-red-400/20'
                      }>
                        {userPredictions.engagement.trend}
                      </Badge>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Predicted Lifetime Value</span>
                      <span className="text-green-400 font-semibold">
                        ${userPredictions.lifetimeValue.toFixed(2)}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-black/40 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Next Bet Prediction</CardTitle>
                    <CardDescription className="text-gray-400">
                      AI prediction for user's next betting behavior
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-purple-400 mb-2">
                        {userPredictions.nextBetPrediction.probability}%
                      </div>
                      <div className="text-gray-400">Probability of betting in next 24h</div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Predicted Sport</span>
                        <span className="text-white font-semibold">
                          {userPredictions.nextBetPrediction.sport}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Suggested Amount</span>
                        <span className="text-green-400 font-semibold">
                          ${userPredictions.nextBetPrediction.suggestedAmount}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h4 className="text-white font-medium">Personalized Offers:</h4>
                      {userPredictions.personalizedOffers.map((offer, index) => (
                        <div key={index} className="flex justify-between items-center">
                          <div>
                            <p className="text-white text-sm">{offer.type}</p>
                            <p className="text-gray-400 text-xs">{offer.timing}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-green-400 font-semibold">{offer.effectiveness}%</p>
                            <p className="text-gray-400 text-xs">Effectiveness</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Model Performance Tab */}
          <TabsContent value="models">
            <div className="space-y-6">
              {models.map((model) => (
                <Card key={model.id} className="bg-black/40 border-gray-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="text-blue-400">
                          {getModelIcon(model.type)}
                        </div>
                        <div>
                          <CardTitle className="text-white">{model.name}</CardTitle>
                          <CardDescription className="text-gray-400">
                            {model.type.replace('_', ' ').toUpperCase()} • {model.trainingData.toLocaleString()} data points
                          </CardDescription>
                        </div>
                      </div>
                      <Badge variant="outline" className={getStatusColor(model.status)}>
                        {model.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-400">{model.accuracy}%</div>
                        <div className="text-sm text-gray-400">Accuracy</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">{model.confidence}%</div>
                        <div className="text-sm text-gray-400">Confidence</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-400">{model.predictions24h}</div>
                        <div className="text-sm text-gray-400">Predictions 24h</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-yellow-400">{model.successRate}%</div>
                        <div className="text-sm text-gray-400">Success Rate</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Model Performance</span>
                        <span className="text-white">{model.accuracy}%</span>
                      </div>
                      <Progress value={model.accuracy} className="h-2" />
                    </div>

                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-400">Last Updated</span>
                      <span className="text-gray-300">{model.lastUpdated.toLocaleTimeString()}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}