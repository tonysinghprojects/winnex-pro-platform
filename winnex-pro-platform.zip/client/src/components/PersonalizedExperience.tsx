import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Settings, Palette, Globe, Target, Clock, Star, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface UserPreferences {
  theme: 'dark' | 'light' | 'auto';
  accentColor: string;
  language: string;
  timezone: string;
  currency: string;
  oddsFormat: 'decimal' | 'fractional' | 'american';
  defaultStake: number;
  favoriteLeagues: string[];
  preferredSports: string[];
  betTypePreferences: string[];
  dashboardLayout: 'compact' | 'detailed' | 'minimal';
  autoOddsRefresh: boolean;
  soundNotifications: boolean;
  pushNotifications: boolean;
  emailMarketing: boolean;
}

interface PersonalizationData {
  bettingPatterns: {
    favoriteSports: Array<{ sport: string; percentage: number; }>;
    preferredStakes: Array<{ range: string; frequency: number; }>;
    bestPerformingMarkets: Array<{ market: string; winRate: number; }>;
    peakBettingHours: Array<{ hour: number; activity: number; }>;
  };
  recommendations: {
    suggestedLeagues: string[];
    recommendedStakes: number;
    optimalBettingTimes: string[];
    personalizedOffers: Array<{ title: string; description: string; value: string; }>;
  };
}

const THEMES = [
  { name: 'Dark Pro', value: 'dark', colors: ['#0a0f1c', '#1a2332', '#00ff9d'] },
  { name: 'Light Mode', value: 'light', colors: ['#ffffff', '#f8fafc', '#059669'] },
  { name: 'Ocean Blue', value: 'ocean', colors: ['#0c1e3d', '#1e40af', '#3b82f6'] },
  { name: 'Neon Green', value: 'neon', colors: ['#0d1117', '#161b22', '#39ff14'] },
];

const CURRENCIES = [
  { code: 'USD', name: 'US Dollar', symbol: '$' },
  { code: 'EUR', name: 'Euro', symbol: '€' },
  { code: 'GBP', name: 'British Pound', symbol: '£' },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥' },
  { code: 'BTC', name: 'Bitcoin', symbol: '₿' },
  { code: 'ETH', name: 'Ethereum', symbol: 'Ξ' },
];

export default function PersonalizedExperience() {
  const [activeTab, setActiveTab] = useState<'preferences' | 'patterns' | 'recommendations'>('preferences');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: preferences } = useQuery<UserPreferences>({
    queryKey: ["/api/user/preferences"],
  });

  const { data: personalizationData } = useQuery<PersonalizationData>({
    queryKey: ["/api/user/personalization"],
  });

  const updatePreferences = useMutation({
    mutationFn: async (data: Partial<UserPreferences>) => {
      return apiRequest("/api/user/preferences", "PUT", data);
    },
    onSuccess: () => {
      toast({
        title: "Preferences Updated",
        description: "Your personalization settings have been saved",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/preferences"] });
    },
  });

  const handlePreferenceChange = (key: keyof UserPreferences, value: any) => {
    updatePreferences.mutate({ [key]: value });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card-modern p-6 gradient-accent">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Settings className="text-white" size={32} />
            <div>
              <h2 className="text-2xl font-bold text-white">Personalized Experience</h2>
              <p className="text-white/80">Customize Winnex to match your betting style and preferences</p>
            </div>
          </div>
          <div className="glass rounded-2xl p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">98%</div>
              <div className="text-white/70 text-sm">Customized</div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="glass rounded-xl p-1 flex">
        {(['preferences', 'patterns', 'recommendations'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all capitalize ${
              activeTab === tab ? 'bg-winnex-green text-black' : 'text-white/70 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Preferences Tab */}
      {activeTab === 'preferences' && (
        <div className="space-y-6">
          {/* Theme Customization */}
          <div className="card-modern p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <Palette className="mr-2 text-winnex-purple" />
              Theme & Appearance
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {THEMES.map((theme) => (
                <button
                  key={theme.value}
                  onClick={() => handlePreferenceChange('theme', theme.value)}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    preferences?.theme === theme.value
                      ? 'border-winnex-green'
                      : 'border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex space-x-1 mb-3">
                    {theme.colors.map((color, index) => (
                      <div
                        key={index}
                        className="w-6 h-6 rounded-full"
                        style={{ backgroundColor: color }}
                      ></div>
                    ))}
                  </div>
                  <div className="font-medium text-sm">{theme.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Currency & Regional Settings */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <Globe className="mr-2 text-winnex-blue" />
                Regional Settings
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Currency</label>
                  <select
                    value={preferences?.currency || 'USD'}
                    onChange={(e) => handlePreferenceChange('currency', e.target.value)}
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  >
                    {CURRENCIES.map((currency) => (
                      <option key={currency.code} value={currency.code}>
                        {currency.symbol} {currency.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Odds Format</label>
                  <select
                    value={preferences?.oddsFormat || 'decimal'}
                    onChange={(e) => handlePreferenceChange('oddsFormat', e.target.value)}
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  >
                    <option value="decimal">Decimal (2.50)</option>
                    <option value="fractional">Fractional (3/2)</option>
                    <option value="american">American (+150)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Language</label>
                  <select
                    value={preferences?.language || 'en'}
                    onChange={(e) => handlePreferenceChange('language', e.target.value)}
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  >
                    <option value="en">English</option>
                    <option value="es">Español</option>
                    <option value="fr">Français</option>
                    <option value="de">Deutsch</option>
                    <option value="it">Italiano</option>
                    <option value="pt">Português</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <Target className="mr-2 text-winnex-orange" />
                Betting Preferences
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Default Stake</label>
                  <input
                    type="number"
                    value={preferences?.defaultStake || 10}
                    onChange={(e) => handlePreferenceChange('defaultStake', parseFloat(e.target.value))}
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Dashboard Layout</label>
                  <select
                    value={preferences?.dashboardLayout || 'detailed'}
                    onChange={(e) => handlePreferenceChange('dashboardLayout', e.target.value)}
                    className="w-full p-3 bg-secondary rounded-lg border border-white/10 text-white"
                  >
                    <option value="minimal">Minimal</option>
                    <option value="compact">Compact</option>
                    <option value="detailed">Detailed</option>
                  </select>
                </div>
                <div className="space-y-3">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences?.autoOddsRefresh || false}
                      onChange={(e) => handlePreferenceChange('autoOddsRefresh', e.target.checked)}
                      className="rounded"
                    />
                    <span>Auto-refresh odds</span>
                  </label>
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences?.soundNotifications || false}
                      onChange={(e) => handlePreferenceChange('soundNotifications', e.target.checked)}
                      className="rounded"
                    />
                    <span>Sound notifications</span>
                  </label>
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences?.pushNotifications || true}
                      onChange={(e) => handlePreferenceChange('pushNotifications', e.target.checked)}
                      className="rounded"
                    />
                    <span>Push notifications</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Betting Patterns Tab */}
      {activeTab === 'patterns' && personalizationData && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card-modern p-6">
              <h3 className="text-xl font-bold mb-4">Your Favorite Sports</h3>
              <div className="space-y-3">
                {personalizationData.bettingPatterns.favoriteSports.map((sport, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="font-medium">{sport.sport}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 h-2 bg-white/10 rounded-full">
                        <div
                          className="h-2 bg-winnex-green rounded-full"
                          style={{ width: `${sport.percentage}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-winnex-green">{sport.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="card-modern p-6">
              <h3 className="text-xl font-bold mb-4">Best Performing Markets</h3>
              <div className="space-y-3">
                {personalizationData.bettingPatterns.bestPerformingMarkets.map((market, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="font-medium">{market.market}</span>
                    <span className="text-winnex-green font-bold">{market.winRate}% win rate</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="card-modern p-6">
            <h3 className="text-xl font-bold mb-4">Peak Betting Activity</h3>
            <div className="grid grid-cols-6 md:grid-cols-12 gap-2">
              {Array.from({ length: 24 }, (_, hour) => {
                const activity = personalizationData.bettingPatterns.peakBettingHours.find(h => h.hour === hour)?.activity || 0;
                return (
                  <div key={hour} className="text-center">
                    <div
                      className="w-full bg-winnex-green rounded mb-1"
                      style={{ height: `${Math.max(activity * 2, 4)}px` }}
                    ></div>
                    <div className="text-xs text-white/60">{hour}h</div>
                  </div>
                );
              })}
            </div>
            <div className="text-sm text-white/60 mt-2">
              Most active: {personalizationData.bettingPatterns.peakBettingHours
                .sort((a, b) => b.activity - a.activity)[0]?.hour}:00
            </div>
          </div>
        </div>
      )}

      {/* Recommendations Tab */}
      {activeTab === 'recommendations' && personalizationData && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <Star className="mr-2 text-winnex-orange" />
                Suggested Leagues
              </h3>
              <div className="space-y-2">
                {personalizationData.recommendations.suggestedLeagues.map((league, index) => (
                  <div key={index} className="glass rounded-lg p-3 flex justify-between items-center">
                    <span className="font-medium">{league}</span>
                    <button className="btn-secondary text-xs">Follow</button>
                  </div>
                ))}
              </div>
            </div>

            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <TrendingUp className="mr-2 text-winnex-green" />
                Optimal Settings
              </h3>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-white/60">Recommended Stake</div>
                  <div className="text-lg font-bold text-winnex-green">
                    ${personalizationData.recommendations.recommendedStakes}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-white/60">Best Betting Times</div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {personalizationData.recommendations.optimalBettingTimes.map((time, index) => (
                      <span key={index} className="text-xs bg-winnex-blue/20 text-winnex-blue px-2 py-1 rounded">
                        {time}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="card-modern p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <Clock className="mr-2 text-winnex-blue" />
                Personal Offers
              </h3>
              <div className="space-y-3">
                {personalizationData.recommendations.personalizedOffers.map((offer, index) => (
                  <div key={index} className="glass rounded-lg p-3">
                    <div className="font-medium text-sm">{offer.title}</div>
                    <div className="text-xs text-white/60 mb-2">{offer.description}</div>
                    <div className="text-lg font-bold text-winnex-orange">{offer.value}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}