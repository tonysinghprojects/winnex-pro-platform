import { useState, useEffect } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Trash2, Ticket, Calculator, Trophy, Target, Shuffle, Zap, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface BetSelection {
  matchId: number;
  match: string;
  market: string;
  selection: string;
  odds: string;
  stake: string;
  sport?: string;
  expectedValue?: number;
  confidence?: number;
}

interface MultiBetCombination {
  type: 'double' | 'treble' | 'accumulator' | 'system';
  selections: number[];
  stake: number;
  potentialReturn: number;
  odds: number;
}

interface CurrencyRate {
  code: string;
  name: string;
  symbol: string;
  rate: number;
  flag: string;
}

export default function EnhancedBetSlip() {
  const [selections, setSelections] = useState<BetSelection[]>([]);
  const [selectedCurrency, setSelectedCurrency] = useState("USD");
  const [betType, setBetType] = useState<'single' | 'multi'>('single');
  const [multiBetCombinations, setMultiBetCombinations] = useState<MultiBetCombination[]>([]);
  const [quickStakeAmount, setQuickStakeAmount] = useState(10);
  const [autoStakeEnabled, setAutoStakeEnabled] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: exchangeRates } = useQuery({
    queryKey: ['/api/exchange-rates'],
    refetchInterval: 60000,
  });

  const currencies: CurrencyRate[] = [
    { code: "USD", name: "US Dollar", symbol: "$", rate: 1.0, flag: "🇺🇸" },
    { code: "EUR", name: "Euro", symbol: "€", rate: 0.85, flag: "🇪🇺" },
    { code: "GBP", name: "British Pound", symbol: "£", rate: 0.73, flag: "🇬🇧" },
    { code: "CAD", name: "Canadian Dollar", symbol: "C$", rate: 1.25, flag: "🇨🇦" },
    { code: "AUD", name: "Australian Dollar", symbol: "A$", rate: 1.35, flag: "🇦🇺" },
    { code: "BTC", name: "Bitcoin", symbol: "₿", rate: 0.000023, flag: "₿" },
  ];

  const getCurrentCurrency = () => currencies.find(c => c.code === selectedCurrency) || currencies[0];

  const placeBetMutation = useMutation({
    mutationFn: async (betData: any) => {
      await apiRequest("POST", "/api/bets", betData);
    },
    onSuccess: () => {
      toast({
        title: "Bet Placed Successfully!",
        description: "Your bet has been placed and is being processed.",
      });
      setSelections([]);
      queryClient.invalidateQueries({ queryKey: ["/api/user/balance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bets"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Bet Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addSelection = (selection: Omit<BetSelection, "stake">) => {
    const existingIndex = selections.findIndex(
      s => s.matchId === selection.matchId && s.selection === selection.selection
    );
    
    if (existingIndex >= 0) {
      const updated = [...selections];
      updated[existingIndex] = { ...selection, stake: updated[existingIndex].stake };
      setSelections(updated);
    } else {
      const newStake = autoStakeEnabled ? quickStakeAmount.toString() : "";
      setSelections([...selections, { ...selection, stake: newStake }]);
    }
  };

  const removeSelection = (index: number) => {
    setSelections(selections.filter((_, i) => i !== index));
  };

  const updateStake = (index: number, stake: string) => {
    const updated = [...selections];
    updated[index].stake = stake;
    setSelections(updated);
  };

  const calculateTotalStake = () => {
    return selections.reduce((total, selection) => {
      return total + (parseFloat(selection.stake) || 0);
    }, 0);
  };

  const calculatePotentialWin = () => {
    if (betType === 'single') {
      return selections.reduce((total, selection) => {
        const stake = parseFloat(selection.stake) || 0;
        const odds = parseFloat(selection.odds) || 0;
        return total + (stake * odds);
      }, 0);
    } else {
      const totalOdds = selections.reduce((total, selection) => {
        const odds = parseFloat(selection.odds) || 1;
        return total * odds;
      }, 1);
      return quickStakeAmount * totalOdds;
    }
  };

  const calculateMultiBetCombinations = () => {
    if (selections.length < 2) return [];
    
    const combinations: MultiBetCombination[] = [];
    
    // Doubles
    if (selections.length >= 2) {
      for (let i = 0; i < selections.length - 1; i++) {
        for (let j = i + 1; j < selections.length; j++) {
          const odds = parseFloat(selections[i].odds) * parseFloat(selections[j].odds);
          combinations.push({
            type: 'double',
            selections: [i, j],
            stake: quickStakeAmount,
            potentialReturn: quickStakeAmount * odds,
            odds: odds
          });
        }
      }
    }
    
    // Accumulator (all selections)
    if (selections.length >= 2) {
      const totalOdds = selections.reduce((total, selection) => {
        return total * parseFloat(selection.odds);
      }, 1);
      combinations.push({
        type: 'accumulator',
        selections: selections.map((_, index) => index),
        stake: quickStakeAmount,
        potentialReturn: quickStakeAmount * totalOdds,
        odds: totalOdds
      });
    }
    
    return combinations;
  };

  const applyQuickStake = (amount: number) => {
    const updated = selections.map(selection => ({
      ...selection,
      stake: amount.toString()
    }));
    setSelections(updated);
    setQuickStakeAmount(amount);
  };

  const placeBet = () => {
    const validSelections = selections.filter(s => parseFloat(s.stake) > 0);
    
    if (validSelections.length === 0) {
      toast({
        title: "No Valid Bets",
        description: "Please add stakes to your selections.",
        variant: "destructive",
      });
      return;
    }

    validSelections.forEach(selection => {
      placeBetMutation.mutate({
        matchId: selection.matchId,
        market: selection.market,
        selection: selection.selection,
        odds: selection.odds,
        stake: selection.stake,
        potentialWin: (parseFloat(selection.stake) * parseFloat(selection.odds)).toFixed(2),
      });
    });
  };

  useEffect(() => {
    setMultiBetCombinations(calculateMultiBetCombinations());
  }, [selections, quickStakeAmount]);

  // Expose addSelection function globally for match cards to use
  (window as any).addToBetSlip = addSelection;

  return (
    <div className="bg-winnex-gray rounded-lg p-4 sticky top-20 max-h-[80vh] overflow-y-auto">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold flex items-center">
          <Ticket className="mr-2" size={18} />
          Enhanced Bet Slip
        </h3>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs">
            {selections.length} selection{selections.length !== 1 ? 's' : ''}
          </Badge>
          {selections.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelections([])}
              className="text-gray-400 hover:text-white"
            >
              Clear All
            </Button>
          )}
        </div>
      </div>

      {selections.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <Ticket size={48} className="mx-auto mb-4 opacity-50" />
          <p>Your bet slip is empty</p>
          <p className="text-sm mt-2">Add selections from matches to get started</p>
        </div>
      ) : (
        <Tabs value={betType} onValueChange={(value) => setBetType(value as 'single' | 'multi')}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="single" className="flex items-center gap-2">
              <Target size={16} />
              Single Bets
            </TabsTrigger>
            <TabsTrigger value="multi" className="flex items-center gap-2">
              <Shuffle size={16} />
              Multi Bets
            </TabsTrigger>
          </TabsList>

          <TabsContent value="single" className="space-y-4">
            {/* Quick Stakes */}
            <Card className="bg-winnex-dark border-winnex-accent">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Zap size={16} />
                  Quick Stakes
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="grid grid-cols-4 gap-2 mb-3">
                  {[5, 10, 25, 50].map(amount => (
                    <Button
                      key={amount}
                      variant={quickStakeAmount === amount ? "default" : "outline"}
                      size="sm"
                      onClick={() => applyQuickStake(amount)}
                      className="text-xs"
                    >
                      ${amount}
                    </Button>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={autoStakeEnabled}
                    onCheckedChange={setAutoStakeEnabled}
                    id="auto-stake"
                  />
                  <label htmlFor="auto-stake" className="text-xs text-gray-400">
                    Auto-apply to new selections
                  </label>
                </div>
              </CardContent>
            </Card>

            {/* Individual Selections */}
            {selections.map((selection, index) => (
              <Card key={index} className="bg-winnex-dark border-winnex-accent">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{selection.match}</h4>
                      <p className="text-xs text-gray-400">{selection.market}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-xs">
                          {selection.selection}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {selection.odds}
                        </Badge>
                        {selection.expectedValue && (
                          <Badge variant="default" className="text-xs bg-green-600">
                            EV: +{selection.expectedValue}%
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSelection(index)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        placeholder="Stake"
                        value={selection.stake}
                        onChange={(e) => updateStake(index, e.target.value)}
                        className="flex-1 bg-winnex-gray border-winnex-accent"
                      />
                      <span className="text-sm text-gray-400">
                        {getCurrentCurrency().symbol}
                      </span>
                    </div>
                    
                    {parseFloat(selection.stake) > 0 && (
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">Potential Win:</span>
                        <span className="text-winnex-accent font-medium">
                          {getCurrentCurrency().symbol}
                          {(parseFloat(selection.stake) * parseFloat(selection.odds)).toFixed(2)}
                        </span>
                      </div>
                    )}
                    
                    {selection.confidence && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-gray-400">AI Confidence:</span>
                          <span className="text-winnex-accent">{selection.confidence}%</span>
                        </div>
                        <Progress value={selection.confidence} className="h-1" />
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="multi" className="space-y-4">
            {selections.length < 2 ? (
              <div className="text-center py-8 text-gray-400">
                <Calculator size={48} className="mx-auto mb-4 opacity-50" />
                <p>Add at least 2 selections for multi bets</p>
              </div>
            ) : (
              <>
                <Card className="bg-winnex-dark border-winnex-accent">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <DollarSign size={16} />
                      Multi Bet Stake
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <Input
                      type="number"
                      value={quickStakeAmount}
                      onChange={(e) => setQuickStakeAmount(parseFloat(e.target.value) || 0)}
                      className="bg-winnex-gray border-winnex-accent"
                      placeholder="Enter stake amount"
                    />
                  </CardContent>
                </Card>

                <div className="space-y-3">
                  {multiBetCombinations.slice(0, 5).map((combination, index) => (
                    <Card key={index} className="bg-winnex-dark border-winnex-accent">
                      <CardContent className="p-3">
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs capitalize">
                              {combination.type}
                            </Badge>
                            <span className="text-xs text-gray-400">
                              {combination.selections.length} selections
                            </span>
                          </div>
                          <div className="text-right">
                            <div className="text-xs text-gray-400">Odds:</div>
                            <div className="text-sm font-medium">{combination.odds.toFixed(2)}</div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-400">
                            Stake: {getCurrentCurrency().symbol}{combination.stake}
                          </div>
                          <div className="text-winnex-accent font-medium">
                            Win: {getCurrentCurrency().symbol}{combination.potentialReturn.toFixed(2)}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
      )}

      {selections.length > 0 && (
        <>
          {/* Currency Selector */}
          <Card className="bg-winnex-dark border-winnex-accent mt-4">
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Currency:</span>
                <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
                  <SelectTrigger className="w-32 bg-winnex-gray border-winnex-accent">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map(currency => (
                      <SelectItem key={currency.code} value={currency.code}>
                        <div className="flex items-center gap-2">
                          <span>{currency.flag}</span>
                          <span>{currency.code}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Betting Summary */}
          <Card className="bg-gradient-to-r from-winnex-accent/20 to-winnex-primary/20 border-winnex-accent mt-4">
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-300">Total Stake:</span>
                  <span className="font-bold text-lg">
                    {getCurrentCurrency().symbol}{(betType === 'single' ? calculateTotalStake() : quickStakeAmount).toFixed(2)}
                  </span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-300">Potential Win:</span>
                  <span className="font-bold text-lg text-winnex-accent">
                    {getCurrentCurrency().symbol}{calculatePotentialWin().toFixed(2)}
                  </span>
                </div>
                
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Potential Profit:</span>
                  <span className="text-green-400 font-medium">
                    {getCurrentCurrency().symbol}
                    {(calculatePotentialWin() - (betType === 'single' ? calculateTotalStake() : quickStakeAmount)).toFixed(2)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Place Bet Button */}
          <Button
            onClick={placeBet}
            disabled={placeBetMutation.isPending || (betType === 'single' && calculateTotalStake() === 0)}
            className="w-full mt-4 bg-gradient-to-r from-winnex-accent to-winnex-primary hover:from-winnex-primary hover:to-winnex-accent transition-all duration-300"
            size="lg"
          >
            {placeBetMutation.isPending ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                Placing Bet...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Trophy size={16} />
                Place {betType === 'single' ? 'Bets' : 'Multi Bet'}
              </div>
            )}
          </Button>
        </>
      )}
    </div>
  );
}