import { useLocation } from "wouter";

// Global navigation utility for consistent routing throughout the app
export const useNavigate = () => {
  const [location, setLocation] = useLocation();
  
  const navigate = (path: string) => {
    setLocation(path);
  };
  
  return { navigate, location };
};

// Fix for buttons that need navigation
export const NavigationButton = ({ 
  href, 
  onClick, 
  children, 
  className,
  ...props 
}: {
  href?: string;
  onClick?: () => void;
  children: React.ReactNode;
  className?: string;
  [key: string]: any;
}) => {
  const { navigate } = useNavigate();
  
  const handleClick = () => {
    if (onClick) {
      onClick();
    } else if (href) {
      navigate(href);
    }
  };
  
  return (
    <button onClick={handleClick} className={className} {...props}>
      {children}
    </button>
  );
};