import Layout from "@/components/Layout";
import EnhancedDashboard from "@/components/EnhancedDashboard";

export default function Dashboard() {
  return (
    <Layout>
      <EnhancedDashboard />
    </Layout>
  );
}