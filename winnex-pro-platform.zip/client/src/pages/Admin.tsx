import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ChartLine,
  Users,
  TicketCheck,
  Shield,
  Pause,
  Edit3,
  Ban,
  UserCheck,
  CreditCard,
  Headphones,
  Radio,
  Megaphone,
  Download,
  TrendingUp,
  AlertTriangle,
} from "lucide-react";

export default function Admin() {
  const { user } = useAuth();
  const { toast } = useToast();

  // Redirect if not admin
  useEffect(() => {
    if (user && !user.isAdmin) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to access the admin panel.",
        variant: "destructive",
      });
      window.location.href = "/";
    }
  }, [user, toast]);

  const { data: adminStats } = useQuery({
    queryKey: ["/api/admin/stats"],
    enabled: user?.isAdmin,
  });

  if (!user?.isAdmin) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <AlertTriangle className="mx-auto mb-4 text-red-500" size={64} />
            <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
            <p className="text-gray-400">You don't have permission to access this page.</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">Platform Management Dashboard</h1>
          <p className="text-gray-400">Admin-only interface for platform operations</p>
        </div>

        {/* Key Metrics */}
        <div className="grid lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-winnex-gray border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Today's Revenue</h3>
                <ChartLine className="text-winnex-green" size={20} />
              </div>
              <div className="text-2xl font-bold text-winnex-green">
                ${adminStats?.revenue?.today || "47,329"}
              </div>
              <div className="text-xs text-green-400">+12.5% vs yesterday</div>
            </CardContent>
          </Card>

          <Card className="bg-winnex-gray border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Active Users</h3>
                <Users className="text-winnex-blue" size={20} />
              </div>
              <div className="text-2xl font-bold text-winnex-blue">
                {adminStats?.users?.active || "2,847"}
              </div>
              <div className="text-xs text-blue-400">+5.2% vs last hour</div>
            </CardContent>
          </Card>

          <Card className="bg-winnex-gray border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Total Bets</h3>
                <TicketCheck className="text-winnex-orange" size={20} />
              </div>
              <div className="text-2xl font-bold text-winnex-orange">
                {adminStats?.bets?.total || "18,492"}
              </div>
              <div className="text-xs text-orange-400">+8.7% vs yesterday</div>
            </CardContent>
          </Card>

          <Card className="bg-winnex-gray border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Risk Exposure</h3>
                <Shield className="text-yellow-500" size={20} />
              </div>
              <div className="text-2xl font-bold text-yellow-500">
                ${adminStats?.risk?.exposure || "234K"}
              </div>
              <div className="text-xs text-yellow-400">Within limits</div>
            </CardContent>
          </Card>
        </div>

        {/* Admin Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-winnex-gray border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="mr-2" size={20} />
                Risk Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start border-gray-600"
              >
                <Pause className="mr-2" size={16} />
                Suspend Market
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start border-gray-600"
              >
                <Edit3 className="mr-2" size={16} />
                Adjust Odds
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start border-gray-600"
              >
                <Ban className="mr-2" size={16} />
                Limit User
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-winnex-gray border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="mr-2" size={20} />
                User Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start border-gray-600"
              >
                <UserCheck className="mr-2" size={16} />
                KYC Reviews
                <Badge className="ml-auto bg-red-500">5</Badge>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start border-gray-600"
              >
                <CreditCard className="mr-2" size={16} />
                Payment Issues
                <Badge className="ml-auto bg-yellow-500">12</Badge>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start border-gray-600"
              >
                <Headphones className="mr-2" size={16} />
                Support Tickets
                <Badge className="ml-auto bg-blue-500">23</Badge>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-winnex-gray border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Radio className="mr-2" size={20} />
                Platform Control
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start border-gray-600"
              >
                <Radio className="mr-2" size={16} />
                System Status
                <Badge className="ml-auto bg-green-500">Online</Badge>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start border-gray-600"
              >
                <Megaphone className="mr-2" size={16} />
                Send Alert
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start border-gray-600"
              >
                <Download className="mr-2" size={16} />
                Export Data
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="bg-winnex-gray border-gray-600">
            <CardHeader>
              <CardTitle>Recent High-Value Bets</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-winnex-dark rounded">
                  <div>
                    <div className="font-semibold">User #2847</div>
                    <div className="text-sm text-gray-400">Arsenal vs Chelsea</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-winnex-green">$5,000</div>
                    <div className="text-xs text-gray-400">2 min ago</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-winnex-dark rounded">
                  <div>
                    <div className="font-semibold">User #1923</div>
                    <div className="text-sm text-gray-400">Lakers vs Warriors</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-winnex-green">$3,200</div>
                    <div className="text-xs text-gray-400">5 min ago</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-winnex-dark rounded">
                  <div>
                    <div className="font-semibold">User #5621</div>
                    <div className="text-sm text-gray-400">Live Blackjack</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-winnex-green">$2,800</div>
                    <div className="text-xs text-gray-400">8 min ago</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-winnex-gray border-gray-600">
            <CardHeader>
              <CardTitle>System Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-red-900/20 border border-red-500/20 rounded">
                  <AlertTriangle className="text-red-500" size={16} />
                  <div className="flex-1">
                    <div className="font-semibold">High Risk Exposure</div>
                    <div className="text-sm text-gray-400">Football: Man City vs Liverpool</div>
                  </div>
                  <Button size="sm" variant="outline" className="border-red-500 text-red-500">
                    Review
                  </Button>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-yellow-900/20 border border-yellow-500/20 rounded">
                  <AlertTriangle className="text-yellow-500" size={16} />
                  <div className="flex-1">
                    <div className="font-semibold">Unusual Betting Pattern</div>
                    <div className="text-sm text-gray-400">Tennis: Djokovic vs Nadal</div>
                  </div>
                  <Button size="sm" variant="outline" className="border-yellow-500 text-yellow-500">
                    Investigate
                  </Button>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-blue-900/20 border border-blue-500/20 rounded">
                  <TrendingUp className="text-blue-500" size={16} />
                  <div className="flex-1">
                    <div className="font-semibold">Peak Traffic Alert</div>
                    <div className="text-sm text-gray-400">Server load at 85%</div>
                  </div>
                  <Button size="sm" variant="outline" className="border-blue-500 text-blue-500">
                    Monitor
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
