import Layout from "@/components/Layout";
import EnhancedSecurityCenter from "@/components/EnhancedSecurityCenter";

export default function Security() {
  return (
    <Layout>
      <EnhancedSecurityCenter />
    </Layout>
  );
}