import Layout from "@/components/Layout";
import CryptoPaymentGateway from "@/components/CryptoPaymentGateway";

export default function Payments() {
  return (
    <Layout>
      <CryptoPaymentGateway />
    </Layout>
  );
}