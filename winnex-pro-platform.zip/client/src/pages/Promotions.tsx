import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Layout from '@/components/Layout';
import { Gift, Percent, Trophy, Clock, Star, Zap, Target, Calendar } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface Promotion {
  id: string;
  title: string;
  description: string;
  type: 'welcome_bonus' | 'deposit_match' | 'free_bet' | 'cashback' | 'loyalty' | 'tournament';
  value: number;
  currency: 'USD' | 'percentage' | 'points';
  requirements: {
    minDeposit?: number;
    minOdds?: number;
    rollover?: number;
    timeLimit?: string;
    eligibleSports?: string[];
  };
  validUntil: string;
  isActive: boolean;
  isEligible: boolean;
  claimed: boolean;
  termsUrl: string;
  popularity: number;
  maxClaim?: number;
  currentClaims?: number;
}

interface UserPromotion {
  id: string;
  promotionId: string;
  title: string;
  status: 'active' | 'completed' | 'expired' | 'pending';
  progress: number;
  target: number;
  reward: string;
  expiresAt: string;
  claimedAt?: string;
}

interface LoyaltyProgram {
  currentTier: string;
  points: number;
  nextTierPoints: number;
  benefits: string[];
  monthlyWagering: number;
  lifetimeWagering: number;
  tierProgress: number;
}

export default function Promotions() {
  const [selectedType, setSelectedType] = useState<string>('all');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: promotions, isLoading: promotionsLoading } = useQuery({
    queryKey: ['/api/promotions'],
  });

  const { data: userPromotions, isLoading: userPromotionsLoading } = useQuery({
    queryKey: ['/api/user/promotions'],
  });

  const { data: loyaltyProgram } = useQuery({
    queryKey: ['/api/user/loyalty'],
  });

  const claimPromotionMutation = useMutation({
    mutationFn: (promotionId: string) =>
      apiRequest('/api/promotions/claim', 'POST', { promotionId }),
    onSuccess: (data) => {
      toast({
        title: "Promotion Claimed!",
        description: "Your bonus has been added to your account.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/promotions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user/promotions'] });
    },
    onError: (error: any) => {
      toast({
        title: "Claim Failed",
        description: error.message || "Unable to claim promotion.",
        variant: "destructive",
      });
    },
  });

  const getPromotionIcon = (type: string) => {
    switch (type) {
      case 'welcome_bonus': return Gift;
      case 'deposit_match': return Percent;
      case 'free_bet': return Target;
      case 'cashback': return Zap;
      case 'loyalty': return Star;
      case 'tournament': return Trophy;
      default: return Gift;
    }
  };

  const getPromotionColor = (type: string) => {
    switch (type) {
      case 'welcome_bonus': return 'bg-green-500/20 text-green-400 border-green-500/20';
      case 'deposit_match': return 'bg-blue-500/20 text-blue-400 border-blue-500/20';
      case 'free_bet': return 'bg-purple-500/20 text-purple-400 border-purple-500/20';
      case 'cashback': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/20';
      case 'loyalty': return 'bg-pink-500/20 text-pink-400 border-pink-500/20';
      case 'tournament': return 'bg-orange-500/20 text-orange-400 border-orange-500/20';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/20';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-400';
      case 'completed': return 'bg-blue-500/20 text-blue-400';
      case 'expired': return 'bg-red-500/20 text-red-400';
      case 'pending': return 'bg-yellow-500/20 text-yellow-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const formatValue = (value: number, currency: string) => {
    switch (currency) {
      case 'USD': return `$${value}`;
      case 'percentage': return `${value}%`;
      case 'points': return `${value} pts`;
      default: return value.toString();
    }
  };

  const filteredPromotions = promotions?.filter((promo: Promotion) => 
    selectedType === 'all' || promo.type === selectedType
  ) || [];

  if (promotionsLoading || userPromotionsLoading) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-500 mx-auto"></div>
            <p className="mt-4 text-slate-300">Loading promotions...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center mb-4">
            <Gift className="h-12 w-12 text-green-400 mr-4" />
            <h1 className="text-4xl font-bold text-white">Promotions & Bonuses</h1>
          </div>
          <p className="text-slate-300 text-lg">Maximize your winnings with exclusive offers and rewards</p>
        </div>

        {/* Loyalty Program Overview */}
        {loyaltyProgram && (
          <Card className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-purple-500/20 backdrop-blur-xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Star className="h-6 w-6 mr-2 text-yellow-400" />
                VIP Loyalty Program - {loyaltyProgram.currentTier} Tier
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <p className="text-slate-300 text-sm">Current Points</p>
                  <p className="text-3xl font-bold text-white">{loyaltyProgram.points.toLocaleString()}</p>
                  <Progress 
                    value={loyaltyProgram.tierProgress} 
                    className="mt-2" 
                  />
                  <p className="text-slate-400 text-xs mt-1">
                    {loyaltyProgram.nextTierPoints - loyaltyProgram.points} points to next tier
                  </p>
                </div>
                <div>
                  <p className="text-slate-300 text-sm">Monthly Wagering</p>
                  <p className="text-2xl font-bold text-green-400">${loyaltyProgram.monthlyWagering.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-slate-300 text-sm">Lifetime Wagering</p>
                  <p className="text-2xl font-bold text-blue-400">${loyaltyProgram.lifetimeWagering.toLocaleString()}</p>
                </div>
              </div>
              <div>
                <p className="text-slate-300 text-sm mb-2">Current Benefits</p>
                <div className="flex flex-wrap gap-2">
                  {loyaltyProgram.benefits.map((benefit, index) => (
                    <Badge key={index} className="bg-purple-500/20 text-purple-400">
                      {benefit}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="available" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="available" className="data-[state=active]:bg-green-500/20">
              Available Promotions
            </TabsTrigger>
            <TabsTrigger value="active" className="data-[state=active]:bg-green-500/20">
              My Active Bonuses
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-green-500/20">
              Bonus History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="available" className="space-y-6">
            {/* Promotion Type Filter */}
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedType === 'all' ? 'default' : 'outline'}
                onClick={() => setSelectedType('all')}
                size="sm"
              >
                All Promotions
              </Button>
              <Button
                variant={selectedType === 'welcome_bonus' ? 'default' : 'outline'}
                onClick={() => setSelectedType('welcome_bonus')}
                size="sm"
              >
                Welcome Bonus
              </Button>
              <Button
                variant={selectedType === 'deposit_match' ? 'default' : 'outline'}
                onClick={() => setSelectedType('deposit_match')}
                size="sm"
              >
                Deposit Match
              </Button>
              <Button
                variant={selectedType === 'free_bet' ? 'default' : 'outline'}
                onClick={() => setSelectedType('free_bet')}
                size="sm"
              >
                Free Bets
              </Button>
              <Button
                variant={selectedType === 'cashback' ? 'default' : 'outline'}
                onClick={() => setSelectedType('cashback')}
                size="sm"
              >
                Cashback
              </Button>
            </div>

            {/* Promotions Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredPromotions.map((promotion: Promotion) => {
                const Icon = getPromotionIcon(promotion.type);
                return (
                  <Card key={promotion.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div className="flex items-center space-x-3">
                          <div className={`p-2 rounded-lg ${getPromotionColor(promotion.type)}`}>
                            <Icon className="h-6 w-6" />
                          </div>
                          <div>
                            <CardTitle className="text-white">{promotion.title}</CardTitle>
                            <Badge className={getPromotionColor(promotion.type)}>
                              {promotion.type.replace('_', ' ')}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-3xl font-bold text-green-400">
                            {formatValue(promotion.value, promotion.currency)}
                          </p>
                          {promotion.maxClaim && (
                            <p className="text-slate-400 text-sm">
                              {promotion.currentClaims || 0}/{promotion.maxClaim} claimed
                            </p>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-slate-300">{promotion.description}</p>

                      {/* Requirements */}
                      <div className="space-y-2">
                        <p className="text-slate-400 text-sm font-medium">Requirements:</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                          {promotion.requirements.minDeposit && (
                            <div className="flex justify-between">
                              <span className="text-slate-400">Min Deposit:</span>
                              <span className="text-white">${promotion.requirements.minDeposit}</span>
                            </div>
                          )}
                          {promotion.requirements.minOdds && (
                            <div className="flex justify-between">
                              <span className="text-slate-400">Min Odds:</span>
                              <span className="text-white">{promotion.requirements.minOdds}</span>
                            </div>
                          )}
                          {promotion.requirements.rollover && (
                            <div className="flex justify-between">
                              <span className="text-slate-400">Rollover:</span>
                              <span className="text-white">{promotion.requirements.rollover}x</span>
                            </div>
                          )}
                          {promotion.requirements.timeLimit && (
                            <div className="flex justify-between">
                              <span className="text-slate-400">Time Limit:</span>
                              <span className="text-white">{promotion.requirements.timeLimit}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Eligible Sports */}
                      {promotion.requirements.eligibleSports && (
                        <div>
                          <p className="text-slate-400 text-sm mb-2">Eligible Sports:</p>
                          <div className="flex flex-wrap gap-1">
                            {promotion.requirements.eligibleSports.map((sport, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {sport}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Expiry and Action */}
                      <div className="flex items-center justify-between pt-4 border-t border-slate-600">
                        <div className="flex items-center text-slate-400 text-sm">
                          <Clock className="h-4 w-4 mr-1" />
                          Expires: {new Date(promotion.validUntil).toLocaleDateString()}
                        </div>
                        <Button
                          onClick={() => claimPromotionMutation.mutate(promotion.id)}
                          disabled={!promotion.isEligible || promotion.claimed || claimPromotionMutation.isPending}
                          className={`${
                            promotion.claimed 
                              ? 'bg-gray-500/20 text-gray-400 cursor-not-allowed' 
                              : 'bg-green-500 hover:bg-green-600'
                          }`}
                        >
                          {promotion.claimed ? 'Claimed' : promotion.isEligible ? 'Claim Now' : 'Not Eligible'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="active" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {userPromotions?.filter((promo: UserPromotion) => promo.status === 'active').map((promotion: UserPromotion) => (
                <Card key={promotion.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-white">{promotion.title}</CardTitle>
                      <Badge className={getStatusColor(promotion.status)}>
                        {promotion.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-slate-400">Progress</span>
                        <span className="text-white">{promotion.progress}/{promotion.target}</span>
                      </div>
                      <Progress value={(promotion.progress / promotion.target) * 100} className="h-2" />
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-slate-400">Reward</p>
                        <p className="text-green-400 font-bold">{promotion.reward}</p>
                      </div>
                      <div>
                        <p className="text-slate-400">Expires</p>
                        <p className="text-white">{new Date(promotion.expiresAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {userPromotions?.filter((promo: UserPromotion) => promo.status === 'active').length === 0 && (
              <div className="text-center py-12">
                <Target className="h-16 w-16 text-slate-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Active Bonuses</h3>
                <p className="text-slate-400">Claim a promotion to start earning rewards</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <div className="space-y-4">
              {userPromotions?.filter((promo: UserPromotion) => promo.status !== 'active').map((promotion: UserPromotion) => (
                <Card key={promotion.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="text-white font-bold">{promotion.title}</h3>
                        <p className="text-slate-400 text-sm">
                          {promotion.status === 'completed' ? 'Completed' : 'Expired'} • 
                          {promotion.claimedAt ? ` Claimed ${new Date(promotion.claimedAt).toLocaleDateString()}` : ''}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge className={getStatusColor(promotion.status)}>
                          {promotion.status}
                        </Badge>
                        <p className="text-green-400 font-bold mt-1">{promotion.reward}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {userPromotions?.filter((promo: UserPromotion) => promo.status !== 'active').length === 0 && (
              <div className="text-center py-12">
                <Calendar className="h-16 w-16 text-slate-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Bonus History</h3>
                <p className="text-slate-400">Your completed and expired bonuses will appear here</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}