import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import Layout from "@/components/Layout";
import MatchCard from "@/components/MatchCard";
import LiveMatch from "@/components/LiveMatch";
import PopularityHeatMap from "@/components/PopularityHeatMap";
import BetSlip from "@/components/BetSlip";
import AchievementTracker from "@/components/AchievementTracker";
import SportsNewsFeed from "@/components/SportsNewsFeed";
import MobileGestureControls from "@/components/MobileGestureControls";
import { Trophy, TrendingUp, Users, DollarSign, Flame, Award, BookOpen, Smartphone } from "lucide-react";

export default function Home() {
  const [selectedSport, setSelectedSport] = useState<string>("all");
  const { data: matches = [] } = useQuery({
    queryKey: ["/api/matches"],
  });

  const { data: sports = [] } = useQuery({
    queryKey: ["/api/sports"],
  });

  // Filter matches based on selected sport
  const filteredMatches = Array.isArray(matches) ? matches.filter((match: any) => {
    if (selectedSport === "all") return true;
    // Map sport IDs to filter names
    const sportMap: { [key: number]: string } = {
      1: "football", // Football
      2: "basketball", // Basketball  
      3: "football", // Soccer (also football)
      4: "tennis", // Tennis
      5: "baseball" // Baseball
    };
    return sportMap[match.sportId]?.toLowerCase() === selectedSport.toLowerCase();
  }) : [];

  // Get odds for matches
  const matchesWithOdds = filteredMatches.slice(0, 5).map((match: any) => ({
    match,
    odds: [], // This would normally be fetched per match
  }));
  
  const liveMatches = Array.isArray(matches) ? matches.filter((match: any) => match.isLive) : [];

  const sportFilters = [
    { id: "all", name: "All" },
    { id: "football", name: "Football" },
    { id: "basketball", name: "Basketball" },
    { id: "tennis", name: "Tennis" }
  ];

  return (
    <Layout>
      {/* Enhanced Hero Section */}
      <section className="relative h-screen overflow-hidden flex items-center justify-center">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="w-full h-full bg-gradient-to-br from-slate-950 via-indigo-950 to-emerald-950"></div>
          
          {/* Dynamic Grid Pattern */}
          <div className="absolute inset-0 opacity-20">
            <div className="grid grid-cols-12 grid-rows-8 h-full w-full">
              {Array.from({ length: 96 }, (_, i) => (
                <div key={i} className="border border-emerald-400/10 animate-pulse" style={{animationDelay: `${i * 0.1}s`}}></div>
              ))}
            </div>
          </div>
          
          {/* Casino Elements Floating */}
          <div className="absolute top-20 left-20">
            <div className="slot-machine w-16 h-16 rounded-lg flex items-center justify-center text-2xl animate-bounce">
              🎰
            </div>
          </div>
          <div className="absolute top-32 right-24">
            <div className="roulette-wheel w-20 h-20 rounded-full flex items-center justify-center text-xl animate-roulette-spin">
              🎡
            </div>
          </div>
          <div className="absolute bottom-40 left-32">
            <div className="card-deck w-12 h-16 rounded flex items-center justify-center text-lg animate-card-flip">
              🃏
            </div>
          </div>
          <div className="absolute bottom-20 right-20">
            <div className="dice-3d w-14 h-14 rounded-lg flex items-center justify-center text-xl animate-dice-roll">
              🎲
            </div>
          </div>
          
          {/* Particle Effects */}
          {Array.from({ length: 20 }, (_, i) => (
            <div 
              key={i}
              className="absolute w-1 h-1 bg-emerald-400 rounded-full animate-ping"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            ></div>
          ))}
        </div>
        
        {/* Floating Orbs */}
        <div className="absolute top-16 left-16 w-40 h-40 bg-gradient-to-r from-emerald-400/30 to-cyan-400/30 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-20 w-32 h-32 bg-gradient-to-r from-violet-400/30 to-purple-400/30 rounded-full blur-3xl animate-float animation-delay-1000"></div>
        <div className="absolute top-1/3 right-1/3 w-24 h-24 bg-gradient-to-r from-orange-400/30 to-red-400/30 rounded-full blur-2xl animate-float animation-delay-2000"></div>
        
        {/* Main Content */}
        <div className="relative z-20 text-center max-w-6xl mx-auto px-6">
          <div className="casino-card backdrop-blur-xl border border-emerald-400/20 rounded-3xl p-16 shadow-2xl glow-green">
            {/* Logo Section */}
            <div className="flex items-center justify-center mb-8">
              <div className="relative">
                <h1 className="text-8xl font-black bg-gradient-to-r from-emerald-400 via-cyan-400 to-emerald-400 bg-clip-text text-transparent animate-jackpot-pulse">
                  W
I
                  NNEX
                </h1>
                <div className="h-1 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-full animate-pulse mt-2"></div>
              </div>
            </div>
            
            {/* Tagline */}
            <div className="mb-8">
              <p className="text-3xl mb-4 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent font-bold">
                The Ultimate Gaming Experience
              </p>
              <p className="text-xl text-emerald-400 font-semibold animate-pulse">
                🏆 Sports • 🎰 Casino • 🎮 Esports • 📺 Live Streaming
              </p>
            </div>
            
            {/* Feature Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <div className="betting-card p-4 rounded-xl text-center">
                <div className="text-3xl mb-2">💰</div>
                <div className="text-emerald-400 font-bold">$2.4M Jackpot</div>
                <div className="text-gray-400 text-sm">Live Now</div>
              </div>
              <div className="betting-card p-4 rounded-xl text-center">
                <div className="text-3xl mb-2">🔴</div>
                <div className="text-red-400 font-bold">156 Live Games</div>
                <div className="text-gray-400 text-sm">Betting Available</div>
              </div>
              <div className="betting-card p-4 rounded-xl text-center">
                <div className="text-3xl mb-2">🎯</div>
                <div className="text-cyan-400 font-bold">AI Predictions</div>
                <div className="text-gray-400 text-sm">94% Accuracy</div>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Link href="/sports">
                <button className="group relative overflow-hidden bg-gradient-to-r from-emerald-500 to-cyan-500 text-black font-bold text-xl px-12 py-4 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-2xl animate-glow">
                  <span className="relative z-10">🚀 Start Betting</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </button>
              </Link>
              <Link href="/casino">
                <button className="group relative overflow-hidden bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xl px-12 py-4 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                  <span className="relative z-10 flex items-center">
                    🎰 <span className="ml-2">Play Casino</span>
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-pink-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </button>
              </Link>
              <Link href="/live">
                <button className="group relative overflow-hidden bg-gradient-to-r from-red-600 to-orange-600 text-white font-bold text-xl px-12 py-4 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                  <span className="relative z-10 flex items-center">
                    <div className="w-3 h-3 bg-white rounded-full mr-3 animate-pulse"></div>
                    Live Now
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </button>
              </Link>
            </div>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <div className="w-6 h-10 border-2 border-emerald-400 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-emerald-400 rounded-full mt-2 animate-bounce"></div>
          </div>
        </div>
      </section>

      {/* Live Betting Banner */}
      <section className="relative mx-6 -mt-20 z-30">
        <div className="glass-hover rounded-2xl p-6 glow-card gradient-live">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="w-4 h-4 bg-white rounded-full animate-pulse"></div>
                  <div className="absolute inset-0 w-4 h-4 bg-white rounded-full animate-ping"></div>
                </div>
                <span className="font-bold text-lg">LIVE NOW</span>
              </div>
              <div className="hidden md:flex items-center space-x-6">
                <span className="font-semibold text-white">Manchester United vs Liverpool</span>
                <div className="text-sm text-white/80">2nd Half • 67:32</div>
              </div>
              <div className="flex space-x-4">
                <button className="glass-hover rounded-lg p-3 transition-all duration-300 hover:scale-105">
                  <div className="text-center">
                    <div className="text-xs text-white/80">Man United</div>
                    <div className="text-lg font-bold text-white">2.45</div>
                  </div>
                </button>
                <button className="glass-hover rounded-lg p-3 transition-all duration-300 hover:scale-105">
                  <div className="text-center">
                    <div className="text-xs text-white/80">Draw</div>
                    <div className="text-lg font-bold text-white">3.20</div>
                  </div>
                </button>
                <button className="glass-hover rounded-lg p-3 transition-all duration-300 hover:scale-105">
                  <div className="text-center">
                    <div className="text-xs text-white/80">Liverpool</div>
                    <div className="text-lg font-bold text-white">1.85</div>
                  </div>
                </button>
              </div>
            </div>
            <Link href="/live">
              <button className="btn-secondary">
                Watch Live
              </button>
            </Link>
          </div>
        </div>
      </section>

      <div className="p-6">
        {/* Popular Matches Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Popular Matches</h2>
            <div className="flex space-x-2">
              {sportFilters.map((filter) => (
                <Button
                  key={filter.id}
                  variant={selectedSport === filter.id ? "default" : "outline"}
                  size="sm"
                  className={selectedSport === filter.id ? "bg-winnex-green text-black" : ""}
                  onClick={() => setSelectedSport(filter.id)}
                >
                  {filter.name}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid gap-4 mb-4">
            {filteredMatches.length > 0 ? (
              filteredMatches.slice(0, 3).map((match: any) => (
                <div key={match.id} className="bg-winnex-gray rounded-lg p-4 hover:bg-gray-700 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-sm text-gray-400">
                        {new Date(match.matchDate).toLocaleDateString()} {new Date(match.matchDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="font-semibold">{match.team1}</span>
                        <span className="text-gray-400">vs</span>
                        <span className="font-semibold">{match.team2}</span>
                      </div>
                      <Badge className="bg-winnex-blue">{match.league}</Badge>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="bg-winnex-dark border-gray-600 hover:bg-gray-800">
                        <div className="text-center">
                          <div className="text-xs text-gray-400">{match.team1} Win</div>
                          <div className="font-bold text-winnex-green">2.10</div>
                        </div>
                      </Button>
                      <Button variant="outline" size="sm" className="bg-winnex-dark border-gray-600 hover:bg-gray-800">
                        <div className="text-center">
                          <div className="text-xs text-gray-400">Draw</div>
                          <div className="font-bold text-winnex-green">3.40</div>
                        </div>
                      </Button>
                      <Button variant="outline" size="sm" className="bg-winnex-dark border-gray-600 hover:bg-gray-800">
                        <div className="text-center">
                          <div className="text-xs text-gray-400">{match.team2} Win</div>
                          <div className="font-bold text-winnex-green">3.20</div>
                        </div>
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-400">
                No matches found for the selected sport. Try selecting a different sport filter.
              </div>
            )}
          </div>
        </div>

        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - More Matches */}
          <div className="lg:col-span-2">
            {/* Live Betting Section */}
            <div className="mb-8">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <div className="w-3 h-3 bg-red-500 rounded-full mr-2 animate-pulse"></div>
                Live Betting
              </h3>
              <div className="space-y-3">
                {/* Sample live matches */}
                <div className="bg-winnex-gray rounded-lg p-4 border-l-4 border-red-500">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="font-semibold">Real Madrid</span>
                        <Badge className="bg-red-500 animate-pulse text-xs">LIVE</Badge>
                        <span className="text-sm text-gray-400">87:23</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl font-bold text-winnex-green">2</span>
                        <span className="text-gray-400">-</span>
                        <span className="text-2xl font-bold text-winnex-green">1</span>
                        <span className="font-semibold ml-2">Barcelona</span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button className="bg-green-600 hover:bg-green-700">
                        <div className="text-center">
                          <div className="font-bold">1.45</div>
                          <div className="text-xs">Next Goal: Real</div>
                        </div>
                      </Button>
                      <Button className="bg-green-600 hover:bg-green-700">
                        <div className="text-center">
                          <div className="font-bold">2.80</div>
                          <div className="text-xs">Next Goal: Barca</div>
                        </div>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Casino Section */}
            <div>
              <h3 className="text-xl font-bold mb-4">Featured Casino Games</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card 
                  className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer"
                  onClick={() => window.location.href = '/casino'}
                >
                  <CardContent className="p-4">
                    <div className="w-full h-20 bg-gradient-to-br from-green-800 to-emerald-900 rounded mb-2 flex items-center justify-center relative overflow-hidden">
                      <div className="text-4xl animate-pulse">🃏</div>
                      <div className="absolute top-1 left-1 w-2 h-2 bg-red-500 rounded-full animate-ping"></div>
                      <div className="absolute bottom-1 right-1 w-1 h-1 bg-yellow-400 rounded-full animate-pulse"></div>
                      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent animate-pulse"></div>
                    </div>
                    <div className="text-sm font-semibold">Live Blackjack</div>
                    <div className="text-xs text-gray-400">47 players</div>
                  </CardContent>
                </Card>

                <Card 
                  className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer"
                  onClick={() => window.location.href = '/casino'}
                >
                  <CardContent className="p-4">
                    <div className="w-full h-20 bg-gradient-to-br from-red-800 to-orange-900 rounded mb-2 flex items-center justify-center relative overflow-hidden">
                      <div className="text-4xl animate-spin" style={{animationDuration: '4s'}}>🎡</div>
                      <div className="absolute top-2 right-2 w-1 h-1 bg-white rounded-full animate-ping"></div>
                      <div className="absolute bottom-2 left-2 w-1 h-1 bg-yellow-400 rounded-full animate-pulse"></div>
                      <div className="absolute inset-0 bg-gradient-to-bl from-transparent via-white/5 to-transparent animate-pulse"></div>
                    </div>
                    <div className="text-sm font-semibold">Roulette</div>
                    <div className="text-xs text-gray-400">32 players</div>
                  </CardContent>
                </Card>

                <Card 
                  className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer"
                  onClick={() => window.location.href = '/casino'}
                >
                  <CardContent className="p-4">
                    <div className="w-full h-20 bg-gradient-to-br from-purple-800 to-pink-900 rounded mb-2 flex items-center justify-center relative overflow-hidden">
                      <div className="text-4xl animate-bounce">🎰</div>
                      <div className="absolute top-1 left-3 w-1 h-1 bg-yellow-400 rounded-full animate-ping"></div>
                      <div className="absolute top-3 right-1 w-1 h-1 bg-red-500 rounded-full animate-pulse"></div>
                      <div className="absolute bottom-1 center w-1 h-1 bg-green-400 rounded-full animate-ping"></div>
                      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent animate-pulse"></div>
                    </div>
                    <div className="text-sm font-semibold">Mega Slots</div>
                    <div className="text-xs text-winnex-green">$2.4M Jackpot</div>
                  </CardContent>
                </Card>

                <Card 
                  className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer"
                  onClick={() => window.location.href = '/casino'}
                >
                  <CardContent className="p-4">
                    <div className="w-full h-20 bg-gradient-to-br from-blue-800 to-cyan-900 rounded mb-2 flex items-center justify-center relative overflow-hidden">
                      <div className="text-4xl animate-pulse">♠️</div>
                      <div className="absolute top-1 right-3 text-lg animate-bounce">♥️</div>
                      <div className="absolute bottom-1 left-1 text-sm animate-pulse">♦️</div>
                      <div className="absolute top-3 left-3 text-xs animate-ping">♣️</div>
                      <div className="absolute inset-0 bg-gradient-to-tl from-transparent via-white/5 to-transparent animate-pulse"></div>
                    </div>
                    <div className="text-sm font-semibold">Texas Hold'em</div>
                    <div className="text-xs text-gray-400">8 players</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          {/* Right Column - Advanced Features */}
          <div className="space-y-6">
            {/* Enhanced Bet Slip with Currency Conversion */}
            <BetSlip />
          </div>
        </div>

        {/* Advanced Features Dashboard */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6 text-center">Advanced Gaming Features</h2>
          
          <Tabs defaultValue="heatmap" className="w-full">
            <TabsList className="grid w-full grid-cols-5 bg-winnex-gray">
              <TabsTrigger value="heatmap" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
                <Flame className="w-4 h-4 mr-2" />
                Heat Map
              </TabsTrigger>
              <TabsTrigger value="achievements" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
                <Award className="w-4 h-4 mr-2" />
                Achievements
              </TabsTrigger>
              <TabsTrigger value="news" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
                <BookOpen className="w-4 h-4 mr-2" />
                Sports News
              </TabsTrigger>
              <TabsTrigger value="mobile" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
                <Smartphone className="w-4 h-4 mr-2" />
                Mobile Controls
              </TabsTrigger>
              <TabsTrigger value="live" className="text-white data-[state=active]:bg-winnex-green data-[state=active]:text-black">
                <TrendingUp className="w-4 h-4 mr-2" />
                Live Stats
              </TabsTrigger>
            </TabsList>

            <TabsContent value="heatmap" className="mt-6">
              <PopularityHeatMap />
            </TabsContent>

            <TabsContent value="achievements" className="mt-6">
              <AchievementTracker />
            </TabsContent>

            <TabsContent value="news" className="mt-6">
              <SportsNewsFeed />
            </TabsContent>

            <TabsContent value="mobile" className="mt-6">
              <MobileGestureControls />
            </TabsContent>

            <TabsContent value="live" className="mt-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Live Betting Analytics */}
                <Card className="bg-winnex-dark border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-winnex-green">2,847</div>
                        <div className="text-sm text-gray-400">Active Bettors</div>
                      </div>
                      <Users className="w-8 h-8 text-blue-500" />
                    </div>
                    <div className="mt-4 flex items-center">
                      <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                      <span className="text-green-500 text-sm">+12.5%</span>
                      <span className="text-gray-400 text-sm ml-1">vs yesterday</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-winnex-dark border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-winnex-green">$45.2M</div>
                        <div className="text-sm text-gray-400">Live Volume</div>
                      </div>
                      <DollarSign className="w-8 h-8 text-green-500" />
                    </div>
                    <div className="mt-4 flex items-center">
                      <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                      <span className="text-green-500 text-sm">+23.1%</span>
                      <span className="text-gray-400 text-sm ml-1">last hour</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-winnex-dark border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-winnex-green">156</div>
                        <div className="text-sm text-gray-400">Live Matches</div>
                      </div>
                      <Trophy className="w-8 h-8 text-yellow-500" />
                    </div>
                    <div className="mt-4 flex items-center">
                      <span className="text-blue-500 text-sm">Football: 89</span>
                      <span className="text-gray-400 text-sm ml-2">Basketball: 67</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-winnex-dark border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-winnex-green">94.7%</div>
                        <div className="text-sm text-gray-400">System Uptime</div>
                      </div>
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                      </div>
                    </div>
                    <div className="mt-4 text-green-500 text-sm">All systems operational</div>
                  </CardContent>
                </Card>
              </div>

              {/* Real-time Market Data */}
              <div className="mt-8">
                <Card className="bg-winnex-dark border-gray-700">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-white mb-4">Real-Time Market Movements</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                          <span className="text-white">Chiefs vs Bills</span>
                          <Badge className="bg-green-600">+15%</Badge>
                        </div>
                        <div className="text-winnex-green font-bold">1.85 → 1.65</div>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                          <span className="text-white">Lakers vs Celtics</span>
                          <Badge className="bg-red-600">-8%</Badge>
                        </div>
                        <div className="text-red-400 font-bold">2.10 → 2.25</div>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse"></div>
                          <span className="text-white">Arsenal vs Chelsea</span>
                          <Badge className="bg-yellow-600">Steam</Badge>
                        </div>
                        <div className="text-yellow-400 font-bold">2.80 → 2.50</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Right Column - User Info */}
        <div className="mt-8">
          <div className="space-y-6">
            {/* Promotions Panel */}
            <Card className="bg-gradient-to-br from-winnex-orange to-red-600 border-0">
              <CardContent className="p-4 text-white">
                <h3 className="font-bold mb-2">🎉 Welcome Bonus</h3>
                <p className="text-sm mb-3">Get 100% match on your first deposit up to $500!</p>
                <Link href="/promotions">
                  <Button className="bg-white text-winnex-orange hover:bg-gray-100 font-semibold">
                    Claim Now
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="bg-winnex-gray border-gray-600">
              <CardContent className="p-4">
                <h3 className="font-bold mb-3">Your Stats</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Bets Today:</span>
                    <span>7</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Win Rate:</span>
                    <span className="text-winnex-green">64%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Profit Today:</span>
                    <span className="text-winnex-green">+$127.50</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total Bets:</span>
                    <span>1,243</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Platform Stats */}
            <Card className="bg-winnex-gray border-gray-600">
              <CardContent className="p-4">
                <h3 className="font-bold mb-3">Platform Activity</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="bg-winnex-green p-2 rounded">
                      <Trophy size={16} className="text-black" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold">Daily Winners</div>
                      <div className="text-xs text-gray-400">2,847 users won today</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="bg-winnex-blue p-2 rounded">
                      <DollarSign size={16} className="text-white" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold">Payouts</div>
                      <div className="text-xs text-gray-400">$47.3K paid today</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
