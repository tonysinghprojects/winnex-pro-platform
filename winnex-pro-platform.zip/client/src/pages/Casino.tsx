import { useState } from "react";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Dice1, Coins, Spade, Users, DollarSign, Zap, Play, Pause, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Casino() {
  const [location, setLocation] = useLocation();
  const [selectedGame, setSelectedGame] = useState(null);
  const [gameModalOpen, setGameModalOpen] = useState(false);
  const [slotSpinning, setSlotSpinning] = useState(false);
  const [slotReels, setSlotReels] = useState(['🍒', '🍋', '⭐']);
  const [credits, setCredits] = useState(1000);
  const [bet, setBet] = useState(10);
  const { toast } = useToast();

  // Slot machine symbols
  const slotSymbols = ['🍒', '🍋', '⭐', '💎', '🔔', '🍇', '🍊', '💰'];

  // Open game modal
  const openGame = (game: any) => {
    setSelectedGame(game);
    setGameModalOpen(true);
  };

  // Spin slot machine
  const spinSlot = () => {
    if (credits < bet) {
      toast({
        title: "Insufficient Credits",
        description: "You don't have enough credits to place this bet.",
        variant: "destructive",
      });
      return;
    }

    setSlotSpinning(true);
    setCredits(credits - bet);

    // Animate spinning
    let spins = 0;
    const maxSpins = 20;
    const spinInterval = setInterval(() => {
      setSlotReels([
        slotSymbols[Math.floor(Math.random() * slotSymbols.length)],
        slotSymbols[Math.floor(Math.random() * slotSymbols.length)],
        slotSymbols[Math.floor(Math.random() * slotSymbols.length)]
      ]);
      
      spins++;
      if (spins >= maxSpins) {
        clearInterval(spinInterval);
        setSlotSpinning(false);
        
        // Check for wins
        const finalReels = [
          slotSymbols[Math.floor(Math.random() * slotSymbols.length)],
          slotSymbols[Math.floor(Math.random() * slotSymbols.length)],
          slotSymbols[Math.floor(Math.random() * slotSymbols.length)]
        ];
        setSlotReels(finalReels);
        
        // Calculate winnings
        let winnings = 0;
        if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
          // Three of a kind
          winnings = bet * 10;
          if (finalReels[0] === '💎') winnings = bet * 50;
          else if (finalReels[0] === '💰') winnings = bet * 25;
          else if (finalReels[0] === '⭐') winnings = bet * 15;
        } else if (finalReels[0] === finalReels[1] || finalReels[1] === finalReels[2] || finalReels[0] === finalReels[2]) {
          // Two of a kind
          winnings = bet * 2;
        }
        
        if (winnings > 0) {
          setCredits(prev => prev + winnings);
          toast({
            title: "🎉 You Won!",
            description: `You won ${winnings} credits!`,
          });
        }
      }
    }, 100);
  };

  // Play blackjack
  const playBlackjack = () => {
    const playerCard = Math.floor(Math.random() * 10) + 1;
    const dealerCard = Math.floor(Math.random() * 10) + 1;
    
    if (playerCard > dealerCard) {
      const winnings = bet * 2;
      setCredits(prev => prev + winnings);
      toast({
        title: "Blackjack Win!",
        description: `You beat the dealer! Won ${winnings} credits.`,
      });
    } else if (playerCard < dealerCard) {
      setCredits(prev => prev - bet);
      toast({
        title: "Dealer Wins",
        description: `You lost ${bet} credits.`,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Push",
        description: "It's a tie! No money lost.",
      });
    }
  };

  const liveGames = [
    {
      id: 1,
      name: "Live Blackjack",
      players: 47,
      category: "Table Games",
      icon: "♠",
      color: "bg-gradient-to-br from-red-600 to-black"
    },
    {
      id: 2,
      name: "European Roulette",
      players: 32,
      category: "Roulette",
      icon: "⚫",
      color: "bg-gradient-to-br from-green-600 to-red-600"
    },
    {
      id: 3,
      name: "Texas Hold'em",
      players: 8,
      category: "Poker",
      icon: "♦",
      color: "bg-gradient-to-br from-blue-600 to-purple-600"
    },
    {
      id: 4,
      name: "Baccarat VIP",
      players: 12,
      category: "Table Games",
      icon: "♥",
      color: "bg-gradient-to-br from-yellow-600 to-orange-600"
    },
  ];

  const slotGames = [
    {
      id: 1,
      name: "Mega Fortune",
      jackpot: "2.4M",
      rtp: "96.6%",
      icon: "💎",
      color: "bg-gradient-to-br from-purple-600 to-pink-600"
    },
    {
      id: 2,
      name: "Starburst",
      jackpot: "150K",
      rtp: "96.1%",
      icon: "⭐",
      color: "bg-gradient-to-br from-blue-600 to-cyan-600"
    },
    {
      id: 3,
      name: "Book of Dead",
      jackpot: "89K",
      rtp: "94.2%",
      icon: "📚",
      color: "bg-gradient-to-br from-amber-600 to-yellow-600"
    },
    {
      id: 4,
      name: "Gonzo's Quest",
      jackpot: "245K",
      rtp: "95.9%",
      icon: "🗿",
      color: "bg-gradient-to-br from-green-600 to-emerald-600"
    },
  ];

  return (
    <Layout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-4">Casino Games</h1>
          <p className="text-gray-400">
            Play the best casino games with live dealers and massive jackpots
          </p>
        </div>

        {/* Casino Stats Banner */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-800 rounded-lg p-6 mb-8">
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold">$2.4M</div>
              <div className="text-purple-200 text-sm">Biggest Jackpot</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">247</div>
              <div className="text-purple-200 text-sm">Players Online</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">$47K</div>
              <div className="text-purple-200 text-sm">Won This Hour</div>
            </div>
            <div className="text-center">
              <Button className="bg-white text-purple-600 hover:bg-gray-100 font-semibold">
                Claim Welcome Bonus
              </Button>
            </div>
          </div>
        </div>

        {/* Game Categories */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer">
            <CardContent className="p-4 text-center">
              <Dice1 className="mx-auto mb-2 text-winnex-orange" size={32} />
              <div className="font-semibold">Live Casino</div>
              <div className="text-xs text-gray-400">Real dealers</div>
            </CardContent>
          </Card>
          
          <Card className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer">
            <CardContent className="p-4 text-center">
              <Coins className="mx-auto mb-2 text-winnex-orange" size={32} />
              <div className="font-semibold">Slots</div>
              <div className="text-xs text-gray-400">500+ games</div>
            </CardContent>
          </Card>
          
          <Card className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer">
            <CardContent className="p-4 text-center">
              <Spade className="mx-auto mb-2 text-winnex-orange" size={32} />
              <div className="font-semibold">Table Games</div>
              <div className="text-xs text-gray-400">Classic games</div>
            </CardContent>
          </Card>
          
          <Card className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer">
            <CardContent className="p-4 text-center">
              <Zap className="mx-auto mb-2 text-winnex-orange" size={32} />
              <div className="font-semibold">Instant Win</div>
              <div className="text-xs text-gray-400">Quick games</div>
            </CardContent>
          </Card>
        </div>

        {/* Live Casino */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center">
              <div className="w-3 h-3 bg-red-500 rounded-full mr-2 animate-pulse"></div>
              Live Casino
            </h2>
            <Button 
              variant="outline" 
              className="border-gray-600"
              onClick={() => setLocation('/casino')}
            >
              View All
            </Button>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {liveGames.map((game) => (
              <Card key={game.id} className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer overflow-hidden">
                <div className="relative">
                  <div className={`w-full h-32 ${game.color} flex items-center justify-center relative overflow-hidden`}>
                    <div className="text-6xl animate-pulse">{game.icon}</div>
                    <div className="absolute inset-0 bg-gradient-to-br from-transparent via-white/5 to-transparent animate-pulse"></div>
                  </div>
                  <Badge className="absolute top-2 left-2 bg-red-500 animate-pulse">
                    LIVE
                  </Badge>
                  <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-xs flex items-center">
                    <Users size={12} className="mr-1" />
                    {game.players}
                  </div>
                </div>
                <CardContent className="p-3">
                  <div className="font-semibold text-sm">{game.name}</div>
                  <div className="text-xs text-gray-400">{game.category}</div>
                  <Button 
                    size="sm" 
                    className="w-full mt-2 bg-winnex-green text-black hover:bg-green-400"
                    onClick={() => openGame(game)}
                  >
                    Play Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Slot Games */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">Popular Slots</h2>
            <Button 
              variant="outline" 
              className="border-gray-600"
              onClick={() => setLocation('/casino')}
            >
              View All
            </Button>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {slotGames.map((game) => (
              <Card key={game.id} className="bg-winnex-gray border-gray-600 hover:bg-gray-700 transition-colors cursor-pointer overflow-hidden">
                <div className="relative">
                  <div className={`w-full h-32 ${game.color} flex items-center justify-center relative overflow-hidden`}>
                    <div className="text-6xl animate-bounce">{game.icon}</div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-white/10 animate-pulse"></div>
                    <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-yellow-400 rounded-full animate-ping opacity-50"></div>
                    <div className="absolute bottom-1/3 right-1/3 w-1 h-1 bg-white rounded-full animate-pulse opacity-70"></div>
                  </div>
                  <div className="absolute top-2 right-2 bg-winnex-green text-black px-2 py-1 rounded text-xs font-bold">
                    ${game.jackpot}
                  </div>
                </div>
                <CardContent className="p-3">
                  <div className="font-semibold text-sm">{game.name}</div>
                  <div className="text-xs text-gray-400 mb-2">RTP: {game.rtp}</div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1 bg-winnex-green text-black hover:bg-green-400"
                      onClick={() => openGame(game)}
                    >
                      Play
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="border-gray-600"
                      onClick={() => openGame({...game, demo: true})}
                    >
                      Demo
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Promotions */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="bg-gradient-to-r from-yellow-500 to-orange-600 border-0">
            <CardContent className="p-6 text-black">
              <h3 className="text-xl font-bold mb-2">🎰 Slot Tournament</h3>
              <p className="mb-4">Win your share of $10,000 prize pool!</p>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm">Ends in: 2d 14h 32m</div>
                </div>
                <Button className="bg-black text-white hover:bg-gray-800">
                  Join Now
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-blue-600 border-0">
            <CardContent className="p-6 text-white">
              <h3 className="text-xl font-bold mb-2">🎲 Live Casino Cashback</h3>
              <p className="mb-4">Get 10% cashback on live casino losses!</p>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm">Valid today only</div>
                </div>
                <Button className="bg-white text-green-600 hover:bg-gray-100">
                  Claim
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Game Modal */}
        <Dialog open={gameModalOpen} onOpenChange={setGameModalOpen}>
          <DialogContent className="max-w-4xl bg-winnex-dark border-gray-700">
            <DialogHeader>
              <DialogTitle className="text-white flex items-center gap-2">
                <span className="text-2xl">{selectedGame?.icon}</span>
                {selectedGame?.name}
                {selectedGame?.demo && <Badge className="bg-blue-600">Demo Mode</Badge>}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Credits Display */}
              <div className="flex items-center justify-between bg-gray-800 rounded-lg p-4">
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-winnex-green">{credits.toLocaleString()}</div>
                    <div className="text-xs text-gray-400">Credits</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-white">${bet}</div>
                    <div className="text-xs text-gray-400">Current Bet</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setBet(Math.max(1, bet - 5))}
                    disabled={bet <= 1}
                  >
                    -$5
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setBet(bet + 5)}
                    disabled={bet + 5 > credits}
                  >
                    +$5
                  </Button>
                </div>
              </div>

              {/* Game Interface */}
              {selectedGame?.category === "Table Games" && selectedGame?.name === "Live Blackjack" && (
                <div className="text-center space-y-6">
                  <div className="bg-green-800 rounded-lg p-8">
                    <h3 className="text-xl font-bold text-white mb-4">♠️ Blackjack Table ♠️</h3>
                    <div className="grid grid-cols-2 gap-8">
                      <div className="text-center">
                        <div className="text-lg text-white mb-2">Your Hand</div>
                        <div className="text-6xl">🂱 🂮</div>
                        <div className="text-xl font-bold text-winnex-green mt-2">19</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg text-white mb-2">Dealer</div>
                        <div className="text-6xl">🂷 🂠</div>
                        <div className="text-xl font-bold text-red-400 mt-2">?</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-center gap-4">
                    <Button
                      className="bg-red-600 hover:bg-red-700 text-white px-8"
                      onClick={playBlackjack}
                      disabled={credits < bet}
                    >
                      Hit
                    </Button>
                    <Button
                      className="bg-blue-600 hover:bg-blue-700 text-white px-8"
                      onClick={playBlackjack}
                      disabled={credits < bet}
                    >
                      Stand
                    </Button>
                  </div>
                </div>
              )}

              {/* Slot Machine Interface */}
              {(selectedGame?.name === "Mega Fortune" || selectedGame?.name === "Starburst" || 
                selectedGame?.name === "Book of Dead" || selectedGame?.name === "Gonzo's Quest") && (
                <div className="text-center space-y-6">
                  <div className="bg-gradient-to-b from-yellow-600 to-yellow-800 rounded-lg p-8">
                    <h3 className="text-xl font-bold text-black mb-4">🎰 {selectedGame.name} 🎰</h3>
                    
                    {/* Slot Reels */}
                    <div className="flex justify-center gap-4 mb-6">
                      {slotReels.map((symbol, index) => (
                        <div key={index} className={`w-20 h-20 bg-white rounded-lg flex items-center justify-center text-4xl border-4 border-yellow-400 ${slotSpinning ? 'animate-spin' : ''}`}>
                          {symbol}
                        </div>
                      ))}
                    </div>
                    
                    {/* Payline */}
                    <div className="flex justify-center mb-4">
                      <div className="bg-red-600 h-1 w-72 rounded"></div>
                    </div>
                    
                    <div className="text-black font-bold mb-4">
                      {selectedGame.name === "Mega Fortune" && "💎 Triple diamonds for MEGA WIN! 💎"}
                      {selectedGame.name === "Starburst" && "⭐ Expanding wilds and re-spins! ⭐"}
                      {selectedGame.name === "Book of Dead" && "📚 Free spins with expanding symbols! 📚"}
                      {selectedGame.name === "Gonzo's Quest" && "🗿 Avalanche feature multipliers! 🗿"}
                    </div>
                  </div>
                  
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-green-500 to-green-700 text-white px-12 py-4 text-xl font-bold"
                    onClick={spinSlot}
                    disabled={slotSpinning || credits < bet}
                  >
                    {slotSpinning ? (
                      <>
                        <RotateCcw className="w-6 h-6 mr-2 animate-spin" />
                        SPINNING...
                      </>
                    ) : (
                      <>
                        <Play className="w-6 h-6 mr-2" />
                        SPIN (${bet})
                      </>
                    )}
                  </Button>
                </div>
              )}

              {/* Roulette Interface */}
              {selectedGame?.name === "European Roulette" && (
                <div className="text-center space-y-6">
                  <div className="bg-green-800 rounded-lg p-8">
                    <h3 className="text-xl font-bold text-white mb-4">🎯 European Roulette 🎯</h3>
                    <div className="text-8xl mb-4">⚫</div>
                    <div className="text-2xl font-bold text-winnex-green">Number 17</div>
                    <div className="text-lg text-white mt-2">Black • Odd • 2nd Dozen</div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <Button className="bg-red-600 hover:bg-red-700" onClick={playBlackjack}>
                      Bet Red
                    </Button>
                    <Button className="bg-gray-800 hover:bg-gray-700" onClick={playBlackjack}>
                      Bet Black
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700" onClick={playBlackjack}>
                      Bet Zero
                    </Button>
                  </div>
                </div>
              )}

              {/* Poker Interface */}
              {selectedGame?.name === "Texas Hold'em" && (
                <div className="text-center space-y-6">
                  <div className="bg-blue-800 rounded-lg p-8">
                    <h3 className="text-xl font-bold text-white mb-4">♦️ Texas Hold'em ♦️</h3>
                    <div className="mb-4">
                      <div className="text-lg text-white mb-2">Your Cards</div>
                      <div className="text-6xl mb-4">🂺 🂻</div>
                      <div className="text-lg text-white mb-2">Community Cards</div>
                      <div className="text-4xl">🂽 🂾 🂿 🃁 🃂</div>
                    </div>
                    <div className="text-xl font-bold text-winnex-green">Royal Flush!</div>
                  </div>
                  
                  <div className="flex justify-center gap-4">
                    <Button className="bg-red-600 hover:bg-red-700" onClick={playBlackjack}>
                      Fold
                    </Button>
                    <Button className="bg-yellow-600 hover:bg-yellow-700" onClick={playBlackjack}>
                      Call
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700" onClick={playBlackjack}>
                      Raise
                    </Button>
                  </div>
                </div>
              )}

              {/* Baccarat Interface */}
              {selectedGame?.name === "Baccarat VIP" && (
                <div className="text-center space-y-6">
                  <div className="bg-purple-800 rounded-lg p-8">
                    <h3 className="text-xl font-bold text-white mb-4">♥️ Baccarat VIP ♥️</h3>
                    <div className="grid grid-cols-2 gap-8">
                      <div className="text-center">
                        <div className="text-lg text-white mb-2">Player</div>
                        <div className="text-6xl">🂨 🂩</div>
                        <div className="text-xl font-bold text-blue-400 mt-2">5</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg text-white mb-2">Banker</div>
                        <div className="text-6xl">🂪 🂫</div>
                        <div className="text-xl font-bold text-red-400 mt-2">7</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-center gap-4">
                    <Button className="bg-blue-600 hover:bg-blue-700" onClick={playBlackjack}>
                      Bet Player
                    </Button>
                    <Button className="bg-red-600 hover:bg-red-700" onClick={playBlackjack}>
                      Bet Banker
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700" onClick={playBlackjack}>
                      Bet Tie
                    </Button>
                  </div>
                </div>
              )}

              {/* Game Stats */}
              <div className="bg-gray-800 rounded-lg p-4">
                <div className="grid grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-lg font-bold text-white">{selectedGame?.rtp || '96.5%'}</div>
                    <div className="text-xs text-gray-400">RTP</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-winnex-green">${selectedGame?.jackpot || '1.2M'}</div>
                    <div className="text-xs text-gray-400">Jackpot</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-blue-400">47</div>
                    <div className="text-xs text-gray-400">Players</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-yellow-500">4.8/5</div>
                    <div className="text-xs text-gray-400">Rating</div>
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
