import Layout from "@/components/Layout";
import VIPLoyaltyProgram from "@/components/VIPLoyaltyProgram";

export default function VIP() {
  return (
    <Layout>
      <VIPLoyaltyProgram />
    </Layout>
  );
}