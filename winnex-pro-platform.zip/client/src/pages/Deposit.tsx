import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CreditCard, Wallet, Bitcoin, DollarSign, Clock, Shield, CheckCircle } from "lucide-react";
import Layout from "@/components/Layout";

interface PaymentMethod {
  id: string;
  name: string;
  type: 'card' | 'crypto' | 'bank' | 'ewallet';
  icon: string;
  minAmount: number;
  maxAmount: number;
  processingTime: string;
  fee: number;
  feeType: 'fixed' | 'percentage';
  isActive: boolean;
}

interface Transaction {
  id: string;
  amount: number;
  method: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  timestamp: string;
  txHash?: string;
}

export default function Deposit() {
  const [amount, setAmount] = useState("");
  const [selectedMethod, setSelectedMethod] = useState("");
  const [activeTab, setActiveTab] = useState("amount");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: paymentMethods, isLoading: methodsLoading } = useQuery({
    queryKey: ['/api/payment/methods'],
  });

  const { data: recentTransactions } = useQuery({
    queryKey: ['/api/user/transactions', 'deposit'],
  });

  const { data: bonuses } = useQuery({
    queryKey: ['/api/deposit/bonuses'],
  });

  const createDepositMutation = useMutation({
    mutationFn: (data: { amount: number; method: string }) =>
      apiRequest('/api/deposit/create', 'POST', data),
    onSuccess: (data) => {
      toast({
        title: "Deposit Initiated",
        description: `Your deposit of $${amount} has been initiated. Redirecting to payment...`,
      });
      
      if (data.redirectUrl) {
        window.location.href = data.redirectUrl;
      } else {
        setActiveTab("confirmation");
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/user/balance'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user/transactions'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Deposit Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const quickAmounts = [25, 50, 100, 250, 500, 1000];

  const handleDeposit = () => {
    if (!amount || !selectedMethod) {
      toast({
        title: "Missing Information",
        description: "Please select an amount and payment method.",
        variant: "destructive",
      });
      return;
    }

    const numAmount = parseFloat(amount);
    if (numAmount < 10) {
      toast({
        title: "Minimum Amount",
        description: "Minimum deposit amount is $10.",
        variant: "destructive",
      });
      return;
    }

    createDepositMutation.mutate({
      amount: numAmount,
      method: selectedMethod,
    });
  };

  const getMethodIcon = (type: string) => {
    switch (type) {
      case 'card': return <CreditCard className="w-5 h-5" />;
      case 'crypto': return <Bitcoin className="w-5 h-5" />;
      case 'bank': return <DollarSign className="w-5 h-5" />;
      case 'ewallet': return <Wallet className="w-5 h-5" />;
      default: return <CreditCard className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500/20 text-green-400 border-green-500/20';
      case 'processing': return 'bg-blue-500/20 text-blue-400 border-blue-500/20';
      case 'pending': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/20';
      case 'failed': return 'bg-red-500/20 text-red-400 border-red-500/20';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/20';
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-winnex-dark via-gray-900 to-black p-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">Deposit Funds</h1>
            <p className="text-gray-400">Add money to your Winnex account securely and instantly</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 bg-winnex-dark border-gray-700">
              <TabsTrigger value="amount" className="data-[state=active]:bg-winnex-green data-[state=active]:text-black">
                Amount
              </TabsTrigger>
              <TabsTrigger value="method" className="data-[state=active]:bg-winnex-green data-[state=active]:text-black">
                Payment Method
              </TabsTrigger>
              <TabsTrigger value="confirmation" className="data-[state=active]:bg-winnex-green data-[state=active]:text-black">
                Confirmation
              </TabsTrigger>
            </TabsList>

            {/* Amount Selection */}
            <TabsContent value="amount" className="space-y-6">
              <Card className="bg-winnex-dark border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-winnex-green" />
                    Select Deposit Amount
                  </CardTitle>
                  <CardDescription>Choose how much you'd like to deposit</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-3 gap-3">
                    {quickAmounts.map((quickAmount) => (
                      <Button
                        key={quickAmount}
                        variant={amount === quickAmount.toString() ? "default" : "outline"}
                        className={`h-12 ${
                          amount === quickAmount.toString()
                            ? "bg-winnex-green text-black"
                            : "border-gray-600 hover:border-winnex-green"
                        }`}
                        onClick={() => setAmount(quickAmount.toString())}
                      >
                        ${quickAmount}
                      </Button>
                    ))}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="custom-amount" className="text-white">Custom Amount</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        id="custom-amount"
                        type="number"
                        placeholder="Enter amount"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="pl-10 bg-gray-800 border-gray-600 text-white"
                        min="10"
                        max="10000"
                      />
                    </div>
                    <p className="text-sm text-gray-400">Minimum: $10 • Maximum: $10,000</p>
                  </div>

                  {bonuses && bonuses.length > 0 && (
                    <div className="bg-gradient-to-r from-winnex-green/10 to-green-400/10 border border-winnex-green/20 rounded-lg p-4">
                      <h3 className="text-winnex-green font-semibold mb-2">Available Deposit Bonuses</h3>
                      {bonuses.map((bonus: any, index: number) => (
                        <div key={index} className="flex justify-between items-center text-sm">
                          <span className="text-gray-300">{bonus.description}</span>
                          <Badge className="bg-winnex-green/20 text-winnex-green">
                            {bonus.percentage}% up to ${bonus.maxAmount}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}

                  <Button
                    onClick={() => setActiveTab("method")}
                    disabled={!amount || parseFloat(amount) < 10}
                    className="w-full bg-winnex-green text-black hover:bg-green-400"
                  >
                    Continue to Payment Method
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Payment Method Selection */}
            <TabsContent value="method" className="space-y-6">
              <Card className="bg-winnex-dark border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-winnex-green" />
                    Choose Payment Method
                  </CardTitle>
                  <CardDescription>Select your preferred payment option</CardDescription>
                </CardHeader>
                <CardContent>
                  {methodsLoading ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[1, 2, 3, 4].map((i) => (
                        <div key={i} className="animate-pulse bg-gray-800 h-20 rounded-lg" />
                      ))}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {paymentMethods?.map((method: PaymentMethod) => (
                        <div
                          key={method.id}
                          className={`border rounded-lg p-4 cursor-pointer transition-all ${
                            selectedMethod === method.id
                              ? "border-winnex-green bg-winnex-green/10"
                              : "border-gray-600 hover:border-gray-500"
                          }`}
                          onClick={() => setSelectedMethod(method.id)}
                        >
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              {getMethodIcon(method.type)}
                              <span className="text-white font-medium">{method.name}</span>
                            </div>
                            {selectedMethod === method.id && (
                              <CheckCircle className="w-5 h-5 text-winnex-green" />
                            )}
                          </div>
                          <div className="space-y-1 text-xs text-gray-400">
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              <span>{method.processingTime}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <DollarSign className="w-3 h-3" />
                              <span>
                                ${method.minAmount} - ${method.maxAmount.toLocaleString()}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Shield className="w-3 h-3" />
                              <span>
                                Fee: {method.feeType === 'percentage' ? `${method.fee}%` : `$${method.fee}`}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <div className="mt-6 flex gap-3">
                    <Button
                      variant="outline"
                      onClick={() => setActiveTab("amount")}
                      className="flex-1 border-gray-600 hover:border-winnex-green"
                    >
                      Back
                    </Button>
                    <Button
                      onClick={handleDeposit}
                      disabled={!selectedMethod || createDepositMutation.isPending}
                      className="flex-1 bg-winnex-green text-black hover:bg-green-400"
                    >
                      {createDepositMutation.isPending ? "Processing..." : `Deposit $${amount}`}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Confirmation */}
            <TabsContent value="confirmation" className="space-y-6">
              <Card className="bg-winnex-dark border-gray-700">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-winnex-green/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-winnex-green" />
                  </div>
                  <CardTitle className="text-white">Deposit Initiated</CardTitle>
                  <CardDescription>Your deposit is being processed</CardDescription>
                </CardHeader>
                <CardContent className="text-center space-y-4">
                  <div className="bg-gray-800 rounded-lg p-4">
                    <div className="text-2xl font-bold text-winnex-green">${amount}</div>
                    <div className="text-gray-400 text-sm">Deposit Amount</div>
                  </div>
                  <p className="text-gray-300">
                    You will receive an email confirmation once your deposit is processed.
                    Funds typically appear in your account within minutes.
                  </p>
                  <Button
                    onClick={() => window.location.href = '/'}
                    className="w-full bg-winnex-green text-black hover:bg-green-400"
                  >
                    Return to Home
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Recent Transactions */}
          {recentTransactions && recentTransactions.length > 0 && (
            <Card className="bg-winnex-dark border-gray-700 mt-8">
              <CardHeader>
                <CardTitle className="text-white">Recent Deposits</CardTitle>
                <CardDescription>Your recent deposit history</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentTransactions.slice(0, 5).map((tx: Transaction) => (
                    <div key={tx.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-winnex-green/20 rounded-full flex items-center justify-center">
                          <DollarSign className="w-5 h-5 text-winnex-green" />
                        </div>
                        <div>
                          <div className="text-white font-medium">${tx.amount}</div>
                          <div className="text-gray-400 text-sm">{tx.method}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge className={getStatusColor(tx.status)}>
                          {tx.status}
                        </Badge>
                        <div className="text-gray-400 text-xs mt-1">
                          {new Date(tx.timestamp).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}