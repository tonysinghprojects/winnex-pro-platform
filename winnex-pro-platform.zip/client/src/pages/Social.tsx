import Layout from "@/components/Layout";
import SocialBettingCommunity from "@/components/SocialBettingCommunity";

export default function Social() {
  return (
    <Layout>
      <SocialBettingCommunity />
    </Layout>
  );
}