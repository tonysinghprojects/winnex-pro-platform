import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Layout from "@/components/Layout";
import MatchCard from "@/components/MatchCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Search, Filter, Play, Users, DollarSign } from "lucide-react";

export default function Sports() {
  const [selectedSport, setSelectedSport] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const { data: sports = [] } = useQuery({
    queryKey: ["/api/sports"],
  });

  const { data: matches = [] } = useQuery({
    queryKey: ["/api/matches", selectedSport ? { sportId: selectedSport } : {}],
  });

  const filteredMatches = matches.filter(match =>
    match.team1.toLowerCase().includes(searchTerm.toLowerCase()) ||
    match.team2.toLowerCase().includes(searchTerm.toLowerCase()) ||
    match.league?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const upcomingMatches = filteredMatches.filter(match => match.status === "scheduled");
  const liveMatches = filteredMatches.filter(match => match.status === "live");

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 gradient-accent opacity-80"></div>
        <div className="absolute inset-0 bg-black/30"></div>
        
        {/* Floating Sports Elements */}
        <div className="absolute top-16 left-20 text-4xl animate-float">⚽</div>
        <div className="absolute bottom-20 right-24 text-3xl animate-float" style={{animationDelay: '1s'}}>🏀</div>
        <div className="absolute top-20 right-1/3 text-2xl animate-float" style={{animationDelay: '2s'}}>🎾</div>
        
        <div className="relative z-20 text-center max-w-4xl mx-auto px-6">
          <h1 className="text-5xl font-black mb-4 text-white">SPORTS BETTING</h1>
          <p className="text-xl text-white/80 mb-8">Bet on your favorite sports with the best odds</p>
          <div className="flex gap-4 justify-center">
            <button className="btn-primary">Browse Sports</button>
            <button className="btn-secondary">Live Matches</button>
          </div>
        </div>
      </section>

      <div className="p-6 max-w-7xl mx-auto -mt-20 relative z-30">
        {/* Search and Filters */}
        <div className="glass rounded-2xl p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60" size={20} />
              <input
                placeholder="Search matches, teams, or leagues..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-secondary rounded-xl border border-white/10 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-winnex-green"
              />
            </div>
            <button className="btn-secondary flex items-center">
              <Filter size={16} className="mr-2" />
              Filters
            </button>
          </div>

          {/* Sport Filters */}
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => setSelectedSport(null)}
              className={selectedSport === null ? "btn-primary" : "btn-secondary"}
            >
              All Sports
            </button>
            {sports.map((sport: any) => (
              <button
                key={sport.id}
                onClick={() => setSelectedSport(sport.id)}
                className={selectedSport === sport.id ? "btn-primary" : "btn-secondary"}
              >
                {sport.name}
              </button>
            ))}
          </div>
        </div>

        {/* Live Matches */}
        {liveMatches.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-4 h-4 bg-red-500 rounded-full mr-3 animate-pulse"></div>
              <h2 className="text-3xl font-bold text-white">Live Matches</h2>
              <div className="ml-4 glass rounded-full px-3 py-1 text-sm font-bold text-red-500">
                {liveMatches.length} LIVE
              </div>
            </div>
            <div className="space-y-4">
              {liveMatches.map((match: any) => (
                <div key={match.id} className="card-modern p-6 gradient-live">
                  <MatchCard match={match} odds={[]} />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Upcoming Matches */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold text-winnex-green">Upcoming Matches</h2>
            <div className="glass rounded-full px-4 py-2 text-sm">
              {upcomingMatches.length} matches
            </div>
          </div>
          
          {upcomingMatches.length === 0 ? (
            <div className="card-modern p-16 text-center">
              <div className="text-6xl mb-6">🎯</div>
              <h3 className="text-2xl font-bold mb-4">No matches found</h3>
              <p className="text-white/60 mb-8">Try adjusting your search or filters</p>
              <button className="btn-primary">Browse All Sports</button>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingMatches.map((match: any) => (
                <div key={match.id} className="card-modern p-6">
                  <MatchCard match={match} odds={[]} />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Load More */}
        {upcomingMatches.length > 0 && (
          <div className="text-center">
            <button className="btn-secondary px-8 py-3">
              Load More Matches
            </button>
          </div>
        )}

        {/* Popular Games Section */}
        <div className="mt-16 mb-12">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-winnex-green mb-2">Popular Games</h2>
              <p className="text-white/60">Take a break from sports betting and try our casino games</p>
            </div>
            <Link href="/casino">
              <Button className="bg-winnex-green text-black hover:bg-green-400">
                View All Games
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Slot Machine */}
            <Card className="bg-gradient-to-br from-purple-900 to-pink-900 border-0 overflow-hidden cursor-pointer hover:scale-105 transition-all duration-300">
              <CardContent className="p-0">
                <div className="relative h-48 flex items-center justify-center">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-pink-600/20"></div>
                  <div className="text-8xl animate-spin-slow">🎰</div>
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-yellow-500 text-black animate-pulse">
                      $2.4M Jackpot
                    </Badge>
                  </div>
                  <div className="absolute bottom-3 left-3 flex items-center gap-2 text-white/80">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">1,247 playing</span>
                  </div>
                </div>
                <div className="p-4 bg-black/40">
                  <h3 className="text-white font-bold text-lg mb-1">Mega Fortune Slots</h3>
                  <p className="text-white/60 text-sm mb-3">Progressive jackpot - RTP 96.6%</p>
                  <Button className="w-full bg-winnex-green text-black hover:bg-green-400">
                    <Play className="w-4 h-4 mr-2" />
                    Play Now
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Blackjack */}
            <Card className="bg-gradient-to-br from-green-900 to-emerald-900 border-0 overflow-hidden cursor-pointer hover:scale-105 transition-all duration-300">
              <CardContent className="p-0">
                <div className="relative h-48 flex items-center justify-center">
                  <div className="absolute inset-0 bg-gradient-to-br from-green-600/20 to-emerald-600/20"></div>
                  <div className="text-8xl animate-pulse">🃏</div>
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-red-500 text-white animate-pulse">
                      LIVE
                    </Badge>
                  </div>
                  <div className="absolute bottom-3 left-3 flex items-center gap-2 text-white/80">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">89 at tables</span>
                  </div>
                </div>
                <div className="p-4 bg-black/40">
                  <h3 className="text-white font-bold text-lg mb-1">Live Blackjack</h3>
                  <p className="text-white/60 text-sm mb-3">Professional dealers - Multiple tables</p>
                  <Button className="w-full bg-winnex-green text-black hover:bg-green-400">
                    <Play className="w-4 h-4 mr-2" />
                    Join Table
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Roulette */}
            <Card className="bg-gradient-to-br from-red-900 to-orange-900 border-0 overflow-hidden cursor-pointer hover:scale-105 transition-all duration-300">
              <CardContent className="p-0">
                <div className="relative h-48 flex items-center justify-center">
                  <div className="absolute inset-0 bg-gradient-to-br from-red-600/20 to-orange-600/20"></div>
                  <div className="text-8xl animate-spin">🎡</div>
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-orange-500 text-white">
                      Hot Streak
                    </Badge>
                  </div>
                  <div className="absolute bottom-3 left-3 flex items-center gap-2 text-white/80">
                    <DollarSign className="w-4 h-4" />
                    <span className="text-sm">$50K+ won today</span>
                  </div>
                </div>
                <div className="p-4 bg-black/40">
                  <h3 className="text-white font-bold text-lg mb-1">European Roulette</h3>
                  <p className="text-white/60 text-sm mb-3">Single zero - Better odds</p>
                  <Button className="w-full bg-winnex-green text-black hover:bg-green-400">
                    <Play className="w-4 h-4 mr-2" />
                    Spin Now
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Poker */}
            <Card className="bg-gradient-to-br from-blue-900 to-cyan-900 border-0 overflow-hidden cursor-pointer hover:scale-105 transition-all duration-300">
              <CardContent className="p-0">
                <div className="relative h-48 flex items-center justify-center">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-cyan-600/20"></div>
                  <div className="text-8xl animate-bounce">♠️</div>
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-blue-500 text-white">
                      Tournament
                    </Badge>
                  </div>
                  <div className="absolute bottom-3 left-3 flex items-center gap-2 text-white/80">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">156 players</span>
                  </div>
                </div>
                <div className="p-4 bg-black/40">
                  <h3 className="text-white font-bold text-lg mb-1">Texas Hold'em</h3>
                  <p className="text-white/60 text-sm mb-3">Daily tournaments - Big prizes</p>
                  <Button className="w-full bg-winnex-green text-black hover:bg-green-400">
                    <Play className="w-4 h-4 mr-2" />
                    Join Game
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
          <div className="card-modern p-8 text-center">
            <div className="text-4xl text-winnex-green mb-4">🏆</div>
            <div className="text-3xl font-bold text-winnex-green mb-2">150+</div>
            <div className="text-white/60">Live Events Daily</div>
          </div>
          <div className="card-modern p-8 text-center">
            <div className="text-4xl text-winnex-blue mb-4">📊</div>
            <div className="text-3xl font-bold text-winnex-blue mb-2">25</div>
            <div className="text-white/60">Sports Available</div>
          </div>
          <div className="card-modern p-8 text-center">
            <div className="text-4xl text-winnex-orange mb-4">⚡</div>
            <div className="text-3xl font-bold text-winnex-orange mb-2">99.9%</div>
            <div className="text-white/60">Platform Uptime</div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
