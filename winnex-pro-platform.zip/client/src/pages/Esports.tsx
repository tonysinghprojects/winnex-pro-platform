import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Layout from '@/components/Layout';
import { Gamepad2, Trophy, Users, Clock, Star, TrendingUp, Zap, Calendar } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface EsportsMatch {
  id: number;
  game: string;
  tournament: string;
  team1: string;
  team2: string;
  startTime: string;
  status: 'upcoming' | 'live' | 'finished';
  odds: {
    team1: number;
    team2: number;
  };
  viewers: number;
  prize: number;
  maps?: string[];
}

interface EsportsGame {
  id: string;
  name: string;
  icon: string;
  category: string;
  activeMatches: number;
  totalPrize: number;
  viewers: number;
  popularity: number;
}

interface EsportsTournament {
  id: string;
  name: string;
  game: string;
  startDate: string;
  endDate: string;
  teams: number;
  prize: number;
  status: 'upcoming' | 'live' | 'finished';
  matches: number;
}

export default function Esports() {
  const [selectedGame, setSelectedGame] = useState<string>('all');
  const [selectedTournament, setSelectedTournament] = useState<string>('all');

  const { data: games, isLoading: gamesLoading } = useQuery({
    queryKey: ['/api/esports/games'],
  });

  const { data: matches, isLoading: matchesLoading } = useQuery({
    queryKey: ['/api/esports/matches', selectedGame, selectedTournament],
  });

  const { data: tournaments, isLoading: tournamentsLoading } = useQuery({
    queryKey: ['/api/esports/tournaments'],
  });

  const { data: liveStats } = useQuery({
    queryKey: ['/api/esports/live-stats'],
    refetchInterval: 5000,
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-red-500/20 text-red-400 border-red-500/20';
      case 'upcoming': return 'bg-blue-500/20 text-blue-400 border-blue-500/20';
      case 'finished': return 'bg-gray-500/20 text-gray-400 border-gray-500/20';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/20';
    }
  };

  const getGameIcon = (game: string) => {
    const gameIcons: { [key: string]: string } = {
      'Counter-Strike 2': '🔫',
      'League of Legends': '⚔️',
      'Dota 2': '🛡️',
      'Valorant': '🎯',
      'Overwatch 2': '🚀',
      'Rocket League': '⚽',
      'Fortnite': '🏗️',
      'Call of Duty': '💥'
    };
    return gameIcons[game] || '🎮';
  };

  if (gamesLoading || matchesLoading || tournamentsLoading) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-500 mx-auto"></div>
            <p className="mt-4 text-slate-300">Loading E-sports...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center mb-4">
            <Gamepad2 className="h-12 w-12 text-green-400 mr-4" />
            <h1 className="text-4xl font-bold text-white">E-sports Betting</h1>
          </div>
          <p className="text-slate-300 text-lg">Bet on the world's biggest gaming tournaments and competitions</p>
        </div>

        {/* Live Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-black/20 border-green-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Live Matches</p>
                  <p className="text-3xl font-bold text-white">{liveStats?.liveMatches || 24}</p>
                </div>
                <Zap className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-blue-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 text-sm font-medium">Total Viewers</p>
                  <p className="text-3xl font-bold text-white">{liveStats?.totalViewers?.toLocaleString() || '2.4M'}</p>
                </div>
                <Users className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-purple-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-400 text-sm font-medium">Prize Pools</p>
                  <p className="text-3xl font-bold text-white">${liveStats?.totalPrize?.toLocaleString() || '15.2M'}</p>
                </div>
                <Trophy className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-yellow-500/20 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-400 text-sm font-medium">Active Tournaments</p>
                  <p className="text-3xl font-bold text-white">{liveStats?.activeTournaments || 47}</p>
                </div>
                <Calendar className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Popular Games */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-6">Popular Games</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {games?.slice(0, 8).map((game: EsportsGame) => (
              <Card
                key={game.id}
                className={`bg-black/20 border-white/10 backdrop-blur-xl cursor-pointer transition-all hover:border-green-500/50 ${
                  selectedGame === game.id ? 'border-green-500/50 bg-green-500/10' : ''
                }`}
                onClick={() => setSelectedGame(game.id)}
              >
                <CardContent className="p-4 text-center">
                  <div className="text-3xl mb-2">{getGameIcon(game.name)}</div>
                  <p className="text-white font-medium text-sm">{game.name}</p>
                  <p className="text-slate-400 text-xs">{game.activeMatches} matches</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Tabs defaultValue="matches" className="space-y-6">
          <TabsList className="bg-black/20 backdrop-blur-xl border-white/10">
            <TabsTrigger value="matches" className="data-[state=active]:bg-green-500/20">
              Live & Upcoming Matches
            </TabsTrigger>
            <TabsTrigger value="tournaments" className="data-[state=active]:bg-green-500/20">
              Tournaments
            </TabsTrigger>
            <TabsTrigger value="results" className="data-[state=active]:bg-green-500/20">
              Results & Stats
            </TabsTrigger>
          </TabsList>

          <TabsContent value="matches" className="space-y-6">
            {/* Filters */}
            <div className="flex flex-wrap gap-4">
              <Select value={selectedGame} onValueChange={setSelectedGame}>
                <SelectTrigger className="w-48 bg-slate-800/50 border-slate-600">
                  <SelectValue placeholder="Select game" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Games</SelectItem>
                  <SelectItem value="cs2">Counter-Strike 2</SelectItem>
                  <SelectItem value="lol">League of Legends</SelectItem>
                  <SelectItem value="dota2">Dota 2</SelectItem>
                  <SelectItem value="valorant">Valorant</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedTournament} onValueChange={setSelectedTournament}>
                <SelectTrigger className="w-48 bg-slate-800/50 border-slate-600">
                  <SelectValue placeholder="Select tournament" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tournaments</SelectItem>
                  <SelectItem value="worlds">World Championship</SelectItem>
                  <SelectItem value="major">Major Tournament</SelectItem>
                  <SelectItem value="regional">Regional League</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Matches Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {matches?.map((match: EsportsMatch) => (
                <Card key={match.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle className="text-white text-lg">{match.tournament}</CardTitle>
                        <p className="text-slate-400 text-sm">{match.game}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={getStatusColor(match.status)}>
                          {match.status === 'live' && <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-1" />}
                          {match.status}
                        </Badge>
                        <div className="flex items-center text-slate-400 text-sm">
                          <Users className="h-4 w-4 mr-1" />
                          {match.viewers.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Teams */}
                    <div className="flex items-center justify-between p-4 bg-slate-800/30 rounded-lg">
                      <div className="text-center flex-1">
                        <p className="text-white font-bold text-lg">{match.team1}</p>
                        <p className="text-green-400 font-bold text-xl">{match.odds.team1}</p>
                      </div>
                      <div className="text-center px-4">
                        <p className="text-slate-400 text-sm">VS</p>
                        <Clock className="h-4 w-4 text-slate-400 mx-auto mt-1" />
                      </div>
                      <div className="text-center flex-1">
                        <p className="text-white font-bold text-lg">{match.team2}</p>
                        <p className="text-green-400 font-bold text-xl">{match.odds.team2}</p>
                      </div>
                    </div>

                    {/* Match Info */}
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-slate-400">Start Time</p>
                        <p className="text-white">{new Date(match.startTime).toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400">Prize Pool</p>
                        <p className="text-white">${match.prize.toLocaleString()}</p>
                      </div>
                    </div>

                    {/* Maps */}
                    {match.maps && (
                      <div>
                        <p className="text-slate-400 text-sm mb-2">Maps</p>
                        <div className="flex flex-wrap gap-1">
                          {match.maps.map((map, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {map}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Betting Actions */}
                    <div className="flex space-x-2">
                      <Button 
                        className="flex-1 bg-green-500 hover:bg-green-600"
                        onClick={() => {
                          const betAmount = 10;
                          apiRequest('POST', '/api/bets', {
                            matchId: match.id,
                            selection: match.team1,
                            odds: match.odds.team1,
                            stake: betAmount
                          }).then(() => {
                            console.log(`Bet placed on ${match.team1}`);
                          }).catch(err => {
                            console.log('Bet placement error:', err);
                          });
                        }}
                      >
                        Bet on {match.team1}
                      </Button>
                      <Button 
                        className="flex-1 bg-blue-500 hover:bg-blue-600"
                        onClick={() => {
                          const betAmount = 10;
                          apiRequest('POST', '/api/bets', {
                            matchId: match.id,
                            selection: match.team2,
                            odds: match.odds.team2,
                            stake: betAmount
                          }).then(() => {
                            console.log(`Bet placed on ${match.team2}`);
                          }).catch(err => {
                            console.log('Bet placement error:', err);
                          });
                        }}
                      >
                        Bet on {match.team2}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="tournaments" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {tournaments?.map((tournament: EsportsTournament) => (
                <Card key={tournament.id} className="bg-black/20 border-white/10 backdrop-blur-xl">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-white">{tournament.name}</CardTitle>
                        <p className="text-slate-400">{tournament.game}</p>
                      </div>
                      <Badge className={getStatusColor(tournament.status)}>
                        {tournament.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-slate-400">Teams</p>
                        <p className="text-white font-bold">{tournament.teams}</p>
                      </div>
                      <div>
                        <p className="text-slate-400">Matches</p>
                        <p className="text-white font-bold">{tournament.matches}</p>
                      </div>
                      <div>
                        <p className="text-slate-400">Prize Pool</p>
                        <p className="text-green-400 font-bold">${tournament.prize.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-400">Duration</p>
                        <p className="text-white">{Math.ceil((new Date(tournament.endDate).getTime() - new Date(tournament.startDate).getTime()) / (1000 * 60 * 60 * 24))} days</p>
                      </div>
                    </div>

                    <div className="text-sm">
                      <p className="text-slate-400">Tournament Period</p>
                      <p className="text-white">
                        {new Date(tournament.startDate).toLocaleDateString()} - {new Date(tournament.endDate).toLocaleDateString()}
                      </p>
                    </div>

                    <Button className="w-full bg-purple-500 hover:bg-purple-600">
                      <Trophy className="h-4 w-4 mr-2" />
                      View Tournament
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            <div className="text-center py-12">
              <TrendingUp className="h-16 w-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Recent Results & Statistics</h3>
              <p className="text-slate-400">View completed matches and player statistics</p>
              <Button className="mt-4 bg-green-500 hover:bg-green-600">
                <Star className="h-4 w-4 mr-2" />
                View Results
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}