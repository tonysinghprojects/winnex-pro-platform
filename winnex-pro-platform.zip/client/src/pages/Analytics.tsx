import Layout from "@/components/Layout";
import AdvancedAnalyticsDashboard from "@/components/AdvancedAnalyticsDashboard";

export default function Analytics() {
  return (
    <Layout>
      <AdvancedAnalyticsDashboard />
    </Layout>
  );
}