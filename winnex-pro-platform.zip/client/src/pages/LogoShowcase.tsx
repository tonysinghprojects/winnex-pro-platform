import Layout from "@/components/Layout";
import LogoSamples from "@/components/LogoSamples";

export default function LogoShowcase() {
  return (
    <Layout>
      <LogoSamples />
    </Layout>
  );
}