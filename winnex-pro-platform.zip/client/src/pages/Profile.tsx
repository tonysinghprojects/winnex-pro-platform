import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  User,
  Wallet,
  History,
  Settings,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle,
  XCircle,
  DollarSign,
  Calendar,
  Target,
  Award,
  LogOut,
} from "lucide-react";
import { useState } from "react";

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [depositAmount, setDepositAmount] = useState("");

  const { data: balance } = useQuery({
    queryKey: ["/api/user/balance"],
    enabled: !!user,
  });

  const { data: bets = [] } = useQuery({
    queryKey: ["/api/bets"],
    enabled: !!user,
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/user/transactions"],
    enabled: !!user,
  });

  const depositMutation = useMutation({
    mutationFn: async (amount: string) => {
      await apiRequest("POST", "/api/user/deposit", { amount });
    },
    onSuccess: () => {
      toast({
        title: "Deposit Successful",
        description: `$${depositAmount} has been added to your account.`,
      });
      setDepositAmount("");
      queryClient.invalidateQueries({ queryKey: ["/api/user/balance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/transactions"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Deposit Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDeposit = () => {
    const amount = parseFloat(depositAmount);
    if (amount <= 0 || isNaN(amount)) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid deposit amount.",
        variant: "destructive",
      });
      return;
    }
    depositMutation.mutate(depositAmount);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  // Calculate betting stats
  const totalBets = bets.length;
  const wonBets = bets.filter(bet => bet.status === "won").length;
  const lostBets = bets.filter(bet => bet.status === "lost").length;
  const pendingBets = bets.filter(bet => bet.status === "pending").length;
  const winRate = totalBets > 0 ? ((wonBets / totalBets) * 100).toFixed(1) : "0.0";
  
  const totalStaked = bets.reduce((sum, bet) => sum + parseFloat(bet.stake), 0);
  const totalWon = bets
    .filter(bet => bet.status === "won")
    .reduce((sum, bet) => sum + parseFloat(bet.potentialWin), 0);
  const netProfit = totalWon - totalStaked;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "won":
        return <CheckCircle className="text-green-500" size={16} />;
      case "lost":
        return <XCircle className="text-red-500" size={16} />;
      case "pending":
        return <Clock className="text-yellow-500" size={16} />;
      default:
        return <Clock className="text-gray-500" size={16} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "won":
        return "bg-green-500";
      case "lost":
        return "bg-red-500";
      case "pending":
        return "bg-yellow-500";
      default:
        return "bg-gray-500";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <Layout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img
                src={user?.profileImageUrl || `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80`}
                alt={user?.firstName || "User"}
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h1 className="text-3xl font-bold">
                  {user?.firstName} {user?.lastName}
                </h1>
                <p className="text-gray-400">{user?.email}</p>
              </div>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-gray-600"
            >
              <LogOut className="mr-2" size={16} />
              Sign Out
            </Button>
          </div>
        </div>

        {/* Account Overview Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-winnex-gray border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Account Balance</p>
                  <p className="text-2xl font-bold text-winnex-green">
                    ${balance?.balance || "0.00"}
                  </p>
                </div>
                <Wallet className="text-winnex-green" size={24} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-winnex-gray border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Total Bets</p>
                  <p className="text-2xl font-bold">{totalBets}</p>
                </div>
                <Target className="text-winnex-blue" size={24} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-winnex-gray border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Win Rate</p>
                  <p className="text-2xl font-bold text-winnex-green">{winRate}%</p>
                </div>
                <Award className="text-winnex-orange" size={24} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-winnex-gray border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Net Profit</p>
                  <p className={`text-2xl font-bold ${netProfit >= 0 ? 'text-winnex-green' : 'text-red-500'}`}>
                    {netProfit >= 0 ? '+' : ''}${netProfit.toFixed(2)}
                  </p>
                </div>
                {netProfit >= 0 ? (
                  <TrendingUp className="text-winnex-green" size={24} />
                ) : (
                  <TrendingDown className="text-red-500" size={24} />
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-winnex-gray">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="bets">Betting History</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Deposit Section */}
              <Card className="bg-winnex-gray border-gray-600">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <DollarSign className="mr-2" size={20} />
                    Quick Deposit
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Input
                    type="number"
                    placeholder="Enter amount"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    className="bg-winnex-dark border-gray-600"
                  />
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setDepositAmount("50")}
                      className="border-gray-600"
                    >
                      $50
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setDepositAmount("100")}
                      className="border-gray-600"
                    >
                      $100
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setDepositAmount("500")}
                      className="border-gray-600"
                    >
                      $500
                    </Button>
                  </div>
                  <Button
                    onClick={handleDeposit}
                    disabled={depositMutation.isPending}
                    className="w-full bg-winnex-green text-black hover:bg-green-400"
                  >
                    {depositMutation.isPending ? "Processing..." : "Deposit"}
                  </Button>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card className="lg:col-span-2 bg-winnex-gray border-gray-600">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {bets.slice(0, 5).map((bet) => (
                      <div key={bet.id} className="flex items-center justify-between p-3 bg-winnex-dark rounded">
                        <div className="flex items-center space-x-3">
                          {getStatusIcon(bet.status)}
                          <div>
                            <div className="font-semibold">{bet.selection}</div>
                            <div className="text-sm text-gray-400">
                              Stake: ${bet.stake} • Odds: {bet.odds}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={getStatusColor(bet.status)}>
                            {bet.status.toUpperCase()}
                          </Badge>
                          <div className="text-xs text-gray-400 mt-1">
                            {formatDate(bet.placedAt)}
                          </div>
                        </div>
                      </div>
                    ))}
                    {bets.length === 0 && (
                      <div className="text-center py-8 text-gray-400">
                        <Target size={48} className="mx-auto mb-2 opacity-50" />
                        <p>No bets placed yet</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Betting Statistics */}
            <Card className="bg-winnex-gray border-gray-600">
              <CardHeader>
                <CardTitle>Betting Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-500">{wonBets}</div>
                    <div className="text-sm text-gray-400">Won Bets</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-500">{lostBets}</div>
                    <div className="text-sm text-gray-400">Lost Bets</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-500">{pendingBets}</div>
                    <div className="text-sm text-gray-400">Pending Bets</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-winnex-green">${totalStaked.toFixed(2)}</div>
                    <div className="text-sm text-gray-400">Total Staked</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bets" className="space-y-4">
            <Card className="bg-winnex-gray border-gray-600">
              <CardHeader>
                <CardTitle>All Bets</CardTitle>
              </CardHeader>
              <CardContent>
                {bets.length === 0 ? (
                  <div className="text-center py-12 text-gray-400">
                    <Target size={64} className="mx-auto mb-4 opacity-50" />
                    <p className="text-lg">No bets found</p>
                    <p className="text-sm">Start betting to see your history here</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {bets.map((bet) => (
                      <div key={bet.id} className="p-4 bg-winnex-dark rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            {getStatusIcon(bet.status)}
                            <span className="font-semibold">{bet.selection}</span>
                            <Badge className={getStatusColor(bet.status)} variant="secondary">
                              {bet.status.toUpperCase()}
                            </Badge>
                          </div>
                          <div className="text-right">
                            <div className="font-bold">
                              {bet.status === "won" ? `+$${bet.potentialWin}` : `-$${bet.stake}`}
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-400">
                          <div>
                            <span className="block">Market</span>
                            <span className="text-white">{bet.market}</span>
                          </div>
                          <div>
                            <span className="block">Stake</span>
                            <span className="text-white">${bet.stake}</span>
                          </div>
                          <div>
                            <span className="block">Odds</span>
                            <span className="text-white">{bet.odds}</span>
                          </div>
                          <div>
                            <span className="block">Placed</span>
                            <span className="text-white">{formatDate(bet.placedAt)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-4">
            <Card className="bg-winnex-gray border-gray-600">
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
              </CardHeader>
              <CardContent>
                {transactions.length === 0 ? (
                  <div className="text-center py-12 text-gray-400">
                    <History size={64} className="mx-auto mb-4 opacity-50" />
                    <p className="text-lg">No transactions found</p>
                    <p className="text-sm">Your transaction history will appear here</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {transactions.map((transaction) => (
                      <div key={transaction.id} className="flex items-center justify-between p-4 bg-winnex-dark rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className={`w-2 h-2 rounded-full ${
                            transaction.amount.startsWith('-') ? 'bg-red-500' : 'bg-green-500'
                          }`}></div>
                          <div>
                            <div className="font-semibold">{transaction.type.toUpperCase()}</div>
                            <div className="text-sm text-gray-400">{transaction.description}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`font-bold ${
                            transaction.amount.startsWith('-') ? 'text-red-500' : 'text-green-500'
                          }`}>
                            ${transaction.amount}
                          </div>
                          <div className="text-xs text-gray-400">
                            {formatDate(transaction.createdAt)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-winnex-gray border-gray-600">
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Personal Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">First Name</label>
                      <Input
                        value={user?.firstName || ""}
                        readOnly
                        className="bg-winnex-dark border-gray-600"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Last Name</label>
                      <Input
                        value={user?.lastName || ""}
                        readOnly
                        className="bg-winnex-dark border-gray-600"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-2">Email</label>
                      <Input
                        value={user?.email || ""}
                        readOnly
                        className="bg-winnex-dark border-gray-600"
                      />
                    </div>
                  </div>
                </div>

                <Separator className="bg-gray-600" />

                <div>
                  <h3 className="text-lg font-semibold mb-4">Betting Limits</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-winnex-dark rounded-lg">
                      <div>
                        <div className="font-semibold">Daily Bet Limit</div>
                        <div className="text-sm text-gray-400">Maximum amount you can bet per day</div>
                      </div>
                      <div className="text-winnex-green font-bold">$1,000</div>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-winnex-dark rounded-lg">
                      <div>
                        <div className="font-semibold">Single Bet Limit</div>
                        <div className="text-sm text-gray-400">Maximum amount per single bet</div>
                      </div>
                      <div className="text-winnex-green font-bold">$500</div>
                    </div>
                  </div>
                </div>

                <Separator className="bg-gray-600" />

                <div>
                  <h3 className="text-lg font-semibold mb-4">Account Actions</h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full border-gray-600">
                      Request Account Verification
                    </Button>
                    <Button variant="outline" className="w-full border-gray-600">
                      Download Account Statement
                    </Button>
                    <Button variant="outline" className="w-full border-red-500 text-red-500">
                      Request Account Closure
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
