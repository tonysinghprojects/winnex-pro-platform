import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { wsManager } from "@/lib/websocket";

import Home from "@/pages/Home";
import Sports from "@/pages/Sports";
import LiveBetting from "@/pages/LiveBetting";
import Casino from "@/pages/Casino";
import Esports from "@/pages/Esports";
import Promotions from "@/pages/Promotions";
import Deposit from "@/pages/Deposit";
import Admin from "@/pages/Admin";
import Profile from "@/pages/Profile";
import LogoShowcase from "@/pages/LogoShowcase";
import Analytics from "@/pages/Analytics";
import VIP from "@/pages/VIP";
import Security from "@/pages/Security";
import Payments from "@/pages/Payments";
import Social from "@/pages/Social";
import LiveStreaming from "@/pages/LiveStreaming";
import AIAssistant from "@/pages/AIAssistant";
import SocialBetting from "@/pages/SocialBetting";
import ResponsibleGambling from "@/pages/ResponsibleGambling";
import FantasySports from "@/pages/FantasySports";
import AffiliateProgram from "@/pages/AffiliateProgram";
import ComplianceCenter from "@/pages/ComplianceCenter";
import Dashboard from "@/pages/Dashboard";
import NotFound from "@/pages/not-found";
import TestRouting from "@/test-routing";
import LiveChatWidget from "@/components/LiveChatWidget";
import EnhancedAIAssistant from "@/components/EnhancedAIAssistant";
import ContactDirectory from "@/components/ContactDirectory";
import AdvancedAnalyticsDashboard from "@/components/AdvancedAnalyticsDashboard";
import SmartNotificationCenter from "@/components/SmartNotificationCenter";
import PredictiveAnalyticsEngine from "@/components/PredictiveAnalyticsEngine";
import SystemDiagnostics from "@/components/SystemDiagnostics";
import RealTimeErrorTracker from "@/components/RealTimeErrorTracker";
import SystemHealthDashboard from "@/components/SystemHealthDashboard";
import PerformanceOptimizer from "@/components/PerformanceOptimizer";

function Router() {
  // Always call all hooks at the top level
  const { isAuthenticated, isLoading } = useAuth();
  const [location, setLocation] = useLocation();
  
  // Navigation handler
  const navigate = (path: string) => {
    setLocation(path);
  };
  
  // Make navigate function globally available
  (window as any).navigateTo = navigate;

  useEffect(() => {
    if (isAuthenticated) {
      wsManager.connect();
    }
    
    return () => {
      wsManager.disconnect();
    };
  }, [isAuthenticated]);

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-winnex-dark">
        <div className="text-center">
          <div className="flex items-center justify-center mb-8">
            <div className="w-16 h-16 mr-4 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center animate-pulse">
              <span className="text-white font-black text-3xl">W</span>
            </div>
            <span className="text-4xl font-light text-white tracking-wide">
              WIN<span className="font-black text-green-400">NEX</span>
            </span>
          </div>
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-winnex-green mx-auto"></div>
          <p className="mt-4 text-gray-400">Loading platform...</p>
        </div>
      </div>
    );
  }

  // Not authenticated state
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-winnex-dark">
        <div className="text-center max-w-md mx-auto p-8">
          <div className="flex items-center justify-center mb-8">
            <div className="w-16 h-16 mr-4 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center">
              <span className="text-white font-black text-3xl">W</span>
            </div>
            <span className="text-5xl font-light text-white tracking-wide">
              WIN<span className="font-black text-green-400">NEX</span>
            </span>
          </div>
          <h1 className="text-3xl font-bold mb-4">Welcome to Winnex</h1>
          <p className="text-gray-400 mb-8">The ultimate sports betting experience awaits you.</p>
          <button
            onClick={() => window.location.href = "/api/login"}
            className="bg-winnex-green text-black px-8 py-3 rounded-lg font-semibold text-lg hover:bg-green-400 transition-colors"
          >
            Sign In to Start Betting
          </button>
        </div>
      </div>
    );
  }
  
  // Main app routes
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/sports" component={Sports} />
      <Route path="/live" component={LiveBetting} />
      <Route path="/casino" component={Casino} />
      <Route path="/esports" component={Esports} />
      <Route path="/promotions" component={Promotions} />
      <Route path="/deposit" component={Deposit} />
      <Route path="/admin" component={Admin} />
      <Route path="/profile" component={Profile} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/vip" component={VIP} />
      <Route path="/security" component={Security} />
      <Route path="/payments" component={Payments} />
      <Route path="/social" component={Social} />
      <Route path="/streaming" component={LiveStreaming} />
      <Route path="/ai-assistant" component={AIAssistant} />
      <Route path="/social-betting" component={SocialBetting} />
      <Route path="/responsible-gambling" component={ResponsibleGambling} />
      <Route path="/fantasy-sports" component={FantasySports} />
      <Route path="/affiliate-program" component={AffiliateProgram} />
      <Route path="/compliance" component={ComplianceCenter} />
      <Route path="/logos" component={LogoShowcase} />
      <Route path="/integrated-dashboard" component={Dashboard} />
      <Route path="/test-routing" component={TestRouting} />
      <Route path="/system-diagnostics" component={SystemDiagnostics} />
      <Route path="/error-tracking" component={RealTimeErrorTracker} />
      <Route path="/system-health" component={SystemHealthDashboard} />
      <Route path="/performance-optimizer" component={PerformanceOptimizer} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="dark">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;