import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  uuid,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  balance: decimal("balance", { precision: 10, scale: 2 }).default("0.00"),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const sports = pgTable("sports", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  slug: varchar("slug", { length: 50 }).notNull().unique(),
  icon: varchar("icon", { length: 50 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  sportId: integer("sport_id").references(() => sports.id),
  team1: varchar("team1", { length: 100 }).notNull(),
  team2: varchar("team2", { length: 100 }).notNull(),
  league: varchar("league", { length: 100 }),
  startTime: timestamp("start_time").notNull(),
  status: varchar("status", { length: 20 }).default("scheduled"), // scheduled, live, finished, cancelled
  score1: integer("score1").default(0),
  score2: integer("score2").default(0),
  isLive: boolean("is_live").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const odds = pgTable("odds", {
  id: serial("id").primaryKey(),
  matchId: integer("match_id").references(() => matches.id),
  market: varchar("market", { length: 50 }).notNull(), // 1x2, over_under, handicap, etc.
  selection: varchar("selection", { length: 50 }).notNull(), // home, away, draw, over, under, etc.
  odds: decimal("odds", { precision: 5, scale: 2 }).notNull(),
  isActive: boolean("is_active").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const bets = pgTable("bets", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  matchId: integer("match_id").references(() => matches.id),
  market: varchar("market", { length: 50 }).notNull(),
  selection: varchar("selection", { length: 50 }).notNull(),
  odds: decimal("odds", { precision: 5, scale: 2 }).notNull(),
  stake: decimal("stake", { precision: 10, scale: 2 }).notNull(),
  potentialWin: decimal("potential_win", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { length: 20 }).default("pending"), // pending, won, lost, cancelled
  placedAt: timestamp("placed_at").defaultNow(),
  settledAt: timestamp("settled_at"),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  type: varchar("type", { length: 20 }).notNull(), // deposit, withdrawal, bet, win, bonus
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description"),
  status: varchar("status", { length: 20 }).default("completed"), // pending, completed, failed
  createdAt: timestamp("created_at").defaultNow(),
});

export const cryptoTransactions = pgTable("crypto_transactions", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  type: text("type").notNull(), // deposit, withdrawal, bet, win
  currency: text("currency").notNull(), // BTC, ETH, USDT, LTC
  amount: decimal("amount", { precision: 18, scale: 8 }).notNull(),
  usdValue: decimal("usd_value", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull(), // pending, confirmed, failed
  txHash: text("tx_hash"),
  address: text("address"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const cryptoBalances = pgTable("crypto_balances", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  currency: text("currency").notNull(),
  balance: decimal("balance", { precision: 18, scale: 8 }).notNull().default("0"),
  depositAddress: text("deposit_address").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  userCurrencyIdx: uniqueIndex("user_currency_idx").on(table.userId, table.currency),
}));

// Schemas for validation
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export const insertSportSchema = createInsertSchema(sports).omit({
  id: true,
  createdAt: true,
});
export type InsertSport = z.infer<typeof insertSportSchema>;

export const insertMatchSchema = createInsertSchema(matches).omit({
  id: true,
  createdAt: true,
});
export type InsertMatch = z.infer<typeof insertMatchSchema>;

export const insertOddsSchema = createInsertSchema(odds).omit({
  id: true,
  updatedAt: true,
});
export type InsertOdds = z.infer<typeof insertOddsSchema>;

export const insertBetSchema = createInsertSchema(bets).omit({
  id: true,
  placedAt: true,
  settledAt: true,
});
export type InsertBet = z.infer<typeof insertBetSchema>;

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export const insertCryptoTransactionSchema = createInsertSchema(cryptoTransactions);
export type InsertCryptoTransaction = z.infer<typeof insertCryptoTransactionSchema>;

export const insertCryptoBalanceSchema = createInsertSchema(cryptoBalances).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCryptoBalance = z.infer<typeof insertCryptoBalanceSchema>;

export type Sport = typeof sports.$inferSelect;
export type Match = typeof matches.$inferSelect;
export type Odds = typeof odds.$inferSelect;
export type Bet = typeof bets.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type CryptoTransaction = typeof cryptoTransactions.$inferSelect;
export type CryptoBalance = typeof cryptoBalances.$inferSelect;
